// Ek özellikler: sesli uyarı, fiş ayarları, yedekleme, web sitesi bağlantısı, lisans listesi (geliştirici),
// rapor detayları + Excel'e aktarma, gün sonu / kasa hesap ekstresi.

const SUPA_RPC = "https://dbpbssdrwolssrdaypzw.supabase.co/rest/v1/rpc/";
const SUPA_ANAHTAR = "sb_publishable_XHbSoSAa11HFP9AAEM3esQ_ziAMPbqX";
const tokenli = () => ({ Authorization: "Bearer " + (DB.token() || ""), "Content-Type": "application/json" });
const gorunum = d => kac("", d);

// ---------- Sesli uyarı (barkod okutulunca) ----------
let sesBaglami = null;
function bip(basarili) {
  if (DB.ayarOku("sesAcik", true) === false) return;
  try {
    sesBaglami = sesBaglami || new (window.AudioContext || window.webkitAudioContext)();
    const o = sesBaglami.createOscillator(), g = sesBaglami.createGain();
    o.type = "sine"; o.frequency.value = basarili ? 1000 : 240;
    g.gain.value = 0.06;
    o.connect(g); g.connect(sesBaglami.destination);
    o.start(); o.stop(sesBaglami.currentTime + (basarili ? 0.07 : 0.22));
  } catch (e) { /* ses çalınamazsa sessiz devam edilir */ }
}

// ---------- Fiş ayarları ----------
let fisGecici = null; // ayar penceresindeki önizleme, kaydedilmeden form değerlerini kullanır
function fisAyari() {
  const eskiOtomatik = DB.ayarOku("otomatikFis", true);
  return {...fisAyariKayitli(eskiOtomatik), ...(fisGecici || {})};
}
function fisAyariKayitli(eskiOtomatik) {
  return {
    genislik: DB.ayarOku("fisGenislik", "80"),
    firma: DB.ayarOku("fisFirma", ""),
    slogan: DB.ayarOku("fisSlogan", ""),
    ustMetin: DB.ayarOku("fisUstMetin", ""),
    altMetin: DB.ayarOku("fisAltMetin", ""),
    kasiyer: DB.ayarOku("fisKasiyer", "evet"),
    vergiDairesi: DB.ayarOku("fisVergiDairesi", ""),
    barkod: DB.ayarOku("fisBarkod", "evet"),
    adres: DB.ayarOku("fisAdres", ""),
    telefon: DB.ayarOku("fisTelefon", ""),
    vergi: DB.ayarOku("fisVergi", ""),
    altNot: DB.ayarOku("fisAltNot", "Bizi tercih ettiğiniz için teşekkürler"),
    mod: DB.ayarOku("fisModu", eskiOtomatik === false ? "hic" : "sor")
  };
}
function fisKagit() {
  const g = fisAyari().genislik;
  return g === "58" ? { px: 200, mm: 58, yazi: 11 } : { px: 280, mm: 80, yazi: 12 };
}
function fisUstBilgi() {
  const a = fisAyari();
  const vergi = [a.vergiDairesi, a.vergi ? "V.No: " + a.vergi : ""].filter(Boolean).join(" · ");
  return [a.adres, a.telefon ? "Tel: " + a.telefon : "", vergi].filter(Boolean).map(s => `<div class="kucuk">${gorunum(s)}</div>`).join("");
}
// Tüm fişlerin ortak şablonu: kutulu firma başlığı, sütunlu ürün listesi, kutulu toplam, fiş no barkodu
function fisSablon(v) {
  const k = fisKagit(), a = fisAyari();
  const { logo, ad } = markaBilgisi();
  const firma = (a.firma || "").trim() || ad;
  let barkodHtml = "";
  if (v.fisNo && a.barkod !== "hayir") { const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg"); try { if (window.JsBarcode) { JsBarcode(svg, String(v.fisNo), { format: "CODE128", width: 1.2, height: 34, displayValue: false, margin: 0 }); svg.setAttribute("style", "max-width:100%"); barkodHtml = `<div class="ortala" style="margin-top:6px">${svg.outerHTML}</div>`; } } catch (e) {} }
  const kalem = (v.kalemler || []).map(x => `<tr class="ad"><td colspan="2">${gorunum(x.ad)}</td></tr><tr class="alt"><td>${gorunum(x.adet)} x ${para(x.fiyat)}</td><td class="sag">${para(x.tutar)}</td></tr>`).join("");
  const ek = (v.toplamlar || []).map(([e, d]) => `<tr><td>${gorunum(e)}</td><td class="sag">${d}</td></tr>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>${gorunum(v.fisNo || "Fiş")}</title><style>
    @page { size: ${k.mm}mm auto; margin: 2mm; }
    * { box-sizing: border-box; }
    body { font-family: 'Courier New', monospace; font-size: ${k.yazi}px; width: ${k.px}px; margin: 0 auto; padding: 6px; color: #000; }
    table { width: 100%; border-collapse: collapse; } td { padding: 2px 0; vertical-align: top; }
    .ortala { text-align: center; } .sag { text-align: right; white-space: nowrap; padding-left: 6px; } .kucuk { font-size: ${k.yazi - 1}px; text-align: center; }
    .kutu { border: 2px solid #000; padding: 6px 4px; text-align: center; margin-bottom: 6px; }
    .kutu h1 { font-size: ${k.yazi + 5}px; margin: 2px 0 3px; letter-spacing: .5px; line-height: 1.15; }
    .slogan { font-size: ${k.yazi - 1}px; font-style: italic; margin-bottom: 3px; }
    .bilgi { border: 1px solid #000; padding: 3px 5px; margin-bottom: 6px; }
    .bilgi td { padding: 1px 0; }
    .liste { border: 1px solid #000; padding: 0 5px; margin-bottom: 6px; }
    .liste .bas td { font-weight: bold; border-bottom: 1px solid #000; padding: 3px 0; }
    .liste .ad td { font-weight: bold; padding-top: 5px; } .liste .alt td { padding-bottom: 3px; border-bottom: 1px dotted #777; }
    .toplam { border: 2px solid #000; padding: 4px 6px; margin-bottom: 6px; }
    .toplam .buyuk td { font-size: ${k.yazi + 5}px; font-weight: bold; padding-top: 3px; }
    .alt-not { border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 5px 0; text-align: center; margin-top: 4px; }
  </style></head><body>
    <div class="kutu">${logo ? `<img src="${logo}" alt="" style="max-height:50px;max-width:${k.px - 40}px;filter:grayscale(1)"><br>` : ""}<h1>${gorunum(firma.toLocaleUpperCase("tr"))}</h1>${a.slogan ? `<div class="slogan">${gorunum(a.slogan)}</div>` : ""}${fisUstBilgi()}${a.ustMetin ? `<div class="kucuk" style="margin-top:3px;white-space:pre-line">${gorunum(a.ustMetin)}</div>` : ""}</div>
    <div class="bilgi"><table>${(v.bilgi || []).filter(([e]) => !(e === "Kasiyer" && a.kasiyer === "hayir")).map(([e, d]) => `<tr><td>${gorunum(e)}</td><td class="sag">${gorunum(d)}</td></tr>`).join("")}</table></div>
    <div class="liste"><table><tr class="bas"><td>ÜRÜN</td><td class="sag">TUTAR</td></tr>${kalem}</table></div>
    <div class="toplam"><table>${ek}<tr class="buyuk"><td>TOPLAM</td><td class="sag">${para(v.toplam)}</td></tr></table></div>
    ${v.odeme ? `<div class="ortala" style="margin-bottom:4px">Ödeme: <b>${gorunum(v.odeme)}</b></div>` : ""}
    ${a.altNot || a.altMetin ? `<div class="alt-not">${a.altNot ? gorunum(a.altNot) : ""}${a.altMetin ? `<div style="white-space:pre-line;margin-top:3px">${gorunum(a.altMetin)}</div>` : ""}</div>` : ""}${barkodHtml}
    <div class="kucuk" style="margin-top:4px">Mali değeri yoktur</div>
  </body></html>`;
}
function fisSonrasi(satis) {
  const mod = fisAyari().mod;
  if (mod === "hep") fisYazdir(satis.id);
  else if (mod === "sor") fisSor(satis);
}
function fisAyarlariAc() {
  if (!aktifKullanici || aktifKullanici.rol !== "yonetici") return;
  const a = fisAyari();
  modalAc(`
    <div class="modal-baslik">Fiş düzenleme</div>
    <div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap"><div style="flex:1 1 360px;min-width:0">
    <form id="fa-form" class="form" style="margin-top:10px">
      <label>Kağıt genişliği<select name="genislik"><option value="80" ${a.genislik === "80" ? "selected" : ""}>80 mm</option><option value="58" ${a.genislik === "58" ? "selected" : ""}>58 mm</option></select></label>
      <label>Satıştan sonra<select name="mod"><option value="sor" ${a.mod === "sor" ? "selected" : ""}>Fiş yazdırılsın mı diye sor</option><option value="hep" ${a.mod === "hep" ? "selected" : ""}>Otomatik yazdır</option><option value="hic" ${a.mod === "hic" ? "selected" : ""}>Hiç sorma</option></select></label>
      <label class="tam">Firma adı (fişte büyük yazılır)<input name="firma" value="${gorunum(a.firma)}" maxlength="50" placeholder="Boşsa işletme adı kullanılır"></label>
      <label class="tam">Alt başlık / slogan<input name="slogan" value="${gorunum(a.slogan)}" maxlength="50" placeholder="Örn. Hırdavat · Yem · Nalbur"></label>
      <label class="tam">Adres<input name="adres" value="${gorunum(a.adres)}" maxlength="80" placeholder="Fişte işletme adının altında görünür"></label>
      <label>Telefon<input name="telefon" value="${gorunum(a.telefon)}" maxlength="30"></label>
      <label>Vergi no<input name="vergi" value="${gorunum(a.vergi)}" maxlength="30"></label>
      <label>Vergi dairesi<input name="vergiDairesi" value="${gorunum(a.vergiDairesi)}" maxlength="30"></label>
      <label>Fiş no barkodu<select name="barkod"><option value="evet" ${a.barkod !== "hayir" ? "selected" : ""}>Fişin altında göster</option><option value="hayir" ${a.barkod === "hayir" ? "selected" : ""}>Gösterme</option></select></label>
      <label class="tam">Fiş altı notu<input name="altNot" value="${gorunum(a.altNot)}" maxlength="80"></label>
      <label class="tam">Üst serbest yazı (başlık kutusunun içine)<textarea name="ustMetin" rows="2" maxlength="200" placeholder="İstediğin satırları yaz (Örn. Kampanya, çalışma saatleri)">${gorunum(a.ustMetin)}</textarea></label>
      <label class="tam">Alt serbest yazı (altına eklenir)<textarea name="altMetin" rows="3" maxlength="300" placeholder="İstediğin satırları yaz (Örn. Değişim için fiş gerekir)">${gorunum(a.altMetin)}</textarea></label>
      <label>Kasiyer adı<select name="kasiyer"><option value="evet" ${a.kasiyer !== "hayir" ? "selected" : ""}>Fişte göster</option><option value="hayir" ${a.kasiyer === "hayir" ? "selected" : ""}>Gösterme</option></select></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="fa-deneme">Deneme fişi yazdır</button><button type="button" class="btn" id="fa-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form></div><div style="flex:0 0 auto"><div style="font-size:12px;opacity:.7;margin-bottom:4px">Önizleme</div><iframe id="fa-onizle" style="width:${fisKagit().px + 40}px;height:520px;border:1px solid var(--line);background:#fff;border-radius:6px"></iframe></div></div>`, true);
  const oku = () => Object.fromEntries(new FormData($("fa-form")).entries());
  const kaydet = () => { const f = oku(); DB.ayarYaz("fisGenislik", f.genislik); DB.ayarYaz("fisModu", f.mod); DB.ayarYaz("fisAdres", f.adres.trim()); DB.ayarYaz("fisFirma", f.firma.trim()); DB.ayarYaz("fisSlogan", f.slogan.trim()); DB.ayarYaz("fisVergiDairesi", f.vergiDairesi.trim()); DB.ayarYaz("fisBarkod", f.barkod); DB.ayarYaz("fisUstMetin", f.ustMetin.trim()); DB.ayarYaz("fisAltMetin", f.altMetin.trim()); DB.ayarYaz("fisKasiyer", f.kasiyer); DB.ayarYaz("fisTelefon", f.telefon.trim()); DB.ayarYaz("fisVergi", f.vergi.trim()); DB.ayarYaz("fisAltNot", f.altNot.trim()); };
  const onizle = () => { fisGecici = oku(); try { $("fa-onizle").srcdoc = denemeFisiHtml(); } finally { fisGecici = null; } };
  $("fa-form").addEventListener("input", () => { clearTimeout(onizle.t); onizle.t = setTimeout(onizle, 400); });
  $("fa-form").addEventListener("change", onizle);
  onizle();
  $("fa-vazgec").addEventListener("click", modalKapat);
  $("fa-form").addEventListener("submit", e => { e.preventDefault(); kaydet(); modalKapat(); bildir("Fiş ayarları kaydedildi"); });
  $("fa-deneme").addEventListener("click", () => { kaydet(); denemeFisiYazdir(); });
}
function denemeFisiHtml() {
  return (fisSablon({ fisNo: "DENEME-0001", bilgi: [["Kasa 1", tarih(new Date().toISOString())], ["Fiş no", "DENEME-0001"], ["Kasiyer", "Deneme"]],
    kalemler: [{ ad: "Örnek ürün", adet: "2", fiyat: 12.5, tutar: 25 }, { ad: "Başka örnek ürün", adet: "1", fiyat: 80, tutar: 80 }], toplamlar: [["Ara toplam", para(105)]], toplam: 105, odeme: "Nakit" }));
}
function denemeFisiYazdir() { sayfaIcindeYazdir(denemeFisiHtml(), "fis"); }

// ---------- Yedekleme ----------
async function yedekApi(yol, secenek) {
  const y = await fetch(yol, { ...secenek, headers: { ...tokenli(), ...((secenek && secenek.headers) || {}) } });
  return y.json();
}
const boyutYaz = b => b > 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB";
async function yedekBolumuYukle() {
  const kutu = $("yedek-bolum");
  if (!kutu) return;
  kutu.innerHTML = '<span style="opacity:.7">Yedekler yükleniyor...</span>';
  let r;
  try { r = await yedekApi("/api/yedekler"); } catch (e) { r = { ok: false, hata: "Sunucuya ulaşılamadı" }; }
  if (!kutu.isConnected) return;
  if (!r.ok) { kutu.innerHTML = `<span class="hata">${gorunum(r.hata)}</span>`; return; }
  kutu.innerHTML = `
    <div class="filtre" style="margin-bottom:8px"><button class="btn ana" id="yedek-simdi">Şimdi yedek al</button>
      <span style="font-size:12px;opacity:.75">Program her gün otomatik yedek alır (son 30 gün). Güncellemeden önce de yedek alınır.</span></div>
    <table class="tablo"><tr><th>Yedek</th><th>Tarih</th><th class="sag">Boyut</th><th></th></tr>
    ${r.liste.slice(0, 12).map(y => `<tr><td>${gorunum(y.ad)}</td><td>${tarih(new Date(y.tarih).toISOString())}</td><td class="sag">${boyutYaz(y.boyut)}</td>
      <td><button class="btn kucuk" data-yedek-indir="${gorunum(y.ad)}">İndir</button> <button class="btn kucuk tehlike" data-yedek-geri="${gorunum(y.ad)}">Geri yükle</button></td></tr>`).join("") || '<tr><td colspan="4">Henüz yedek yok</td></tr>'}</table>`;
  $("yedek-simdi").addEventListener("click", async () => {
    const s = await yedekApi("/api/yedek-al", { method: "POST" });
    bildir(s.ok ? "Yedek alındı: " + s.ad : "Yedek alınamadı: " + s.hata);
    if (s.ok) yedekBolumuYukle();
  });
  kutu.querySelectorAll("[data-yedek-indir]").forEach(b => b.addEventListener("click", async () => {
    try {
      const y = await fetch("/api/yedek-indir?dosya=" + encodeURIComponent(b.dataset.yedekIndir), { headers: tokenli() });
      if (!y.ok) throw new Error("indirilemedi");
      const a = document.createElement("a");
      a.href = URL.createObjectURL(await y.blob()); a.download = b.dataset.yedekIndir; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    } catch (e) { bildir("Yedek indirilemedi"); }
  }));
  kutu.querySelectorAll("[data-yedek-geri]").forEach(b => b.addEventListener("click", () => yedekGeriYukle(b.dataset.yedekGeri)));
}
async function yedekGeriYukle(ad) {
  const onay = prompt("YEDEĞİ GERİ YÜKLE: " + ad + ". Şu anki tüm veriler (ürünler, satışlar, kullanıcılar) bu yedekteki hâliyle değiştirilir. Önce şu anki verinin yedeği alınır. Onaylamak için GERI YUKLE yazın:");
  if (onay === null) return;
  if (onay !== "GERI YUKLE") return bildir("Onay metni yanlış, geri yüklenmedi");
  const s = await yedekApi("/api/yedek-geri-yukle", { method: "POST", body: JSON.stringify({ dosya: ad, onay }) });
  if (!s.ok) return bildir("Geri yüklenemedi: " + s.hata);
  DB.sifirla();
  try { localStorage.removeItem("kasaSatisSekmeleri"); sessionStorage.clear(); } catch (e) { /* önemli değil */ }
  alert("Yedek geri yüklendi. Uygulama yeniden açılacak, tekrar giriş yapın.");
  location.reload();
}

// ---------- Web sitesi bağlantısı ----------
async function webBolumuYukle() {
  const kutu = $("web-bolum");
  if (!kutu) return;
  let r;
  try { r = await yedekApi("/api/web-durum"); } catch (e) { r = { ok: false, hata: "Sunucuya ulaşılamadı" }; }
  if (!kutu.isConnected) return;
  if (!r.ok) { kutu.innerHTML = `<span class="hata">${gorunum(r.hata)}</span>`; return; }
  const acik = !!DB.ayarOku("webSenkron", false);
  const son = r.son;
  kutu.innerHTML = `
    <label class="web-anahtar"><input type="checkbox" id="web-ac" ${acik ? "checked" : ""}> Ürünlerimi web sitesine gönder (ad, kategori, fiyat, stok)</label>
    <div class="web-durum" id="web-durum">${!r.anahtar ? "Önce Ayarlar → Lisans'tan lisans anahtarınızı girin." : son ? (son.ok ? `Son gönderim: ${tarih(new Date(son.zaman).toISOString())} · ${son.adet} ürün` : `Son gönderim başarısız: ${gorunum(son.hata)}`) : (acik ? "İlk gönderim birkaç dakika içinde yapılır." : "Kapalı")}</div>
    <div class="filtre"><button class="btn ana" id="web-simdi" ${r.anahtar ? "" : "disabled"}>Web sitesine gönder…</button><button class="btn" id="web-kod" ${r.anahtar ? "" : "disabled"}>Web siteme ekleme kodunu göster</button></div>
    <small style="opacity:.7">${Array.isArray(DB.ayarOku("webSecim", null)) ? "Şu an yalnızca seçtiğiniz " + DB.ayarOku("webSecim", []).length + " ürün gönderiliyor. " : "Tüm ürünler gönderiliyor. "}Müşteri bilgisi, satış ve şifre gönderilmez. Stok değişince en geç 5 dakika içinde web sitesine yansır.</small>`;
  $("web-ac").addEventListener("change", e => { DB.ayarYaz("webSenkron", e.target.checked); bildir(e.target.checked ? "Web sitesine gönderme açıldı" : "Web sitesine gönderme kapatıldı"); if (e.target.checked) setTimeout(() => $("web-simdi") && $("web-simdi").click(), 1200); });
  $("web-simdi").addEventListener("click", webUrunSecimiAc);
  $("web-kod").addEventListener("click", () => webKoduGoster(r.anahtar));
}
// Web sitesine gönder: ürünleri seçip gönderme penceresi
function webUrunSecimiAc() {
  const urunler = DB.liste("urunler", u => u.aktif && u.barkod).sort((a, b) => String(a.ad).localeCompare(String(b.ad), "tr"));
  const kategoriler = DB.liste("kategoriler");
  const kayitli = DB.ayarOku("webSecim", null);
  const secili = new Set(Array.isArray(kayitli) ? kayitli : urunler.map(u => u.id));
  let ara = "", kat = "";
  const suz = () => { const q = ara.trim().toLocaleLowerCase("tr"); return urunler.filter(u => (!kat || String(u.kategori_id) === kat) && (!q || String(u.ad).toLocaleLowerCase("tr").includes(q) || String(u.barkod).includes(q))); };
  modalAc(`
    <div class="modal-baslik">Web sitesine gönder · ürünleri seçin</div>
    <div class="filtre" style="margin:8px 0">
      <input id="ws-ara" type="search" placeholder="Ürün veya barkod ara" autocomplete="off" style="flex:1;min-width:180px">
      <select id="ws-kat"><option value="">Tüm kategoriler</option>${kategoriler.map(k => `<option value="${k.id}">${gorunum(k.ad)}</option>`).join("")}</select>
    </div>
    <div class="filtre" style="margin-bottom:6px">
      <label class="onay-kutusu"><input type="checkbox" id="ws-hepsi"> Görünen ürünlerin tümünü seç</label>
      <span id="ws-sayi" style="margin-left:auto;font-weight:600"></span>
    </div>
    <div id="ws-liste" style="max-height:46vh;overflow:auto;border:1px solid var(--line);border-radius:10px"></div>
    <p id="ws-bilgi" style="font-size:12px;opacity:.7;margin:6px 0"></p>
    <div class="modal-alt"><button class="btn" id="ws-kapat">Vazgeç</button><button class="btn" id="ws-tumu">Tüm ürünleri gönder</button><button class="btn ana" id="ws-gonder">Seçilenleri gönder</button></div>`, true);
  const ciz = () => {
    const l = suz(), gorunen = l.slice(0, 300);
    $("ws-liste").innerHTML = '<table class="tablo">' + gorunen.map(u => `<tr><td style="width:34px"><input type="checkbox" data-ws="${u.id}" ${secili.has(u.id) ? "checked" : ""}></td><td>${gorunum(u.ad)}</td><td style="opacity:.6">${gorunum(u.barkod)}</td><td class="sag">${para(u.satis_fiyati)}</td><td class="sag" style="opacity:.7">Stok ${sayi(u.stok)}</td></tr>`).join("") + "</table>" || "";
    $("ws-bilgi").textContent = l.length > 300 ? `${l.length} üründen ilk 300'ü listeleniyor; aramayı daraltın. "Tümünü seç" süzülmüş ${l.length} ürünün hepsini kapsar.` : (l.length ? "" : "Ürün bulunamadı");
    $("ws-hepsi").checked = l.length > 0 && l.every(u => secili.has(u.id));
    $("ws-sayi").textContent = secili.size + " / " + urunler.length + " ürün seçili";
    $("ws-gonder").disabled = !secili.size;
  };
  $("ws-ara").addEventListener("input", e => { ara = e.target.value; ciz(); });
  $("ws-kat").addEventListener("change", e => { kat = e.target.value; ciz(); });
  $("ws-hepsi").addEventListener("change", e => { suz().forEach(u => e.target.checked ? secili.add(u.id) : secili.delete(u.id)); ciz(); });
  $("ws-liste").addEventListener("change", e => { const c = e.target.closest("[data-ws]"); if (!c) return; const id = Number(c.dataset.ws); c.checked ? secili.add(id) : secili.delete(id); $("ws-sayi").textContent = secili.size + " / " + urunler.length + " ürün seçili"; $("ws-gonder").disabled = !secili.size; const l = suz(); $("ws-hepsi").checked = l.length > 0 && l.every(u => secili.has(u.id)); });
  const gonder = async tumu => {
    if (!tumu && !secili.size) return;
    DB.ayarYaz("webSecim", tumu || secili.size === urunler.length ? null : [...secili]);
    $("ws-gonder").disabled = true; $("ws-tumu").disabled = true; $("ws-bilgi").textContent = "Gönderiliyor...";
    const s = await yedekApi("/api/web-gonder", { method: "POST" });
    if (s.ok) { modalKapat(); bildir(s.adet + " ürün web sitesine gönderildi"); } else { $("ws-bilgi").textContent = "Gönderilemedi: " + s.hata; $("ws-gonder").disabled = false; $("ws-tumu").disabled = false; return; }
    webBolumuYukle();
  };
  $("ws-gonder").addEventListener("click", () => gonder(false));
  $("ws-tumu").addEventListener("click", () => gonder(true));
  $("ws-kapat").addEventListener("click", modalKapat);
  ciz();
  $("ws-ara").focus();
}
function webKoduGoster(anahtar) {
  const kod = `<div id="urunler"></div>
<script>
fetch("${SUPA_RPC}web_urunler", { method: "POST",
  headers: { apikey: "${SUPA_ANAHTAR}", "Content-Type": "application/json" },
  body: JSON.stringify({ p_anahtar: "${anahtar}" }) })
.then(r => r.json()).then(s => {
  document.getElementById("urunler").innerHTML = (s.urunler || []).map(u =>
    "<div><b>" + u.ad + "</b> — " + Number(u.fiyat).toFixed(2) + " TL" + (u.stok > 0 ? " (stokta)" : " (tükendi)") + "</div>").join("");
});
<\/script>`;
  modalAc(`<div class="modal-baslik">Web sitenize ekleme kodu</div>
    <p style="font-size:13px;margin:8px 0">Bu kodu web sitenizin HTML sayfasına yapıştırın. Ürünler (ad, fiyat, stok durumu) listelenir. Kendi tasarımınıza göre düzenleyebilirsiniz; veri <code>ad, kategori, fiyat, stok, barkod</code> alanlarıyla gelir.</p>
    <textarea id="web-kod-alan" readonly style="width:100%;height:210px;font:12px Consolas,monospace;padding:8px;border-radius:8px;border:1px solid var(--line)">${gorunum(kod)}</textarea>
    <div class="modal-alt"><button class="btn" id="wk-kapat">Kapat</button><button class="btn ana" id="wk-kopya">Kodu kopyala</button></div>`, true);
  $("wk-kapat").addEventListener("click", modalKapat);
  $("wk-kopya").addEventListener("click", async () => { try { await navigator.clipboard.writeText(kod); bildir("Kod kopyalandı"); } catch (e) { $("web-kod-alan").select(); } });
}

// ---------- Lisans listesi (yalnızca geliştirici paneli) ----------
const goreli = t => {
  if (!t) return "hiç bağlanmadı";
  const dk = Math.round((Date.now() - new Date(t)) / 60000);
  return dk < 2 ? "şimdi" : dk < 90 ? dk + " dk önce" : dk < 2880 ? Math.round(dk / 60) + " sa önce" : Math.round(dk / 1440) + " gün önce";
};
function lisansListesiEkle(kutu) {
  const k = document.createElement("div");
  k.id = "gel-liste-kutu";
  k.innerHTML = `<div class="baslik-satir" style="margin-top:22px"><h2>Lisans listesi</h2><button class="btn" id="gl-yenile">Listeyi yenile</button></div><div id="gl-alan" class="gel-kart"><small style="opacity:.7">Listeyi görmek için yukarıdaki üretici parolasını yazıp "Listeyi yenile"ye basın.</small></div>`;
  kutu.appendChild(k);
  const rpc = async (ad, govde) => (await fetch(SUPA_RPC + ad, { method: "POST", headers: { apikey: SUPA_ANAHTAR, "Content-Type": "application/json" }, body: JSON.stringify(govde) })).json();
  const yukle = async () => {
    const parola = $("gel-parola").value;
    if (!parola) return ($("gl-alan").innerHTML = '<span class="hata">Önce üretici parolasını yazın</span>');
    $("gl-alan").textContent = "Yükleniyor...";
    let r; try { r = await rpc("lisans_listele", { p_parola: parola }); } catch (e) { r = { ok: false, hata: "Ulaşılamadı" }; }
    if (!r.ok) return ($("gl-alan").innerHTML = `<span class="hata">${gorunum(r.hata || r.message)}</span>`);
    const bugun = new Date().toISOString().slice(0, 10);
    $("gl-alan").innerHTML = `<div style="overflow:auto"><table class="tablo"><tr><th>İşletme</th><th>Anahtar</th><th>Bitiş</th><th>Durum</th><th>Son bağlantı</th><th>Bilgisayar</th><th>Sürüm</th><th></th></tr>
      ${r.liste.map(l => { const bitti = l.bitis < bugun; return `<tr><td>${gorunum(l.isletme)}${l.gelistirici ? " <small>(geliştirici)</small>" : ""}</td><td><b style="font-family:Consolas,monospace">${gorunum(l.anahtar)}</b></td>
        <td>${gorunum(l.bitis)}</td><td>${!l.aktif ? '<span class="rozet uyari">Kapalı</span>' : bitti ? '<span class="rozet uyari">Süresi doldu</span>' : '<span class="rozet">Aktif</span>'}</td>
        <td>${goreli(l.son_gorulme)}</td><td>${gorunum(l.bilgisayar || "—")}</td><td>${gorunum(l.surum || "—")}</td>
        <td style="white-space:nowrap"><button class="btn kucuk" data-gl="${gorunum(l.anahtar)}" data-ekle="30">+30 gün</button> <button class="btn kucuk" data-gl="${gorunum(l.anahtar)}" data-ekle="365">+1 yıl</button>
        <button class="btn kucuk ${l.aktif ? "tehlike" : ""}" data-gl="${gorunum(l.anahtar)}" data-aktif="${l.aktif ? "0" : "1"}">${l.aktif ? "Kapat" : "Aç"}</button></td></tr>`; }).join("")}</table></div>`;
    $("gl-alan").querySelectorAll("[data-gl]").forEach(b => b.addEventListener("click", async () => {
      const govde = { p_parola: parola, p_anahtar: b.dataset.gl };
      if (b.dataset.ekle) govde.p_ekle_gun = Number(b.dataset.ekle); else govde.p_aktif = b.dataset.aktif === "1";
      const s = await rpc("lisans_guncelle", govde);
      bildir(s.ok ? "Güncellendi" : "Hata: " + (s.hata || s.message));
      if (s.ok) yukle();
    }));
  };
  $("gl-yenile").addEventListener("click", yukle);
}

// ---------- Excel (.xlsx) dosyası oluşturma ----------
const CRC_TABLOSU = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_TABLOSU[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function zipOlustur(dosyalar) {
  const enc = new TextEncoder(), parcalar = [], merkez = [];
  let konum = 0;
  const d = new Date();
  const dosZaman = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const dosTarih = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  for (const [ad, icerik] of dosyalar) {
    const adB = enc.encode(ad), veri = typeof icerik === "string" ? enc.encode(icerik) : icerik, crc = crc32(veri);
    const yerel = new DataView(new ArrayBuffer(30));
    yerel.setUint32(0, 0x04034b50, true); yerel.setUint16(4, 20, true); yerel.setUint16(6, 0x0800, true); yerel.setUint16(8, 0, true);
    yerel.setUint16(10, dosZaman, true); yerel.setUint16(12, dosTarih, true); yerel.setUint32(14, crc, true);
    yerel.setUint32(18, veri.length, true); yerel.setUint32(22, veri.length, true); yerel.setUint16(26, adB.length, true); yerel.setUint16(28, 0, true);
    const m = new DataView(new ArrayBuffer(46));
    m.setUint32(0, 0x02014b50, true); m.setUint16(4, 20, true); m.setUint16(6, 20, true); m.setUint16(8, 0x0800, true); m.setUint16(10, 0, true);
    m.setUint16(12, dosZaman, true); m.setUint16(14, dosTarih, true); m.setUint32(16, crc, true); m.setUint32(20, veri.length, true); m.setUint32(24, veri.length, true);
    m.setUint16(28, adB.length, true); m.setUint32(42, konum, true);
    parcalar.push(new Uint8Array(yerel.buffer), adB, veri);
    merkez.push(new Uint8Array(m.buffer), adB);
    konum += 30 + adB.length + veri.length;
  }
  const merkezBoyut = merkez.reduce((t, p) => t + p.length, 0);
  const son = new DataView(new ArrayBuffer(22));
  son.setUint32(0, 0x06054b50, true); son.setUint16(8, dosyalar.length, true); son.setUint16(10, dosyalar.length, true);
  son.setUint32(12, merkezBoyut, true); son.setUint32(16, konum, true);
  return new Blob([...parcalar, ...merkez, new Uint8Array(son.buffer)], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}
const xmlKac = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
const sutunHarfi = i => { let s = ""; for (i++; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + ((i - 1) % 26)) + s; return s; };
// sayfalar: [{ ad: "Sayfa", satirlar: [[başlıklar], [değerler...]] }]; sayılar sayı olarak, metinler metin olarak yazılır
function xlsxIndir(dosyaAdi, sayfalar) {
  const sayfaXml = sf => {
    const genislik = sf.satirlar[0] ? sf.satirlar[0].map((_, i) => `<col min="${i + 1}" max="${i + 1}" width="${Math.min(40, Math.max(12, ...sf.satirlar.slice(0, 200).map(s => String(s[i] === undefined ? "" : s[i]).length + 2)))}" customWidth="1"/>`).join("") : "";
    const satirlar = sf.satirlar.map((s, r) => `<row r="${r + 1}">${s.map((h, c) => {
      const ref = sutunHarfi(c) + (r + 1);
      if (typeof h === "number" && Number.isFinite(h)) return `<c r="${ref}"><v>${h}</v></c>`;
      return h === "" || h === null || h === undefined ? "" : `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlKac(h)}</t></is></c>`;
    }).join("")}</row>`).join("");
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${genislik}</cols><sheetData>${satirlar}</sheetData></worksheet>`;
  };
  const adlar = sayfalar.map((s, i) => xmlKac(String(s.ad || "Sayfa" + (i + 1)).replace(/[\[\]:*?\/\\]/g, " ").slice(0, 31)));
  const dosyalar = [
    ["[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sayfalar.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`],
    ["_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
    ["xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${adlar.map((a, i) => `<sheet name="${a}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>`],
    ["xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sayfalar.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}</Relationships>`],
    ...sayfalar.map((s, i) => [`xl/worksheets/sheet${i + 1}.xml`, sayfaXml(s)])
  ];
  const blob = zipOlustur(dosyalar);
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = dosyaAdi; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
  return blob;
}

// ---------- Rapor detayları (ürün / kasiyer / ödeme / fişler) ----------
let raporDetaySekme = "urun";
function raporVerisi() {
  const { bas, son } = raporAraligi();
  const icinde = s => { const g = kayitGunu(s.tarih); return g >= bas && g <= son && (!raporKasa || String(s.kasa_no) === raporKasa); };
  const satislar = DB.liste("satislar", icinde);
  const tamam = satislar.filter(s => s.durum === "tamamlandi");
  const idler = new Set(tamam.map(s => s.id));
  const kalemler = DB.liste("satis_kalemleri", k => idler.has(k.satis_id));
  const odemeler = DB.liste("odemeler", o => idler.has(o.satis_id));
  const kullaniciAdi = id => (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad || "—";
  const kategoriAdi = id => (DB.bul("kategoriler", x => x.id === id) || {}).ad || "—";
  const yuvarla = n => Math.round(n * 100) / 100;

  const urunMap = {};
  kalemler.forEach(k => {
    const u = DB.bul("urunler", x => x.id === k.urun_id) || {};
    const o = urunMap[k.urun_id] = urunMap[k.urun_id] || { barkod: u.barkod || "", ad: u.ad || "Silinmiş ürün", kategori: kategoriAdi(u.kategori_id), adet: 0, ciro: 0, maliyet: 0 };
    o.adet += k.miktar; o.ciro += k.tutar; o.maliyet += (u.alis_fiyati || 0) * k.miktar;
  });
  const urunler = Object.values(urunMap).sort((a, b) => b.ciro - a.ciro);

  // Kâr: aynı fişin kopyaları bir kez sayılır (kayıtlara dokunulmaz). Maliyet, ürünün bugünkü alış fiyatıdır
  const tekil = new Map(); tamam.forEach(s => { const k = s.fis_no + "|" + s.tarih + "|" + s.toplam; if (!tekil.has(k)) tekil.set(k, s.id); });
  const tekilId = new Set(tekil.values()), karMap = {}, karAlissiz = new Set();
  kalemler.filter(k => tekilId.has(k.satis_id)).forEach(k => {
    const u = DB.bul("urunler", x => x.id === k.urun_id) || {}, ad = kategoriAdi(u.kategori_id);
    const o = karMap[ad] = karMap[ad] || { ad, adet: 0, ciro: 0, maliyet: 0 };
    o.adet += k.miktar; o.ciro += k.tutar; o.maliyet += (u.alis_fiyati || 0) * k.miktar;
    if (!(u.alis_fiyati > 0)) karAlissiz.add(k.urun_id);
  });
  const karSatirlari = Object.values(karMap).sort((a, b) => (b.ciro - b.maliyet) - (a.ciro - a.maliyet));

  const kasMap = {};
  satislar.forEach(s => {
    const o = kasMap[s.kullanici_id] = kasMap[s.kullanici_id] || { ad: kullaniciAdi(s.kullanici_id), fis: 0, ciro: 0, iptal: 0, iptalTutar: 0 };
    if (s.durum === "tamamlandi") { o.fis++; o.ciro += s.toplam; } else { o.iptal++; o.iptalTutar += s.toplam; }
  });
  const kasiyerler = Object.values(kasMap).sort((a, b) => b.ciro - a.ciro);

  const odeme = { nakit: { adet: 0, tutar: 0 }, kart: { adet: 0, tutar: 0 }, acik_hesap: { adet: 0, tutar: 0 } };
  odemeler.forEach(o => { const x = odeme[o.yontem]; if (x) { x.adet++; x.tutar += o.tutar; } });
  const yontemAdi = { nakit: "Nakit", kart: "Kart", acik_hesap: "Açık hesap (veresiye)" };
  const odemeSatirlari = Object.keys(odeme).map(y => ({ ad: yontemAdi[y], adet: odeme[y].adet, tutar: odeme[y].tutar }));

  const fisler = satislar.slice().sort((a, b) => String(b.tarih).localeCompare(String(a.tarih))).map(s => {
    const od = DB.bul("odemeler", o => o.satis_id === s.id);
    return { fis: s.fis_no, tarih: tarih(s.tarih), kasiyer: kullaniciAdi(s.kullanici_id), odeme: od ? yontemAdi[od.yontem] : "", tutar: s.toplam, durum: s.durum === "iptal" ? "İptal" : "Tamam" };
  });
  return { bas, son, urunler, karSatirlari, karAlissiz: karAlissiz.size, kopyaFis: tamam.length - tekilId.size, kasiyerler, odemeSatirlari, fisler, yuvarla, ciro: tamam.reduce((t, s) => t + s.toplam, 0) };
}
function raporTabloSatirlari(v, sekme) {
  const y = v.yuvarla;
  if (sekme === "urun") return { baslik: ["Barkod", "Ürün", "Kategori", "Satılan adet", "Ciro (TL)", "Maliyet (TL)", "Kâr (TL)"], satirlar: v.urunler.map(u => [u.barkod, u.ad, u.kategori, u.adet, y(u.ciro), y(u.maliyet), y(u.ciro - u.maliyet)]), ad: "Ürün satışları" };
  if (sekme === "kar") {
    const top = k => v.karSatirlari.reduce((t, x) => t + x[k], 0), marj = (c, m) => c > 0 ? y((c - m) / c * 100) : 0;
    const satirlar = v.karSatirlari.map(k => [k.ad, k.adet, y(k.ciro), y(k.maliyet), y(k.ciro - k.maliyet), marj(k.ciro, k.maliyet)]);
    if (satirlar.length) satirlar.push(["TOPLAM", top("adet"), y(top("ciro")), y(top("maliyet")), y(top("ciro") - top("maliyet")), marj(top("ciro"), top("maliyet"))]);
    return { baslik: ["Kategori", "Satılan adet", "Ciro (TL)", "Maliyet (TL)", "Kâr (TL)", "Kâr oranı (%)"], satirlar, ad: "Kâr raporu" };
  }
  if (sekme === "kasiyer") return { baslik: ["Kasiyer", "Fiş adedi", "Ciro (TL)", "İptal fiş", "İptal tutarı (TL)"], satirlar: v.kasiyerler.map(k => [k.ad, k.fis, y(k.ciro), k.iptal, y(k.iptalTutar)]), ad: "Kasiyer satışları" };
  if (sekme === "odeme") return { baslik: ["Ödeme türü", "İşlem adedi", "Tutar (TL)"], satirlar: v.odemeSatirlari.map(o => [o.ad, o.adet, y(o.tutar)]), ad: "Ödeme türleri" };
  return { baslik: ["Fiş no", "Tarih", "Kasiyer", "Ödeme", "Tutar (TL)", "Durum"], satirlar: v.fisler.map(f => [f.fis, f.tarih, f.kasiyer, f.odeme, y(f.tutar), f.durum]), ad: "Fişler" };
}
function raporDetayHtml() {
  const v = raporVerisi(), t = raporTabloSatirlari(v, raporDetaySekme);
  const sekmeler = [["urun", "Ürün bazlı"], ["kar", "Kâr"], ["kasiyer", "Kasiyer bazlı"], ["odeme", "Ödeme türü"], ["fis", "Fişler"]];
  const bicim = h => typeof h === "number" ? (Number.isInteger(h) ? sayi(h) : h.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })) : gorunum(h);
  return `<div class="baslik-satir"><h2>Satış raporu · ${v.bas === v.son ? v.bas : v.bas + " – " + v.son}</h2><button class="btn" id="rapor-excel">Excel'e aktar</button></div>
    <div class="donemler" id="rapor-detay-sekme">${sekmeler.map(([k, ad]) => `<button class="donem ${raporDetaySekme === k ? "aktif" : ""}" data-rds="${k}">${ad}</button>`).join("")}</div>
    <div style="overflow:auto;max-height:420px;margin-bottom:18px"><table class="tablo"><tr>${t.baslik.map((b, i) => `<th class="${i >= t.baslik.length - (raporDetaySekme === "fis" ? 2 : t.baslik.length - 1) && typeof t.satirlar[0]?.[i] === "number" ? "sag" : ""}">${b}</th>`).join("")}</tr>
    ${t.satirlar.slice(0, 500).map(s => `<tr>${s.map((h, i) => `<td class="${typeof h === "number" ? "sag" : ""}">${bicim(h)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${t.baslik.length}">Bu dönemde kayıt yok</td></tr>`}</table></div>
    ${raporDetaySekme === "kar" ? `<p style="font-size:12px;opacity:.7">Maliyet, ürünlerin bugünkü alış fiyatıyla hesaplanır.${v.karAlissiz ? ` Alış fiyatı girilmemiş ${v.karAlissiz} ürün maliyetsiz sayıldı, kâr olduğundan yüksek görünür.` : ""}${v.kopyaFis ? ` ${v.kopyaFis} kopya fiş hesaba katılmadı.` : ""}</p>` : ""}
    ${t.satirlar.length > 500 ? `<p style="font-size:12px;opacity:.7">İlk 500 satır gösteriliyor, Excel dosyasında tamamı vardır.</p>` : ""}`;
}
function raporDetayBagla() {
  document.querySelectorAll("[data-rds]").forEach(b => b.addEventListener("click", () => { raporDetaySekme = b.dataset.rds; raporCiz(); }));
  if ($("rapor-excel")) $("rapor-excel").addEventListener("click", () => {
    const v = raporVerisi();
    const sayfalar = ["urun", "kar", "kasiyer", "odeme", "fis"].map(k => { const t = raporTabloSatirlari(v, k); return { ad: t.ad, satirlar: [t.baslik, ...t.satirlar] }; });
    xlsxIndir(`satis-raporu-${v.bas}${v.bas === v.son ? "" : "_" + v.son}.xlsx`, sayfalar);
    bildir("Excel dosyası indirildi");
  });
}

// ---------- Gün sonu / Kasa hesap ekstresi ----------
let gunSonuTarih = "";
function gunSonuVerisi(gun) {
  const yontemAdi = { nakit: "Nakit", kart: "Kart", acik_hesap: "Açık hesap" };
  const satislar = DB.liste("satislar", s => kayitGunu(s.tarih) === gun);
  const tamam = satislar.filter(s => s.durum === "tamamlandi");
  const idler = new Set(tamam.map(s => s.id));
  const odemeler = DB.liste("odemeler", o => idler.has(o.satis_id));
  const topla = y => odemeler.filter(o => o.yontem === y).reduce((t, o) => t + o.tutar, 0);
  const tahsilatlar = DB.liste("cari_hareketler", h => h.tur === "tahsilat" && h.islem !== "fis_iptali" && h.islem !== "kayit_iptal" && !h.iptal && kayitGunu(h.tarih) === gun);
  const tahsilat = y => tahsilatlar.filter(h => h.yontem === y).reduce((t, h) => t + h.tutar, 0);
  const iptaller = satislar.filter(s => s.durum === "iptal" && s.iptal_turu !== "sepet");
  const nakitOdemeler = DB.liste("cari_hareketler", h => (h.islem === "musteri_odeme" || h.islem === "tedarikci_odeme") && h.yontem === "nakit" && !h.iptal && kayitGunu(h.tarih) === gun);
  const hareketler = [
    ...tamam.map(s => { const od = DB.bul("odemeler", o => o.satis_id === s.id); return { zaman: s.tarih, tur: "Satış fişi", aciklama: s.fis_no, yontem: od ? yontemAdi[od.yontem] || "" : "", tutar: s.toplam, nakit: od && od.yontem === "nakit" ? s.toplam : 0 }; }),
    ...tahsilatlar.map(h => { const m = DB.bul("musteriler", x => x.id === h.musteri_id) || {}; return { zaman: h.tarih, tur: "Tahsilat", aciklama: m.ad_soyad || "Müşteri", yontem: { nakit: "Nakit", kart: "Kart", havale: "Havale" }[h.yontem] || "", tutar: h.tutar, nakit: h.yontem === "nakit" ? h.tutar : 0 }; }),
    ...nakitOdemeler.map(h => { const m = DB.bul("musteriler", x => x.id === h.musteri_id) || {}; return { zaman: h.tarih, tur: "Ödeme", aciklama: m.ad_soyad || "Cari", yontem: "Nakit", tutar: -h.tutar, nakit: -h.tutar }; })
  ].sort((a, b) => String(a.zaman).localeCompare(String(b.zaman)));
  const acilisKayit = DB.ayarOku("kasaAcilis", {})[gun];
  return { gun, nakitSatis: topla("nakit"), kartSatis: topla("kart"), acikHesap: topla("acik_hesap"), nakitTahsilat: tahsilat("nakit"), nakitOdeme: nakitOdemeler.reduce((t, h) => t + h.tutar, 0), kartTahsilat: tahsilat("kart"), havaleTahsilat: tahsilat("havale"), fisAdet: tamam.length, ciro: tamam.reduce((t, s) => t + s.toplam, 0), iptalAdet: iptaller.length, iptalTutar: iptaller.reduce((t, s) => t + s.toplam, 0), acilis: acilisKayit === undefined ? 0 : acilisKayit, hareketler };
}
function gunSonuHtml() {
  const bugun = yerelGun(new Date());
  if (!gunSonuTarih) gunSonuTarih = bugun;
  const v = gunSonuVerisi(gunSonuTarih);
  const kapanis = (DB.ayarOku("kasaKapanislari", []) || []).find(k => k.tarih === gunSonuTarih);
  const beklenen = v.acilis + v.nakitSatis + v.nakitTahsilat - v.nakitOdeme;
  const sayilan = kapanis ? kapanis.sayilan : "";
  return `<div class="baslik-satir"><h2>Gün sonu · Kasa hesap ekstresi</h2><input type="date" id="gs-tarih" value="${gunSonuTarih}" max="${bugun}"></div>
    <div class="gs-izgara">
      <div class="gs-kart"><small>Açılış nakdi (kasadaki para)</small><input id="gs-acilis" type="number" step="0.01" min="0" value="${v.acilis}"></div>
      <div class="gs-kart"><small>Nakit satış</small><strong>${para(v.nakitSatis)}</strong></div>
      <div class="gs-kart"><small>Nakit tahsilat (cari)</small><strong>${para(v.nakitTahsilat)}</strong></div>
      <div class="gs-kart"><small>Nakit ödeme (cari)</small><strong>${para(v.nakitOdeme)}</strong></div>
      <div class="gs-kart gs-vurgu"><small>Kasada olması gereken nakit</small><strong id="gs-beklenen">${para(beklenen)}</strong></div>
      <div class="gs-kart"><small>Sayılan nakit</small><input id="gs-sayilan" type="number" step="0.01" min="0" value="${sayilan}" placeholder="Kasayı sayıp yazın"></div>
      <div class="gs-kart"><small>Fark</small><strong id="gs-fark">—</strong></div>
      <div class="gs-kart"><small>Kart satış</small><strong>${para(v.kartSatis)}</strong></div>
      <div class="gs-kart"><small>Açık hesap (veresiye)</small><strong>${para(v.acikHesap)}</strong></div>
      <div class="gs-kart"><small>Kart / havale tahsilat</small><strong>${para(v.kartTahsilat + v.havaleTahsilat)}</strong></div>
      <div class="gs-kart"><small>Toplam ciro · ${v.fisAdet} fiş</small><strong>${para(v.ciro)}</strong></div>
      <div class="gs-kart"><small>İptal edilen fiş</small><strong>${v.iptalAdet} adet · ${para(v.iptalTutar)}</strong></div>
    </div>
    <div class="filtre" style="margin:10px 0 16px"><button class="btn ana" id="gs-kapat">${kapanis ? "Günü yeniden kaydet" : "Günü kapat ve kaydet"}</button><button class="btn" id="gs-yazdir">Yazdır</button><button class="btn" id="gs-excel">Excel'e aktar</button>${kapanis ? `<span class="rozet">Kapatıldı · ${tarih(new Date(kapanis.zaman).toISOString())}</span>` : ""}</div>
    <div style="overflow:auto;max-height:300px;margin-bottom:18px"><table class="tablo"><tr><th>Saat</th><th>İşlem</th><th>Açıklama</th><th>Ödeme</th><th class="sag">Tutar</th><th class="sag">Kasaya giren nakit</th></tr>
    ${v.hareketler.map(h => `<tr><td>${gorunum(tarih(h.zaman).slice(-5))}</td><td>${h.tur}</td><td>${gorunum(h.aciklama)}</td><td>${h.yontem}</td><td class="sag">${para(h.tutar)}</td><td class="sag">${h.nakit ? para(h.nakit) : "—"}</td></tr>`).join("") || '<tr><td colspan="6">Bu gün hareket yok</td></tr>'}</table></div>`;
}
function gunSonuFisHtml(v, sayilan) {
  const k = fisKagit(), beklenen = v.acilis + v.nakitSatis + v.nakitTahsilat - v.nakitOdeme;
  const satir = (a, b) => `<tr><td>${a}</td><td style="text-align:right">${b}</td></tr>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>Gün sonu</title><style>
    @page { size: ${k.mm}mm auto; margin: 2mm; } body { font-family: 'Courier New', monospace; font-size: ${k.yazi}px; width: ${k.px}px; margin: 0 auto; padding: 8px; }
    h1 { font-size: 14px; text-align: center; margin: 4px 0; } table { width: 100%; border-collapse: collapse; } td { padding: 2px 0; vertical-align: top; } .ortala { text-align: center; } .cizgi { border-top: 1px dashed #000; margin: 6px 0; } .kalin td { font-weight: bold; }
  </style></head><body>${fisBasligi()}<div class="ortala">GÜN SONU RAPORU</div><div class="ortala">${v.gun}</div><div class="cizgi"></div>
  <table>${satir("Açılış nakdi", para(v.acilis))}${satir("Nakit satış", para(v.nakitSatis))}${satir("Nakit tahsilat", para(v.nakitTahsilat))}${satir("Nakit ödeme", para(v.nakitOdeme))}<tr class="kalin"><td>Olması gereken</td><td style="text-align:right">${para(beklenen)}</td></tr>
  ${sayilan !== "" && sayilan !== null ? satir("Sayılan", para(sayilan)) + `<tr class="kalin"><td>Fark</td><td style="text-align:right">${para(sayilan - beklenen)}</td></tr>` : ""}</table><div class="cizgi"></div>
  <table>${satir("Kart satış", para(v.kartSatis))}${satir("Açık hesap", para(v.acikHesap))}${satir("Kart/havale tahsilat", para(v.kartTahsilat + v.havaleTahsilat))}${satir("Toplam ciro", para(v.ciro))}${satir("Fiş adedi", v.fisAdet)}${satir("İptal fiş", v.iptalAdet + " · " + para(v.iptalTutar))}</table>
  <div class="cizgi"></div><div class="ortala">Hazırlayan: ${gorunum(aktifKullanici ? aktifKullanici.ad_soyad : "")}</div></body></html>`;
}
function gunSonuBagla() {
  const hesapla = () => {
    const v = gunSonuVerisi(gunSonuTarih), acilis = Number($("gs-acilis").value) || 0;
    const beklenen = acilis + v.nakitSatis + v.nakitTahsilat - v.nakitOdeme, sayilan = $("gs-sayilan").value;
    $("gs-beklenen").textContent = para(beklenen);
    const fark = $("gs-fark");
    if (sayilan === "") { fark.textContent = "—"; fark.className = ""; return; }
    const f = Number(sayilan) - beklenen;
    fark.textContent = (f > 0.004 ? "+" : "") + para(f) + (Math.abs(f) < 0.005 ? " ✓" : f > 0 ? " (fazla)" : " (eksik)");
    fark.className = Math.abs(f) < 0.005 ? "gs-tamam" : "gs-sorun";
  };
  const acilisKaydet = () => { const a = { ...DB.ayarOku("kasaAcilis", {}) }; a[gunSonuTarih] = Number($("gs-acilis").value) || 0; DB.ayarYaz("kasaAcilis", a); };
  $("gs-tarih").addEventListener("change", e => { gunSonuTarih = e.target.value || yerelGun(new Date()); raporCiz(); });
  $("gs-acilis").addEventListener("change", () => { acilisKaydet(); raporCiz(); });
  $("gs-sayilan").addEventListener("input", hesapla);
  hesapla();
  $("gs-kapat").addEventListener("click", () => {
    acilisKaydet();
    const v = gunSonuVerisi(gunSonuTarih), sayilan = $("gs-sayilan").value === "" ? null : Number($("gs-sayilan").value);
    const beklenen = v.acilis + v.nakitSatis + v.nakitTahsilat - v.nakitOdeme;
    const kayit = { tarih: gunSonuTarih, acilis: v.acilis, nakitSatis: v.nakitSatis, nakitTahsilat: v.nakitTahsilat, kartSatis: v.kartSatis, acikHesap: v.acikHesap, ciro: v.ciro, beklenen, sayilan, fark: sayilan === null ? null : sayilan - beklenen, kullanici: aktifKullanici.ad_soyad, zaman: Date.now() };
    const liste = (DB.ayarOku("kasaKapanislari", []) || []).filter(k => k.tarih !== gunSonuTarih);
    liste.push(kayit); liste.sort((a, b) => a.tarih.localeCompare(b.tarih));
    DB.ayarYaz("kasaKapanislari", liste.slice(-400));
    bildir("Gün kapatıldı ve kaydedildi");
    raporCiz();
  });
  $("gs-yazdir").addEventListener("click", () => sayfaIcindeYazdir(gunSonuFisHtml(gunSonuVerisi(gunSonuTarih), $("gs-sayilan").value === "" ? "" : Number($("gs-sayilan").value)), "fis"));
  $("gs-excel").addEventListener("click", () => {
    const v = gunSonuVerisi(gunSonuTarih), beklenen = v.acilis + v.nakitSatis + v.nakitTahsilat - v.nakitOdeme;
    xlsxIndir(`gun-sonu-${gunSonuTarih}.xlsx`, [
      { ad: "Özet", satirlar: [["Kalem", "Tutar (TL)"], ["Açılış nakdi", v.acilis], ["Nakit satış", v.nakitSatis], ["Nakit tahsilat", v.nakitTahsilat], ["Nakit ödeme", v.nakitOdeme], ["Kasada olması gereken nakit", beklenen], ["Kart satış", v.kartSatis], ["Açık hesap", v.acikHesap], ["Kart/havale tahsilat", v.kartTahsilat + v.havaleTahsilat], ["Toplam ciro", v.ciro], ["Fiş adedi", v.fisAdet], ["İptal fiş adedi", v.iptalAdet], ["İptal tutarı", v.iptalTutar]] },
      { ad: "Hareketler", satirlar: [["Saat", "İşlem", "Açıklama", "Ödeme", "Tutar (TL)", "Kasaya giren nakit (TL)"], ...v.hareketler.map(h => [tarih(h.zaman), h.tur, h.aciklama, h.yontem, h.tutar, h.nakit])] }
    ]);
  });
}
function kapanisGecmisiHtml() {
  const liste = (DB.ayarOku("kasaKapanislari", []) || []).slice(-10).reverse();
  if (!liste.length) return "";
  return `<div class="baslik-satir"><h2>Son gün kapanışları</h2></div><div style="overflow:auto"><table class="tablo"><tr><th>Gün</th><th class="sag">Ciro</th><th class="sag">Olması gereken nakit</th><th class="sag">Sayılan</th><th class="sag">Fark</th><th>Kapatan</th></tr>
    ${liste.map(k => `<tr><td>${gorunum(k.tarih)}</td><td class="sag">${para(k.ciro)}</td><td class="sag">${para(k.beklenen)}</td><td class="sag">${k.sayilan === null ? "—" : para(k.sayilan)}</td><td class="sag ${k.fark === null ? "" : Math.abs(k.fark) < 0.005 ? "gs-tamam" : "gs-sorun"}">${k.fark === null ? "—" : para(k.fark)}</td><td>${gorunum(k.kullanici)}</td></tr>`).join("")}</table></div>`;
}

// ---------- Telefon uygulaması (bulut eşitleme) ----------
async function bulutBolumuYukle() {
  const kutu = $("bulut-bolum");
  if (!kutu) return;
  let r;
  try { r = await yedekApi("/api/bulut-durum"); } catch (e) { r = { ok: false, hata: "Sunucuya ulaşılamadı" }; }
  if (!kutu.isConnected) return;
  if (!r.ok) { kutu.innerHTML = `<span class="hata">${gorunum(r.hata)}</span>`; return; }
  const acik = !!DB.ayarOku("bulutEsitleme", false), son = r.son;
  kutu.innerHTML = `
    <label class="web-anahtar"><input type="checkbox" id="bulut-ac" ${acik ? "checked" : ""}> Verilerimi telefon uygulamasıyla eşitle (ürünler, stok, satışlar, müşteriler)</label>
    <div class="web-durum">${!r.anahtar ? "Önce Ayarlar → Lisans'tan lisans anahtarınızı girin." : son ? (son.ok ? `Son eşitleme: ${tarih(new Date(son.zaman).toISOString())} · ${son.alinan} alındı, ${son.gonderilen} gönderildi` : `Son eşitleme başarısız: ${gorunum(son.hata)}`) : (acik ? "İlk eşitleme birkaç dakika içinde yapılır." : "Kapalı")}</div>
    ${r.anahtar ? `<div class="web-durum">Telefon uygulamasında giriş için lisans anahtarınız: <strong style="font-family:Consolas,monospace">${gorunum(r.anahtar)}</strong>, ardından bu programdaki kullanıcı adı ve şifreniz.</div>` : ""}
    <div class="filtre"><button class="btn" id="bulut-simdi" ${r.anahtar ? "" : "disabled"}>Şimdi eşitle</button></div>
    <small style="opacity:.7">Veriler lisans anahtarınıza özel olarak bulutta saklanır; başka işletmeler göremez. Telefondaki satışlar bu programa, buradaki stok ve fiyatlar telefona yansır.</small>`;
  $("bulut-ac").addEventListener("change", e => { DB.ayarYaz("bulutEsitleme", e.target.checked); bildir(e.target.checked ? "Telefon eşitlemesi açıldı" : "Telefon eşitlemesi kapatıldı"); if (e.target.checked) setTimeout(() => $("bulut-simdi") && $("bulut-simdi").click(), 1200); });
  $("bulut-simdi").addEventListener("click", async () => {
    $("bulut-simdi").disabled = true; $("bulut-simdi").textContent = "Eşitleniyor...";
    const s = await yedekApi("/api/bulut-esitle", { method: "POST" });
    bildir(s.ok ? `Eşitlendi (${s.alinan} alındı, ${s.gonderilen} gönderildi)` : "Eşitlenemedi: " + s.hata);
    bulutBolumuYukle();
  });
}
