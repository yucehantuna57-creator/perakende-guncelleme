// Alış faturası işleme: hem tarayıcıda (elle fatura girişi) hem sunucuda (SOFTNEST cari'den gelen fatura) aynı kod çalışır.
// "durum" düz veri nesnesidir (urunler, musteriler, stok_hareketleri, cari_hareketler, alis_faturalari, sayac...).
// Fatura işlenince: stok girişi, ürünün alış fiyatı/KDV'si ve tedarikçi carisi (borcumuz) güncellenir.
(function (kok) {
  const yuvarla = x => Math.round(x * 100) / 100;
  const sayi = x => { x = Number(String(x === undefined || x === null ? 0 : x).replace(",", ".")); return isFinite(x) ? x : 0; };
  const kucuk = m => String(m || "").toLocaleLowerCase("tr").trim();
  const sonrakiId = (d, t) => { d.sayac = d.sayac || {}; d.sayac[t] = Math.max(d.sayac[t] || 0, (d[t] || []).reduce((m, x) => Math.max(m, x.id || 0), 0)) + 1; return d.sayac[t]; };
  const hazirla = (d) => { ["urunler", "musteriler", "kategoriler", "stok_hareketleri", "cari_hareketler", "alis_faturalari"].forEach(t => { d[t] = d[t] || []; }); };

  // ---- Ürün adı eşleştirme: faturadaki yazım ile stoktaki ad farklı olabilir; stoktaki ad her zaman geçerlidir ----
  const SADE = { "ı": "i", "ş": "s", "ğ": "g", "ü": "u", "ö": "o", "ç": "c", "İ": "i" };
  const BIRIM = { lt: "l", litre: "l", gr: "g", gram: "g", kilo: "kg", kilogram: "kg", mt: "m", metre: "m", ml: "ml", cm: "cm", mm: "mm", adet: "", ad: "", adt: "", pkt: "paket", paket: "paket", koli: "koli", takim: "takim", tk: "takim" };
  function adNormal(m) {
    let t = String(m || "").toLocaleLowerCase("tr").replace(/[ışğüöçİ]/g, c => SADE[c]);
    t = t.replace(/(\d),(\d)/g, "$1.$2").replace(/(\d)([a-z])/g, "$1 $2").replace(/([a-z])(\d)/g, "$1 $2");
    return t.replace(/[^a-z0-9.]+/g, " ").split(" ").map(x => x.replace(/^\.+|\.+$/g, "")).filter(Boolean).map(x => (x in BIRIM ? BIRIM[x] : x)).filter(Boolean);
  }
  const bigram = t => { const g = new Map(), x = " " + t + " "; for (let i = 0; i < x.length - 1; i++) { const k = x.slice(i, i + 2); g.set(k, (g.get(k) || 0) + 1); } return g; };
  function dice(a, b) {
    if (!a.size || !b.size) return 0;
    let ort = 0, ta = 0, tb = 0;
    a.forEach(v => { ta += v; }); b.forEach(v => { tb += v; });
    a.forEach((v, k) => { if (b.has(k)) ort += Math.min(v, b.get(k)); });
    return 2 * ort / (ta + tb);
  }
  // 0..1 benzerlik: sözcük örtüşmesi + harf çifti benzerliği; sayılar (500 / 1000, 1.5 / 5) farklıysa ceza
  function benzerlik(a, b) {
    const ta = typeof a === "string" ? adNormal(a) : a, tb = typeof b === "string" ? adNormal(b) : b;
    if (!ta.length || !tb.length) return 0;
    const ka = new Set(ta), kb = new Set(tb);
    let ort = 0; ka.forEach(x => { if (kb.has(x)) ort++; });
    const sozcuk = 2 * ort / (ka.size + kb.size), kapsam = ort / Math.min(ka.size, kb.size);
    let skor = 0.45 * sozcuk + 0.25 * kapsam + 0.3 * dice(bigram(ta.join(" ")), bigram(tb.join(" ")));
    const sa = ta.filter(x => /^\d/.test(x)), sb = tb.filter(x => /^\d/.test(x));
    if (sa.length && sb.length && sa.join(" ") !== sb.join(" ") && !(sa.every(x => sb.includes(x)) || sb.every(x => sa.includes(x)))) skor *= 0.55;
    else if ((sa.length && !sb.length) || (!sa.length && sb.length)) skor *= 0.85;
    return Math.min(1, skor);
  }
  // Kalem için stoktan en olası ürünler (barkod tam eşleşirse tek kesin aday)
  function adaylar(d, kalem, adet) {
    const urunler = (d.urunler || []).filter(u => !u.silindi);
    const kod = String(kalem.barkod || "").trim();
    if (kod) { const u = urunler.find(x => x.barkod === kod); if (u) return [{ urun: u, skor: 1, neden: "barkod" }]; }
    const ham = String(kalem.ad || "").trim();
    const anahtar = adNormal(ham).join(" ");
    const hatirla = d.ayarlar && d.ayarlar.fatura_esles && d.ayarlar.fatura_esles[anahtar];
    if (hatirla) { const u = urunler.find(x => x.id === hatirla); if (u) return [{ urun: u, skor: 1, neden: "hatirlanan" }]; }
    if (!ham) return [];
    const tk = adNormal(ham);
    return urunler.map(u => ({ urun: u, skor: benzerlik(tk, u.ad), neden: "ad" })).filter(x => x.skor >= 0.3).sort((a, b) => b.skor - a.skor).slice(0, adet || 6);
  }
  // Onaylanan eşleşmeyi sonraki faturalar için hatırlat
  function eslesmeHatirla(d, faturaAdi, urunId) {
    const anahtar = adNormal(faturaAdi).join(" ");
    if (!anahtar || !urunId) return;
    d.ayarlar = d.ayarlar || {}; d.ayarlar.fatura_esles = d.ayarlar.fatura_esles || {};
    d.ayarlar.fatura_esles[anahtar] = urunId;
  }

  function tedarikciBul(d, t) {
    const ad = String((t && (t.ad || t.ad_soyad)) || "").trim(), vergi = String((t && (t.vergi_no || t.vergi)) || "").trim();
    let m = (vergi && d.musteriler.find(x => x.tedarikci && String(x.vergi_no || "").trim() === vergi)) || (ad && d.musteriler.find(x => x.tedarikci && kucuk(x.ad_soyad) === kucuk(ad)));
    if (!m) {
      if (!ad) return null;
      m = { id: sonrakiId(d, "musteriler"), ad_soyad: ad.slice(0, 80), telefon: String((t && t.telefon) || ""), vergi_no: vergi, aktif: 1, tedarikci: 1 };
      d.musteriler.push(m);
    }
    return m;
  }

  function cariYaz(d, musteriId, tur, tutar, islem, aciklama, tarih) {
    const h = { id: sonrakiId(d, "cari_hareketler"), musteri_id: musteriId, tur, tutar, satis_id: null, aciklama, islem, yontem: null, kullanici_id: null, tarih };
    d.cari_hareketler.push(h);
    return h.id;
  }

  // f: { fatura_no, tarih, tedarikci:{ad,vergi_no,telefon}|tedarikci_id, odeme:"acik_hesap"|"nakit"|"kart"|"havale", kalemler:[{barkod,ad,adet,fiyat,kdv,satis_fiyati?,kategori?}], kaynak, dis_id }
  function faturaIsle(d, f) {
    hazirla(d);
    if (f.kaynak && f.dis_id !== undefined && d.alis_faturalari.some(x => x.kaynak === f.kaynak && String(x.dis_id) === String(f.dis_id) && x.durum !== "onay_bekliyor" && x.durum !== "birlesti")) return { atlandi: true };
    const kalemler = (f.kalemler || []).map(k => ({ urun_id: k.urun_id || null, fatura_ad: String(k.fatura_ad || k.ad || "").trim(), barkod: String(k.barkod || "").trim(), ad: String(k.ad || "").trim(), adet: sayi(k.adet), fiyat: sayi(k.fiyat), kdv: k.kdv === undefined || k.kdv === "" ? 20 : sayi(k.kdv), satis_fiyati: k.satis_fiyati, kategori: k.kategori })).filter(k => k.adet > 0 && (k.barkod || k.ad));
    if (!kalemler.length) return { hata: "Faturada ürün satırı yok" };
    // Bulut (SOFTNEST cari) faturası: kesin eşleşen satırlar otomatik bağlanır; emin olunmayanlar için kullanıcıya sorulana kadar fatura işlenmez
    if (f.otomatik) {
      const belirsiz = [];
      kalemler.forEach(k => {
        if (k.urun_id) return;
        const ad = adaylar(d, k, 4);
        if (ad.length && ad[0].skor >= 0.95) { k.urun_id = ad[0].urun.id; return; }
        if (ad.length && ad[0].skor >= 0.5) belirsiz.push(k.fatura_ad || k.ad);
      });
      if (belirsiz.length) {
        const bekleyen = { id: sonrakiId(d, "alis_faturalari"), fatura_no: String(f.fatura_no || ""), tarih: f.tarih ? new Date(f.tarih).toISOString() : new Date().toISOString(), tedarikci_ad: String((f.tedarikci && (f.tedarikci.ad || f.tedarikci.ad_soyad)) || ""), odeme: f.odeme || "acik_hesap", toplam: yuvarla(kalemler.reduce((t, k) => t + k.adet * k.fiyat * (1 + (k.kdv === undefined || k.kdv === "" ? 20 : sayi(k.kdv)) / 100), 0)), kalemler: [], durum: "onay_bekliyor", ham: f, belirsiz, kaynak: f.kaynak || "cari", dis_id: f.dis_id === undefined ? null : f.dis_id, olusturma: new Date().toISOString() };
        d.alis_faturalari.push(bekleyen);
        return { bekliyor: true };
      }
    }
    const ted = f.tedarikci_id ? d.musteriler.find(x => x.id === f.tedarikci_id) : tedarikciBul(d, f.tedarikci);
    if (!ted) return { hata: "Tedarikçi adı gerekli" };
    const tarih = f.tarih ? new Date(f.tarih).toISOString() : new Date().toISOString();
    const no = String(f.fatura_no || "").trim() || "AF-" + String(sonrakiId(d, "alis_faturalari_no")).padStart(5, "0");
    let ara = 0, kdvT = 0;
    const stokIds = [], cariIds = [], satirlar = [];
    for (const k of kalemler) {
      let u = (k.urun_id && d.urunler.find(x => x.id === k.urun_id)) || (k.barkod && d.urunler.find(x => x.barkod === k.barkod)) || (!k.barkod && d.urunler.find(x => kucuk(x.ad) === kucuk(k.ad)));
      if (!u) {
        const kn = k.kategori && String(k.kategori).trim();
        let kid = null;
        if (kn) { let kt = (d.kategoriler || []).find(x => kucuk(x.ad) === kucuk(kn)); if (!kt) { kt = { id: sonrakiId(d, "kategoriler"), ad: kn.slice(0, 30) }; d.kategoriler.push(kt); } kid = kt.id; }
        const kod = k.barkod || "U" + String(Math.max(0, ...d.urunler.map(x => /^U\d+$/.test(x.barkod || "") ? Number(x.barkod.slice(1)) : 0)) + 1).padStart(6, "0");
        u = { id: sonrakiId(d, "urunler"), barkod: kod, ad: k.ad || kod, kategori_id: kid, satis_fiyati: sayi(k.satis_fiyati), alis_fiyati: k.fiyat, kdv_orani: k.kdv, birim: "adet", stok: 0, kritik_stok: 0, aktif: 1 };
        d.urunler.push(u);
      } else {
        u.silindi = 0; u.aktif = 1; u.alis_fiyati = k.fiyat; u.kdv_orani = k.kdv;
        if (k.satis_fiyati !== undefined && k.satis_fiyati !== null && k.satis_fiyati !== "" && sayi(k.satis_fiyati) > 0) u.satis_fiyati = sayi(k.satis_fiyati);
      }
      const h = { id: sonrakiId(d, "stok_hareketleri"), urun_id: u.id, tur: "giris", miktar: k.adet, aciklama: "Alış faturası " + no, kullanici_id: null, tarih };
      d.stok_hareketleri.push(h); stokIds.push(h.id);
      u.stok = Math.round(((u.stok || 0) + k.adet) * 1000) / 1000;
      const net = yuvarla(k.adet * k.fiyat), kdvTl = yuvarla(net * k.kdv / 100);
      ara += net; kdvT += kdvTl;
      satirlar.push({ urun_id: u.id, barkod: u.barkod, ad: u.ad, fatura_ad: k.fatura_ad && k.fatura_ad !== u.ad ? k.fatura_ad : undefined, adet: k.adet, fiyat: k.fiyat, kdv: k.kdv, tutar: yuvarla(net + kdvTl) });
    }
    const toplam = yuvarla(ara + kdvT), odeme = ["nakit", "kart", "havale"].includes(f.odeme) ? f.odeme : "acik_hesap";
    // Tedarikçi carisi: fatura "alacak" (borcumuz artar); peşin ödendiyse aynı tutarda ödeme kaydı da düşülür
    cariIds.push(cariYaz(d, ted.id, "alacak", toplam, "alis_faturasi", "Alış faturası " + no, tarih));
    if (odeme !== "acik_hesap") cariIds.push(cariYaz(d, ted.id, "borc", toplam, "tedarikci_odeme", "Alış faturası " + no + " ödemesi (" + odeme + ")", tarih));
    const fatura = { id: sonrakiId(d, "alis_faturalari"), fatura_no: no, tarih, vade: f.vade || null, tedarikci_id: ted.id, tedarikci_ad: ted.ad_soyad, odeme, ara_toplam: yuvarla(ara), kdv_tutari: yuvarla(kdvT), toplam, kalemler: satirlar, durum: "aktif", kaynak: f.kaynak || "elle", dis_id: f.dis_id === undefined ? null : f.dis_id, stok_hareketleri: stokIds, cari_hareketleri: cariIds, olusturma: new Date().toISOString() };
    d.alis_faturalari.push(fatura);
    return { fatura };
  }

  // İptal: stok girişleri geri alınır, cari kayıtları ters yazılır; fatura silinmez, "iptal" olur
  function faturaIptal(d, id) {
    hazirla(d);
    const f = d.alis_faturalari.find(x => x.id === id);
    if (!f || f.durum === "iptal") return false;
    const tarih = new Date().toISOString();
    for (const k of f.kalemler) {
      const u = d.urunler.find(x => x.id === k.urun_id);
      d.stok_hareketleri.push({ id: sonrakiId(d, "stok_hareketleri"), urun_id: k.urun_id, tur: "cikis", miktar: -k.adet, aciklama: "Alış faturası " + f.fatura_no + " iptali", kullanici_id: null, tarih });
      if (u) u.stok = Math.round(((u.stok || 0) - k.adet) * 1000) / 1000;
    }
    for (const hid of f.cari_hareketleri || []) {
      const h = d.cari_hareketler.find(x => x.id === hid);
      if (h) cariYaz(d, h.musteri_id, h.tur === "borc" ? "alacak" : "borc", h.tutar, "fatura_iptali", "Alış faturası " + f.fatura_no + " iptali", tarih);
    }
    f.durum = "iptal"; f.iptal_tarihi = tarih;
    return true;
  }

  const api = { faturaIsle, faturaIptal, adNormal, benzerlik, adaylar, eslesmeHatirla };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else kok.FATURA = api;
})(typeof window !== "undefined" ? window : globalThis);
