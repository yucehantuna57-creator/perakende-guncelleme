// Masaüstü uygulaması açılırken (sunucu başlamadan önce) çağırır:
//   node guncelleme-cli.js kontrol  → {"durum":"var"|"guncel"|"hata"|..., "mevcut", "yeni", "notlar"}
//   node guncelleme-cli.js uygula   → {"ok":true,"yeni":"x.y.z"} ya da {"ok":false,"hata":"..."}
const g = require("./guncelleme");
const yaz = o => process.stdout.write(JSON.stringify(o));
(async () => {
  try {
    if (process.argv[2] === "uygula") { const s = await g.uygula(); yaz({ ok: true, yeni: s.yeni }); }
    else yaz(await g.kontrolEt());
  } catch (e) {
    yaz({ ok: false, durum: "hata", hata: e.message });
  }
})();
