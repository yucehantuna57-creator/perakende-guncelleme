// Giriş, kurulum ve lisans formları için ekran (sanal) klavyesi: dokunmatik kasada sayısal şifre ve kullanıcı adı yazmak için.
// Şifre alanında büyük sayı tuşları, kullanıcı adı alanında harf klavyesi açılır; "ABC / 123" ile değiştirilir.
(function () {
  const DEPO = "sanal_klavye_acik";
  const acikMi = () => { try { return localStorage.getItem(DEPO) !== "0"; } catch (e) { return true; } };
  const HARF = [["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"], ["q", "w", "e", "r", "t", "y", "u", "ı", "o", "p", "ğ", "ü"], ["a", "s", "d", "f", "g", "h", "j", "k", "l", "ş", "i"], ["⇧", "z", "x", "c", "v", "b", "n", "m", "ö", "ç", ".", "⌫"]];
  const SAYI = [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"], ["C", "0", "⌫"]];

  function kur(form) {
    const alanlar = () => [...form.querySelectorAll("input")].filter(i => !["checkbox", "hidden", "submit"].includes(i.type));
    let aktif = null, duzen = "sayi", buyuk = false;
    const kutu = document.createElement("div");
    kutu.className = "sanal-klavye";
    const anahtar = document.createElement("button");
    anahtar.type = "button"; anahtar.className = "klavye-ac";
    const son = alanlar().slice(-1)[0];
    if (son) { son.after(kutu); kutu.after(anahtar); } else { form.appendChild(kutu); form.appendChild(anahtar); }

    const hedef = () => aktif && form.contains(aktif) ? aktif : (alanlar()[0] || null);
    function yaz(t) {
      const i = hedef(); if (!i) return;
      i.focus();
      const bas = i.selectionStart ?? i.value.length, son = i.selectionEnd ?? i.value.length;
      if (t === "⌫") { if (bas === son && bas > 0) i.setRangeText("", bas - 1, son, "end"); else i.setRangeText("", bas, son, "end"); }
      else if (t === "C") i.value = "";
      else i.setRangeText(buyuk ? t.toLocaleUpperCase("tr") : t, bas, son, "end");
      i.dispatchEvent(new Event("input", { bubbles: true }));
    }
    function ciz() {
      const ac = acikMi();
      kutu.hidden = !ac;
      anahtar.textContent = ac ? "⌨ Sanal klavyeyi gizle" : "⌨ Sanal klavyeyi göster";
      alanlar().forEach(i => { if (ac) { i.dataset.imodu = i.inputMode || ""; i.inputMode = "none"; } else if (i.dataset.imodu !== undefined) { i.inputMode = i.dataset.imodu; } });
      if (!ac) return;
      const satirlar = duzen === "sayi" ? SAYI : HARF;
      kutu.className = "sanal-klavye " + (duzen === "sayi" ? "sayisal" : "harfli");
      kutu.innerHTML = satirlar.map(s => `<div class="kl-satir">${s.map(t => `<button type="button" class="kl-tus${t === "⌫" || t === "C" || t === "⇧" ? " ozel" : ""}${t === "⇧" && buyuk ? " basili" : ""}" data-t="${t}">${buyuk && t.length === 1 && t !== "⇧" ? t.toLocaleUpperCase("tr") : t}</button>`).join("")}</div>`).join("") +
        `<div class="kl-satir kl-alt">${duzen === "harf" ? '<button type="button" class="kl-tus genis" data-t=" ">boşluk</button>' : ""}<button type="button" class="kl-tus ozel" data-mod="1">${duzen === "sayi" ? "ABC" : "123"}</button><button type="button" class="kl-tus tamam" data-gonder="1">Giriş ⏎</button></div>`;
    }
    kutu.addEventListener("mousedown", e => e.preventDefault()); // alanın odağı kaybolmasın
    kutu.addEventListener("click", e => {
      const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.mod) { duzen = duzen === "sayi" ? "harf" : "sayi"; ciz(); return; }
      if (b.dataset.gonder) { form.requestSubmit(); return; }
      const t = b.dataset.t;
      if (t === "⇧") { buyuk = !buyuk; ciz(); return; }
      yaz(t);
      if (buyuk && t !== "⌫" && t !== "C") { buyuk = false; ciz(); }
    });
    anahtar.addEventListener("click", () => { try { localStorage.setItem(DEPO, acikMi() ? "0" : "1"); } catch (e) { /* önemsiz */ } ciz(); });
    form.addEventListener("focusin", e => {
      if (!alanlar().includes(e.target)) return;
      aktif = e.target;
      const yeni = e.target.type === "password" || /anahtar/.test(e.target.id) ? "sayi" : "harf";
      if (yeni !== duzen) { duzen = yeni; ciz(); }
    });
    duzen = "harf"; ciz();
  }
  function basla() { document.querySelectorAll("form.giris-kutu").forEach(kur); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", basla); else basla();
})();
