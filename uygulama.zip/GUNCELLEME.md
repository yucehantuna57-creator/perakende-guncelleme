# Uygulamayı başlatma ve güncelleme

## Başlatma
Masaüstündeki **Perakende Satış** simgesine tıklayın. Sunucu arka planda açılır, uygulama kendi penceresinde gelir.
Simge yoksa `kisayol-olustur.bat` dosyasını bir kez çalıştırın (her kasa bilgisayarında bir kez).

## Yeni sürüm yayınlama (geliştirici)
Yeni bir şey ekleyip denedikten sonra:

```
node yayinla.js 1.0.1 "Fişlerde tarih filtresi eklendi|Barkod etiketi büyütüldü"
```

- Sürüm numarası bir öncekinden büyük olmalı (`1.0.1`, `1.1.0`, `2.0.0`).
- Notlar `|` ile ayrılır, kasada güncelleme penceresinde madde madde görünür.
- Komut `surum.json` ve `uygulama.zip` dosyalarını güncelleme kaynağına koyar.

## Kasada ne olur
Simgeye tıklanınca uygulama açılır ve yeni sürüm varsa **"Güncelleme var, şimdi güncellensin mi?"** diye sorar.
**Şimdi güncelle** denirse dosyalar indirilir, doğrulanır, sunucu yeniden başlar ve uygulama yeni sürümle açılır.
**Sonra** denirse bir sonraki açılışta tekrar sorulur. Ayarlar sayfasındaki **Güncellemeleri denetle** butonu da aynı işi yapar.

## Güncelleme kaynağı
`guncelleme-ayar.json` dosyasındaki `kaynak` alanı:

| Kaynak | Örnek |
| --- | --- |
| Klasör (aynı bilgisayar, ağ paylaşımı, eşitlenen klasör) | `"../yayin"` veya `"\\\\SUNUCU\\yayin"` |
| Web adresi (içinde `surum.json` ve `uygulama.zip` bulunan adres) | `"https://ornek.com/perakende"` |

Kasa bilgisayarlarında bu dosya bir kez ayarlanır, güncellemeler dosyayı değiştirmez.

## Güvenlik ve veri
- `data` klasörü (veritabanı, günlük yedekler) ve `guncelleme-ayar.json` güncellemeyle değişmez.
- Her güncellemeden önce eski dosyalar `onceki-surum` klasörüne yedeklenir. Paket bozuksa ya da kurulum yarım kalırsa eski dosyalara dönülür.
- Güncelleme yalnızca sunucunun çalıştığı bilgisayardaki uygulamadan yapılabilir (diğer kasalardan yapılamaz).
- Kaynağa yalnızca güvendiğiniz kişilerin yazabildiğinden emin olun: oradaki paket kasaya kod olarak kurulur.
