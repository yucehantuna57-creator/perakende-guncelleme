// Örnek başlangıç verisi. Sunucu ilk çalıştığında veritabanına yazılır.
const crypto = require("node:crypto");

function sha256(metin) {
  return crypto.createHash("sha256").update(metin, "utf8").digest("hex");
}

// Yeni kurulum boş başlar: örnek kullanıcı, kategori veya ürün yoktur. İlk açılışta kurulum ekranı yönetici hesabını oluşturur.
function tohumDurum() {
  return {
    kullanicilar: [], kategoriler: [], urunler: [], stok_hareketleri: [], musteriler: [],
    satislar: [], satis_kalemleri: [], odemeler: [], cari_hareketler: [], sayimlar: [], sayim_kalemleri: [], alis_faturalari: [],
    ayarlar: {}, sayac: {}
  };
}

module.exports = { tohumDurum, sha256 };
