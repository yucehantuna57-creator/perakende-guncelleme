// Örnek başlangıç verisi. Sunucu ilk çalıştığında veritabanına yazılır.
const crypto = require("node:crypto");

function sha256(metin) {
  return crypto.createHash("sha256").update(metin, "utf8").digest("hex");
}

function tohumDurum() {
  const sayac = {};
  const ekle = (tablo, kayit) => {
    sayac[tablo] = (sayac[tablo] || 0) + 1;
    return { id: sayac[tablo], ...kayit };
  };

  const ozet = sha256("1234");
  const kullanicilar = [
    ekle("kullanicilar", { ad_soyad: "Yönetici", kullanici_adi: "admin", sifre_hash: ozet, rol: "yonetici", aktif: 1 }),
    ekle("kullanicilar", { ad_soyad: "Kasiyer Ayşe", kullanici_adi: "ayse", sifre_hash: ozet, rol: "kasiyer", aktif: 1 })
  ];

  const kategoriler = ["Süt", "Ekmek", "İçecek", "Temizlik", "Atıştırmalık"].map(ad => ekle("kategoriler", { ad }));
  const kategoriId = ad => kategoriler.find(k => k.ad === ad).id;

  const urunler = [];
  const stokHareketleri = [];
  [
    ["8690001", "Süt 1 L", "Süt", 42.5, 35, 20, 50, 10],
    ["8690002", "Beyaz peynir 500 g", "Süt", 118, 95, 1, 20, 5],
    ["8690003", "Ekmek", "Ekmek", 12, 8, 1, 60, 15],
    ["8690004", "Simit", "Ekmek", 15, 10, 1, 40, 10],
    ["8690005", "Su 1,5 L", "İçecek", 15, 10, 10, 80, 20],
    ["8690006", "Çay 500 g", "İçecek", 96, 80, 1, 25, 5],
    ["8690007", "Deterjan 3 kg", "Temizlik", 249, 200, 20, 12, 3],
    ["8690008", "Bulaşık süngeri", "Temizlik", 18.5, 12, 20, 30, 8],
    ["8690009", "Cips 150 g", "Atıştırmalık", 34.5, 25, 20, 45, 10],
    ["8690010", "Çikolata", "Atıştırmalık", 27, 19, 20, 4, 10]
  ].forEach(([barkod, ad, kategori, fiyat, alis, kdv, stok, kritik]) => {
    const u = ekle("urunler", { barkod, ad, kategori_id: kategoriId(kategori), satis_fiyati: fiyat, alis_fiyati: alis, kdv_orani: kdv, birim: "adet", stok, kritik_stok: kritik, aktif: 1 });
    urunler.push(u);
    stokHareketleri.push(ekle("stok_hareketleri", { urun_id: u.id, tur: "giris", miktar: stok, aciklama: "Açılış stoku", kullanici_id: null, tarih: new Date().toISOString() }));
  });

  const musteriler = [ekle("musteriler", { ad_soyad: "Mehmet Kaya", telefon: "0500 000 00 00", vergi_no: "", aktif: 1 })];

  return {
    kullanicilar, kategoriler, urunler, stok_hareketleri: stokHareketleri, musteriler,
    satislar: [], satis_kalemleri: [], odemeler: [], cari_hareketler: [], sayimlar: [], sayim_kalemleri: [],
    ayarlar: {}, sayac
  };
}

module.exports = { tohumDurum, sha256 };
