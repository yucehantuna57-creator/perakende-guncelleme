// Uygulamayı başlatır: sunucu kapalıysa arka planda açar, sonra uygulama penceresini getirir.
// Masaüstü kısayolu bu dosyayı çalıştırır. Güncelleme sorusu uygulama açılınca ekranda çıkar.
const http = require("node:http");
const path = require("node:path");
const { spawn, execSync } = require("node:child_process");

const KOK = __dirname;
const PORT = process.env.PORT || 3000;

function calisiyor() {
  return new Promise(coz => {
    const istek = http.get({ host: "127.0.0.1", port: PORT, path: "/api/surum", timeout: 1500 }, yanit => { yanit.resume(); coz(true); });
    istek.on("error", () => coz(false));
    istek.on("timeout", () => { istek.destroy(); coz(false); });
  });
}

const bekle = ms => new Promise(coz => setTimeout(coz, ms));

function tarayiciVarMi(ad) {
  try { execSync(`where ${ad}`, { stdio: "ignore" }); return true; } catch (e) { return false; }
}

function uygulamayiAc() {
  const adres = `http://localhost:${PORT}`;
  const profil = path.join(process.env.LOCALAPPDATA || KOK, "PerakendeKasa");
  // --app: adres çubuğu olmadan uygulama penceresi, --kiosk-printing: fişi yazıcı seçtirmeden varsayılan yazıcıya gönderir
  const secenekler = ["--app=" + adres, "--kiosk-printing", "--user-data-dir=" + profil];
  const tarayici = tarayiciVarMi("msedge") ? "msedge" : tarayiciVarMi("chrome") ? "chrome" : null;
  const argumanlar = tarayici ? ["/c", "start", "", tarayici, ...secenekler] : ["/c", "start", "", adres];
  spawn("cmd", argumanlar, { detached: true, stdio: "ignore", windowsHide: true }).unref();
}

(async () => {
  if (!(await calisiyor())) {
    spawn(process.execPath, ["server.js"], { cwd: KOK, detached: true, stdio: "ignore", windowsHide: true }).unref();
    for (let i = 0; i < 60 && !(await calisiyor()); i++) await bekle(250);
    if (!(await calisiyor())) {
      console.error("Sunucu başlatılamadı. node server.js komutunu elle çalıştırıp hatayı görebilirsiniz.");
      process.exit(1);
    }
  }
  uygulamayiAc();
})();
