// Bulut eşitleme: bu bilgisayarın verisi ile telefon uygulaması (SOFTNEST-satış mobil) arasında lisans anahtarına bağlı eşitleme.
// Her kayıt (ürün, satış, müşteri...) ayrı ayrı Supabase'e gönderilir/alınır; çakışmada son değişen kazanır, satış ve stok
// hareketleri hiç silinmez. Yalnızca yönetici Ayarlar'dan "Telefon bağlantısı"nı açarsa çalışır.
const crypto = require("node:crypto");

const SUPA = "https://dbpbssdrwolssrdaypzw.supabase.co/rest/v1/rpc/";
const ANAHTAR = "sb_publishable_XHbSoSAa11HFP9AAEM3esQ_ziAMPbqX";
const TABLOLAR = ["kullanicilar", "kategoriler", "urunler", "stok_hareketleri", "musteriler", "satislar", "satis_kalemleri", "odemeler", "cari_hareketler", "sayimlar", "sayim_kalemleri"];
const KALICI = new Set(["satislar", "satis_kalemleri", "odemeler", "stok_hareketleri", "cari_hareketler", "sayimlar", "sayim_kalemleri"]);
const PARCA = 400;

// Anahtar sırasından bağımsız, aynı içerik aynı özeti verir
function kanon(o) {
  if (Array.isArray(o)) return o.map(kanon);
  if (o && typeof o === "object") return Object.keys(o).sort().reduce((a, k) => { a[k] = kanon(o[k]); return a; }, {});
  return o;
}
const ozet = o => crypto.createHash("md5").update(JSON.stringify(kanon(o))).digest("hex");
// Buluta giden hâli: büyük fotoğraf alanı gönderilmez
const buluta = r => { const { resim, ...geri } = r; return geri; };

// Buluttan gelen kayıt bozuksa (zorunlu alan yok) atlanır; böylece tek bir bozuk kayıt eşitlemeyi durdurmaz
const ZORUNLU = {
  kullanicilar: ["kullanici_adi", "sifre_hash", "rol"], kategoriler: ["ad"], urunler: ["barkod", "ad", "satis_fiyati"], musteriler: ["ad_soyad"],
  satislar: ["fis_no", "kullanici_id", "toplam", "tarih"], satis_kalemleri: ["satis_id", "urun_id", "miktar", "tutar"], odemeler: ["satis_id", "yontem", "tutar"],
  stok_hareketleri: ["urun_id", "tur", "miktar"], cari_hareketler: ["musteri_id", "tur", "tutar"]
};
const gecerliKayit = (tablo, v) => !!v && typeof v === "object" && (ZORUNLU[tablo] || []).every(a => v[a] !== undefined && v[a] !== null && v[a] !== "");

function kur(ctx) {
  const { kayitOku, kayitYaz, durumuYaz, surum, lisansOku, lisansBilgi } = ctx;
  let calisiyor = false;

  async function rpc(ad, govde) {
    const y = await fetch(SUPA + ad, { method: "POST", headers: { apikey: ANAHTAR, "Content-Type": "application/json" }, body: JSON.stringify(govde), signal: AbortSignal.timeout(30000) });
    if (!y.ok) throw new Error("Bulut yanıt vermedi (" + y.status + ")");
    return y.json();
  }

  function cihazKimligi() {
    let c = kayitOku("bulut_cihaz");
    if (!c || !c.id) { c = { id: "pc-" + crypto.randomUUID().slice(0, 8) }; kayitYaz("bulut_cihaz", c); }
    return c.id;
  }

  async function esitle(zorla) {
    if (calisiyor) return { ok: false, hata: "Eşitleme sürüyor" };
    let durum = kayitOku("durum") || {};
    if (!zorla && !(durum.ayarlar || {}).bulutEsitleme) return { ok: false, hata: "Kapalı" };
    const l = lisansOku();
    if (!l.anahtar) return { ok: false, hata: "Önce lisans anahtarı girilmeli" };
    if (!lisansBilgi().gecerli) return { ok: false, hata: "Lisans geçersiz" };
    calisiyor = true;
    const sonuc = { zaman: Date.now(), alinan: 0, gonderilen: 0 };
    try {
      const cihaz = cihazKimligi();
      const ayna = kayitOku("bulut_ayna") || {};
      let sira = kayitOku("bulut_sira") || 0;

      // 1) Buluttan yeni değişiklikler (telefon vb.)
      let degisti = false;
      for (let tur = 0; tur < 40; tur++) {
        const r = await rpc("bulut_al", { p_anahtar: l.anahtar, p_sonra: sira, p_cihaz: cihaz });
        if (!r.ok) throw new Error(r.hata || "Alınamadı");
        durum = kayitOku("durum") || {};
        for (const k of r.kayitlar) {
          if (!TABLOLAR.includes(k.tablo)) continue;
          if (!k.silindi && !gecerliKayit(k.tablo, k.veri)) { sonuc.atlanan = (sonuc.atlanan || 0) + 1; continue; }
          const dizi = durum[k.tablo] = durum[k.tablo] || [];
          const id = Number(k.kid), anahtar = k.tablo + ":" + id, yerelG = (ayna[anahtar] || {}).g || 0;
          const idx = dizi.findIndex(x => x.id === id);
          if (k.silindi) {
            if (!KALICI.has(k.tablo) && idx >= 0 && k.guncelleme >= yerelG) { dizi.splice(idx, 1); degisti = true; }
            ayna[anahtar] = { h: "silindi", g: k.guncelleme };
            continue;
          }
          let uygulandi = false;
          if (idx < 0) {
            dizi.push({ ...k.veri });
            // Yeni stok hareketi: ürünün stoğuna yansıtılır
            if (k.tablo === "stok_hareketleri") {
              const u = (durum.urunler || []).find(x => x.id === k.veri.urun_id);
              if (u) u.stok = Math.round(((u.stok || 0) + (k.veri.miktar || 0)) * 1000) / 1000;
            }
            uygulandi = true;
          } else if (k.guncelleme > yerelG) {
            const eski = dizi[idx];
            if (ozet(buluta(eski)) !== ozet(k.veri)) {
              // Fotoğraf ve (ürünlerde) stok yerelde kalır: stok yalnızca hareketlerle değişir
              dizi[idx] = { ...k.veri, ...(eski.resim ? { resim: eski.resim } : {}), ...(k.tablo === "urunler" && eski.stok !== undefined ? { stok: eski.stok } : {}) };
              uygulandi = true;
            } else uygulandi = true;
          }
          if (uygulandi) {
            degisti = true;
            const son = dizi.find(x => x.id === id);
            ayna[anahtar] = { h: ozet(buluta(son)), g: k.guncelleme };
            // Stok hareketi ürünü değiştirdiyse ürün satırı bir sonraki turda buluta gider
          }
          sonuc.alinan++;
        }
        sira = r.sira;
        if (degisti) {
          try { dizi_kaydet(durum); } catch (e) { sonuc.uyari = "Bazı kayıtlar işlenemedi: " + e.message; }
          degisti = false;
        }
        if (r.kayitlar.length < 1500) break;
      }
      kayitYaz("bulut_sira", sira);

      // 2) Bu bilgisayardaki yeni/değişen kayıtlar buluta
      durum = kayitOku("durum") || {};
      const simdi = Date.now(), degisenler = [];
      const gorulen = new Set();
      for (const t of TABLOLAR) {
        for (const satir of durum[t] || []) {
          const anahtar = t + ":" + satir.id; gorulen.add(anahtar);
          const h = ozet(buluta(satir)), e = ayna[anahtar];
          if (!e || e.h !== h) degisenler.push({ anahtar, tablo: t, kid: satir.id, veri: buluta(satir), silindi: false, g: simdi, h });
        }
      }
      // İşletme adı telefon uygulamasında görünsün diye küçük bir "ayarlar" kaydı da gönderilir
      const ayarKaydi = { id: 1, isletmeAdi: (durum.ayarlar || {}).isletmeAdi || "" };
      const ayarH = ozet(ayarKaydi);
      if (!ayna["ayarlar:1"] || ayna["ayarlar:1"].h !== ayarH) degisenler.push({ anahtar: "ayarlar:1", tablo: "ayarlar", kid: 1, veri: ayarKaydi, silindi: false, g: simdi, h: ayarH });
      gorulen.add("ayarlar:1");
      for (const [anahtar, e] of Object.entries(ayna)) {
        if (gorulen.has(anahtar) || e.h === "silindi") continue;
        const [t, id] = anahtar.split(":");
        if (KALICI.has(t) || !TABLOLAR.includes(t)) continue; // "ayarlar" kaydı hiç silinmez
        degisenler.push({ anahtar, tablo: t, kid: Number(id), veri: null, silindi: true, g: simdi, h: "silindi" });
      }
      for (let i = 0; i < degisenler.length; i += PARCA) {
        const parca = degisenler.slice(i, i + PARCA);
        const r = await rpc("bulut_gonder", { p_anahtar: l.anahtar, p_cihaz: cihaz, p_kayitlar: parca.map(p => ({ tablo: p.tablo, kid: p.kid, veri: p.veri, silindi: p.silindi, g: p.g })) });
        if (!r.ok) throw new Error(r.hata || "Gönderilemedi");
        parca.forEach(p => { ayna[p.anahtar] = { h: p.h, g: p.g }; });
        sonuc.gonderilen += parca.length;
        kayitYaz("bulut_ayna", ayna);
      }
      kayitYaz("bulut_ayna", ayna);
      sonuc.ok = true;
    } catch (e) {
      sonuc.ok = false; sonuc.hata = e.message || "Eşitlenemedi";
    } finally {
      calisiyor = false;
    }
    kayitYaz("bulut_son", sonuc);
    return sonuc;
  }

  // Alınan değişiklikleri sunucu durumuna yazar; açık ekranlar bir sonraki kayıtta güncel veriyi alır
  function dizi_kaydet(durum) {
    durumuYaz(durum, false);
    kayitYaz("surum", { no: surum() + 1 });
  }

  setTimeout(() => esitle(false), 25000);
  setInterval(() => esitle(false), 30 * 1000).unref();
  return { esitle };
}

module.exports = { kur };
