-- Perakende satış veritabanı şeması
-- Hedef: SQLite (yerel kasa) veya PostgreSQL (merkez sunucu). Standart SQL'e yakın yazıldı.

PRAGMA foreign_keys = ON;

-- Kullanıcılar ve roller
CREATE TABLE IF NOT EXISTS kullanicilar (
  id            INTEGER PRIMARY KEY,
  ad_soyad      TEXT NOT NULL,
  kullanici_adi TEXT NOT NULL UNIQUE,
  sifre_hash    TEXT NOT NULL,
  rol           TEXT NOT NULL CHECK (rol IN ('yonetici', 'kasiyer')),
  aktif         INTEGER NOT NULL DEFAULT 1,
  olusturma     TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Kategoriler
CREATE TABLE IF NOT EXISTS kategoriler (
  id   INTEGER PRIMARY KEY,
  ad   TEXT NOT NULL UNIQUE
);

-- Ürünler (stok miktarı hareketlerden hesaplanır, burada önbellek olarak tutulur)
CREATE TABLE IF NOT EXISTS urunler (
  id            INTEGER PRIMARY KEY,
  barkod        TEXT NOT NULL UNIQUE,
  ad            TEXT NOT NULL,
  kategori_id   INTEGER REFERENCES kategoriler(id),
  satis_fiyati  NUMERIC NOT NULL CHECK (satis_fiyati >= 0),
  alis_fiyati   NUMERIC NOT NULL DEFAULT 0 CHECK (alis_fiyati >= 0),
  kdv_orani     INTEGER NOT NULL DEFAULT 20,
  birim         TEXT NOT NULL DEFAULT 'adet',
  stok          NUMERIC NOT NULL DEFAULT 0,
  kritik_stok   NUMERIC NOT NULL DEFAULT 0,
  aktif         INTEGER NOT NULL DEFAULT 1,
  resim         TEXT                        -- küçültülmüş ürün fotoğrafı (data URL)
);

-- Stok hareketleri: her giriş, çıkış, satış, iade ve sayım düzeltmesi burada tutulur
CREATE TABLE IF NOT EXISTS stok_hareketleri (
  id           INTEGER PRIMARY KEY,
  urun_id      INTEGER NOT NULL REFERENCES urunler(id),
  tur          TEXT NOT NULL CHECK (tur IN ('giris', 'cikis', 'satis', 'iade', 'sayim')),
  miktar       NUMERIC NOT NULL,            -- giriş ve iade pozitif, çıkış ve satış negatif
  aciklama     TEXT,
  kullanici_id INTEGER REFERENCES kullanicilar(id),
  tarih        TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Stok sayımları: başlarken sistem stoğu kaydedilir, sayılan miktarlar girilir, tamamlanınca farklar stok hareketi olur
CREATE TABLE IF NOT EXISTS sayimlar (
  id               INTEGER PRIMARY KEY,
  ad               TEXT NOT NULL,
  durum            TEXT NOT NULL DEFAULT 'devam' CHECK (durum IN ('devam', 'tamamlandi', 'iptal')),
  kapsam           TEXT NOT NULL DEFAULT 'hepsi' CHECK (kapsam IN ('hepsi', 'kategori', 'stoklu')),
  kategori_id      INTEGER,                                  -- kapsam 'kategori' ise hangi kategori (kategori silinse de sayım kaydı kalır)
  aciklama         TEXT,
  baslangic        TEXT NOT NULL,
  bitis            TEXT,
  kullanici_id     INTEGER REFERENCES kullanicilar(id),     -- sayımı başlatan
  tamamlayan_id    INTEGER REFERENCES kullanicilar(id),     -- farkları stoğa işleyen
  sayilmayan_islem TEXT CHECK (sayilmayan_islem IN ('koru', 'sifirla'))
);

CREATE TABLE IF NOT EXISTS sayim_kalemleri (
  id             INTEGER PRIMARY KEY,
  sayim_id       INTEGER NOT NULL REFERENCES sayimlar(id) ON DELETE CASCADE,
  urun_id        INTEGER NOT NULL REFERENCES urunler(id),
  sistem_stok    NUMERIC NOT NULL,                          -- sayım başladığındaki stok
  sayilan        NUMERIC,                                   -- boşsa henüz sayılmadı
  maliyet        NUMERIC NOT NULL DEFAULT 0,                -- fark tutarı için birim alış fiyatı
  uygulanan_fark NUMERIC,                                   -- tamamlanınca stoğa yazılan fark
  sayilma_tarihi TEXT
);

-- Müşteriler ve açık hesap (cari) bakiyesi
CREATE TABLE IF NOT EXISTS musteriler (
  id          INTEGER PRIMARY KEY,
  ad_soyad    TEXT NOT NULL,
  telefon     TEXT,
  vergi_no    TEXT,
  aktif       INTEGER NOT NULL DEFAULT 1
);

-- Satışlar (fiş başlığı)
CREATE TABLE IF NOT EXISTS satislar (
  id            INTEGER PRIMARY KEY,
  fis_no        TEXT NOT NULL UNIQUE,
  kasa_no       TEXT NOT NULL,
  kullanici_id  INTEGER NOT NULL REFERENCES kullanicilar(id),
  musteri_id    INTEGER REFERENCES musteriler(id),
  ara_toplam    NUMERIC NOT NULL,
  indirim       NUMERIC NOT NULL DEFAULT 0,
  toplam        NUMERIC NOT NULL,
  durum         TEXT NOT NULL DEFAULT 'tamamlandi' CHECK (durum IN ('tamamlandi', 'iptal')),
  tarih         TEXT NOT NULL DEFAULT (datetime('now')),
  iptal_tarihi  TEXT,                       -- fiş iptal edildiyse ne zaman
  iptal_eden_id INTEGER REFERENCES kullanicilar(id),
  iptal_nedeni  TEXT,                       -- iptal sebebi veya 'Sepet iptali' (ödeme alınmadan vazgeçilen sepet)
  iptal_turu    TEXT CHECK (iptal_turu IN ('fis', 'sepet'))  -- fis: kesilmiş fiş iptali, sepet: ödeme öncesi vazgeçme
);

-- Satış kalemleri
CREATE TABLE IF NOT EXISTS satis_kalemleri (
  id          INTEGER PRIMARY KEY,
  satis_id    INTEGER NOT NULL REFERENCES satislar(id) ON DELETE CASCADE,
  urun_id     INTEGER NOT NULL REFERENCES urunler(id),
  miktar      NUMERIC NOT NULL CHECK (miktar > 0),
  birim_fiyat NUMERIC NOT NULL,
  tutar       NUMERIC NOT NULL
);

-- Ödemeler (bir satış birden fazla yöntemle ödenebilir)
CREATE TABLE IF NOT EXISTS odemeler (
  id        INTEGER PRIMARY KEY,
  satis_id  INTEGER NOT NULL REFERENCES satislar(id) ON DELETE CASCADE,
  yontem    TEXT NOT NULL CHECK (yontem IN ('nakit', 'kart', 'acik_hesap')),
  tutar     NUMERIC NOT NULL CHECK (tutar > 0)
);

-- Cari hareketleri: açık hesap borç ve tahsilat kayıtları
CREATE TABLE IF NOT EXISTS cari_hareketler (
  id          INTEGER PRIMARY KEY,
  musteri_id  INTEGER NOT NULL REFERENCES musteriler(id),
  tur         TEXT NOT NULL CHECK (tur IN ('borc', 'tahsilat', 'alacak')),
  tutar       NUMERIC NOT NULL CHECK (tutar > 0),
  satis_id    INTEGER REFERENCES satislar(id),
  aciklama    TEXT,
  islem       TEXT,                                                      -- satis, tahsilat, borc_duzeltme, fis_iptali, alis_faturasi, tedarikci_odeme, fatura_iptali
  yontem      TEXT CHECK (yontem IN ('nakit', 'kart', 'havale')),   -- tahsilatın ödeme yöntemi
  kullanici_id INTEGER REFERENCES kullanicilar(id),                 -- hareketi kimin yaptığı
  tarih       TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Uygulama ayarları (tema, kasa no, KDV varsayılanı vb.)
CREATE TABLE IF NOT EXISTS ayarlar (
  anahtar TEXT PRIMARY KEY,
  deger   TEXT NOT NULL
);

-- Sık kullanılan sorgular için indeksler
CREATE INDEX IF NOT EXISTS idx_urun_barkod   ON urunler(barkod);
CREATE INDEX IF NOT EXISTS idx_hareket_urun  ON stok_hareketleri(urun_id, tarih);
CREATE INDEX IF NOT EXISTS idx_satis_tarih   ON satislar(tarih);
CREATE INDEX IF NOT EXISTS idx_cari_musteri  ON cari_hareketler(musteri_id);
