// Alış faturası dosyası okuma: e-Fatura XML (UBL-TR), Excel/CSV ve PDF (metin içeren PDF'ler).
// Sonuç her zaman aynı biçimdedir: { fatura_no, tarih, tedarikci:{ad,vergi_no}, kalemler:[{barkod,ad,adet,fiyat,kdv}], uyari }
// Satır adları fatura düzenleyicinin yazdığı gibi gelir; stoktaki ürünle eşleştirmeyi ekran yapar (stoktaki ad geçerli olur).
const FATURAOKU = (() => {
  const sayiCoz = m => {
    let t = String(m === undefined || m === null ? "" : m).replace(/[^\d.,\-]/g, "");
    if (!t) return 0;
    if (t.includes(",") && t.includes(".")) t = t.lastIndexOf(",") > t.lastIndexOf(".") ? t.replace(/\./g, "").replace(",", ".") : t.replace(/,/g, "");
    else if (t.includes(",")) t = t.replace(",", ".");
    else if ((t.match(/\./g) || []).length > 1) t = t.replace(/\./g, "");
    const n = Number(t);
    return isFinite(n) ? n : 0;
  };
  const tarihCoz = m => {
    const t = String(m || "").trim();
    let k = /^(\d{4})-(\d{2})-(\d{2})/.exec(t);
    if (k) return k[1] + "-" + k[2] + "-" + k[3];
    k = /(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})/.exec(t);
    return k ? k[3] + "-" + k[2].padStart(2, "0") + "-" + k[1].padStart(2, "0") : "";
  };

  // ---------- XML (UBL-TR e-Fatura / e-Arşiv) ----------
  function xmlOku(metin) {
    const doc = new DOMParser().parseFromString(metin, "application/xml");
    if (doc.querySelector("parsererror")) throw new Error("XML dosyası okunamadı");
    const yerel = (kok, ad) => [...kok.getElementsByTagName("*")].filter(e => e.localName === ad);
    const cocuk = (kok, ad) => [...kok.children].find(e => e.localName === ad);
    const ilk = (kok, ...yol) => { let n = kok; for (const a of yol) { n = n && (cocuk(n, a)); } return n ? n.textContent.trim() : ""; };
    const kok = doc.documentElement;
    const satici = yerel(kok, "AccountingSupplierParty")[0];
    const taraf = satici && cocuk(satici, "Party");
    let ad = taraf ? ilk(taraf, "PartyName", "Name") : "";
    if (!ad && taraf) { const kisi = cocuk(taraf, "Person"); if (kisi) ad = (ilk(kisi, "FirstName") + " " + ilk(kisi, "FamilyName")).trim(); }
    let vergi = "";
    if (taraf) for (const pi of [...taraf.children].filter(e => e.localName === "PartyIdentification")) { const id = cocuk(pi, "ID"); if (id && /^(VKN|TCKN)$/i.test(id.getAttribute("schemeID") || "")) vergi = id.textContent.trim(); }
    const kalemler = yerel(kok, "InvoiceLine").map(l => {
      const adet = sayiCoz(ilk(l, "InvoicedQuantity")) || 0;
      const urun = cocuk(l, "Item");
      const net = sayiCoz(ilk(l, "LineExtensionAmount"));
      const birim = sayiCoz(ilk(l, "Price", "PriceAmount"));
      let kdv = 20;
      const vergiler = yerel(l, "TaxSubtotal").map(t => ({ tur: ilk(t, "TaxCategory", "TaxScheme", "TaxTypeCode"), oran: ilk(t, "Percent") })).find(t => t.tur === "0015" || t.tur === "");
      if (vergiler && vergiler.oran !== "") kdv = sayiCoz(vergiler.oran);
      let barkod = "";
      if (urun) {
        const std = cocuk(urun, "StandardItemIdentification"), sat = cocuk(urun, "SellersItemIdentification"), alici = cocuk(urun, "BuyersItemIdentification");
        barkod = (std && ilk(std, "ID")) || (sat && ilk(sat, "ID")) || (alici && ilk(alici, "ID")) || "";
      }
      return { barkod, ad: urun ? (ilk(urun, "Name") || ilk(urun, "Description")) : "", adet, fiyat: adet ? (net ? Math.round(net / adet * 10000) / 10000 : birim) : birim, kdv };
    }).filter(k => k.ad || k.barkod);
    return { fatura_no: ilk(kok, "ID"), tarih: tarihCoz(ilk(kok, "IssueDate")), tedarikci: { ad, vergi_no: vergi }, kalemler };
  }

  // ---------- Excel / CSV ----------
  const sade = s => String(s || "").toLocaleLowerCase("tr").replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c").replace(/[^a-z0-9]/g, "");
  const SUTUN = {
    barkod: ["barkod", "barkodno", "urunkodu", "stokkodu", "kod", "malkodu"],
    ad: ["urunadi", "malhizmet", "malhizmetadi", "aciklama", "urun", "stokadi", "ad", "isim", "malinciniadi"],
    adet: ["miktar", "adet", "mik"],
    fiyat: ["birimfiyat", "birimfiyati", "fiyat", "alisfiyati", "netfiyat", "birimtutar"],
    kdv: ["kdv", "kdvorani", "kdv%", "kdvyuzde"]
  };
  function tabloOku(satirlar) {
    let bas = -1, kolon = {};
    for (let i = 0; i < Math.min(20, satirlar.length); i++) {
      const bul = {};
      satirlar[i].forEach((h, j) => { const x = sade(h); for (const [k, adaylar] of Object.entries(SUTUN)) if (bul[k] === undefined && adaylar.includes(x)) bul[k] = j; });
      if (bul.ad !== undefined && (bul.adet !== undefined || bul.fiyat !== undefined)) { bas = i; kolon = bul; break; }
    }
    if (bas < 0) throw new Error("Excel'de başlık satırı bulunamadı. Sütunlar: Barkod, Ürün adı, Miktar, Birim fiyat, KDV");
    const al = (s, k) => (kolon[k] === undefined ? "" : s[kolon[k]]);
    const kalemler = satirlar.slice(bas + 1).map(s => ({ barkod: String(al(s, "barkod") || "").trim(), ad: String(al(s, "ad") || "").trim(), adet: sayiCoz(al(s, "adet")) || 1, fiyat: sayiCoz(al(s, "fiyat")), kdv: al(s, "kdv") === "" ? 20 : sayiCoz(al(s, "kdv")) })).filter(k => k.ad || k.barkod);
    return { fatura_no: "", tarih: "", tedarikci: { ad: "", vergi_no: "" }, kalemler };
  }

  // ---------- PDF (metin içeren; taranmış resim PDF okunamaz) ----------
  let pdfYuklendi = null;
  function pdfKutuphane() {
    if (window.pdfjsLib) return Promise.resolve();
    if (pdfYuklendi) return pdfYuklendi;
    pdfYuklendi = new Promise((tamam, hata) => {
      const s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";
      s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js"; tamam(); };
      s.onerror = () => { pdfYuklendi = null; hata(new Error("PDF okuyucu indirilemedi (internet gerekir). XML veya Excel dosyasını deneyin")); };
      document.head.appendChild(s);
    });
    return pdfYuklendi;
  }
  async function pdfSatirlari(tampon) {
    await pdfKutuphane();
    const pdf = await window.pdfjsLib.getDocument({ data: tampon }).promise;
    const satirlar = [];
    for (let p = 1; p <= pdf.numPages; p++) {
      const sayfa = await pdf.getPage(p), icerik = await sayfa.getTextContent();
      const gruplar = [];
      icerik.items.filter(i => i.str && i.str.trim()).forEach(i => {
        const y = i.transform[5], x = i.transform[4];
        let g = gruplar.find(q => Math.abs(q.y - y) < 3);
        if (!g) { g = { y, ogeler: [] }; gruplar.push(g); }
        g.ogeler.push({ x, son: x + (i.width || 0), s: i.str.trim() });
      });
      gruplar.sort((a, b) => b.y - a.y).forEach(g => {
        g.ogeler.sort((a, b) => a.x - b.x);
        let t = "", onceki = null;
        g.ogeler.forEach(o => { t += (onceki === null ? "" : (o.x - onceki > 6 ? "  " : " ")) + o.s; onceki = o.son; });
        satirlar.push(t);
      });
    }
    return satirlar;
  }
  const SAYI_HUCRE = /^%?\s*-?\d[\d.,]*\s*(%|TL|TRY|₺)?$/i;
  function pdfCoz(satirlar) {
    const tum = satirlar.join("\n");
    const sonuc = { fatura_no: "", tarih: "", tedarikci: { ad: "", vergi_no: "" }, kalemler: [], uyari: "PDF'den okundu: satırları ve eşleşmeleri mutlaka kontrol edin." };
    const no = /(?:Fatura\s*No|Belge\s*No|Fatura\s*Numaras[ıi])\s*[:\-]?\s*([A-Za-z0-9\-\/]{4,})/i.exec(tum); if (no) sonuc.fatura_no = no[1];
    const tar = /(?:Fatura\s*Tarihi|D[üu]zenlenme\s*Tarihi|Tarih)\s*[:\-]?\s*(\d{1,2}[.\/-]\d{1,2}[.\/-]\d{4})/i.exec(tum) || /(\d{2}[.\/-]\d{2}[.\/-]\d{4})/.exec(tum); if (tar) sonuc.tarih = tarihCoz(tar[1]);
    const vk = /(?:VKN|Vergi\s*(?:Kimlik\s*)?(?:No|Numaras[ıi]))\s*[:\-]?\s*(\d{10,11})/i.exec(tum); if (vk) sonuc.tedarikci.vergi_no = vk[1];
    sonuc.tedarikci.ad = (satirlar.find(s => /[A-Za-zÇĞİÖŞÜçğıöşü]{3,}/.test(s) && !/fatura|sayın|tarih|e-ar/i.test(s)) || "").split(/\s{2,}/)[0].trim();
    for (const satir of satirlar) {
      const hucre = satir.split(/\s{2,}/).map(h => h.trim()).filter(Boolean);
      const sayilar = hucre.filter(h => SAYI_HUCRE.test(h));
      if (sayilar.length < 3) continue;
      const adHucre = hucre.find(h => !SAYI_HUCRE.test(h) && /[A-Za-zÇĞİÖŞÜçğıöşü]{3,}/.test(h) && !/^(adet|kg|lt|mt|paket|koli|takim)$/i.test(h) && !/toplam|tutar|kdv|iskonto|vergi/i.test(h));
      if (!adHucre) continue;
      const degerler = hucre.slice(hucre.indexOf(adHucre) + 1).filter(h => SAYI_HUCRE.test(h)).map(h => ({ ham: h, n: sayiCoz(h) }));
      if (degerler.length < 2) continue;
      const kdvAday = degerler.find(d => /%/.test(d.ham));
      const sayisal = degerler.filter(d => d !== kdvAday);
      const adet = sayisal[0] ? sayisal[0].n : 1, fiyat = sayisal[1] ? sayisal[1].n : 0;
      if (!(adet > 0)) continue;
      const bk = hucre.find(h => /^\d{8,14}$/.test(h)) || "";
      sonuc.kalemler.push({ barkod: bk, ad: adHucre.replace(/^\d+\s+(?=\D)/, ""), adet, fiyat, kdv: kdvAday ? kdvAday.n : 20 });
    }
    if (!sonuc.kalemler.length) throw new Error("PDF'de ürün satırı bulunamadı (taranmış resim olabilir). XML veya Excel dosyasını deneyin");
    return sonuc;
  }

  async function dosyadanOku(dosya) {
    const ad = dosya.name.toLowerCase();
    if (ad.endsWith(".xml")) return xmlOku(await dosya.text());
    if (ad.endsWith(".xlsx") || ad.endsWith(".csv") || ad.endsWith(".txt")) return tabloOku(await urunDosyasiOku(dosya));
    if (ad.endsWith(".pdf")) return pdfCoz(await pdfSatirlari(await dosya.arrayBuffer()));
    throw new Error("Desteklenen dosyalar: .xml (e-Fatura), .xlsx, .csv, .pdf");
  }
  return { dosyadanOku, xmlOku, tabloOku, pdfCoz, pdfSatirlari };
})();
