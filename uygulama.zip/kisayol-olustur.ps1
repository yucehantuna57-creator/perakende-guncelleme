﻿# Masaüstüne "Perakende Satış" simgesi koyar. Simgeye tıklayınca sunucu arka planda açılır,
# uygulama penceresi gelir, yeni sürüm varsa uygulama içinde güncellensin mi diye sorulur.
# Her kasa bilgisayarında bir kez çalıştırılır: kisayol-olustur.bat
$klasor = $PSScriptRoot
$masaustu = [Environment]::GetFolderPath("Desktop")
$yol = Join-Path $masaustu "Perakende Satış.lnk"

# Önce kendi pencereli masaüstü uygulaması (runtime\PerakendeSatis.exe), yoksa tarayıcı penceresiyle açan eski yöntem
$uygulamaExe = Join-Path $klasor "runtime\PerakendeSatis.exe"
$kabuk = New-Object -ComObject WScript.Shell
$kisayol = $kabuk.CreateShortcut($yol)
if (Test-Path $uygulamaExe) {
  $kisayol.TargetPath = $uygulamaExe
  $kisayol.Arguments = ""
  $kisayol.WindowStyle = 1
} else {
  $node = (Get-Command node -ErrorAction SilentlyContinue).Source
  if (-not $node) { Write-Error "Node.js bulunamadı. Önce Node.js kurun."; exit 1 }
  $kisayol.TargetPath = $node
  $kisayol.Arguments = "baslat.js"
  $kisayol.WindowStyle = 7   # simge durumunda: siyah pencere görünmez
}
$kisayol.WorkingDirectory = $klasor
$kisayol.IconLocation = (Join-Path $klasor "ikon.ico")
$kisayol.Description = "Perakende Satış uygulamasını başlatır"
$kisayol.Save()
Write-Output "Kısayol oluşturuldu: $yol"
