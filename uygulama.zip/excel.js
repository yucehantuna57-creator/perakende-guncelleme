// Excel / CSV ile toplu ürün yükleme (Ayarlar). Ek program gerekmez: .xlsx dosyası tarayıcıda açılır (zip + XML),
// .csv dosyası da desteklenir. Sütunlar: Barkod, Ürün adı, Kategori, Satış fiyatı, Alış fiyatı, KDV %, Stok, Kritik stok.
// Yeni barkod → yeni ürün (stok açılış stoğu olur); kayıtlı barkod → ürün bilgileri güncellenir (stok değişmez).

const EXCEL_SUTUNLARI = ["Barkod", "Ürün adı", "Kategori", "Satış fiyatı", "Alış fiyatı", "KDV %", "Stok", "Kritik stok"];

// ---------- Dosya okuma ----------
async function zipDosyalari(tampon) {
  const v = new DataView(tampon), b = new Uint8Array(tampon);
  let son = -1;
  for (let i = b.length - 22; i >= Math.max(0, b.length - 70000); i--) { if (v.getUint32(i, true) === 0x06054b50) { son = i; break; } }
  if (son < 0) throw new Error("Geçerli bir Excel (.xlsx) dosyası değil");
  const adet = v.getUint16(son + 10, true);
  let konum = v.getUint32(son + 16, true);
  const dosyalar = {};
  const metin = new TextDecoder("utf-8");
  for (let i = 0; i < adet; i++) {
    if (v.getUint32(konum, true) !== 0x02014b50) break;
    const yontem = v.getUint16(konum + 10, true), boyut = v.getUint32(konum + 20, true);
    const adUzun = v.getUint16(konum + 28, true), ekUzun = v.getUint16(konum + 30, true), yorumUzun = v.getUint16(konum + 32, true);
    const yerel = v.getUint32(konum + 42, true);
    const ad = metin.decode(b.subarray(konum + 46, konum + 46 + adUzun));
    konum += 46 + adUzun + ekUzun + yorumUzun;
    if (!/^xl\/(sharedStrings\.xml|workbook\.xml|_rels\/workbook\.xml\.rels|worksheets\/[^/]+\.xml)$/.test(ad)) continue;
    const veriBas = yerel + 30 + v.getUint16(yerel + 26, true) + v.getUint16(yerel + 28, true);
    const ham = b.subarray(veriBas, veriBas + boyut);
    if (yontem === 0) dosyalar[ad] = metin.decode(ham);
    else if (yontem === 8) {
      const akis = new Blob([ham]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      dosyalar[ad] = metin.decode(await new Response(akis).arrayBuffer());
    }
  }
  return dosyalar;
}

function sutunNo(ref) {
  let n = 0;
  for (const c of String(ref).replace(/[0-9]/g, "").toUpperCase()) n = n * 26 + (c.charCodeAt(0) - 64);
  return n - 1;
}

async function xlsxOku(tampon) {
  const d = await zipDosyalari(tampon);
  const xml = s => new DOMParser().parseFromString(s, "application/xml");
  const ortak = [];
  if (d["xl/sharedStrings.xml"]) {
    xml(d["xl/sharedStrings.xml"]).querySelectorAll("si").forEach(si => { ortak.push([...si.querySelectorAll("t")].map(t => t.textContent).join("")); });
  }
  // İlk sayfa: workbook ilişkilerinden bulunur, yoksa ilk worksheet
  let sayfaAdi = Object.keys(d).filter(k => k.startsWith("xl/worksheets/")).sort()[0];
  try {
    const wb = xml(d["xl/workbook.xml"]), ilis = xml(d["xl/_rels/workbook.xml.rels"]);
    const id = wb.querySelector("sheet").getAttribute("r:id");
    const hedef = [...ilis.querySelectorAll("Relationship")].find(r => r.getAttribute("Id") === id).getAttribute("Target");
    const yol = "xl/" + hedef.replace(/^\/?(xl\/)?/, "");
    if (d[yol]) sayfaAdi = yol;
  } catch (e) { /* ilk sayfa kullanılır */ }
  if (!sayfaAdi) throw new Error("Excel dosyasında sayfa bulunamadı");
  const satirlar = [];
  xml(d[sayfaAdi]).querySelectorAll("sheetData > row").forEach(row => {
    const s = [];
    row.querySelectorAll("c").forEach(c => {
      const tur = c.getAttribute("t"), no = sutunNo(c.getAttribute("r") || "A1");
      let deger = "";
      if (tur === "s") deger = ortak[Number((c.querySelector("v") || {}).textContent)] || "";
      else if (tur === "inlineStr") deger = [...c.querySelectorAll("t")].map(t => t.textContent).join("");
      else { const v = c.querySelector("v"); deger = v ? v.textContent : ""; }
      s[no] = deger;
    });
    satirlar.push(Array.from(s, x => x === undefined ? "" : x));
  });
  return satirlar;
}

function csvOku(tampon) {
  let metin = new TextDecoder("utf-8").decode(tampon);
  if (metin.includes("�")) metin = new TextDecoder("windows-1254").decode(tampon);
  metin = metin.replace(/^﻿/, "");
  const ilk = metin.split(/\r?\n/)[0] || "";
  const ayirac = (ilk.match(/;/g) || []).length >= (ilk.match(/,/g) || []).length ? ";" : ",";
  const satirlar = []; let satir = [], hucre = "", tirnak = false;
  for (let i = 0; i < metin.length; i++) {
    const c = metin[i];
    if (tirnak) { if (c === '"') { if (metin[i + 1] === '"') { hucre += '"'; i++; } else tirnak = false; } else hucre += c; }
    else if (c === '"') tirnak = true;
    else if (c === ayirac) { satir.push(hucre); hucre = ""; }
    else if (c === "\n") { satir.push(hucre.replace(/\r$/, "")); satirlar.push(satir); satir = []; hucre = ""; }
    else hucre += c;
  }
  if (hucre !== "" || satir.length) { satir.push(hucre.replace(/\r$/, "")); satirlar.push(satir); }
  return satirlar;
}

async function urunDosyasiOku(dosya) {
  const tampon = await dosya.arrayBuffer();
  if (/\.xlsx$/i.test(dosya.name)) return xlsxOku(tampon);
  if (/\.csv$/i.test(dosya.name) || /\.txt$/i.test(dosya.name)) return csvOku(tampon);
  if (/\.xls$/i.test(dosya.name)) throw new Error("Eski .xls biçimi desteklenmiyor. Excel'de 'Farklı kaydet' ile .xlsx seçin");
  throw new Error("Yalnızca .xlsx veya .csv dosyası yüklenebilir");
}

// ---------- Satırları ürüne çevirme ----------
const sade = s => String(s || "").toLocaleLowerCase("tr").replace(/ı/g, "i").replace(/ş/g, "s").replace(/ğ/g, "g").replace(/ü/g, "u").replace(/ö/g, "o").replace(/ç/g, "c").replace(/[^a-z0-9]/g, "");
const BASLIK_ESLEME = {
  barkod: ["barkod", "barkodno", "kod", "urunkodu", "stokkodu"],
  ad: ["urunadi", "urun", "ad", "isim", "urunismi", "aciklama", "stokadi"],
  kategori: ["kategori", "grup", "kategoriadi"],
  satis: ["satisfiyati", "satis", "fiyat", "satisfiyat", "birimfiyat"],
  alis: ["alisfiyati", "alis", "alisfiyat", "maliyet"],
  kdv: ["kdv", "kdvorani", "kdv%", "kdv"],
  stok: ["stok", "miktar", "adet", "mevcut", "stokmiktari"],
  kritik: ["kritikstok", "kritik", "minstok", "minimumstok"]
};
function sayiOku(x) {
  let s = String(x === undefined || x === null ? "" : x).trim().replace(/\s/g, "").replace(/[₺%]|tl/gi, "");
  if (s === "") return null;
  if (s.includes(",") && s.includes(".")) s = s.replace(/\./g, "").replace(",", ".");
  else if (s.includes(",")) s = s.replace(",", ".");
  const n = Number(s);
  return Number.isFinite(n) ? n : NaN;
}
function barkodOku(x) {
  let s = String(x === undefined || x === null ? "" : x).trim();
  if (/^\d+(\.\d+)?e\+?\d+$/i.test(s)) s = Number(s).toFixed(0);
  return s.replace(/\.0+$/, "");
}

// satirlar: dosyadan okunan ham tablo. Dönüş: { kayitlar:[{satir, barkod, ad, ...}], hatalar:[{satir, mesaj}] }
function urunSatirlariniCoz(satirlar, mevcutBarkodlar) {
  if (!satirlar.length) throw new Error("Dosya boş");
  const baslik = satirlar[0].map(sade);
  const kolon = {};
  for (const [alan, adaylar] of Object.entries(BASLIK_ESLEME)) {
    const i = baslik.findIndex(h => adaylar.includes(h));
    if (i >= 0) kolon[alan] = i;
  }
  if (kolon.ad === undefined || kolon.satis === undefined) throw new Error("Başlık satırında en az 'Ürün adı' ve 'Satış fiyatı' sütunları olmalı. Şablonu indirip kullanın.");
  const kayitlar = [], hatalar = [], gorulen = new Set();
  satirlar.slice(1).forEach((s, i) => {
    const no = i + 2;
    if (s.every(h => String(h || "").trim() === "")) return;
    const al = alan => (kolon[alan] === undefined ? "" : s[kolon[alan]]);
    const ad = String(al("ad") || "").trim();
    const satis = sayiOku(al("satis"));
    if (!ad) return hatalar.push({ satir: no, mesaj: "Ürün adı boş" });
    if (satis === null || Number.isNaN(satis) || satis < 0) return hatalar.push({ satir: no, mesaj: "Satış fiyatı geçersiz" });
    const alis = sayiOku(al("alis")), kdv = sayiOku(al("kdv")), stok = sayiOku(al("stok")), kritik = sayiOku(al("kritik"));
    for (const [ad2, d] of [["Alış fiyatı", alis], ["KDV", kdv], ["Stok", stok], ["Kritik stok", kritik]]) if (Number.isNaN(d)) return hatalar.push({ satir: no, mesaj: ad2 + " sayı olmalı" });
    const barkod = barkodOku(al("barkod"));
    if (barkod && gorulen.has(barkod)) return hatalar.push({ satir: no, mesaj: "Aynı barkod dosyada tekrar ediyor (" + barkod + ")" });
    if (barkod) gorulen.add(barkod);
    kayitlar.push({ satir: no, barkod, ad, kategori: String(al("kategori") || "").trim(), satis, alis: alis === null ? 0 : alis, kdv: kdv === null ? 20 : kdv, stok: stok === null ? 0 : stok, kritik: kritik === null ? 0 : kritik, mevcut: !!(barkod && mevcutBarkodlar.has(barkod)) });
  });
  return { kayitlar, hatalar };
}

// ---------- İçe aktarma ----------
function urunleriIceAktar(kayitlar) {
  const kategoriler = DB.liste("kategoriler");
  const kategoriId = ad => {
    if (!ad) return null;
    let k = kategoriler.find(x => String(x.ad).toLocaleLowerCase("tr") === ad.toLocaleLowerCase("tr"));
    if (!k) { k = DB.ekle("kategoriler", { ad: ad.slice(0, 30) }); kategoriler.push(k); }
    return k.id;
  };
  const urunler = DB.liste("urunler");
  let sonKod = Math.max(0, ...urunler.map(u => /^U\d+$/.test(u.barkod || "") ? Number(u.barkod.slice(1)) : 0));
  const yeniler = [], guncellenen = [];
  for (const k of kayitlar) {
    const kid = kategoriId(k.kategori);
    const mevcut = k.mevcut && urunler.find(u => u.barkod === k.barkod);
    if (mevcut) {
      DB.guncelle("urunler", mevcut.id, { ad: k.ad, kategori_id: k.kategori ? kid : mevcut.kategori_id, satis_fiyati: k.satis, alis_fiyati: k.alis, kdv_orani: k.kdv, kritik_stok: k.kritik, aktif: 1 });
      guncellenen.push(mevcut.id);
    } else {
      const barkod = k.barkod || "U" + String(++sonKod).padStart(6, "0");
      yeniler.push({ barkod, ad: k.ad, kategori_id: kid, satis_fiyati: k.satis, alis_fiyati: k.alis, kdv_orani: k.kdv, birim: "adet", stok: k.stok, kritik_stok: k.kritik, aktif: 1 });
    }
  }
  const eklenen = yeniler.length ? DB.topluEkle("urunler", yeniler) : [];
  const hareketler = eklenen.filter(u => u.stok > 0).map(u => ({ urun_id: u.id, tur: "giris", miktar: u.stok, aciklama: "Toplu yükleme açılış stoğu", kullanici_id: aktifKullanici ? aktifKullanici.id : null, tarih: new Date().toISOString() }));
  if (hareketler.length) DB.topluEkle("stok_hareketleri", hareketler);
  return { yeni: eklenen.length, guncellenen: guncellenen.length };
}

// ---------- Şablon ----------
function urunSablonuIndir() {
  const satirlar = [
    EXCEL_SUTUNLARI,
    ["8690001000001", "Süt 1 L", "Süt", "42,50", "35", "20", "50", "10"],
    ["8690001000002", "Ekmek", "Ekmek", "12", "8", "1", "60", "15"],
    ["", "Barkodsuz ürün örneği", "", "25", "18", "20", "10", "2"]
  ];
  const csv = "﻿" + satirlar.map(s => s.map(h => /[;"\n]/.test(h) ? '"' + h.replace(/"/g, '""') + '"' : h).join(";")).join("\r\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  a.download = "urun-sablonu.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- Pencere ----------
function topluUrunAc() {
  if (!aktifKullanici || aktifKullanici.rol !== "yonetici") return;
  let cozum = null;
  modalAc(`
    <div class="modal-baslik">Excel ile toplu ürün yükle</div>
    <div class="form" style="margin-top:10px">
      <p class="tam" style="font-size:13px;opacity:.8;margin:0">Excel'de (.xlsx) veya CSV dosyasında sütunlar: <strong>${EXCEL_SUTUNLARI.join(", ")}</strong>. Zorunlu olanlar <strong>Ürün adı</strong> ve <strong>Satış fiyatı</strong>. Barkod boşsa otomatik verilir. Kategori yoksa oluşturulur. Barkodu kayıtlı olan ürünlerin bilgileri güncellenir (stok değişmez).</p>
      <div class="filtre tam"><button type="button" class="btn" id="tu-sablon">Şablonu indir</button>
        <label class="btn" style="cursor:pointer">Dosya seç (.xlsx / .csv)<input id="tu-dosya" type="file" accept=".xlsx,.csv,.txt" hidden></label></div>
      <div id="tu-sonuc" class="tam"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="tu-vazgec">Kapat</button><button type="button" class="btn ana" id="tu-aktar" disabled>İçe aktar</button></div>
    </div>`, true);
  $("tu-vazgec").addEventListener("click", modalKapat);
  $("tu-sablon").addEventListener("click", urunSablonuIndir);
  $("tu-dosya").addEventListener("change", async e => {
    const dosya = e.target.files[0];
    $("tu-aktar").disabled = true; cozum = null;
    if (!dosya) return;
    $("tu-sonuc").innerHTML = "<p>Dosya okunuyor...</p>";
    try {
      const mevcut = new Set(DB.liste("urunler").map(u => u.barkod).filter(Boolean));
      cozum = urunSatirlariniCoz(await urunDosyasiOku(dosya), mevcut);
    } catch (err) { $("tu-sonuc").innerHTML = `<p class="hata">${kac("", err.message)}</p>`; return; }
    const yeni = cozum.kayitlar.filter(k => !k.mevcut).length, guncel = cozum.kayitlar.length - yeni;
    $("tu-sonuc").innerHTML = `
      <p><strong>${cozum.kayitlar.length}</strong> geçerli satır: <strong>${yeni}</strong> yeni ürün, <strong>${guncel}</strong> güncelleme${cozum.hatalar.length ? `, <span class="hata">${cozum.hatalar.length} hatalı satır (atlanacak)</span>` : ""}.</p>
      <div style="max-height:220px;overflow:auto"><table class="tablo"><tr><th>Satır</th><th>Barkod</th><th>Ürün</th><th>Kategori</th><th class="sag">Satış</th><th class="sag">Stok</th><th>Durum</th></tr>
      ${cozum.kayitlar.slice(0, 50).map(k => `<tr><td>${k.satir}</td><td>${kac("", k.barkod || "otomatik")}</td><td>${kac("", k.ad)}</td><td>${kac("", k.kategori || "—")}</td><td class="sag">${para(k.satis)}</td><td class="sag">${k.stok}</td><td>${k.mevcut ? "Güncellenecek" : "Yeni"}</td></tr>`).join("")}
      ${cozum.hatalar.slice(0, 30).map(h => `<tr><td>${h.satir}</td><td colspan="5" class="hata">${kac("", h.mesaj)}</td><td>Atlanacak</td></tr>`).join("")}
      </table></div>${cozum.kayitlar.length > 50 ? `<p style="font-size:12px;opacity:.7">İlk 50 satır gösteriliyor, tümü içe aktarılacak.</p>` : ""}`;
    $("tu-aktar").disabled = cozum.kayitlar.length === 0;
  });
  $("tu-aktar").addEventListener("click", () => {
    if (!cozum || !cozum.kayitlar.length) return;
    const s = urunleriIceAktar(cozum.kayitlar);
    modalKapat();
    kasaUrunleriCiz();
    bildir(`${s.yeni} ürün eklendi, ${s.guncellenen} ürün güncellendi`);
  });
}

// ---------- Barkod birleştirme ----------
// Dosyadaki (Barkod, Ürün Adı, Stok Kodu, Tür) satırlarını stoktaki ürünlerle eşleştirir ve ürünlerin barkodunu dosyadakiyle günceller.
// Eşleştirme sırası: aynı barkod → aynı stok kodu → aynı ürün adı (yalnızca stokta tek ise). Ürün silinmez, yeni ürün eklenmez.
function barkodBirlestirPlani(satirlar) {
  const baslik = satirlar[0].map(sade);
  const bul = (...adaylar) => baslik.findIndex(h => adaylar.includes(h));
  const iF = bul("satisfiyatikdvdahil", "satisfiyati", "satis", "fiyat"), iB = bul("barkod", "barkodno"), iA = bul("urunadi", "urun", "ad", "stokadi"), iK = bul("stokkodu", "kod"), iT = bul("tur");
  if (iB < 0 || iA < 0) throw new Error("Başlık satırında 'Barkod' ve 'Ürün Adı' sütunları olmalı");
  const urunler = DB.liste("urunler", u => u.aktif !== 0 && !u.silindi);
  const barkodlari = new Map(urunler.map(u => [String(u.barkod || ""), u]));
  const adlari = new Map();
  urunler.forEach(u => { const k = sade(u.ad); if (!adlari.has(k) || (Number(u.stok) || 0) > (Number(adlari.get(k).stok) || 0)) adlari.set(k, u); }); // aynı adlı birden çok ürün varsa stoğu çok olan esas alınır
  const kullanilan = new Set(), degisecek = [], ayni = [], eslesmeyen = [], cakisan = [], yeniler = [], gorulenYeni = new Set();
  satirlar.slice(1).forEach((s, i) => {
    if (s.every(h => String(h || "").trim() === "")) return;
    const b = barkodOku(s[iB]), ad = String(s[iA] || "").trim(), kod = iK >= 0 ? String(s[iK] || "").trim() : "";
    const barkodlu = iT < 0 || /barkodlu/i.test(String(s[iT] || "")) && !/sadece/i.test(String(s[iT] || ""));
    const yeniBarkod = barkodlu && b ? b : (kod || b);
    if (!ad || !yeniBarkod) return;
    const u = barkodlari.get(b) || (kod && barkodlari.get(kod)) || adlari.get(sade(ad)) || null;
    const fiyat = iF >= 0 ? sayiOku(s[iF]) : null;
    if (!u) {
      // Stokta yok: yeni ürün olarak eklenecek (aynı barkod ya da aynı ad dosyada tekrar ediyorsa bir kez)
      const an = sade(ad);
      if (gorulenYeni.has(yeniBarkod) || gorulenYeni.has("ad:" + an)) return eslesmeyen.push({ satir: i + 2, ad, barkod: yeniBarkod, neden: "dosyada tekrar" });
      gorulenYeni.add(yeniBarkod); gorulenYeni.add("ad:" + an);
      return yeniler.push({ satir: i + 2, ad, barkod: yeniBarkod, satis: fiyat === null || Number.isNaN(fiyat) ? 0 : fiyat });
    }
    if (kullanilan.has(u.id)) return;
    kullanilan.add(u.id);
    if (String(u.barkod) === yeniBarkod) return ayni.push(u.id);
    const baskasi = barkodlari.get(yeniBarkod);
    if (baskasi && baskasi.id !== u.id) return cakisan.push({ satir: i + 2, ad: u.ad, barkod: yeniBarkod, baska: baskasi.ad });
    degisecek.push({ id: u.id, ad: u.ad, eski: u.barkod || "—", yeni: yeniBarkod, satis: fiyat === null || Number.isNaN(fiyat) ? null : fiyat, eskiSatis: u.satis_fiyati });
  });
  return { degisecek, ayni, eslesmeyen, cakisan, yeniler };
}
function barkodBirlestirAc() {
  if (!aktifKullanici || aktifKullanici.rol !== "yonetici") return;
  let plan = null;
  modalAc(`
    <div class="modal-baslik">Barkodları birleştir (Excel)</div>
    <div class="form" style="margin-top:10px">
      <p class="tam" style="font-size:13px;opacity:.8;margin:0">Excel dosyasındaki barkodlar stoktaki ürünlerle eşleştirilir ve ürünlerin barkodu dosyadakiyle güncellenir. Sütunlar: <strong>Barkod, Ürün Adı, Stok Kodu, Tür</strong>. Ürün silinmez, yeni ürün eklenmez; eşleşmeyenler listelenir.</p>
      <label class="onay-kutusu tam"><input type="checkbox" id="bb-yeni" checked> Stokta olmayan ürünleri yeni ürün olarak ekle (stok 0, KDV %20)</label>
      <label class="onay-kutusu tam"><input type="checkbox" id="bb-fiyat"> Eşleşen ürünlerin satış fiyatını da dosyadakiyle güncelle</label>
      <div class="filtre tam"><label class="btn" style="cursor:pointer">Dosya seç (.xlsx)<input id="bb-dosya" type="file" accept=".xlsx,.csv" hidden></label></div>
      <div id="bb-sonuc" class="tam"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="bb-kapat">Kapat</button><button type="button" class="btn ana" id="bb-uygula" disabled>Barkodları güncelle</button></div>
    </div>`, true);
  $("bb-kapat").addEventListener("click", modalKapat);
  $("bb-dosya").addEventListener("change", async e => {
    const dosya = e.target.files[0]; $("bb-uygula").disabled = true; plan = null;
    if (!dosya) return;
    $("bb-sonuc").innerHTML = "<p>Dosya okunuyor...</p>";
    try { plan = barkodBirlestirPlani(await urunDosyasiOku(dosya)); } catch (err) { $("bb-sonuc").innerHTML = `<p class="hata">${kac("", err.message)}</p>`; return; }
    const tablo = (l, b) => l.length ? `<div style="max-height:200px;overflow:auto;margin-top:6px"><table class="tablo">${l.slice(0, 40).map(b).join("")}</table></div>${l.length > 40 ? `<small>İlk 40 satır gösteriliyor</small>` : ""}` : "";
    $("bb-sonuc").innerHTML = `<p><strong>${plan.degisecek.length}</strong> ürünün barkodu değişecek · <strong>${plan.ayni.length}</strong> zaten aynı · <strong>${plan.yeniler.length}</strong> yeni ürün eklenecek · <strong>${plan.cakisan.length}</strong> çakışma (atlanır)</p>
      ${tablo(plan.degisecek, x => `<tr><td>${kac("", x.ad)}</td><td>${kac("", x.eski)}</td><td>→</td><td><b>${kac("", x.yeni)}</b></td></tr>`)}
      ${plan.cakisan.length ? `<p class="hata" style="margin:8px 0 0">Bu barkod başka üründe kayıtlı:</p>${tablo(plan.cakisan, x => `<tr><td>${kac("", x.ad)}</td><td>${kac("", x.barkod)}</td><td>${kac("", x.baska)}</td></tr>`)}` : ""}
      ${plan.yeniler.length ? `<p style="margin:8px 0 0">Yeni eklenecekler:</p>${tablo(plan.yeniler, x => `<tr><td>${x.satir}</td><td>${kac("", x.ad)}</td><td>${kac("", x.barkod)}</td><td>${para(x.satis)}</td></tr>`)}` : ""}${plan.eslesmeyen.length ? `<p style="margin:8px 0 0">Dosyada tekrar edenler (atlandı): ${plan.eslesmeyen.length}</p>` : ""}`;
    $("bb-uygula").disabled = !plan.degisecek.length && !plan.yeniler.length;
  });
  $("bb-uygula").addEventListener("click", async () => {
    if (!plan) return;
    const yeniEkle = $("bb-yeni").checked, fiyatYaz = $("bb-fiyat").checked;
    const yeniler = yeniEkle ? plan.yeniler : [];
    if (!plan.degisecek.length && !yeniler.length) return;
    if (!await kucukPencere({ baslik: "Uygulansın mı?", mesaj: plan.degisecek.length + " ürünün barkodu güncellenecek" + (fiyatYaz ? " (satış fiyatı da)" : "") + ", " + yeniler.length + " yeni ürün eklenecek. Mevcut ürünler ve stok miktarları silinmez.", evet: "Uygula" })) return;
    plan.degisecek.forEach(x => DB.guncelle("urunler", x.id, { barkod: x.yeni, ...(fiyatYaz && x.satis !== null ? { satis_fiyati: x.satis } : {}) }));
    if (yeniler.length) DB.topluEkle("urunler", yeniler.map(x => ({ barkod: x.barkod, ad: x.ad, kategori_id: null, satis_fiyati: x.satis, alis_fiyati: 0, kdv_orani: 20, birim: "adet", stok: 0, kritik_stok: 0, aktif: 1 })));
    modalKapat(); kasaUrunleriCiz(); if (aktifSayfa === "urunler") urunlerCizSayfa();
    bildir(plan.degisecek.length + " ürün güncellendi, " + yeniler.length + " yeni ürün eklendi");
  });
}
