// Uygulama güncelleme modülü.
// Güncelleme kaynağı (guncelleme-ayar.json → "kaynak") iki türde olabilir:
//   - klasör yolu (ağ paylaşımı, eşitlenen klasör): "../yayin" veya "\\\\sunucu\\yayin"
//   - web adresi: "https://ornek.com/perakende"
// Kaynakta iki dosya bulunur: surum.json (sürüm bilgisi, sha256) ve uygulama.zip (yeni dosyalar).
// Güncelleme sırasında data klasörü (veritabanı, yedekler) ve guncelleme-ayar.json asla değiştirilmez.
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const crypto = require("node:crypto");
const { execFileSync, spawn } = require("node:child_process");

const KOK = __dirname;
// Güncellemede dokunulmayan yerler: veriler, kaynak ayarı, eski sürüm yedeği ve kurulumla gelen Node çalışma ortamı (runtime)
// Varsayılan güncelleme adresi uygulamanın içindedir; kullanıcı ayrıca bir şey girmez
const VARSAYILAN_KAYNAK = "https://raw.githubusercontent.com/yucehantuna57-creator/perakende-guncelleme/main";
const KORUNAN = new Set(["data", "guncelleme-ayar.json", "onceki-surum", "node_modules", "runtime", "webview"]);
let islemde = false;

function surumOku() {
  try { return JSON.parse(fs.readFileSync(path.join(KOK, "surum.json"), "utf8")); }
  catch (e) { return { surum: "0.0.0", notlar: [], gecmis: [] }; }
}

function ayarOku() {
  try {
    const a = JSON.parse(fs.readFileSync(path.join(KOK, "guncelleme-ayar.json"), "utf8"));
    return { kaynak: a.kaynak || VARSAYILAN_KAYNAK };
  } catch (e) { return { kaynak: VARSAYILAN_KAYNAK }; }
}

// Güncelleme kaynağını kaydeder (uygulamadaki Ayarlar sayfasından). Boş bırakılırsa güncelleme kapalı olur.
function ayarYaz(kaynak) {
  const temiz = String(kaynak || "").trim();
  if (temiz.length > 500) throw new Error("Kaynak çok uzun");
  fs.writeFileSync(path.join(KOK, "guncelleme-ayar.json"), JSON.stringify({ kaynak: temiz }, null, 2) + "\n");
  return { kaynak: temiz };
}

// a > b ise pozitif, eşitse 0, küçükse negatif (1.10.0 > 1.9.0)
function karsilastir(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) {
    const fark = (pa[i] || 0) - (pb[i] || 0);
    if (fark) return fark;
  }
  return 0;
}

const uzakMi = kaynak => /^https?:\/\//i.test(kaynak);

// raw.githubusercontent.com yanıtları ~5 dakika önbellekte kalır (sorgu eklemek işe yaramaz). Bu yüzden GitHub kaynağında
// önce dalın son commit kimliği (sha) alınır, dosyalar o commit adresinden indirilir: her zaman en yeni sürüm görülür.
let shaOnbellek = { anahtar: "", sha: "", zaman: 0 };
async function githubSabitKaynak(kaynak) {
  const m = new RegExp("^https://raw\\.githubusercontent\\.com/([^/]+)/([^/]+)/([^/]+)/?$", "i").exec(kaynak.trim());
  if (!m) return kaynak;
  const anahtar = m.slice(1, 4).join("/");
  if (shaOnbellek.anahtar === anahtar && Date.now() - shaOnbellek.zaman < 60000) return `https://raw.githubusercontent.com/${m[1]}/${m[2]}/${shaOnbellek.sha}`;
  try {
    const y = await fetch(`https://api.github.com/repos/${m[1]}/${m[2]}/commits/${m[3]}`, { headers: { Accept: "application/vnd.github.sha", "User-Agent": "perakende-satis" }, signal: AbortSignal.timeout(10000) });
    const sha = (await y.text()).trim();
    if (!y.ok || !/^[0-9a-f]{40}$/.test(sha)) return kaynak;
    shaOnbellek = { anahtar, sha, zaman: Date.now() };
    return `https://raw.githubusercontent.com/${m[1]}/${m[2]}/${sha}`;
  } catch (e) { return kaynak; } // API'ye ulaşılamazsa (sınır, ağ) normal adres kullanılır
}

async function dosyaOku(kaynak, dosya) {
  if (uzakMi(kaynak)) {
    kaynak = await githubSabitKaynak(kaynak);
    const yanit = await fetch(kaynak.replace(/\/+$/, "") + "/" + dosya + "?t=" + Date.now(), { signal: AbortSignal.timeout(15000) });
    if (!yanit.ok) throw new Error(`${dosya} indirilemedi (${yanit.status})`);
    return Buffer.from(await yanit.arrayBuffer());
  }
  return fs.readFileSync(path.resolve(KOK, kaynak, dosya));
}

// Yeni sürüm var mı? Sürümler arasındaki tüm notlar birleştirilir.
async function kontrolEt() {
  const mevcut = surumOku().surum;
  const { kaynak } = ayarOku();
  if (!kaynak) return { durum: "kaynak-yok", mevcut };
  try {
    const m = JSON.parse((await dosyaOku(kaynak, "surum.json")).toString("utf8"));
    if (karsilastir(m.surum, mevcut) <= 0) return { durum: "guncel", mevcut };
    const yeniler = (m.gecmis || []).filter(g => karsilastir(g.surum, mevcut) > 0);
    const notlar = yeniler.length ? yeniler.flatMap(g => g.notlar || []) : (m.notlar || []);
    return { durum: "var", mevcut, yeni: m.surum, tarih: m.tarih, notlar };
  } catch (e) {
    // Yayın klasörü ya da surum.json henüz yoksa (hiç sürüm yayınlanmamış) bu bir hata değil, güncelleme yok demektir
    if (e.code === "ENOENT" || /404/.test(e.message)) return { durum: "guncel", mevcut };
    return { durum: "hata", mevcut, hata: e.message };
  }
}

function koruyarakKopyala(kaynakKlasor, hedefKlasor) {
  for (const ad of fs.readdirSync(kaynakKlasor)) {
    if (KORUNAN.has(ad)) continue;
    dosyaKopyala(path.join(kaynakKlasor, ad), path.join(hedefKlasor, ad));
  }
}

// fs.cpSync Windows'ta var olan dosyanın üzerine yazarken "file exists" hatası verebiliyor; dosyalar tek tek kopyalanır
function dosyaKopyala(kaynak, hedef) {
  if (fs.statSync(kaynak).isDirectory()) {
    fs.mkdirSync(hedef, { recursive: true });
    for (const ad of fs.readdirSync(kaynak)) dosyaKopyala(path.join(kaynak, ad), path.join(hedef, ad));
    return;
  }
  try { fs.chmodSync(hedef, 0o666); } catch (e) { /* hedef yoksa sorun değil */ }
  fs.copyFileSync(kaynak, hedef);
}

// Pakette masaüstü uygulamasının yeni hali (istemci klasörü) varsa runtime klasörüne ".yeni" adıyla bırakılır.
// Çalışan program kendi dosyasının üzerine yazamaz; PerakendeSatis.exe bir sonraki açılışta bunları yerine koyar.
function istemciHazirla() {
  const kaynak = path.join(KOK, "istemci");
  if (!fs.existsSync(kaynak)) return;
  const hedef = path.join(KOK, "runtime");
  fs.mkdirSync(hedef, { recursive: true });
  for (const ad of fs.readdirSync(kaynak)) fs.copyFileSync(path.join(kaynak, ad), path.join(hedef, ad + ".yeni"));
  fs.rmSync(kaynak, { recursive: true, force: true });
}

// Güncellemeyi indirir, doğrular, yedekler ve dosyaların üzerine yazar. Hata olursa eski dosyalara döner.
async function uygula() {
  if (islemde) throw new Error("Güncelleme zaten sürüyor");
  islemde = true;
  const gecici = fs.mkdtempSync(path.join(os.tmpdir(), "perakende-guncelleme-"));
  const onceki = path.join(KOK, "onceki-surum");
  let yedekAlindi = false;
  try {
    const { kaynak } = ayarOku();
    if (!kaynak) throw new Error("Güncelleme kaynağı ayarlanmamış");
    const manifest = JSON.parse((await dosyaOku(kaynak, "surum.json")).toString("utf8"));
    if (karsilastir(manifest.surum, surumOku().surum) <= 0) throw new Error("Zaten güncel sürümdesiniz");

    // 1) İndir ve bütünlüğünü doğrula
    const zipVeri = await dosyaOku(kaynak, manifest.dosya || "uygulama.zip");
    const ozet = crypto.createHash("sha256").update(zipVeri).digest("hex");
    if (manifest.sha256 && ozet !== manifest.sha256) throw new Error("İndirilen paket bozuk (sha256 uyuşmuyor)");
    // İmza: açık anahtar dosyası varsa imzasız ya da hatalı imzalı paket kurulmaz (depoya yetkisiz yazılan paketi engeller)
    const acikYolu = path.join(KOK, "imza-acik.pem");
    if (fs.existsSync(acikYolu)) {
      let gecerli = false;
      try { gecerli = !!manifest.sha256 && !!manifest.imza && crypto.verify(null, Buffer.from(`${manifest.surum}\n${ozet}`), crypto.createPublicKey(fs.readFileSync(acikYolu)), Buffer.from(manifest.imza, "base64")); } catch (e) { gecerli = false; }
      if (!gecerli) throw new Error("Paket imzası doğrulanamadı; güncelleme kurulmadı");
    }
    const zipYolu = path.join(gecici, "paket.zip");
    fs.writeFileSync(zipYolu, zipVeri);

    // 2) Paketi geçici klasöre aç
    const cikar = path.join(gecici, "yeni");
    execFileSync("powershell", ["-NoProfile", "-NonInteractive", "-Command",
      `Expand-Archive -LiteralPath '${zipYolu.replace(/'/g, "''")}' -DestinationPath '${cikar.replace(/'/g, "''")}' -Force`], { stdio: "pipe" });
    const acilanSurum = JSON.parse(fs.readFileSync(path.join(cikar, "surum.json"), "utf8")).surum;
    if (acilanSurum !== manifest.surum) throw new Error("Paketin sürümü beklenenle uyuşmuyor");

    // 3) Mevcut dosyaları yedekle (geri dönüş için)
    fs.rmSync(onceki, { recursive: true, force: true });
    fs.mkdirSync(onceki, { recursive: true });
    koruyarakKopyala(KOK, onceki);
    yedekAlindi = true;

    // 4) Yeni dosyaları yaz (data ve ayar dosyası korunur)
    koruyarakKopyala(cikar, KOK);
    istemciHazirla();
    if (surumOku().surum !== manifest.surum) throw new Error("Yazılan sürüm doğrulanamadı");
    return { yeni: manifest.surum };
  } catch (e) {
    if (yedekAlindi) {
      try { koruyarakKopyala(onceki, KOK); } catch (geriDonus) { /* eski dosyalar yerinde kalır */ }
    }
    throw e;
  } finally {
    islemde = false;
    fs.rmSync(gecici, { recursive: true, force: true });
  }
}

// Yeni sürümü ayrı bir süreç olarak başlatır, ardından bu süreç kapanır (port boşalınca yenisi dinlemeye başlar)
function yenidenBaslat() {
  spawn(process.execPath, ["server.js"], { cwd: KOK, detached: true, stdio: "ignore", windowsHide: true }).unref();
  setTimeout(() => process.exit(0), 300);
}

module.exports = { surumOku, ayarOku, ayarYaz, karsilastir, kontrolEt, uygula, yenidenBaslat, KORUNAN };
