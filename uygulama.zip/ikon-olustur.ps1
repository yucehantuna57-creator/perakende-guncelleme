﻿# Uygulama simgesini (ikon.ico) çizer: lacivert zemin üzerinde dört çubuk (açılış animasyonundaki logo).
# Kullanım: powershell -ExecutionPolicy Bypass -File ikon-olustur.ps1
Add-Type -AssemblyName System.Drawing

$boyut = 256
$bmp = New-Object System.Drawing.Bitmap $boyut, $boyut
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.Clear([System.Drawing.Color]::Transparent)

function Yuvarlak-Dikdortgen($x, $y, $w, $h, $r) {
  $p = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = $r * 2
  $p.AddArc($x, $y, $d, $d, 180, 90)
  $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
  $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
  $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
  $p.CloseFigure()
  return $p
}

# Zemin
$zemin = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 31, 58, 95))
$g.FillPath($zemin, (Yuvarlak-Dikdortgen 8 8 240 240 48))

# Çubuklar: yüksekliklerin oranı açılış animasyonuyla aynı (40, 70, 55, 100)
$oranlar = @(0.40, 0.70, 0.55, 1.00)
$renkler = @(
  [System.Drawing.Color]::FromArgb(255, 159, 180, 204),
  [System.Drawing.Color]::FromArgb(255, 159, 180, 204),
  [System.Drawing.Color]::FromArgb(255, 244, 162, 97),
  [System.Drawing.Color]::White
)
$genislik = 36; $aralik = 16; $taban = 196; $enYuksek = 130
$baslangic = (256 - (4 * $genislik + 3 * $aralik)) / 2
for ($i = 0; $i -lt 4; $i++) {
  $yuk = [int]($enYuksek * $oranlar[$i])
  $fircasi = New-Object System.Drawing.SolidBrush $renkler[$i]
  $g.FillPath($fircasi, (Yuvarlak-Dikdortgen ($baslangic + $i * ($genislik + $aralik)) ($taban - $yuk) $genislik $yuk 8))
}

$png = Join-Path $PSScriptRoot "ikon.png"
$bmp.Save($png, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()

# PNG'yi ICO kabına koy (Windows 7 ve sonrası PNG içeren simgeleri destekler)
$veri = [System.IO.File]::ReadAllBytes($png)
$ms = New-Object System.IO.MemoryStream
$w = New-Object System.IO.BinaryWriter $ms
$w.Write([uint16]0); $w.Write([uint16]1); $w.Write([uint16]1)         # ICONDIR
$w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0); $w.Write([byte]0)  # 256x256, renk sayısı, ayrılmış
$w.Write([uint16]1); $w.Write([uint16]32)                             # düzlem, bit derinliği
$w.Write([uint32]$veri.Length); $w.Write([uint32]22)                  # boyut, veri başlangıcı
$w.Write($veri)
[System.IO.File]::WriteAllBytes((Join-Path $PSScriptRoot "ikon.ico"), $ms.ToArray())
Remove-Item $png
Write-Output "ikon.ico oluşturuldu"
