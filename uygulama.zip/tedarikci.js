// Tedarikçi fiyat takibi (Yamanlar B2B / Entegre Ticaret altyapısı). TEST AŞAMASI: yalnızca okur ve karşılaştırır,
// hiçbir ürünün stoğu, alış ya da satış fiyatı değiştirilmez.
// Akış: bayi girişi (ASP.NET formu) → getItems.ashx ile tüm katalog sayfa sayfa → kayıt "tedarikci_katalog".
const SITE = "https://b2b.yamanlargrup.com.tr";
const TARAYICI = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36";
const SAYFA = 300;

function kur({ kayitOku, kayitYaz }) {
  // Barkod karşılaştırması: boşluk ve baştaki sıfırlar yok sayılır (ör. 0868... ile 868... aynı)
  const barkodAnahtar = b => String(b || "").replace(/D/g, "").replace(/^0+/, "");
  let durum = { calisiyor: false, mesaj: "", yuzde: 0 };

  // Çerezleri elde tutan basit istemci
  function oturum() {
    const cerez = new Map();
    const al = r => (r.headers.getSetCookie ? r.headers.getSetCookie() : []).forEach(c => { const [kv] = c.split(";"); const i = kv.indexOf("="); cerez.set(kv.slice(0, i).trim(), kv.slice(i + 1)); });
    return async (yol, secenek = {}) => {
      const r = await fetch(SITE + yol, {
        ...secenek, redirect: "manual", signal: AbortSignal.timeout(60000),
        headers: { "User-Agent": TARAYICI, Cookie: [...cerez].map(([k, v]) => k + "=" + v).join("; "), ...(secenek.headers || {}) }
      });
      al(r);
      return r;
    };
  }
  const coz = async r => new TextDecoder(/8859-9|1254/i.test(r.headers.get("content-type") || "") ? "windows-1254" : "utf-8").decode(await r.arrayBuffer());
  const xmlCoz = x => {
    const ust = (x.match(/<recs([^>]*)>/) || ["", ""])[1];
    const nit = n => (ust.match(new RegExp(n + '="([^"]*)"')) || [])[1];
    const alan = (r, n) => { const m = r.match(new RegExp("<" + n + ">([\\s\\S]*?)</" + n + ">")); return m ? m[1].replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").trim() : ""; };
    const sayi = s => Number(String(s || "").replace(/\./g, "").replace(",", ".")) || 0;
    const kayitlar = (x.match(/<rec>[\s\S]*?<\/rec>/g) || []).map(r => ({
      kod: alan(r, "CODE"), ad: alan(r, "NAME"), barkod: alan(r, "BARCODE").replace(/\s/g, ""),
      fiyat: Number(alan(r, "net_fiyat_tl")) || sayi(alan(r, "FIYAT_TL")), birim: alan(r, "UNIT"), marka: alan(r, "MAKE"),
      kucukGorsel: alan(r, "thumb_url"), gorsel: alan(r, "org_url") || alan(r, "thumb_url")
    }));
    return { kayitlar, toplamSayfa: Number(nit("totalPageCount")) || 1, toplam: Number(nit("recNum")) || kayitlar.length, hata: (x.match(/<err[^>]*>([\s\S]*?)<\/err>/) || [])[1] };
  };

  async function girisYap(istek, kadi, sifre) {
    const sayfa = await coz(await istek("/EntegreTicaretStandartLogin.aspx"));
    const gizli = n => (sayfa.match(new RegExp('name="' + n + '"[^>]*value="([^"]*)"')) || sayfa.match(new RegExp('id="' + n + '"[^>]*value="([^"]*)"')) || [])[1] || "";
    const govde = new URLSearchParams({ __VIEWSTATE: gizli("__VIEWSTATE"), __VIEWSTATEGENERATOR: gizli("__VIEWSTATEGENERATOR"), radioRol: "b", txtUserName: kadi, txtPassword: sifre, submit: "" });
    await istek("/EntegreTicaretStandartLogin.aspx", { method: "POST", body: govde.toString(), headers: { "Content-Type": "application/x-www-form-urlencoded" } });
    // Giriş başarılı mı: veri isteği "Oturum süresi doldu" demiyorsa evet
    const deneme = xmlCoz(await coz(await istek("/getItems.ashx?q=&pSize=1&sira=6&p=1&dummy=" + Date.now())));
    if (deneme.hata || !deneme.kayitlar.length) throw new Error("Giriş yapılamadı: kullanıcı adı ya da şifre hatalı olabilir");
    return deneme.toplamSayfa;
  }

  async function katalogCek() {
    if (durum.calisiyor) return { ok: false, hata: "Fiyatlar zaten çekiliyor" };
    const a = kayitOku("tedarikci_ayar") || {};
    if (!a.kadi || !a.sifre) return { ok: false, hata: "Önce bayi kullanıcı adı ve şifresini girin" };
    durum = { calisiyor: true, mesaj: "Siteye giriş yapılıyor", yuzde: 0, basla: Date.now() };
    (async () => {
      try {
        const istek = oturum();
        await girisYap(istek, a.kadi, a.sifre);
        // Raporda yalnızca bu programdaki ürünler: barkodu eşleşenler ya da elle bağlanmış (eşleştirilmiş) site kodları.
        // Sitenin tam listesi ("tedarikci_tum") yalnızca isimle eşleştirme önerileri için ayrıca kısa biçimde tutulur.
        const bizim = new Set(((kayitOku("durum") || {}).urunler || []).filter(u => u.aktif !== 0).map(u => barkodAnahtar(u.barkod)).filter(b => b.length >= 6));
        const bagliKod = new Set(Object.values(kayitOku("tedarikci_eslesme") || {}));
        const urunler = [], tum = [];
        let toplamSayfa = 1, taranan = 0;
        for (let p = 1; p <= toplamSayfa; p++) {
          durum.mesaj = `Fiyatlar okunuyor (${p}/${toplamSayfa})`;
          const s = xmlCoz(await coz(await istek(`/getItems.ashx?q=&pSize=${SAYFA}&sira=6&p=${p}&dummy=${Date.now()}`)));
          if (s.hata) throw new Error("Site oturumu kapattı: " + s.hata);
          toplamSayfa = s.toplamSayfa;
          taranan += s.kayitlar.length;
          urunler.push(...s.kayitlar.filter(k => bizim.has(barkodAnahtar(k.barkod)) || bagliKod.has(k.kod)));
          s.kayitlar.forEach(k => tum.push([k.kod, k.ad, k.barkod, k.fiyat, k.kucukGorsel, k.gorsel]));
          durum.yuzde = Math.round(p / toplamSayfa * 100);
        }
        const onceki = kayitOku("tedarikci_katalog");
        if (onceki) kayitYaz("tedarikci_katalog_onceki", onceki);
        kayitYaz("tedarikci_katalog", { zaman: new Date().toISOString(), urunler, taranan });
        kayitYaz("tedarikci_tum", { zaman: new Date().toISOString(), alanlar: ["kod", "ad", "barkod", "fiyat", "kucukGorsel", "gorsel"], urunler: tum });
        durum = { calisiyor: false, mesaj: `Sitede ${taranan} ürün tarandı, sizin ${urunler.length} ürününüz eşleşti`, yuzde: 100, bitti: Date.now() };
      } catch (e) {
        durum = { calisiyor: false, mesaj: "", yuzde: 0, hata: e.message };
      }
    })();
    return { ok: true };
  }

  return {
    durum: () => ({ ...durum, ...((k => k ? { sonCekim: k.zaman, urunSayisi: k.urunler.length } : {})(kayitOku("tedarikci_katalog"))) }),
    ayarOku: () => { const a = kayitOku("tedarikci_ayar") || {}; return { kadi: a.kadi || "", sifreVar: !!a.sifre }; },
    ayarYaz: ({ kadi, sifre }) => { const a = kayitOku("tedarikci_ayar") || {}; kayitYaz("tedarikci_ayar", { kadi: String(kadi || "").trim(), sifre: sifre ? String(sifre) : a.sifre || "" }); },
    katalog: () => kayitOku("tedarikci_katalog"),
    katalogOnceki: () => kayitOku("tedarikci_katalog_onceki"),
    katalogCek,
    // Sitenin tam listesi (isimle eşleştirme önerileri için) ve kalıcı ürün ↔ site kodu bağlantıları
    tum: () => kayitOku("tedarikci_tum"),
    eslesmeler: () => kayitOku("tedarikci_eslesme") || {},
    eslesmeYaz: ({ urunId, kod }) => {
      const e = kayitOku("tedarikci_eslesme") || {};
      if (kod) e[String(Number(urunId))] = String(kod); else delete e[String(Number(urunId))];
      kayitYaz("tedarikci_eslesme", e);
    },
    // Ürün görseli: sitenin /upload klasöründen (girişsiz açık) indirilir
    gorsel: async yol => {
      if (!/^\/upload\/[\w.-]+\.(jpe?g|png|webp|gif)$/i.test(String(yol || ""))) throw new Error("Geçersiz görsel");
      const r = await fetch(SITE + yol, { headers: { "User-Agent": TARAYICI }, signal: AbortSignal.timeout(20000) });
      if (!r.ok) throw new Error("Görsel alınamadı");
      return { tur: r.headers.get("content-type") || "image/jpeg", veri: Buffer.from(await r.arrayBuffer()) };
    }
  };
}

module.exports = { kur };
