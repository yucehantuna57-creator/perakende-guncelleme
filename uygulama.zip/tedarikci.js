// Tedarikçi fiyat takibi. İki site desteklenir: Yamanlar (Entegre Ticaret altyapısı, XML) ve Samsun Yapı Market (JSON + HTML kartlar).
// TEST AŞAMASI: bu modül yalnızca okur; ürünlerde stok ya da fiyat değiştirmez (satış fiyatı/görsel/barkod yazımı arayüzde kullanıcı onayıyla yapılır).
// Her sitenin ayarı, kataloğu, eşleştirmeleri ve "sitede yok" listesi ayrı tutulur (anahtar sonekiyle).
const SITELER = {
  yamanlar: { ad: "Yamanlar", taban: "https://b2b.yamanlargrup.com.tr", sonek: "" },
  yapimarket: { ad: "Samsun Yapı Market", taban: "https://bayi.samsunyapimarket.com.tr", sonek: "_yapimarket" }
};
const TARAYICI = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36";
const AYNI_ANDA = 3;

// Barkod karşılaştırması: rakam dışı karakterler ve baştaki sıfırlar yok sayılır (ör. 0868... ile 868... aynı)
// Harf içeren kodlar (ör. ELEKTRİK001-00000031) barkod sayılmaz: harfler silinince sahte rakam dizisi çıkardı
const barkodAnahtar = b => /[^\d\s.\-]/.test(String(b || "")) ? "" : String(b || "").replace(/\D/g, "").replace(/^0+/, "");
const metinTemizle = m => String(m || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'")
  // Siteler Türkçe harfleri bazen sayısal kodla yazar ("Fır&#231;a" → "Fırça")
  .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16))).trim();

// Çerezleri elde tutan basit istemci
function oturum(taban) {
  const cerez = new Map();
  const al = r => (r.headers.getSetCookie ? r.headers.getSetCookie() : []).forEach(c => { const [kv] = c.split(";"); const i = kv.indexOf("="); cerez.set(kv.slice(0, i).trim(), kv.slice(i + 1)); });
  return async (yol, secenek = {}) => {
    const r = await fetch(taban + yol, {
      ...secenek, redirect: "manual", signal: AbortSignal.timeout(60000),
      headers: { "User-Agent": TARAYICI, Cookie: [...cerez].map(([k, v]) => k + "=" + v).join("; "), ...(secenek.headers || {}) }
    });
    al(r);
    return r;
  };
}
const coz = async r => new TextDecoder(/8859-9|1254/i.test(r.headers.get("content-type") || "") ? "windows-1254" : "utf-8").decode(await r.arrayBuffer());

// ---------- Yamanlar okuyucusu ----------
const yamanlar = {
  sayfa: 1000,
  xmlCoz(x) {
    const ust = (x.match(/<recs([^>]*)>/) || ["", ""])[1];
    const nit = n => (ust.match(new RegExp(n + '="([^"]*)"')) || [])[1];
    const alan = (r, n) => { const m = r.match(new RegExp("<" + n + ">([\\s\\S]*?)</" + n + ">")); return m ? metinTemizle(m[1]) : ""; };
    const sayi = s => Number(String(s || "").replace(/\./g, "").replace(",", ".")) || 0;
    const kayitlar = (x.match(/<rec>[\s\S]*?<\/rec>/g) || []).map(r => ({
      kod: alan(r, "CODE"), ad: alan(r, "NAME"), barkod: alan(r, "BARCODE").replace(/\s/g, ""),
      fiyat: Number(alan(r, "net_fiyat_tl")) || sayi(alan(r, "FIYAT_TL")), birim: alan(r, "UNIT"), marka: alan(r, "MAKE"),
      kucukGorsel: alan(r, "thumb_url"), gorsel: alan(r, "org_url") || alan(r, "thumb_url")
    }));
    return { kayitlar, toplamSayfa: Number(nit("totalPageCount")) || 1, hata: (x.match(/<err[^>]*>([\s\S]*?)<\/err>/) || [])[1] };
  },
  async giris(istek, kadi, sifre) {
    const sayfa = await coz(await istek("/EntegreTicaretStandartLogin.aspx"));
    const gizli = n => (sayfa.match(new RegExp('name="' + n + '"[^>]*value="([^"]*)"')) || sayfa.match(new RegExp('id="' + n + '"[^>]*value="([^"]*)"')) || [])[1] || "";
    const govde = new URLSearchParams({ __VIEWSTATE: gizli("__VIEWSTATE"), __VIEWSTATEGENERATOR: gizli("__VIEWSTATEGENERATOR"), radioRol: "b", txtUserName: kadi, txtPassword: sifre, submit: "" });
    await istek("/EntegreTicaretStandartLogin.aspx", { method: "POST", body: govde.toString(), headers: { "Content-Type": "application/x-www-form-urlencoded" } });
    // Giriş başarılı mı: veri isteği "Oturum süresi doldu" demiyorsa evet
    const deneme = this.xmlCoz(await coz(await istek("/getItems.ashx?q=&pSize=1&sira=6&p=1&dummy=" + Date.now())));
    if (deneme.hata || !deneme.kayitlar.length) throw new Error("Giriş yapılamadı: kullanıcı adı ya da şifre hatalı olabilir");
  },
  async parca(istek, p) {
    const s = this.xmlCoz(await coz(await istek(`/getItems.ashx?q=&pSize=${this.sayfa}&sira=6&p=${p}&dummy=${Date.now()}${p}`)));
    if (s.hata) throw new Error("Site oturumu kapattı: " + s.hata);
    return s;
  }
};

// ---------- Samsun Yapı Market okuyucusu ----------
// Giriş: /uye-giris formu (kullanıcı adı + şifre). Site gerekirse ikinci adımda SMS kodu ister; program SMS kodu girmez,
// bu durumda açık bir hata verir ("Beni hatırla" ile güvenilir cihaz sayılırsa SMS istenmeyebilir).
const yapimarket = {
  sayfa: 200,
  fiyatOku(s) {
    let t = String(s || "").replace(/[^\d.,]/g, "");
    if (t.includes(",") && t.includes(".")) t = t.replace(/,/g, "");
    else if (t.includes(",")) t = t.replace(",", ".");
    return Number(t) || 0;
  },
  jsonCoz(metin) {
    let j; try { j = JSON.parse(metin); } catch (e) { return { hata: "Site oturumu kapattı ya da yanıt okunamadı" }; }
    const kayitlar = (j.Products || []).map(h => {
      const yazilar = [...h.matchAll(/<a\b[^>]*>([^<]+)<\/a>/g)].map(m => metinTemizle(m[1])).filter(Boolean);
      const resim = (h.match(/<img\b[^>]*\bsrc="([^"]*)"/) || [])[1] || "";
      const gorsel = /no-img/i.test(resim) ? "" : resim.split("?")[0];
      return { kod: yazilar[0] || "", ad: yazilar[1] || "", barkod: "", fiyat: this.fiyatOku((h.match(/tp-product-price[^>]*>\s*([^<]*)</) || [])[1]), birim: "", marka: "", kucukGorsel: gorsel, gorsel };
    }).filter(k => k.kod);
    return { kayitlar, toplamSayfa: Math.max(1, Math.ceil(Number(j.RecordCount || 0) / this.sayfa)) };
  },
  async giris(istek, kadi, sifre) {
    await istek("/uye-giris");
    const r = await istek("/uye-giris", { method: "POST", body: new URLSearchParams({ ID: "", PART_SMSCODE: "", PART_USERNAME: kadi, PART_PASSWORD: sifre, remeber: "true" }).toString(), headers: { "Content-Type": "application/x-www-form-urlencoded" } });
    const govde = r.status === 200 ? await coz(r) : "";
    if (/isSmsApprove\s*=\s*'True'/i.test(govde)) throw new Error("Bu site giriş için SMS onayı istiyor. Program SMS kodu girmez; bu siteden fiyat çekilemez.");
    const deneme = this.jsonCoz(await coz(await istek(`/Search/GetFilteredProductsPartial?query=&page=1&pageSize=1&inStockOnly=false&sortBy=default&updateFilters=false&viewType=grid`)));
    if (deneme.hata || !deneme.kayitlar.length) throw new Error("Giriş yapılamadı: kullanıcı adı ya da şifre hatalı olabilir");
  },
  async parca(istek, p) {
    const s = this.jsonCoz(await coz(await istek(`/Search/GetFilteredProductsPartial?query=&page=${p}&pageSize=${this.sayfa}&inStockOnly=false&sortBy=default&updateFilters=false&viewType=grid`)));
    if (s.hata) throw new Error(s.hata);
    return s;
  }
};
const OKUYUCU = { yamanlar, yapimarket };

function kur({ kayitOku, kayitYaz }) {
  const siteler = {};
  function siteKur(id) {
    const S = SITELER[id], okuyucu = OKUYUCU[id], k = ad => "tedarikci_" + ad + S.sonek;
    let durum = { calisiyor: false, mesaj: "", yuzde: 0 };

    async function katalogCek() {
      if (durum.calisiyor) return { ok: false, hata: "Fiyatlar zaten çekiliyor" };
      const a = kayitOku(k("ayar")) || {};
      if (!a.kadi || !a.sifre) return { ok: false, hata: "Önce bayi kullanıcı adı ve şifresini girin" };
      durum = { calisiyor: true, mesaj: "Siteye giriş yapılıyor", yuzde: 0, basla: Date.now() };
      (async () => {
        try {
          const istek = oturum(S.taban);
          await okuyucu.giris(istek, a.kadi, a.sifre);
          // Raporda yalnızca bu programdaki ürünler: barkodu eşleşenler ya da elle bağlanmış (eşleştirilmiş) site kodları.
          // Sitenin tam listesi yalnızca isimle eşleştirme önerileri için ayrıca kısa biçimde tutulur.
          const bizim = new Set(((kayitOku("durum") || {}).urunler || []).filter(u => u.aktif !== 0).map(u => barkodAnahtar(u.barkod)).filter(b => b.length >= 6));
          const bagliKod = new Set(Object.values(kayitOku(k("eslesme")) || {}));
          const urunler = [], tum = [];
          let taranan = 0, biten = 0;
          const parcaAl = async p => {
            for (let deneme = 1; ; deneme++) {
              try { return await okuyucu.parca(istek, p); } catch (e) { if (deneme >= 2) throw e; } // bir kez yeniden denenir
            }
          };
          const isle = (s, toplamSayfa) => {
            taranan += s.kayitlar.length;
            urunler.push(...s.kayitlar.filter(x => (barkodAnahtar(x.barkod).length >= 6 && bizim.has(barkodAnahtar(x.barkod))) || bagliKod.has(x.kod)));
            s.kayitlar.forEach(x => tum.push([x.kod, x.ad, x.barkod, x.fiyat, x.kucukGorsel, x.gorsel]));
            biten++;
            durum.yuzde = Math.round(biten / toplamSayfa * 100);
            durum.mesaj = `Fiyatlar okunuyor (${biten}/${toplamSayfa} parça, ${taranan} ürün)`;
          };
          durum.mesaj = "Fiyatlar okunuyor";
          const ilk = await parcaAl(1), toplamSayfa = ilk.toplamSayfa;
          isle(ilk, toplamSayfa);
          const kalan = Array.from({ length: Math.max(0, toplamSayfa - 1) }, (_, i) => i + 2);
          await Promise.all(Array.from({ length: Math.min(AYNI_ANDA, kalan.length) }, async () => {
            while (kalan.length) isle(await parcaAl(kalan.shift()), toplamSayfa);
          }));
          const onceki = kayitOku(k("katalog"));
          if (onceki) kayitYaz(k("katalog_onceki"), onceki);
          kayitYaz(k("katalog"), { zaman: new Date().toISOString(), urunler, taranan });
          kayitYaz(k("tum"), { zaman: new Date().toISOString(), alanlar: ["kod", "ad", "barkod", "fiyat", "kucukGorsel", "gorsel"], urunler: tum });
          durum = { calisiyor: false, mesaj: `${S.ad}: ${taranan} ürün tarandı, sizin ${urunler.length} ürününüz eşleşti`, yuzde: 100, bitti: Date.now() };
        } catch (e) {
          durum = { calisiyor: false, mesaj: "", yuzde: 0, hata: e.message };
        }
      })();
      return { ok: true };
    }

    return {
      ad: S.ad,
      durum: () => ({ ...durum, ...((x => x ? { sonCekim: x.zaman, urunSayisi: x.urunler.length } : {})(kayitOku(k("katalog")))) }),
      ayarOku: () => { const a = kayitOku(k("ayar")) || {}; return { kadi: a.kadi || "", sifreVar: !!a.sifre, site: S.ad }; },
      ayarYaz: ({ kadi, sifre }) => { const a = kayitOku(k("ayar")) || {}; kayitYaz(k("ayar"), { kadi: String(kadi || "").trim(), sifre: sifre ? String(sifre) : a.sifre || "" }); },
      katalog: () => kayitOku(k("katalog")),
      katalogOnceki: () => kayitOku(k("katalog_onceki")),
      katalogCek,
      // Sitenin tam listesi (isimle eşleştirme önerileri için) ve kalıcı ürün ↔ site kodu bağlantıları
      tum: () => kayitOku(k("tum")),
      eslesmeler: () => kayitOku(k("eslesme")) || {},
      eslesmeYaz: ({ urunId, kod }) => {
        const e = kayitOku(k("eslesme")) || {};
        if (kod) e[String(Number(urunId))] = String(kod); else delete e[String(Number(urunId))];
        kayitYaz(k("eslesme"), e);
      },
      // "Sitede yok" denen ürünler: eşleştirme listesinde bir daha sorulmaz (ürün programdan silinmez)
      yoklar: () => kayitOku(k("yok")) || [],
      yokYaz: ({ urunIdler, gizle }) => {
        const s = new Set(kayitOku(k("yok")) || []);
        (urunIdler || []).map(Number).forEach(i => (gizle ? s.add(i) : s.delete(i)));
        kayitYaz(k("yok"), [...s]);
      },
      // Ürün görseli: sitenin görsel klasöründen indirilir (yalnızca bilinen klasörler)
      gorsel: async yol => {
        if (!/^\/(upload|Content|images?)\/[\w\/.-]+\.(jpe?g|png|webp|gif)$/i.test(String(yol || ""))) throw new Error("Geçersiz görsel");
        const r = await fetch(S.taban + yol, { headers: { "User-Agent": TARAYICI }, signal: AbortSignal.timeout(20000) });
        if (!r.ok) throw new Error("Görsel alınamadı");
        return { tur: r.headers.get("content-type") || "image/jpeg", veri: Buffer.from(await r.arrayBuffer()) };
      }
    };
  }
  return {
    site: id => (siteler[SITELER[id] ? id : "yamanlar"] = siteler[SITELER[id] ? id : "yamanlar"] || siteKur(SITELER[id] ? id : "yamanlar")),
    liste: () => Object.entries(SITELER).map(([id, s]) => ({ id, ad: s.ad }))
  };
}

module.exports = { kur, okuyucular: OKUYUCU };
