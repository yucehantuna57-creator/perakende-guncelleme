// Cari hesap ekstresi: tasarlanabilir çıktı ve tasarım ekranı.
// Ekstre; başlık, bilgi alanları, sütunlar, fiş kalemleri (detaylı ekstre) ve alt bilgi bölümlerinden oluşur.
// Her bölümün neyi göstereceği, sütun sırası ve başlıkları "Ekstre tasarımı" ekranından düzenlenir.
// Tasarımlar Ayarlar kaydında (ekstreTasarimlari) saklanır, biri varsayılan olarak yazdırmada kullanılır.

const sayi2 = n => Number(n || 0).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const gunKisa = iso => new Date(iso).toLocaleDateString("tr-TR");
const bakiyeMetni = b => `${sayi2(Math.abs(b))} (${b >= 0 ? "B" : "A"})`; // B: müşteri borçlu, A: alacaklı

const EKSTRE_SAG = new Set(["borc", "alacak", "bakiye"]);
const KALEM_SAG = new Set(["miktar", "fiyat", "kdv", "tutar"]);

function varsayilanEkstreTasarimi() {
  return {
    id: 1,
    ad: "Varsayılan ekstre tasarımı",
    baslik: "CARİ HESAP EKSTRESİ",
    renk: "#b00000",
    logo: true,
    zebra: true,
    yazi: 12,
    baslikAlanlari: [
      { k: "kod", ad: "Müşteri Kodu", goster: true },
      { k: "ad", ad: "Müşteri Adı", goster: true },
      { k: "telefon", ad: "Telefon", goster: false },
      { k: "vergi", ad: "Vergi No", goster: false },
      { k: "bas", ad: "Başlangıç Tarihi", goster: true },
      { k: "bit", ad: "Bitiş Tarihi", goster: true }
    ],
    kolonlar: [
      { k: "tarih", ad: "Tarih", goster: true },
      { k: "fisNo", ad: "Fiş No", goster: true },
      { k: "islem", ad: "Fiş Türü", goster: true },
      { k: "aciklama", ad: "Açıklama", goster: true },
      { k: "yontem", ad: "Yöntem", goster: false },
      { k: "kullanici", ad: "Kullanıcı", goster: false },
      { k: "borc", ad: "Borç", goster: true },
      { k: "alacak", ad: "Alacak", goster: true },
      { k: "bakiye", ad: "Bakiye", goster: true }
    ],
    kalemlerGoster: false,
    kalemKolonlari: [
      { k: "kod", ad: "Kodu", goster: true },
      { k: "urun", ad: "Açıklama", goster: true },
      { k: "miktar", ad: "Miktar", goster: true },
      { k: "birim", ad: "Br.", goster: true },
      { k: "fiyat", ad: "B.Fiyat", goster: true },
      { k: "kdv", ad: "KDV%", goster: true },
      { k: "tutar", ad: "Tutar", goster: true }
    ],
    fisToplami: true,
    renkliTutarlar: true, renkBorc: "#b91c1c", renkAlacak: "#15803d",
    alt: { odemeOzeti: true, sayfaToplami: true, guncelBakiye: true, kayitSayisi: true }
  };
}

// Sonradan eklenen alanlar eski kayıtlı tasarımlarda eksik kalmasın
function ekstreTasarimiTamamla(t) {
  const v = varsayilanEkstreTasarimi();
  const tamam = { ...v, ...t, alt: { ...v.alt, ...(t.alt || {}) } };
  ["baslikAlanlari", "kolonlar", "kalemKolonlari"].forEach(liste => {
    const mevcut = Array.isArray(t[liste]) ? t[liste] : [];
    tamam[liste] = [...mevcut, ...v[liste].filter(d => !mevcut.some(x => x.k === d.k)).map(d => ({ ...d, goster: false }))];
  });
  return tamam;
}

function ekstreTasarimlariOku() {
  const kayitli = DB.ayarOku("ekstreTasarimlari", null);
  const liste = Array.isArray(kayitli) && kayitli.length ? kayitli : [varsayilanEkstreTasarimi()];
  return liste.map(ekstreTasarimiTamamla);
}

function ekstreAktifTasarim() {
  const liste = ekstreTasarimlariOku();
  const id = DB.ayarOku("ekstreAktif", liste[0].id);
  return liste.find(t => t.id === id) || liste[0];
}

// ---------- Ekstre çıktısı (DIA tarzı: kırmızı başlıklı, şeritli satırlar, bakiyede B/A) ----------
function ekstreHtml(m, o, satirlar, f, t, detayli) {
  const fisNoDe = id => (DB.bul("satislar", s => s.id === id) || {}).fis_no || "";
  const marka = markaBilgisi();
  const detay = detayli || t.kalemlerGoster;
  const gorunenKolon = t.kolonlar.filter(c => c.goster);
  const kolonSayisi = Math.max(1, gorunenKolon.length);

  const ilkTarih = satirlar.length ? gunKisa(satirlar[0].tarih) : "-";
  const sonTarih = satirlar.length ? gunKisa(satirlar[satirlar.length - 1].tarih) : "-";
  const gunBicimi = s => s.split("-").reverse().join(".");
  const baslikDeger = {
    kod: String(m.id).padStart(8, "0"), ad: m.ad_soyad, telefon: m.telefon || "-", vergi: m.vergi_no || "-",
    bas: f.bas ? gunBicimi(f.bas) : ilkTarih, bit: f.bit ? gunBicimi(f.bit) : sonTarih
  };
  const bilgi = k => `<div class="bilgi"><span class="e">${kac("", t.baslikAlanlari.find(a => a.k === k).ad)}</span><span>:</span><span class="d">${kac("", baslikDeger[k])}</span></div>`;
  const solAlanlar = t.baslikAlanlari.filter(a => a.goster && !["bas", "bit"].includes(a.k)).map(a => bilgi(a.k)).join("");
  const sagAlanlar = t.baslikAlanlari.filter(a => a.goster && ["bas", "bit"].includes(a.k)).map(a => bilgi(a.k)).join("");

  const deger = {
    tarih: h => gunKisa(h.tarih),
    fisNo: h => fisNoDe(h.satis_id),
    islem: h => CARI_ISLEM[h.islemTuru].ad,
    aciklama: h => (h.aciklama && h.aciklama !== fisNoDe(h.satis_id) ? h.aciklama : ""),
    yontem: h => cariYontemAdi(h),
    kullanici: h => cariKullaniciAdi(h),
    borc: h => (h.tur === "borc" ? sayi2(h.tutar) : ""),
    alacak: h => (h.tur === "tahsilat" ? sayi2(h.tutar) : ""),
    bakiye: h => bakiyeMetni(h.bakiye)
  };

  // Fiş kalemleri: ürün kodu (barkod), açıklama, miktar, birim, birim fiyat, KDV ve tutar
  const kalemDeger = {
    kod: (k, u) => u.barkod || "", urun: (k, u) => u.ad || "Silinmiş ürün", miktar: k => sayi(k.miktar),
    birim: (k, u) => u.birim || "adet", fiyat: k => sayi2(k.birim_fiyat),
    kdv: (k, u) => (u.kdv_orani != null ? "%" + u.kdv_orani : ""), tutar: k => sayi2(k.tutar)
  };
  const kalemBlogu = h => {
    const s = DB.bul("satislar", x => x.id === h.satis_id);
    const kalemler = DB.liste("satis_kalemleri", k => k.satis_id === h.satis_id);
    if (!s || !kalemler.length) return "";
    const kolonlar = t.kalemKolonlari.filter(c => c.goster);
    if (!kolonlar.length) return "";
    const satirlarHtml = kalemler.map(k => {
      const u = DB.bul("urunler", x => x.id === k.urun_id) || {};
      return `<tr>${kolonlar.map(c => `<td class="${KALEM_SAG.has(c.k) ? "sag" : ""}">${kac("", kalemDeger[c.k](k, u))}</td>`).join("")}</tr>`;
    }).join("");
    const toplam = t.fisToplami
      ? `<tr class="kt"><td colspan="${Math.max(1, kolonlar.length - 1)}">Fiş toplamı${s.durum === "iptal" ? " (iptal edildi)" : ""}${s.indirim > 0 ? ` · indirim -${sayi2(s.indirim)}` : ""}</td><td class="sag">${sayi2(s.toplam)}</td></tr>`
      : "";
    return `<tr class="kalem"><td colspan="${kolonSayisi}"><table class="k"><thead><tr>${kolonlar.map(c => `<th class="${KALEM_SAG.has(c.k) ? "sag" : ""}">${kac("", c.ad)}</th>`).join("")}</tr></thead><tbody>${satirlarHtml}${toplam}</tbody></table></td></tr>`;
  };

  let sira = 0;
  const govde = satirlar.map(h => {
    const z = t.zebra && sira++ % 2 === 1 ? " z" : "";
    // Hücre sınıfları: tutarlar ve bakiye için renk, işlem türü için ayırt edici renk; iptal satırları soluk
    const hucre = c => {
      const sinif = [EKSTRE_SAG.has(c.k) ? "sag" : "", "c-" + c.k];
      if (c.k === "bakiye") sinif.push(h.bakiye >= 0 ? "bb" : "ba");
      if (c.k === "islem") sinif.push("i-" + h.islemTuru);
      return `<td class="${sinif.filter(Boolean).join(" ")}">${kac("", deger[c.k](h))}</td>`;
    };
    const satir = `<tr class="v${z}${h.islemTuru === "fis_iptali" ? " iptal" : ""}">${gorunenKolon.map(hucre).join("")}</tr>`;
    return satir + (detay && h.satis_id ? kalemBlogu(h) : "");
  }).join("") || `<tr><td colspan="${kolonSayisi}">Seçilen aralıkta hareket yok</td></tr>`;

  // Alt bilgi: ödeme özeti ve rapor toplamı
  const borcToplam = satirlar.filter(h => h.tur === "borc").reduce((a, h) => a + h.tutar, 0);
  const alacakToplam = satirlar.filter(h => h.tur === "tahsilat").reduce((a, h) => a + h.tutar, 0);
  const sonBakiye = satirlar.length ? satirlar[satirlar.length - 1].bakiye : 0;
  const topla = islem => satirlar.filter(h => h.islemTuru === islem).reduce((a, h) => a + h.tutar, 0);
  const tahsilatYontem = {};
  satirlar.filter(h => h.islemTuru === "tahsilat").forEach(h => {
    const ad = h.yontem ? (YONTEM_AD[h.yontem] || h.yontem) : "Belirtilmemiş";
    tahsilatYontem[ad] = (tahsilatYontem[ad] || 0) + h.tutar;
  });
  const ozetSatirlari = [
    ["Açık hesap satışları", topla("satis")], ["Borç düzeltmeleri", topla("borc_duzeltme")], ["İptal edilen fişler", topla("fis_iptali")],
    ...Object.entries(tahsilatYontem).map(([ad, tutar]) => [`Tahsilat · ${ad}`, tutar])
  ].filter(([, tutar]) => tutar > 0);
  const odemeOzeti = t.alt.odemeOzeti ? `
    <table class="oz"><thead><tr><th>Ödeme özeti</th><th class="sag">Tutar</th></tr></thead><tbody>
      ${ozetSatirlari.map(([ad, tutar]) => `<tr><td>${kac("", ad)}</td><td class="sag">${sayi2(tutar)}</td></tr>`).join("") || '<tr><td colspan="2">Hareket yok</td></tr>'}
    </tbody></table>` : "";
  // Güncel bakiye sayfanın sağında, ayrı ve vurgulu bir kutuda (B: müşteri borçlu, A: alacaklı)
  const guncelBakiye = t.alt.guncelBakiye ? `
    <div class="guncel"><span>Güncel bakiye :</span><b class="${o.bakiye >= 0 ? "bb" : "ba"}">${bakiyeMetni(o.bakiye)}</b></div>` : "";
  const raporToplami = t.alt.sayfaToplami ? `
    <div class="rapor-top"><strong>Rapor toplamı :</strong> Borç <b>${sayi2(borcToplam)}</b> &nbsp; Alacak <b>${sayi2(alacakToplam)}</b> &nbsp; Bakiye <b>${bakiyeMetni(sonBakiye)}</b></div>` : "";
  const kayitSayisi = t.alt.kayitSayisi ? `<div class="kayit">Listelenen: ${satirlar.length} kayıt</div>` : "";

  const renk = t.renk || "#b00000";
  const yazi = Number(t.yazi) || 12;
  return `<!doctype html><html><head><meta charset="utf-8"><title>${kac("", t.baslik)}</title>
    <style>
      @page { size: A4; margin: 10mm; }
      body { font-family: Arial, Helvetica, sans-serif; font-size: ${yazi}px; color: #111; margin: 0; padding: 8mm 10mm; }
      .ust { display: flex; justify-content: space-between; align-items: center; font-size: ${yazi - 1}px; color: #444; }
      .ust img { max-height: 36px; max-width: 120px; vertical-align: middle; margin-right: 8px; }
      .baslik { text-align: center; font-weight: bold; font-size: ${yazi + 5}px; color: ${renk}; border-top: 3px solid ${renk}; border-bottom: 3px solid ${renk}; padding: 5px 0; margin: 8px 0 12px; }
      .bilgiler { display: flex; justify-content: space-between; gap: 24px; }
      .bilgi { display: flex; gap: 8px; line-height: 1.5; } .bilgi .e { font-weight: bold; min-width: 112px; }
      table { border-collapse: collapse; width: 100%; }
      table.ana { margin-top: 14px; }
      table.ana > thead > tr > th { color: ${renk}; font-weight: bold; text-align: left; border-bottom: 2px solid ${renk}; padding: 4px 6px; }
      table.ana > thead { display: table-header-group; }
      table.ana > tbody > tr.v > td { padding: 4px 6px; }
      tr.z > td { background: #e6e6f6; }
      .sag { text-align: right !important; }
      tr { page-break-inside: avoid; }
      tr.kalem > td { padding: 0 6px 8px 28px; }
      table.k { font-size: ${yazi - 1}px; }
      table.k th { color: ${renk}; text-align: left; border-bottom: 1px solid ${renk}; padding: 2px 6px; }
      table.k td { padding: 2px 6px; border-bottom: 1px dotted #bbb; }
      table.k tr.kt td { font-weight: bold; border-bottom: 0; }
      table.oz { width: 55%; margin-top: 18px; }
      table.oz th { text-align: left; border-bottom: 1px solid #111; padding: 4px 6px; font-size: ${yazi + 1}px; }
      table.oz td { padding: 3px 6px; }
      .guncel { margin: 14px 0 0 auto; width: fit-content; min-width: 260px; display: flex; justify-content: space-between; gap: 24px; padding: 8px 12px; border: 2px solid ${renk}; border-radius: 4px; font-size: ${yazi + 3}px; }
      ${t.renkliTutarlar ? `
      td.c-borc { color: ${t.renkBorc}; } td.c-alacak { color: ${t.renkAlacak}; }
      td.bb, .guncel b.bb { color: ${t.renkBorc}; font-weight: bold; } td.ba, .guncel b.ba { color: ${t.renkAlacak}; font-weight: bold; }
      td.i-satis { color: #9a3412; } td.i-tahsilat { color: ${t.renkAlacak}; } td.i-borc_duzeltme { color: #a16207; } td.i-fis_iptali { color: #1d4ed8; }
      tr.iptal > td { color: #6b7280 !important; font-style: italic; }` : ""}
      .rapor-top { margin-top: 14px; border-top: 2px solid ${renk}; border-bottom: 2px solid ${renk}; padding: 5px 6px; text-align: right; }
      .kayit { margin-top: 8px; color: #555; font-size: ${yazi - 1}px; }
    </style></head><body>
    <div class="ust"><div>${t.logo && marka.logo ? `<img src="${marka.logo}" alt="">` : ""}<strong>${kac("", marka.ad)}</strong></div><div>${tarih(new Date().toISOString())}</div></div>
    <div class="baslik">${kac("", t.baslik)}${detay ? " (DETAYLI)" : ""}</div>
    <div class="bilgiler"><div>${solAlanlar}</div><div>${sagAlanlar}</div></div>
    <table class="ana"><thead><tr>${gorunenKolon.map(c => `<th class="${EKSTRE_SAG.has(c.k) ? "sag" : ""}">${kac("", c.ad)}</th>`).join("")}</tr></thead><tbody>${govde}</tbody></table>
    ${raporToplami}${odemeOzeti}${guncelBakiye}${kayitSayisi}
    </body></html>`;
}

// "Ekstre yazdır" varsayılan tasarımla yazdırır. "Detaylı ekstre yazdır" fiş kalemlerini de ekler.
function cariEkstreYazdir(m, o, satirlar, f, detayli) {
  sayfaIcindeYazdir(ekstreHtml(m, o, satirlar, f, ekstreAktifTasarim(), detayli));
}

// ---------- Ekstre tasarım ekranı ----------
function ekstreOrnekVeri() {
  const musteriler = DB.liste("musteriler", x => x.aktif).map(x => ({ x, o: cariOzet(x.id) })).sort((a, b) => b.o.satirlar.length - a.o.satirlar.length);
  if (musteriler.length && musteriler[0].o.satirlar.length) {
    const { x, o } = musteriler[0];
    return { m: x, o, satirlar: o.satirlar, f: { bas: "", bit: "", islem: "hepsi" } };
  }
  // Hiç hareket yoksa örnek veri gösterilir
  const simdi = new Date().toISOString();
  const satirlar = [
    { id: 1, tur: "borc", tutar: 250, tarih: simdi, islemTuru: "satis", aciklama: "Örnek satış", bakiye: 250 },
    { id: 2, tur: "tahsilat", tutar: 100, tarih: simdi, islemTuru: "tahsilat", yontem: "nakit", aciklama: "Tahsilat", bakiye: 150 }
  ];
  const m = musteriler.length ? musteriler[0].x : { id: 1, ad_soyad: "Örnek Müşteri", telefon: "0500 000 00 00", vergi_no: "" };
  return { m, o: { satirlar, bakiye: 150, satis: 250, tahsilat: 100, duzeltme: 0, iptal: 0 }, satirlar, f: { bas: "", bit: "", islem: "hepsi" } };
}

function ekstreTasarimiAc(baglam) {
  const veri = baglam && baglam.m ? baglam : { ...ekstreOrnekVeri(), ...(baglam || {}) };
  const geri = veri.geri;
  // Düzenlemeler bu kopyada yapılır; Kaydet'e basılınca saklanır, Vazgeç'te atılır
  let liste = JSON.parse(JSON.stringify(ekstreTasarimlariOku()));
  let aktifId = DB.ayarOku("ekstreAktif", liste[0].id);
  if (!liste.some(t => t.id === aktifId)) aktifId = liste[0].id;
  let secili = liste.find(t => t.id === aktifId);

  const yeniId = () => Math.max(0, ...liste.map(t => t.id)) + 1;
  const satirKutusu = (anahtar, ogeler, siralanabilir) => ogeler.map((c, i) => `
    <div class="tas-satir">
      <input type="checkbox" data-liste="${anahtar}" data-i="${i}" data-oz="goster" ${c.goster ? "checked" : ""} aria-label="Göster">
      <input type="text" data-liste="${anahtar}" data-i="${i}" data-oz="ad" value="${kac("", c.ad)}">
      ${siralanabilir ? `<button class="btn kucuk" data-yon="-1" data-liste="${anahtar}" data-i="${i}" aria-label="Yukarı">↑</button><button class="btn kucuk" data-yon="1" data-liste="${anahtar}" data-i="${i}" aria-label="Aşağı">↓</button>` : ""}
    </div>`).join("");

  const solHtml = () => `
    <div class="tas-grup"><h3>Başlık</h3>
      <label>Başlık metni<input type="text" data-alan="baslik" value="${kac("", secili.baslik)}"></label>
      <div class="tas-satir"><label class="onay-kutusu">Renk <input type="color" data-alan="renk" value="${secili.renk}"></label>
        <label class="onay-kutusu">Yazı boyutu <select data-alan="yazi">${[10, 11, 12, 13, 14].map(n => `<option ${Number(secili.yazi) === n ? "selected" : ""}>${n}</option>`).join("")}</select></label></div>
      <label class="onay-kutusu"><input type="checkbox" data-alan="logo" ${secili.logo ? "checked" : ""}> Logo ve işletme adı</label>
      <label class="onay-kutusu"><input type="checkbox" data-alan="zebra" ${secili.zebra ? "checked" : ""}> Şeritli satırlar</label>
      <label class="onay-kutusu"><input type="checkbox" data-alan="renkliTutarlar" ${secili.renkliTutarlar ? "checked" : ""}> Renkli tutarlar ve işlem türleri</label>
      <div class="tas-satir"><label class="onay-kutusu">Borç rengi <input type="color" data-alan="renkBorc" value="${secili.renkBorc}"></label>
        <label class="onay-kutusu">Alacak rengi <input type="color" data-alan="renkAlacak" value="${secili.renkAlacak}"></label></div>
    </div>
    <div class="tas-grup"><h3>Bilgi alanları</h3>${satirKutusu("baslikAlanlari", secili.baslikAlanlari, false)}</div>
    <div class="tas-grup"><h3>Sütunlar (sırayı oklarla değiştirin)</h3>${satirKutusu("kolonlar", secili.kolonlar, true)}</div>
    <div class="tas-grup"><h3>Fiş kalemleri (detaylı ekstre)</h3>
      <label class="onay-kutusu"><input type="checkbox" data-alan="kalemlerGoster" ${secili.kalemlerGoster ? "checked" : ""}> Her fişin altında ürünleri göster</label>
      <label class="onay-kutusu"><input type="checkbox" data-alan="fisToplami" ${secili.fisToplami ? "checked" : ""}> Fiş toplamı satırı</label>
      ${satirKutusu("kalemKolonlari", secili.kalemKolonlari, true)}
    </div>
    <div class="tas-grup"><h3>Alt bilgi</h3>
      <label class="onay-kutusu"><input type="checkbox" data-alan="alt.odemeOzeti" ${secili.alt.odemeOzeti ? "checked" : ""}> Ödeme özeti</label>
      <label class="onay-kutusu"><input type="checkbox" data-alan="alt.sayfaToplami" ${secili.alt.sayfaToplami ? "checked" : ""}> Rapor toplamı</label>
      <label class="onay-kutusu"><input type="checkbox" data-alan="alt.guncelBakiye" ${secili.alt.guncelBakiye ? "checked" : ""}> Güncel bakiye (sağda)</label>
      <label class="onay-kutusu"><input type="checkbox" data-alan="alt.kayitSayisi" ${secili.alt.kayitSayisi ? "checked" : ""}> Kayıt sayısı</label>
    </div>`;

  const ustHtml = () => `
    <select id="et-sec" aria-label="Tasarım">${liste.map(t => `<option value="${t.id}" ${t.id === secili.id ? "selected" : ""}>${kac("", t.ad)}${t.id === aktifId ? " (varsayılan)" : ""}</option>`).join("")}</select>
    <input type="text" id="et-ad" value="${kac("", secili.ad)}" aria-label="Tasarım adı">
    <button class="btn" id="et-yeni">Yeni</button><button class="btn" id="et-kopya">Çoğalt</button><button class="btn tehlike" id="et-sil">Sil</button>
    <label class="onay-kutusu"><input type="checkbox" id="et-aktif" ${secili.id === aktifId ? "checked disabled" : ""}> Varsayılan tasarım</label>`;

  modalAc(`
    <div class="modal-baslik">Ekstre tasarımı</div>
    <div class="filtre" id="et-ust" style="margin:8px 0">${ustHtml()}</div>
    <div class="tasarim-govde">
      <div class="tasarim-sol" id="et-sol">${solHtml()}</div>
      <iframe id="et-onizleme" class="tasarim-onizleme" title="Ekstre önizleme"></iframe>
    </div>
    <p style="margin:6px 0 0;font-size:12px;opacity:0.75">Önizleme ${kac("", veri.m.ad_soyad)} müşterisinin gerçek hareketleriyle çizilir.</p>
    <div class="modal-alt">
      <button class="btn" id="et-yazdir">Önizlemeyi yazdır</button>
      <button class="btn" id="et-vazgec">Vazgeç</button>
      <button class="btn ana" id="et-kaydet">Kaydet</button>
    </div>`, "cok");

  const onizle = () => { $("et-onizleme").srcdoc = ekstreHtml(veri.m, veri.o, veri.satirlar, veri.f, secili, false); };
  const sol = () => { $("et-sol").innerHTML = solHtml(); };
  const ust = () => { $("et-ust").innerHTML = ustHtml(); };
  const hepsiniCiz = () => { ust(); sol(); onizle(); };

  // Kutulardan gelen değişiklikler seçili tasarıma işlenir ve önizleme yenilenir
  const degistir = e => {
    const el = e.target;
    if (el.dataset.alan) {
      const yol = el.dataset.alan.split(".");
      const hedef = yol.length === 2 ? secili[yol[0]] : secili;
      const ad = yol[yol.length - 1];
      hedef[ad] = el.type === "checkbox" ? el.checked : ad === "yazi" ? Number(el.value) : el.value;
    } else if (el.dataset.liste) {
      const oge = secili[el.dataset.liste][Number(el.dataset.i)];
      oge[el.dataset.oz] = el.dataset.oz === "goster" ? el.checked : el.value;
    } else return;
    onizle();
  };
  $("et-sol").addEventListener("input", degistir);
  $("et-sol").addEventListener("change", degistir);
  $("et-sol").addEventListener("click", e => {
    const b = e.target.closest("[data-yon]");
    if (!b) return;
    const dizi = secili[b.dataset.liste];
    const i = Number(b.dataset.i);
    const j = i + Number(b.dataset.yon);
    if (j < 0 || j >= dizi.length) return;
    [dizi[i], dizi[j]] = [dizi[j], dizi[i]];
    sol();
    onizle();
  });

  $("et-ust").addEventListener("change", e => {
    if (e.target.id === "et-sec") { secili = liste.find(t => t.id === Number(e.target.value)); hepsiniCiz(); }
    if (e.target.id === "et-aktif" && e.target.checked) { aktifId = secili.id; ust(); }
  });
  $("et-ust").addEventListener("input", e => {
    if (e.target.id !== "et-ad") return;
    secili.ad = e.target.value;
    const secenek = $("et-sec").querySelector(`option[value="${secili.id}"]`);
    if (secenek) secenek.textContent = secili.ad + (secili.id === aktifId ? " (varsayılan)" : "");
  });
  $("et-ust").addEventListener("click", e => {
    if (e.target.id === "et-yeni") {
      secili = { ...varsayilanEkstreTasarimi(), id: yeniId(), ad: `Yeni tasarım ${liste.length + 1}` };
      liste.push(secili);
      hepsiniCiz();
    }
    if (e.target.id === "et-kopya") {
      secili = { ...JSON.parse(JSON.stringify(secili)), id: yeniId(), ad: secili.ad + " (kopya)" };
      liste.push(secili);
      hepsiniCiz();
    }
    if (e.target.id === "et-sil") {
      if (liste.length === 1) return bildir("Son tasarım silinemez");
      if (!confirm(`"${secili.ad}" tasarımı silinsin mi?`)) return;
      liste = liste.filter(t => t.id !== secili.id);
      if (aktifId === secili.id) aktifId = liste[0].id;
      secili = liste.find(t => t.id === aktifId);
      hepsiniCiz();
    }
  });

  const kapat = () => (geri ? geri() : modalKapat());
  $("et-yazdir").addEventListener("click", () => sayfaIcindeYazdir(ekstreHtml(veri.m, veri.o, veri.satirlar, veri.f, secili, false)));
  $("et-vazgec").addEventListener("click", kapat);
  $("et-kaydet").addEventListener("click", () => {
    if (liste.some(t => !t.ad.trim())) return bildir("Tasarım adı boş olamaz");
    DB.ayarYaz("ekstreTasarimlari", liste);
    DB.ayarYaz("ekstreAktif", aktifId);
    bildir("Ekstre tasarımı kaydedildi");
    kapat();
  });
  onizle();
}
