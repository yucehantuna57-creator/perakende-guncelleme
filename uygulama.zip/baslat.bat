@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Sunucuyu arka planda açar ve uygulama penceresini getirir (güncelleme varsa uygulama içinde sorulur).
node baslat.js
if errorlevel 1 (
  echo.
  echo Uygulama baslatilamadi. Hata mesaji yukarida.
  pause
)
