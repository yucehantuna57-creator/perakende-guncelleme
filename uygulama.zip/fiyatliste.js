// Tedarikçi fiyat listesi (PDF / Excel / CSV): listedeki ürünler programdaki ürünlerle eşleştirilir, alış fiyatları karşılaştırılır.
// Eşleşmeler tedarikçi adına göre bu bilgisayarda saklanır; aynı tedarikçinin sonraki listesinde aynı ürünler kendiliğinden eşleşir.
// Alış ve satış yalnızca kullanıcı düğmeye bastığında değişir (Fiyat takibindeki kurallarla aynı).

let FL = null; // { tedarikci, dosyaAd, pdf, tablo: [[hücre]], ayar: { bas, ad, kod, fiyat, fiyatSira, kdvDahil, iskonto } }
let flSekme = "fark", flSayfa = 0;
try { FL = JSON.parse(localStorage.getItem("fl_son") || "null"); } catch (e) { FL = null; }
const flKaydet = () => { try { localStorage.setItem("fl_son", JSON.stringify(FL)); } catch (e) { /* liste çok büyükse yalnızca bu oturumda kalır */ } };
const flTedAnahtar = t => trKucuk(String(t || "").trim()) || "genel";
function flEslesmeler() { try { return JSON.parse(localStorage.getItem("fl_eslesme") || "{}"); } catch (e) { return {}; } }
function flEslesmeYaz(an, urunId) {
  const t = flEslesmeler(), k = flTedAnahtar(FL && FL.tedarikci);
  t[k] = t[k] || {};
  if (urunId) t[k][an] = urunId; else delete t[k][an];
  try { localStorage.setItem("fl_eslesme", JSON.stringify(t)); } catch (e) { /* kaydedilemedi */ }
}
const flTedarikciler = () => { const t = flEslesmeler(); return Object.keys(t).filter(k => k !== "genel"); };

// Hücredeki sayı (1.234,56 / 1,234.56 / 12,5 TL); barkod gibi uzun tam sayılar fiyat sayılmaz
function flSayi(x) {
  let t = String(x ?? "").replace(/(TL|TRY|₺|\s)/gi, "");
  if (!/^-?[\d.,]+$/.test(t) || !/\d/.test(t) || /^\d{7,}$/.test(t)) return null;
  if (t.includes(",") && t.includes(".")) t = t.lastIndexOf(",") > t.lastIndexOf(".") ? t.replace(/\./g, "").replace(",", ".") : t.replace(/,/g, "");
  else if (t.includes(",")) t = t.replace(",", ".");
  else if ((t.match(/\./g) || []).length > 1) t = t.replace(/\./g, "");
  const n = Number(t);
  return isFinite(n) ? n : null;
}
const HARF = /[A-Za-zÇĞİÖŞÜçğıöşü]{3,}/;

async function flDosyaOku(dosya) {
  const ad = dosya.name.toLowerCase();
  if (ad.endsWith(".pdf")) {
    const satirlar = await FATURAOKU.pdfSatirlari(await dosya.arrayBuffer());
    return { pdf: true, tablo: satirlar.map(s => s.split(/\s{2,}/).map(h => h.trim()).filter(Boolean)) };
  }
  if (/\.(xlsx|csv|txt|xls)$/.test(ad)) return { pdf: false, tablo: (await urunDosyasiOku(dosya)).map(r => (r || []).map(h => String(h ?? "").trim())) };
  throw new Error("PDF, Excel (.xlsx) ya da CSV dosyası seçin");
}

// Excel'de başlık satırı ve sütunlar tahmin edilir; kullanıcı ekrandan değiştirebilir
function flAyarTahmin(F) {
  const a = { bas: -1, ad: -1, kod: -1, fiyat: -1, fiyatSira: "son", kdvDahil: false, iskonto: 0 };
  if (F.pdf) { a.kdvDahil = F.tablo.some(h => /kdv\s*dahil/i.test(h.join(" "))); return a; }
  const s = h => trKucuk(h).replace(/\s+/g, " ");
  for (let i = 0; i < Math.min(25, F.tablo.length); i++) {
    const h = F.tablo[i].map(s);
    const ad = h.findIndex(x => /(ürün|urun|stok|mal|malzeme)\s*(ad|ismi|tanım)|açıklama|aciklama|^ad$|^cinsi?$|ürün$|^isim/.test(x));
    const fiyatlar = h.map((x, j) => /fiyat|tutar|^net|liste|birim/.test(x) ? j : -1).filter(j => j >= 0);
    if (ad >= 0 && fiyatlar.length) {
      a.bas = i; a.ad = ad;
      a.fiyat = fiyatlar.find(j => /net|iskontolu|indirimli/.test(h[j])) ?? fiyatlar[0];
      a.kod = h.findIndex(x => /barkod|kod|^no$|stok no/.test(x));
      a.kdvDahil = /kdv\s*dahil|kdv'?li/.test(h[a.fiyat]);
      return a;
    }
  }
  // Başlık bulunamazsa: en uzun metinli sütun ad, en çok sayı içeren sütun fiyat
  const ornek = F.tablo.slice(0, 60), say = n => ornek.reduce((t, h) => t + (n(h) ? 1 : 0), 0);
  const genislik = Math.max(0, ...ornek.map(h => h.length));
  let enAd = -1, enAdP = 0, enFiyat = -1, enFiyatP = 0;
  for (let j = 0; j < genislik; j++) {
    const p = say(h => HARF.test(h[j] || "")), q = say(h => flSayi(h[j]) > 0);
    if (p > enAdP) { enAdP = p; enAd = j; }
    if (q > enFiyatP) { enFiyatP = q; enFiyat = j; }
  }
  a.ad = enAd; a.fiyat = enFiyat;
  return a;
}

// Tablo → [{ kod, ad, fiyat }]
function flSatirlar() {
  if (!FL) return [];
  const a = FL.ayar, sonuc = [];
  FL.tablo.forEach((h, i) => {
    let ad = "", kod = "", fiyat = null;
    if (FL.pdf) {
      const sayilar = h.map(x => flSayi(x)).filter(n => n !== null && n > 0);
      const metinler = h.filter(x => flSayi(x) === null && HARF.test(x) && !/toplam|sayfa|tarih|fiyat listesi/i.test(x));
      if (!sayilar.length || !metinler.length) return;
      ad = metinler.reduce((u, x) => (x.length > u.length ? x : u), "");
      fiyat = a.fiyatSira === "ilk" ? sayilar[0] : a.fiyatSira === "sondan2" ? sayilar[sayilar.length - 2] : sayilar[sayilar.length - 1];
      kod = h.find(x => /^\d{8,14}$/.test(x)) || h.find(x => x !== ad && /\d/.test(x) && /^[A-Za-z0-9][A-Za-z0-9.\-\/]{2,24}$/.test(x) && flSayi(x) === null) || "";
    } else {
      if (i <= a.bas || a.ad < 0 || a.fiyat < 0) return;
      ad = h[a.ad] || ""; kod = a.kod >= 0 ? h[a.kod] || "" : ""; fiyat = flSayi(h[a.fiyat]);
    }
    if (!HARF.test(ad) || !(fiyat > 0)) return;
    sonuc.push({ kod: String(kod).trim(), ad: String(ad).trim(), fiyat });
  });
  return sonuc;
}

const flAnahtar = s => (s.kod ? "k:" + trKucuk(s.kod) : "a:" + FATURA.adNormal(s.ad).join(" "));
// Listedeki fiyat → programla karşılaştırılan KDV hariç net alış
const flNetAlis = (s, u) => {
  const iskonto = Number(FL.ayar.iskonto) || 0;
  let f = s.fiyat * (1 - iskonto / 100);
  if (FL.ayar.kdvDahil) f = f / (1 + Number(u ? u.kdv_orani ?? 20 : 20) / 100);
  return Math.round(f * 10000) / 10000;
};

function flEsle(satirlar) {
  const kayit = flEslesmeler()[flTedAnahtar(FL.tedarikci)] || {};
  const urunler = DB.liste("urunler", u => u.aktif);
  const byId = new Map(urunler.map(u => [u.id, u]));
  const byBarkod = new Map(urunler.filter(u => tdBarkod(u.barkod).length >= 6).map(u => [tdBarkod(u.barkod), u]));
  return satirlar.map(s => {
    const an = flAnahtar(s);
    let u = null, nasil = "";
    if (kayit[an] && byId.has(kayit[an])) { u = byId.get(kayit[an]); nasil = "bagli"; }
    else if (tdBarkod(s.kod).length >= 6 && byBarkod.has(tdBarkod(s.kod))) { u = byBarkod.get(tdBarkod(s.kod)); nasil = "barkod"; }
    if (!u) return { s, an, u: null };
    const alis = Number(u.alis_fiyati) || 0, yeni = flNetAlis(s, u);
    return { s, an, u, nasil, alis, yeni, fark: alis > 0 ? (yeni - alis) / alis * 100 : null,
      oneri: alis > 0 && yeni > 0 && Number(u.satis_fiyati) > 0 ? tedarikciYuvarla(Number(u.satis_fiyati) * yeni / alis) : null };
  });
}

// Programdaki ürünler için ad dizini; öneriler Fiyat takibi eşleştirmesiyle aynı ölçütle (ayırt edici kelimeler ağırlıklı)
function flDizin() {
  const liste = DB.liste("urunler", u => u.aktif), kelime = new Map();
  liste.forEach((u, i) => new Set(FATURA.adNormal(u.ad).filter(k => k.length >= 3)).forEach(k => { if (!kelime.has(k)) kelime.set(k, []); kelime.get(k).push(i); }));
  return { liste, kelime };
}
function flOneri(dz, ad, bagli) {
  const N = dz.liste.length || 1, idf = k => Math.log(1 + N / ((dz.kelime.get(k) || []).length || 1));
  const kelimeler = [...new Set(FATURA.adNormal(ad).filter(k => k.length >= 3 && !/^\d/.test(k)))];
  if (!kelimeler.length) return [];
  const toplam = kelimeler.reduce((t, k) => t + idf(k), 0) || 1, say = new Map();
  kelimeler.forEach(k => (dz.kelime.get(k) || []).forEach(i => say.set(i, (say.get(i) || 0) + idf(k))));
  return [...say].sort((a, b) => b[1] - a[1]).slice(0, 200)
    .map(([i, w]) => ({ u: dz.liste[i], pay: w / toplam, skor: 0.5 * (w / toplam) + 0.5 * FATURA.benzerlik(ad, dz.liste[i].ad) }))
    .filter(x => x.pay >= 0.6 && x.skor >= 0.5 && !bagli.has(x.u.id)).sort((a, b) => b.skor - a.skor).slice(0, 3);
}

function fiyatListesiCiz() {
  const k = $("s-tedarikci");
  const satirlar = flSatirlar(), eslesme = FL ? flEsle(satirlar) : [];
  const eslesen = eslesme.filter(x => x.u), eslesmeyen = eslesme.filter(x => !x.u);
  const farkli = eslesen.filter(x => Math.abs(x.yeni - x.alis) > 0.005);
  const a = FL ? FL.ayar : null, genislik = FL ? Math.max(0, ...FL.tablo.slice(0, 80).map(h => h.length)) : 0;
  const sutunSec = (ad, deger, bosOlur) => `<select data-fl-ayar="${ad}">${bosOlur ? `<option value="-1" ${deger < 0 ? "selected" : ""}>Yok</option>` : ""}${Array.from({ length: genislik }, (_, j) => {
    const ornek = FL.tablo.slice(a.bas + 1).map(h => h[j]).find(x => x) || "";
    return `<option value="${j}" ${j === deger ? "selected" : ""}>${j + 1}. sütun${a.bas >= 0 && FL.tablo[a.bas][j] ? " · " + kac("", FL.tablo[a.bas][j]) : ""} (${kac("", String(ornek).slice(0, 18))})</option>`;
  }).join("")}</select>`;
  k.innerHTML = `
    <div class="baslik-satir"><h2>Fiyat listesi (PDF / Excel)</h2><div><button class="btn" id="fl-site">← Site fiyatları</button></div></div>
    <p style="margin:0 0 10px;font-size:13px;opacity:.8">Tedarikçinin gönderdiği fiyat listesini yükleyin; listedeki ürünler sizin ürünlerinizle eşleştirilir ve alış fiyatları karşılaştırılır. Eşleştirdikleriniz tedarikçi adıyla saklanır, sonraki listede kendiliğinden eşleşir. Alış ve satış yalnızca siz düğmeye bastığınızda değişir. Taranmış (resim) PDF okunamaz.</p>
    <div class="filtre" style="margin-bottom:10px;align-items:flex-end">
      <label style="display:flex;flex-direction:column;font-size:12px">Tedarikçi<input id="fl-ted" list="fl-ted-liste" value="${kac("", FL ? FL.tedarikci : "")}" placeholder="Örn. Abdullah Şahin" style="height:38px;min-width:220px" autocomplete="off"><datalist id="fl-ted-liste">${flTedarikciler().map(t => `<option value="${kac("", t)}">`).join("")}</datalist></label>
      <label class="btn ana" style="cursor:pointer">Dosya seç (PDF / Excel)<input id="fl-dosya" type="file" accept=".pdf,.xlsx,.csv,.txt" style="display:none"></label>
      ${FL ? `<span style="font-size:13px;opacity:.8">${kac("", FL.dosyaAd)}</span><button class="btn" id="fl-temizle">Listeyi kapat</button>` : ""}
    </div>
    <div id="fl-durum" style="margin-bottom:8px"></div>
    ${FL ? `
    <div class="filtre" style="margin-bottom:10px;font-size:13px;align-items:center;flex-wrap:wrap;gap:8px">
      ${FL.pdf ? `<label>Fiyat <select data-fl-ayar="fiyatSira"><option value="son" ${a.fiyatSira === "son" ? "selected" : ""}>satırdaki son sayı</option><option value="sondan2" ${a.fiyatSira === "sondan2" ? "selected" : ""}>sondan 2. sayı</option><option value="ilk" ${a.fiyatSira === "ilk" ? "selected" : ""}>ilk sayı</option></select></label>`
        : `<label>Başlık satırı <input data-fl-ayar="bas" type="number" min="0" value="${a.bas + 1}" style="width:60px"></label><label>Ürün adı ${sutunSec("ad", a.ad)}</label><label>Kod / barkod ${sutunSec("kod", a.kod, true)}</label><label>Fiyat ${sutunSec("fiyat", a.fiyat)}</label>`}
      <label>Listedeki fiyatlar <select data-fl-ayar="kdvDahil"><option value="0" ${a.kdvDahil ? "" : "selected"}>KDV hariç</option><option value="1" ${a.kdvDahil ? "selected" : ""}>KDV dahil</option></select></label>
      <label>İskonto % <input data-fl-ayar="iskonto" type="number" min="0" max="100" step="0.5" value="${a.iskonto || 0}" style="width:70px"></label>
    </div>
    <div class="ozet-kutular">
      <div class="ozet"><small>Listedeki ürün</small><strong>${satirlar.length}</strong></div>
      <div class="ozet"><small>Eşleşen</small><strong>${eslesen.length}</strong></div>
      <div class="ozet"><small>Alışı farklı</small><strong style="color:#c0392b">${farkli.length}</strong></div>
      <div class="ozet"><small>Eşleşmeyen</small><strong>${eslesmeyen.length}</strong></div>
    </div>
    <div class="filtre" style="margin:10px 0"><button class="btn ${flSekme === "fark" ? "ana" : ""}" data-fl-sekme="fark">Alışı farklı (${farkli.length})</button><button class="btn ${flSekme === "hepsi" ? "ana" : ""}" data-fl-sekme="hepsi">Eşleşenler (${eslesen.length})</button><button class="btn ${flSekme === "eslesmeyen" ? "ana" : ""}" data-fl-sekme="eslesmeyen">Eşleşmeyenler (${eslesmeyen.length})</button>
      ${farkli.some(x => x.yeni > x.alis + 0.005 && x.oneri > Number(x.u.satis_fiyati) + 0.005) ? '<button class="btn" id="fl-satis-toplu" style="margin-left:auto">Alışı artanlara önerilen satış fiyatını uygula</button>' : ""}${etiketBekleyenler().size ? `<button class="btn ana" id="fl-etiket">Fiyatı değişenlerin etiketini yazdır (${etiketBekleyenler().size})</button>` : ""}</div>
    <div id="fl-icerik"></div>` : ""}`;

  $("fl-site").addEventListener("click", () => { tedarikciMod = "site"; tedarikciCiz(); });
  $("fl-ted").addEventListener("change", e => { if (FL) { FL.tedarikci = e.target.value.trim(); flKaydet(); fiyatListesiCiz(); } });
  $("fl-dosya").addEventListener("change", async e => {
    const dosya = e.target.files[0]; if (!dosya) return;
    const ted = $("fl-ted").value.trim();
    $("fl-durum").textContent = "Dosya okunuyor...";
    try {
      const o = await flDosyaOku(dosya);
      if (!o.tablo.length) throw new Error("Dosyada okunacak satır bulunamadı");
      FL = { tedarikci: ted, dosyaAd: dosya.name, pdf: o.pdf, tablo: o.tablo, ayar: null };
      FL.ayar = flAyarTahmin(FL);
      flKaydet(); flSekme = "fark"; flSayfa = 0;
      fiyatListesiCiz();
      const n = flSatirlar().length;
      bildir(n ? `${n} ürün satırı okundu` : "Ürün satırı bulunamadı: sütun seçimlerini kontrol edin", 5000);
    } catch (x) { $("fl-durum").innerHTML = `<span class="hata">${kac("", x.message)}</span>`; }
  });
  if (!FL) return;
  $("fl-temizle").addEventListener("click", () => { FL = null; try { localStorage.removeItem("fl_son"); } catch (e) {} fiyatListesiCiz(); });
  k.querySelectorAll("[data-fl-ayar]").forEach(g => g.addEventListener("change", () => {
    const ad = g.dataset.flAyar;
    FL.ayar[ad] = ad === "kdvDahil" ? g.value === "1" : ad === "fiyatSira" ? g.value : ad === "bas" ? Math.max(0, Number(g.value) || 0) - 1 : Number(g.value);
    flKaydet(); flSayfa = 0; fiyatListesiCiz();
  }));
  k.querySelectorAll("[data-fl-sekme]").forEach(b => b.addEventListener("click", () => { flSekme = b.dataset.flSekme; flSayfa = 0; fiyatListesiCiz(); }));
  if ($("fl-etiket")) $("fl-etiket").addEventListener("click", topluEtiketPenceresi);
  if ($("fl-satis-toplu")) $("fl-satis-toplu").addEventListener("click", () => tedarikciSatisToplu(farkli.filter(x => x.yeni > x.alis + 0.005 && x.oneri > Number(x.u.satis_fiyati) + 0.005)));
  if (flSekme === "eslesmeyen") flEslesmeyenCiz(eslesmeyen, new Set(eslesen.map(x => x.u.id)));
  else flEslesenCiz(flSekme === "fark" ? farkli : eslesen);
}

const FL_SAYFA = 50;
function flSayfaAlti(toplam) {
  const sayfa = Math.ceil(toplam / FL_SAYFA);
  return sayfa > 1 ? `<div class="filtre" style="margin-top:8px;justify-content:center"><button class="btn" data-fl-git="-1" ${flSayfa ? "" : "disabled"}>‹ Önceki</button><span style="align-self:center">${flSayfa + 1} / ${sayfa}</span><button class="btn" data-fl-git="1" ${flSayfa + 1 < sayfa ? "" : "disabled"}>Sonraki ›</button></div>` : "";
}

function flEslesenCiz(l) {
  const c = $("fl-icerik");
  l = l.slice().sort((a, b) => Math.abs(b.fark ?? 0) - Math.abs(a.fark ?? 0));
  const sayfa = l.slice(flSayfa * FL_SAYFA, (flSayfa + 1) * FL_SAYFA);
  c.innerHTML = `<table class="tablo">
    <tr><th>Görsel</th><th>Programdaki ürün</th><th>Listedeki ürün</th><th class="sag">Programdaki alış</th><th class="sag">Listedeki alış (KDV hariç)</th><th class="sag">KDV dahil</th><th class="sag">Fark</th><th class="sag">Satış</th></tr>
    ${sayfa.map(x => {
      const farkli = Math.abs(x.yeni - x.alis) > 0.005;
      return `<tr${farkli ? ' style="background:rgba(192,57,43,.12);box-shadow:inset 4px 0 0 #c0392b"' : ""}>
        <td style="width:60px">${urunResmi(x.u)}</td>
        <td>${kac("", x.u.ad)}<div style="font-size:12px;opacity:.6">${kac("", x.u.barkod)}</div><span class="rozet">${x.nasil === "barkod" ? "barkodla eşleşti" : "elle eşleşti"}</span>${x.nasil === "bagli" ? ` <button class="btn kucuk" data-fl-kaldir="${kac("", x.an)}">Eşleşmeyi kaldır</button>` : ""}</td>
        <td style="font-size:13px">${kac("", x.s.ad)}${x.s.kod ? `<div style="opacity:.6">${kac("", x.s.kod)}</div>` : ""}<div style="opacity:.6">listede ${para(x.s.fiyat)}</div></td>
        <td class="sag">${x.alis > 0 ? para(x.alis) : "—"}${farkli ? `<div><button class="btn kucuk" data-fl-alis="${kac("", x.an)}">Alışı güncelle</button></div>` : ""}</td>
        <td class="sag"><strong>${para(x.yeni)}</strong></td>
        <td class="sag">${para(x.yeni * (1 + Number(x.u.kdv_orani ?? 20) / 100))}</td>
        <td class="sag" style="color:${x.fark > 0.05 ? "#c0392b" : x.fark < -0.05 ? "#1e8e4e" : "inherit"}">${x.fark === null ? "—" : (x.fark > 0 ? "+" : "") + x.fark.toFixed(1) + "%"}</td>
        <td class="sag">${para(x.u.satis_fiyati)}<div><button class="btn kucuk" data-fl-satis="${kac("", x.an)}">Satışı değiştir</button></div>${x.oneri && Math.abs(x.oneri - x.u.satis_fiyati) > 0.005 ? `<div style="font-size:11px;opacity:.75">öneri ${para(x.oneri)}</div>` : ""}</td></tr>`;
    }).join("") || '<tr><td colspan="8" style="text-align:center;padding:20px;opacity:.7">Bu sekmede ürün yok</td></tr>'}
  </table>${flSayfaAlti(l.length)}`;
  const bul = an => l.find(x => x.an === an);
  c.onclick = e => {
    const git = e.target.closest("[data-fl-git]"); if (git) { flSayfa += Number(git.dataset.flGit); return fiyatListesiCiz(); }
    const kal = e.target.closest("[data-fl-kaldir]"); if (kal) { flEslesmeYaz(kal.dataset.flKaldir, null); bildir("Eşleşme kaldırıldı"); return fiyatListesiCiz(); }
    const al = e.target.closest("[data-fl-alis]"); if (al) { const x = bul(al.dataset.flAlis); if (!x) return; DB.guncelle("urunler", x.u.id, { alis_fiyati: x.yeni }); bildir(`${x.u.ad}: alış ${para(x.alis)} → ${para(x.yeni)}`); return fiyatListesiCiz(); }
    const st = e.target.closest("[data-fl-satis]"); if (st) { const x = bul(st.dataset.flSatis); if (x) tedarikciSatisDegis(x); }
  };
}

function flEslesmeyenCiz(l, bagli) {
  const c = $("fl-icerik"), dz = flDizin();
  const sayfa = l.slice(flSayfa * FL_SAYFA, (flSayfa + 1) * FL_SAYFA);
  const oneriHtml = (x, liste) => liste.map(o => `<div style="display:flex;align-items:center;gap:8px;margin:3px 0">${urunResmi(o.u)}<span style="flex:1">${kac("", o.u.ad)} <small style="opacity:.6">${kac("", o.u.barkod)} · alış ${para(o.u.alis_fiyati)}</small></span>${o.skor ? `<small style="opacity:.6">%${Math.round(o.skor * 100)}</small>` : ""}<button class="btn kucuk ana" data-fl-bagla="${kac("", x.an)}" data-urun="${o.u.id}">Bağla</button></div>`).join("");
  c.innerHTML = `<p style="font-size:13px;opacity:.8;margin:0 0 8px">Listedeki ürünün sizin programınızdaki karşılığını seçin (Bağla). Önerilen yoksa altındaki kutuya ürün adı ya da barkod yazın.</p>
  <table class="tablo"><tr><th style="width:34%">Listedeki ürün</th><th>Programdaki karşılığı</th></tr>
    ${sayfa.map((x, i) => {
      const o = flOneri(dz, x.s.ad, bagli);
      return `<tr><td>${kac("", x.s.ad)}${x.s.kod ? `<div style="font-size:12px;opacity:.6">${kac("", x.s.kod)}</div>` : ""}<div><strong>${para(x.s.fiyat)}</strong></div></td>
        <td>${oneriHtml(x, o) || '<div style="font-size:12px;opacity:.6">Benzer ürün bulunamadı; aşağıdan arayın</div>'}
          <input data-fl-ara="${i}" type="search" placeholder="Programda ara (ad, barkod)" style="height:34px;width:100%;max-width:360px;margin-top:4px" autocomplete="off"><div data-fl-sonuc="${i}"></div></td></tr>`;
    }).join("") || '<tr><td colspan="2" style="text-align:center;padding:20px;opacity:.7">Eşleşmeyen ürün yok</td></tr>'}
  </table>${flSayfaAlti(l.length)}`;
  c.querySelectorAll("[data-fl-ara]").forEach(g => g.addEventListener("input", () => {
    const q = trKucuk(g.value.trim()), x = sayfa[Number(g.dataset.flAra)];
    const sonuc = q.length < 2 ? [] : dz.liste.filter(u => trKucuk(u.ad).includes(q) || String(u.barkod || "").includes(g.value.trim())).slice(0, 6).map(u => ({ u }));
    c.querySelector(`[data-fl-sonuc="${g.dataset.flAra}"]`).innerHTML = oneriHtml(x, sonuc);
  }));
  c.onclick = e => {
    const git = e.target.closest("[data-fl-git]"); if (git) { flSayfa += Number(git.dataset.flGit); return fiyatListesiCiz(); }
    const b = e.target.closest("[data-fl-bagla]"); if (!b) return;
    flEslesmeYaz(b.dataset.flBagla, Number(b.dataset.urun));
    const u = DB.bul("urunler", y => y.id === Number(b.dataset.urun));
    bildir((u ? u.ad : "Ürün") + " bağlandı");
    fiyatListesiCiz();
  };
}
