// Veri katmanı. Tablo adları schema.sql ile aynıdır.
// Sunucu varsa veri sunucuda tutulur (oturum belirteci ile). Sunucu yoksa tarayıcıdaki yerel kopya kullanılır.
const DB = (() => {
  const ANAHTAR = "perakende_db_v1";
  const TOKEN_ANAHTARI = "perakende_token";
  // Bu tablolardaki kayıtlar yalnızca eklenir, sunucu bunları asla silmez
  const KALICI = ["satislar", "satis_kalemleri", "odemeler", "stok_hareketleri", "cari_hareketler", "sayimlar", "sayim_kalemleri", "alis_faturalari"];

  const bos = () => ({
    kullanicilar: [], kategoriler: [], urunler: [], stok_hareketleri: [],
    musteriler: [], satislar: [], satis_kalemleri: [], odemeler: [],
    cari_hareketler: [], sayimlar: [], sayim_kalemleri: [], alis_faturalari: [], ayarlar: {}, sayac: {}, _surum: 0
  });

  let veri;
  try { veri = { ...bos(), ...JSON.parse(localStorage.getItem(ANAHTAR)) }; } catch (e) { veri = bos(); }
  let sunucuVar = false;
  let gonderimZamani = null;

  const token = () => { try { return sessionStorage.getItem(TOKEN_ANAHTARI); } catch (e) { return null; } };
  const tokenYaz = t => { try { t ? sessionStorage.setItem(TOKEN_ANAHTARI, t) : sessionStorage.removeItem(TOKEN_ANAHTARI); } catch (e) {} };

  function yerelYaz() {
    try { localStorage.setItem(ANAHTAR, JSON.stringify(veri)); } catch (e) {}
  }

  function kaydet() {
    yerelYaz();
    if (!sunucuVar) return;
    clearTimeout(gonderimZamani);
    gonderimZamani = setTimeout(sunucuyaGonder, 250);
  }

  // Sunucuya kaydedilemeyen değişiklikler "bekleyen" olarak işaretlenir ve bir sonraki girişte birleştirilir
  // Aynı anda tek gönderim yapılır: yanıt gelmeden ikinci istek eski sürüm numarasıyla gidip sahte "çakışma"
  // üretirse yerel değişiklikler (yeni kullanıcı, silinen ürün vb.) sunucu verisiyle ezilirdi.
  let gonderiyor = false, tekrarGerekli = false;
  async function sunucuyaGonder() {
    if (!sunucuVar) return;
    if (gonderiyor) { tekrarGerekli = true; return; }
    gonderiyor = true;
    try { await sunucuyaGonderGercek(); }
    finally {
      gonderiyor = false;
      if (tekrarGerekli) { tekrarGerekli = false; clearTimeout(gonderimZamani); gonderimZamani = setTimeout(sunucuyaGonder, 50); }
    }
  }
  async function sunucuyaGonderGercek() {
    if (!sunucuVar) return;
    try {
      const yanit = await fetch("/api/durum", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + (token() || "") },
        body: JSON.stringify({ ...veri, _surum: veri._surum })
      });
      if (yanit.status === 409) {
        // Başka cihaz değişiklik yaptı: sunucu verisini al, yerel satışları koruyarak birleştir
        const sonuc = await yanit.json();
        veri._bekleyen = true;
        veri = birlestir(sonuc.guncel, veri);
        yerelYaz();
        DB.onCakisma && DB.onCakisma();
        gonderimZamani = setTimeout(sunucuyaGonder, 250);
        return;
      }
      if (yanit.status === 402) {
        // Lisans geçersiz: veriler tarayıcıda saklanır, lisans yenilenince sunucuya işlenir
        veri._bekleyen = true;
        yerelYaz();
        sunucuVar = false;
        tokenYaz(null);
        DB.onLisans && DB.onLisans();
        return;
      }
      if (yanit.status === 401) {
        veri._bekleyen = true;
        yerelYaz();
        sunucuVar = false;
        tokenYaz(null);
        DB.onOturumDustu && DB.onOturumDustu();
        return;
      }
      if (yanit.ok) {
        const sonuc = await yanit.json();
        veri._surum = sonuc._surum;
        delete veri._bekleyen;
        yerelYaz();
        return;
      }
      // Sunucu kaydı reddetti: sessiz kalma, kullanıcıya göster ve bir süre sonra yeniden dene
      veri._bekleyen = true;
      yerelYaz();
      let mesaj = "Sunucu hatası (" + yanit.status + ")";
      try { const h = await yanit.json(); if (h && h.hata) mesaj = h.hata; } catch (e2) { /* yanıt metni okunamadı */ }
      DB.onKayitHatasi && DB.onKayitHatasi(mesaj);
      gonderimZamani = setTimeout(sunucuyaGonder, 15000);
    } catch (e) {
      // Ağ hatası: değişiklikler bekleyen olarak kalır, sonraki kayıtta yeniden denenir
      veri._bekleyen = true;
      yerelYaz();
      gonderimZamani = setTimeout(sunucuyaGonder, 5000);
    }
  }

  // Sunucu verisine yerel (henüz gönderilmemiş) satış kayıtlarını ekler
  function birlestir(uzak, yerel) {
    const sonuc = { ...bos(), ...uzak };
    // Aynı numara sunucuda başka bir kayda verilmişse (ör. buluttan gelen fatura) yerel kayıt atılmaz: yeni numara alır,
    // ona bağlı satır/ödeme/cari kayıtları da yeni numarayı gösterir. Kayıt aynı mı, tarih ve ana alanlarından anlaşılır.
    const imza = x => [x.tarih, x.fis_no, x.satis_id, x.musteri_id, x.urun_id, x.sayim_id, x.tur, x.tutar, x.miktar].join("|");
    const yeniNo = {};
    const bagla = (t, x) => {
      const y = { ...x }, s = yeniNo.satislar;
      if (s && t !== "satislar" && s.has(y.satis_id)) y.satis_id = s.get(y.satis_id);
      if (s && t === "satislar" && s.has(y.iade_fis_id)) y.iade_fis_id = s.get(y.iade_fis_id);
      if (yeniNo.sayimlar && t === "sayim_kalemleri" && yeniNo.sayimlar.has(y.sayim_id)) y.sayim_id = yeniNo.sayimlar.get(y.sayim_id);
      return y;
    };
    for (const t of KALICI) {
      sonuc[t] = [...(sonuc[t] || [])]; // sunucudan gelen dizi değiştirilmesin
      const uzakNo = new Map(sonuc[t].map(x => [x.id, x]));
      let enBuyuk = Math.max(0, ...sonuc[t].map(x => x.id).filter(n => n < 1e9), (sonuc.sayac || {})[t] || 0, (yerel.sayac || {})[t] || 0);
      (yerel[t] || []).forEach(x => {
        const y = bagla(t, x), u = uzakNo.get(x.id);
        if (!u) return sonuc[t].push(y);
        if (imza(u) === imza(x)) return; // aynı kayıt, sunucudaki geçerli
        (yeniNo[t] = yeniNo[t] || new Map()).set(x.id, ++enBuyuk);
        y.id = enBuyuk;
        sonuc[t].push(y);
      });
      if (yeniNo[t]) { sonuc.sayac = sonuc.sayac || {}; sonuc.sayac[t] = Math.max(sonuc.sayac[t] || 0, enBuyuk); }
      sonuc[t].sort((a, b) => a.id - b.id);
    }
    // Sunucuya yazılamayan yeni kategori / ürün / müşteri kayıtları kaybolmasın: sunucunun bilmediği (numarası sunucu sayacından büyük) yerel kayıtlar eklenir
    for (const tb of ["kategoriler", "musteriler", "urunler"]) {
      const kayitli = new Set((sonuc[tb] || []).map(x => x.id)), sayacUzak = ((uzak && uzak.sayac) || {})[tb] || 0;
      (yerel[tb] || []).forEach(x => { if (!kayitli.has(x.id) && x.id > sayacUzak) { sonuc[tb] = sonuc[tb] || []; sonuc[tb].push(x); } });
    }
    // Stok, tüm stok hareketlerinin toplamından yeniden hesaplanır
    sonuc.urunler.forEach(u => {
      u.stok = Math.round(sonuc.stok_hareketleri.filter(h => h.urun_id === u.id).reduce((t, h) => t + h.miktar, 0) * 1000) / 1000;
    });
    for (const [t, d] of Object.entries(yerel.sayac || {})) sonuc.sayac[t] = Math.max(sonuc.sayac[t] || 0, d);
    sonuc._bekleyen = true;
    return sonuc;
  }

  // Sunucuya erişilebiliyor mu? Oturum geçersiz olsa bile sunucu yanıt verirse true döner.
  async function sunucuErisilebilir() {
    try {
      const yanit = await fetch("/api/durum", { headers: { Authorization: "Bearer " + (token() || "") } });
      return yanit.status === 200 || yanit.status === 401;
    } catch (e) {
      return false;
    }
  }

  // Sunucudan oturumla veri çeker. Oturum yoksa ya da geçersizse false döner.
  async function yukle() {
    if (!token()) return false;
    try {
      const yanit = await fetch("/api/durum", { headers: { Authorization: "Bearer " + token() } });
      if (yanit.status === 401) { tokenYaz(null); return false; }
      if (!yanit.ok) return false;
      const uzak = await yanit.json();
      sunucuVar = true;
      const bekleyenVar = !!veri._bekleyen;
      veri = bekleyenVar ? birlestir(uzak, veri) : { ...bos(), ...uzak };
      if (!bekleyenVar) delete veri._bekleyen;
      yerelYaz();
      if (bekleyenVar) kaydet();
      return true;
    } catch (e) {
      sunucuVar = false;
      return false;
    }
  }

  // Sunucuya giriş yapar. Sunucu yoksa null döner ve yerel giriş kullanılır.
  async function sunucuGirisi(kadi, sifre) {
    try {
      const yanit = await fetch("/api/giris", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kadi, sifre })
      });
      const sonuc = await yanit.json();
      if (!yanit.ok) return { ok: false, hata: sonuc.hata, lisans: !!sonuc.lisans };
      tokenYaz(sonuc.token);
      sunucuVar = true;
      return { ok: true, kullanici: sonuc.kullanici };
    } catch (e) {
      return null;
    }
  }

  function sunucuVarMi() { return sunucuVar; }

  function sonrakiId(tablo) {
    veri.sayac[tablo] = (veri.sayac[tablo] || 0) + 1;
    return veri.sayac[tablo];
  }

  function ekle(tablo, kayit) {
    const yeni = { id: sonrakiId(tablo), ...kayit };
    veri[tablo].push(yeni);
    kaydet();
    return yeni;
  }

  // Çok kayıt eklerken tek seferde kaydeder (ör. sayım başlarken yüzlerce kalem)
  function topluEkle(tablo, kayitlar) {
    const eklenen = kayitlar.map(k => {
      const yeni = { id: sonrakiId(tablo), ...k };
      veri[tablo].push(yeni);
      return yeni;
    });
    kaydet();
    return eklenen;
  }

  function guncelle(tablo, id, alanlar) {
    const k = veri[tablo].find(x => x.id === id);
    if (k) Object.assign(k, alanlar);
    kaydet();
    return k;
  }

  // Satış kayıtları silinemez (sunucu da korur). Silme yalnızca kategori gibi yönetim kayıtları içindir.
  const SILINEMEZ = ["satislar", "satis_kalemleri", "odemeler", "stok_hareketleri", "cari_hareketler", "sayimlar", "sayim_kalemleri", "alis_faturalari"];
  function sil(tablo, id) {
    if (SILINEMEZ.includes(tablo)) return false;
    veri[tablo] = veri[tablo].filter(x => x.id !== id);
    kaydet();
    return true;
  }

  function liste(tablo, filtre) {
    const kaynak = tablo === "urunler" ? veri[tablo].filter(x => !x.silindi) : veri[tablo];
    return filtre ? kaynak.filter(filtre) : kaynak.slice();
  }

  function bul(tablo, filtre) {
    return veri[tablo].find(filtre);
  }

  function stokHareketi(urunId, tur, miktar, aciklama, kullaniciId) {
    const urun = bul("urunler", u => u.id === urunId);
    if (!urun) return null;
    const hareket = ekle("stok_hareketleri", {
      urun_id: urunId, tur, miktar, aciklama: aciklama || "",
      kullanici_id: kullaniciId || null, tarih: new Date().toISOString()
    });
    urun.stok = Math.round((urun.stok + miktar) * 1000) / 1000;
    kaydet();
    return hareket;
  }

  function ayarOku(anahtar, varsayilan) {
    return veri.ayarlar[anahtar] !== undefined ? veri.ayarlar[anahtar] : varsayilan;
  }
  function ayarYaz(anahtar, deger) {
    veri.ayarlar[anahtar] = deger;
    kaydet();
  }

  function disaAktar() { return JSON.stringify(veri, null, 2); }
  function iceAktar(metin) { veri = { ...bos(), ...JSON.parse(metin) }; kaydet(); }
  function sifirla() { veri = bos(); yerelYaz(); }

  return {
    yukle, sunucuGirisi, sunucuErisilebilir, tokenYaz, token, sunucuVarMi,
    ekle, topluEkle, guncelle, sil, liste, bul, stokHareketi, ayarOku, ayarYaz, kaydet,
    disaAktar, iceAktar, sifirla, veri: () => veri, onCakisma: null, onKayitHatasi: null, onOturumDustu: null, onLisans: null
  };
})();

// SHA-256 ile şifre özeti (yerel giriş yedeği için)
async function sifreOzeti(metin) {
  const bytes = new TextEncoder().encode(metin);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}
