// Perakende satış sunucusu. Node.js 22.5+ içindeki yerleşik node:sqlite kullanılır, ek paket gerekmez.
// Çalıştırma: node server.js  →  http://localhost:3000
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const { tohumDurum, sha256 } = require("./seed");
const guncelleme = require("./guncelleme");

const PORT = process.env.PORT || 3000;
const KOK = __dirname;
const VERI_KLASORU = path.join(KOK, "data");
const OTURUM_SURESI = 12 * 60 * 60 * 1000;
fs.mkdirSync(VERI_KLASORU, { recursive: true });

const db = new DatabaseSync(path.join(VERI_KLASORU, "perakende.db"));
db.exec(fs.readFileSync(path.join(KOK, "db", "schema.sql"), "utf8"));
db.exec(`CREATE TABLE IF NOT EXISTS kayit (anahtar TEXT PRIMARY KEY, veri TEXT NOT NULL, guncelleme TEXT NOT NULL)`);

// Eski veritabanlarına sonradan eklenen kolonlar
function kolonEkle(tablo, kolon, tanim) {
  const var_mi = db.prepare(`PRAGMA table_info(${tablo})`).all().some(c => c.name === kolon);
  if (!var_mi) db.exec(`ALTER TABLE ${tablo} ADD COLUMN ${kolon} ${tanim}`);
}
kolonEkle("satislar", "iptal_tarihi", "TEXT");
kolonEkle("satislar", "iptal_eden_id", "INTEGER");
kolonEkle("satislar", "iptal_nedeni", "TEXT");
kolonEkle("satislar", "iptal_turu", "TEXT");
kolonEkle("urunler", "resim", "TEXT");
kolonEkle("cari_hareketler", "islem", "TEXT");
kolonEkle("cari_hareketler", "yontem", "TEXT");
kolonEkle("cari_hareketler", "kullanici_id", "INTEGER");

// Günde bir kez veritabanının yedeği alınır (data/yedek klasörü, son 30 gün tutulur)
function gunlukYedek() {
  try {
    const klasor = path.join(VERI_KLASORU, "yedek");
    fs.mkdirSync(klasor, { recursive: true });
    const hedef = path.join(klasor, `perakende-${new Date().toISOString().slice(0, 10)}.db`);
    if (!fs.existsSync(hedef)) db.exec(`VACUUM INTO '${hedef.replace(/'/g, "''")}'`);
    const dosyalar = fs.readdirSync(klasor).filter(f => f.startsWith("perakende-")).sort();
    dosyalar.slice(0, Math.max(0, dosyalar.length - 30)).forEach(f => fs.unlinkSync(path.join(klasor, f)));
  } catch (e) {
    console.error("Yedek alınamadı:", e.message);
  }
}

// Güncellemeden hemen önce veritabanının ayrı bir yedeği alınır (yeni sürüm tabloları/kolonları açılışta kendiliğinden ekler)
function guncellemeYedegi() {
  const klasor = path.join(VERI_KLASORU, "yedek");
  fs.mkdirSync(klasor, { recursive: true });
  const hedef = path.join(klasor, `guncelleme-oncesi-${new Date().toISOString().replace(/[:.]/g, "-")}.db`);
  db.exec(`VACUUM INTO '${hedef.replace(/'/g, "''")}'`);
  const eskiler = fs.readdirSync(klasor).filter(f => f.startsWith("guncelleme-oncesi-")).sort();
  eskiler.slice(0, Math.max(0, eskiler.length - 10)).forEach(f => fs.unlinkSync(path.join(klasor, f)));
}

const TIPLER = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json", ".png": "image/png", ".svg": "image/svg+xml" };
const TABLOLAR = ["kullanicilar", "kategoriler", "urunler", "stok_hareketleri", "sayimlar", "sayim_kalemleri", "musteriler", "satislar", "satis_kalemleri", "odemeler", "cari_hareketler"];
const KALICI_TABLOLAR = ["satislar", "satis_kalemleri", "odemeler", "stok_hareketleri", "cari_hareketler", "sayimlar", "sayim_kalemleri"];
const oturumlar = new Map(); // token → { kullaniciId, son }
// Oturumlar veritabanında da tutulur: sunucu yeniden başlasa bile kasadaki kullanıcı atılmaz
function oturumlariYukle() {
  const kayitli = (db.prepare("SELECT veri FROM kayit WHERE anahtar = 'oturumlar'").get() || {}).veri;
  if (!kayitli) return;
  for (const [token, o] of Object.entries(JSON.parse(kayitli))) {
    if (Date.now() - o.son < OTURUM_SURESI) oturumlar.set(token, o);
  }
}
function oturumlariKaydet() {
  db.prepare("INSERT OR REPLACE INTO kayit (anahtar, veri, guncelleme) VALUES ('oturumlar', ?, ?)")
    .run(JSON.stringify(Object.fromEntries(oturumlar)), new Date().toISOString());
}
oturumlariYukle();

// ---------- Kayıt okuma / yazma ----------
function kayitOku(anahtar) {
  const satir = db.prepare("SELECT veri FROM kayit WHERE anahtar = ?").get(anahtar);
  return satir ? JSON.parse(satir.veri) : null;
}

function kayitYaz(anahtar, veri) {
  db.prepare("INSERT OR REPLACE INTO kayit (anahtar, veri, guncelleme) VALUES (?, ?, ?)").run(anahtar, JSON.stringify(veri), new Date().toISOString());
}

function surum() {
  const s = kayitOku("surum");
  return s ? s.no : 0;
}

// İlk çalıştırmada örnek veriyi yaz
if (!kayitOku("durum")) {
  const ilk = tohumDurum();
  durumuYaz(ilk, true);
  kayitYaz("surum", { no: 1 });
}

function tabloAlanlari(tablo) {
  return db.prepare(`PRAGMA table_info(${tablo})`).all().map(c => c.name);
}

function degerHazirla(v) {
  if (v === undefined) return null;
  if (typeof v === "boolean") return v ? 1 : 0;
  if (typeof v === "object" && v !== null) return JSON.stringify(v);
  return v;
}

// Durum nesnesini hem JSON kaydı hem normalize tablolar olarak yazar
function durumuYaz(durum, ilkKurulum) {
  const mevcut = kayitOku("durum") || {};
  // Parola özetleri istemciden gelmez, sunucudaki değer korunur
  if (!ilkKurulum && Array.isArray(durum.kullanicilar)) {
    durum.kullanicilar = durum.kullanicilar.map(k => {
      const eski = (mevcut.kullanicilar || []).find(x => x.id === k.id);
      return { ...k, sifre_hash: k.sifre_hash || (eski && eski.sifre_hash) || "" };
    });
  }
  // Satış kayıtları asla silinmez: istemcide eksik olsa bile sunucudaki satırlar korunur.
  // Gelen satırlar aynı id'li olanların üzerine yazar (ör. fişin iptal durumuna geçmesi).
  if (!ilkKurulum) {
    for (const tablo of KALICI_TABLOLAR) {
      const gelen = durum[tablo] || [];
      const gelenIdler = new Set(gelen.map(x => x.id));
      const korunan = (mevcut[tablo] || []).filter(x => !gelenIdler.has(x.id));
      durum[tablo] = [...gelen, ...korunan].sort((a, b) => a.id - b.id);
    }
    // Sayaçlar geriye gitmesin (aynı id tekrar verilmesin)
    durum.sayac = durum.sayac || {};
    for (const [tablo, deger] of Object.entries(mevcut.sayac || {})) {
      durum.sayac[tablo] = Math.max(durum.sayac[tablo] || 0, deger);
    }
  }
  db.exec("BEGIN");
  try {
    // Önce çocuk tablolar silinir (yabancı anahtar hatası olmaması için)
    for (const tablo of [...TABLOLAR].reverse()) db.exec(`DELETE FROM ${tablo}`);
    for (const tablo of TABLOLAR) {
      const alanlar_tablo = tabloAlanlari(tablo);
      for (const satir of durum[tablo] || []) {
        const alanlar = Object.keys(satir).filter(a => alanlar_tablo.includes(a));
        if (!alanlar.length) continue;
        db.prepare(`INSERT OR REPLACE INTO ${tablo} (${alanlar.join(",")}) VALUES (${alanlar.map(() => "?").join(",")})`)
          .run(...alanlar.map(a => degerHazirla(satir[a])));
      }
    }
    kayitYaz("durum", durum);
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}

// İstemciye giden veride parola özeti olmaz
function istemciVerisi() {
  const d = kayitOku("durum") || {};
  return {
    ...d,
    kullanicilar: (d.kullanicilar || []).map(({ sifre_hash, ...k }) => k),
    _surum: surum()
  };
}

// ---------- Yardımcılar ----------
function json(res, kod, veri) {
  res.writeHead(kod, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(veri));
}

function govdeOku(req) {
  return new Promise((resolve, reject) => {
    let veri = "";
    req.on("data", p => { veri += p; if (veri.length > 20 * 1024 * 1024) reject(new Error("Veri çok büyük")); });
    req.on("end", () => resolve(veri));
    req.on("error", reject);
  });
}

function yerelMi(req) {
  const adres = req.socket.remoteAddress || "";
  return adres === "127.0.0.1" || adres === "::1" || adres === "::ffff:127.0.0.1";
}

function oturumDogrula(req) {
  const baslik = req.headers.authorization || "";
  const token = baslik.startsWith("Bearer ") ? baslik.slice(7) : "";
  const oturum = oturumlar.get(token);
  if (!oturum || Date.now() - oturum.son > OTURUM_SURESI) {
    oturumlar.delete(token);
    return null;
  }
  // Kayan süre: her istekte yenilenir, kayıt dakikada en fazla bir kez yazılır
  const onceki = oturum.son;
  oturum.son = Date.now();
  if (oturum.son - onceki > 60 * 1000) oturumlariKaydet();
  return oturum;
}

// ---------- Sunucu ----------
const sunucu = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  // Giriş: kullanıcı adı ve şifre sunucuda doğrulanır
  if (url.pathname === "/api/giris" && req.method === "POST") {
    try {
      const { kadi, sifre } = JSON.parse(await govdeOku(req) || "{}");
      const durum = kayitOku("durum") || {};
      const k = (durum.kullanicilar || []).find(x => String(x.kullanici_adi || "").trim().toLowerCase() === String(kadi || "").trim().toLowerCase() && x.aktif && x.sifre_hash === sha256(String(sifre || "")));
      if (!k) return json(res, 401, { ok: false, hata: "Kullanıcı adı veya şifre hatalı" });
      const token = crypto.randomUUID();
      oturumlar.set(token, { kullaniciId: k.id, son: Date.now() });
      oturumlariKaydet();
      return json(res, 200, { ok: true, token, kullanici: { id: k.id, ad_soyad: k.ad_soyad, kullanici_adi: k.kullanici_adi, rol: k.rol } });
    } catch (e) {
      return json(res, 400, { ok: false, hata: "Geçersiz istek" });
    }
  }

  // ---------- Sürüm ve güncelleme ----------
  // Sürüm bilgisi herkese açık. Denetleme ve uygulama yalnızca sunucu bilgisayarından (localhost) yapılabilir.
  // klasor: masaüstü uygulaması, açık sunucunun kendi klasöründen çalışıp çalışmadığını buradan anlar
  if (url.pathname === "/api/surum") return json(res, 200, { surum: guncelleme.surumOku().surum, klasor: KOK });

  // Masaüstü uygulaması kapanırken sunucuyu da kapatır (yalnızca bu bilgisayardan)
  if (url.pathname === "/api/kapat" && req.method === "POST") {
    if (!yerelMi(req)) return json(res, 403, { ok: false });
    json(res, 200, { ok: true });
    setTimeout(() => process.exit(0), 300);
    return;
  }

  // Marka (logo ve işletme adı) giriş ekranında da görünsün diye herkese açık okunur
  if (url.pathname === "/api/marka") {
    const ayarlar = (kayitOku("durum") || {}).ayarlar || {};
    return json(res, 200, { logo: ayarlar.logo || null, isletmeAdi: ayarlar.isletmeAdi || null });
  }

  // Güncelleme kaynağı (yayın klasörü veya web adresi) uygulamadan okunur ve değiştirilir; yalnızca bu bilgisayardan
  if (url.pathname === "/api/guncelleme/ayar") {
    if (!yerelMi(req)) return json(res, 403, { ok: false, hata: "Yalnızca sunucu bilgisayarından" });
    if (req.method === "GET") return json(res, 200, { ok: true, kaynak: guncelleme.ayarOku().kaynak || "" });
    if (req.method === "PUT") {
      try {
        const { kaynak } = JSON.parse((await govdeOku(req)) || "{}");
        return json(res, 200, { ok: true, ...guncelleme.ayarYaz(kaynak) });
      } catch (e) {
        return json(res, 400, { ok: false, hata: e.message });
      }
    }
    return json(res, 405, { ok: false });
  }

  if (url.pathname === "/api/guncelleme/kontrol") {
    if (!yerelMi(req)) return json(res, 403, { durum: "yetkisiz", hata: "Güncelleme yalnızca sunucu bilgisayarından yapılır" });
    return json(res, 200, await guncelleme.kontrolEt());
  }

  if (url.pathname === "/api/guncelleme/uygula" && req.method === "POST") {
    if (!yerelMi(req)) return json(res, 403, { ok: false, hata: "Güncelleme yalnızca sunucu bilgisayarından yapılır" });
    try {
      guncellemeYedegi();
      const sonuc = await guncelleme.uygula();
      json(res, 200, { ok: true, yeni: sonuc.yeni });
      setTimeout(() => guncelleme.yenidenBaslat(), 400); // yanıt gittikten sonra yeni sürümle yeniden başlar
    } catch (e) {
      json(res, 500, { ok: false, hata: e.message });
    }
    return;
  }

  // Deneme verilerini sıfırlar: ürün, kategori, stok, satış/fiş, müşteri ve cari kayıtları silinir.
  // Kullanıcılar ve ayarlar (logo, tema, ekstre tasarımı) kalır. Önce veritabanının yedeği alınır.
  if (url.pathname === "/api/deneme-sifirla" && req.method === "POST") {
    if (!yerelMi(req)) return json(res, 403, { ok: false, hata: "Sıfırlama yalnızca sunucu bilgisayarından yapılır" });
    const oturum = oturumDogrula(req);
    if (!oturum) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    try {
      const durum = kayitOku("durum") || {};
      const kullanici = (durum.kullanicilar || []).find(k => k.id === oturum.kullaniciId);
      if (!kullanici || kullanici.rol !== "yonetici") return json(res, 403, { ok: false, hata: "Yalnızca yönetici sıfırlayabilir" });
      const gelen = JSON.parse((await govdeOku(req)) || "{}");
      if (gelen.onay !== "SIFIRLA") return json(res, 400, { ok: false, hata: "Onay metni hatalı" });
      const klasor = path.join(VERI_KLASORU, "yedek");
      fs.mkdirSync(klasor, { recursive: true });
      const yedek = path.join(klasor, `sifirlama-oncesi-${new Date().toISOString().replace(/[:.]/g, "-")}.db`);
      db.exec(`VACUUM INTO '${yedek.replace(/'/g, "''")}'`);
      durum.sayac = durum.sayac || {};
      for (const tablo of TABLOLAR) {
        if (tablo === "kullanicilar") continue;
        durum[tablo] = [];
        durum.sayac[tablo] = 0;
      }
      durumuYaz(durum, true);
      kayitYaz("surum", { no: surum() + 1 });
      return json(res, 200, { ok: true, yedek: path.basename(yedek) });
    } catch (e) {
      return json(res, 500, { ok: false, hata: e.message });
    }
  }

  if (url.pathname === "/api/durum") {
    const oturum = oturumDogrula(req);
    if (!oturum) return json(res, 401, { ok: false, hata: "Oturum gerekli" });

    if (req.method === "GET") return json(res, 200, istemciVerisi());

    if (req.method === "PUT") {
      try {
        const gelen = JSON.parse(await govdeOku(req));
        const beklenen = gelen._surum;
        const su = surum();
        // Başka bir cihaz daha önce yazdıysa yazmayı reddet, güncel veriyi döndür
        if (beklenen !== undefined && beklenen !== su) {
          return json(res, 409, { ok: false, hata: "Veri başka bir cihazda değişti", guncel: istemciVerisi() });
        }
        delete gelen._surum;
        delete gelen._bekleyen;
        durumuYaz(gelen, false);
        kayitYaz("surum", { no: su + 1 });
        gunlukYedek();
        return json(res, 200, { ok: true, _surum: su + 1 });
      } catch (e) {
        return json(res, 400, { ok: false, hata: e.message });
      }
    }
    return json(res, 405, { ok: false });
  }

  // Statik dosyalar: yalnızca uygulama klasörü, veri ve sunucu kodu hariç
  const yol = path.normalize(path.join(KOK, url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname)));
  const yasakli = ["data", "onceki-surum", "server.js", "seed.js", "guncelleme.js", "yayinla.js", "baslat.js", "sifre-sifirla.js", "guncelleme-ayar.json"].map(a => path.join(KOK, a));
  if (!yol.startsWith(KOK) || yasakli.some(y => yol === y || yol.startsWith(y + path.sep))) {
    res.writeHead(403); return res.end("Erişim yok");
  }
  fs.readFile(yol, (hata, icerik) => {
    if (hata) { res.writeHead(404); return res.end("Bulunamadı"); }
    res.writeHead(200, { "Content-Type": TIPLER[path.extname(yol)] || "application/octet-stream", "Cache-Control": "no-cache" });
    res.end(icerik);
  });
});

gunlukYedek();

// Erişim: varsayılan olarak yalnızca bu bilgisayardan (güvenlik duvarı sorusu çıkmaz, ağdaki diğer cihazlar erişemez).
// Aynı sunucuya birden çok kasa bağlanacaksa uygulama-ayar.json içine {"erisim": "tum"} yazılır.
function uygulamaAyari() {
  try { return JSON.parse(fs.readFileSync(path.join(KOK, "uygulama-ayar.json"), "utf8")); } catch (e) { return {}; }
}
const DINLEME_ADRESI = uygulamaAyari().erisim === "tum" ? "0.0.0.0" : "127.0.0.1";

// Güncelleme sonrası yeni süreç eskisi kapanana kadar bekler (port boşalınca dinlemeye başlar)
let dinlemeDenemesi = 0;
sunucu.on("error", e => {
  if (e.code === "EADDRINUSE" && dinlemeDenemesi++ < 60) return setTimeout(() => sunucu.listen(PORT, DINLEME_ADRESI), 500);
  console.error(e);
  process.exit(1);
});
sunucu.on("listening", () => {
  console.log(`Perakende satış ${guncelleme.surumOku().surum} çalışıyor: http://localhost:${PORT} (${DINLEME_ADRESI === "0.0.0.0" ? "ağdan erişime açık" : "yalnızca bu bilgisayar"})`);
});
sunucu.listen(PORT, DINLEME_ADRESI);
