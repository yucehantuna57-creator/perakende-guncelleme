// Perakende satış sunucusu. Node.js 22.5+ içindeki yerleşik node:sqlite kullanılır, ek paket gerekmez.
// Çalıştırma: node server.js  →  http://localhost:3000
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const { tohumDurum, sha256 } = require("./seed");
const guncelleme = require("./guncelleme");

// Masaüstü uygulaması çıktıyı günlüğe yönlendirir; pencere kapanıp sunucu açık kalırsa bu borular kopar, sunucu çökmesin
process.stdout.on("error", () => {});
process.stderr.on("error", () => {});

const PORT = process.env.PORT || 3000;
const KOK = __dirname;
const VERI_KLASORU = path.join(KOK, "data");
const OTURUM_SURESI = 12 * 60 * 60 * 1000;
fs.mkdirSync(VERI_KLASORU, { recursive: true });

const db = new DatabaseSync(path.join(VERI_KLASORU, "perakende.db"));
db.exec(fs.readFileSync(path.join(KOK, "db", "schema.sql"), "utf8"));
db.exec(`CREATE TABLE IF NOT EXISTS kayit (anahtar TEXT PRIMARY KEY, veri TEXT NOT NULL, guncelleme TEXT NOT NULL)`);

// Eski veritabanlarına sonradan eklenen kolonlar
function kolonEkle(tablo, kolon, tanim) {
  const var_mi = db.prepare(`PRAGMA table_info(${tablo})`).all().some(c => c.name === kolon);
  if (!var_mi) db.exec(`ALTER TABLE ${tablo} ADD COLUMN ${kolon} ${tanim}`);
}
kolonEkle("satislar", "iptal_tarihi", "TEXT");
kolonEkle("satislar", "iptal_eden_id", "INTEGER");
kolonEkle("satislar", "iptal_nedeni", "TEXT");
kolonEkle("satislar", "iptal_turu", "TEXT");
kolonEkle("urunler", "resim", "TEXT");
kolonEkle("urunler", "kat_sira", "INTEGER");
kolonEkle("cari_hareketler", "islem", "TEXT");
kolonEkle("cari_hareketler", "yontem", "TEXT");
kolonEkle("cari_hareketler", "kullanici_id", "INTEGER");

// Eski veritabanlarında cari_hareketler tablosu yalnızca borç/tahsilat ve eski işlem türlerini kabul ediyordu;
// alış faturası (tedarikçi carisi) kayıtları için kısıtlar gevşetilir. Tablo, JSON verisinden her kayıtta yeniden yazılan bir yansımadır.
(function cariKisitlariniGevset() {
  const sql = (db.prepare("SELECT sql FROM sqlite_master WHERE name = 'cari_hareketler'").get() || {}).sql || "";
  if (!sql.includes("CHECK (islem IN") && !sql.includes("CHECK (tur IN ('borc', 'tahsilat'))")) return;
  db.exec("BEGIN");
  try {
    db.exec("ALTER TABLE cari_hareketler RENAME TO cari_hareketler_eski");
    db.exec(`CREATE TABLE cari_hareketler (
      id INTEGER PRIMARY KEY,
      musteri_id INTEGER NOT NULL REFERENCES musteriler(id),
      tur TEXT NOT NULL CHECK (tur IN ('borc', 'tahsilat', 'alacak')),
      tutar NUMERIC NOT NULL CHECK (tutar > 0),
      satis_id INTEGER REFERENCES satislar(id),
      aciklama TEXT,
      islem TEXT,
      yontem TEXT CHECK (yontem IN ('nakit', 'kart', 'havale')),
      kullanici_id INTEGER REFERENCES kullanicilar(id),
      tarih TEXT NOT NULL DEFAULT (datetime('now'))
    )`);
    db.exec("INSERT INTO cari_hareketler (id, musteri_id, tur, tutar, satis_id, aciklama, islem, yontem, kullanici_id, tarih) SELECT id, musteri_id, tur, tutar, satis_id, aciklama, islem, yontem, kullanici_id, tarih FROM cari_hareketler_eski");
    db.exec("DROP TABLE cari_hareketler_eski");
    db.exec("COMMIT");
  } catch (e) { db.exec("ROLLBACK"); console.error("cari_hareketler güncellenemedi:", e.message); }
})();

// Eski veritabanlarında satış kalemi ve ödeme tutarı pozitif olmak zorundaydı; iade kayıtları (eksi tutar) için kısıt gevşetilir.
// Bu iki tablo başka tablo tarafından referans edilmez; veriler korunarak yeniden kurulur.
function kisitiGevset(tablo, desenler) {
  try {
    const sql = (db.prepare("SELECT sql FROM sqlite_master WHERE name = ?").get(tablo) || {}).sql || "";
    let yeni = sql;
    desenler.forEach(r => { yeni = yeni.replace(r, ""); });
    if (!sql || yeni === sql) return;
    db.exec("BEGIN");
    db.exec(`ALTER TABLE ${tablo} RENAME TO ${tablo}_eski`);
    db.exec(yeni);
    db.exec(`INSERT INTO ${tablo} SELECT * FROM ${tablo}_eski`);
    db.exec(`DROP TABLE ${tablo}_eski`);
    db.exec("COMMIT");
  } catch (e) { try { db.exec("ROLLBACK"); } catch (e2) { /* işlem yok */ } console.error(tablo + " kısıtı gevşetilemedi:", e.message); }
}
kisitiGevset("satis_kalemleri", [/\s*CHECK\s*\(miktar > 0\)/]);
kisitiGevset("odemeler", [/\s*CHECK\s*\(tutar > 0\)/]);

// Günde bir kez veritabanının yedeği alınır (data/yedek klasörü, son 30 gün tutulur)
function gunlukYedek() {
  try {
    const klasor = path.join(VERI_KLASORU, "yedek");
    fs.mkdirSync(klasor, { recursive: true });
    const hedef = path.join(klasor, `perakende-${new Date().toISOString().slice(0, 10)}.db`);
    if (!fs.existsSync(hedef)) db.exec(`VACUUM INTO '${hedef.replace(/'/g, "''")}'`);
    const dosyalar = fs.readdirSync(klasor).filter(f => f.startsWith("perakende-")).sort();
    dosyalar.slice(0, Math.max(0, dosyalar.length - 30)).forEach(f => fs.unlinkSync(path.join(klasor, f)));
  } catch (e) {
    console.error("Yedek alınamadı:", e.message);
  }
  bulutYedek();
}

// Bulut yedeği: veritabanının kopyası OneDrive klasörüne yazılır, OneDrive da buluta yükler (bilgisayar bozulsa da veri kalır).
// En fazla saatte bir, günün dosyası güncellenir; son 60 gün tutulur. Başka klasör için uygulama-ayar.json: {"bulutYedek": "D:\\Yedek"}
let sonBulutYedek = 0;
function bulutYedekKlasoru() {
  const ayar = uygulamaAyari().bulutYedek;
  if (ayar === false || ayar === "") return null;
  if (ayar) return ayar;
  return process.env.OneDrive && fs.existsSync(process.env.OneDrive) ? path.join(process.env.OneDrive, "SOFTNEST-yedek", "veritabani") : null;
}
function bulutYedek() {
  if (Date.now() - sonBulutYedek < 3600 * 1000) return;
  sonBulutYedek = Date.now();
  try {
    const klasor = bulutYedekKlasoru();
    if (!klasor) return;
    fs.mkdirSync(klasor, { recursive: true });
    // Dosya adında bilgisayarın adı var: aynı OneDrive hesabını kullanan birden çok kasa birbirinin yedeğinin üzerine yazmasın
    const pc = String(require("node:os").hostname() || "kasa").replace(/[^A-Za-z0-9_-]/g, "") || "kasa";
    const hedef = path.join(klasor, `perakende-${pc}-${new Date().toISOString().slice(0, 10)}.db`), gecici = hedef + ".yaziliyor";
    fs.rmSync(gecici, { force: true });
    db.exec(`VACUUM INTO '${gecici.replace(/'/g, "''")}'`);
    fs.renameSync(gecici, hedef); // yarım dosya buluta gitmesin diye önce geçici adla yazılır
    const dosyalar = fs.readdirSync(klasor).filter(f => f.startsWith(`perakende-${pc}-`) && f.endsWith(".db")).sort();
    dosyalar.slice(0, Math.max(0, dosyalar.length - 60)).forEach(f => fs.unlinkSync(path.join(klasor, f)));
  } catch (e) {
    console.error("Bulut yedeği alınamadı:", e.message);
  }
}
setInterval(bulutYedek, 3600 * 1000).unref();

// Güncellemeden hemen önce veritabanının ayrı bir yedeği alınır (yeni sürüm tabloları/kolonları açılışta kendiliğinden ekler)
function guncellemeYedegi() {
  const klasor = path.join(VERI_KLASORU, "yedek");
  fs.mkdirSync(klasor, { recursive: true });
  const hedef = path.join(klasor, `guncelleme-oncesi-${new Date().toISOString().replace(/[:.]/g, "-")}.db`);
  db.exec(`VACUUM INTO '${hedef.replace(/'/g, "''")}'`);
  const eskiler = fs.readdirSync(klasor).filter(f => f.startsWith("guncelleme-oncesi-")).sort();
  eskiler.slice(0, Math.max(0, eskiler.length - 10)).forEach(f => fs.unlinkSync(path.join(klasor, f)));
}

// ---------- Yedekleme ve web ürün senkronu ----------
const YEDEK_KLASORU = path.join(VERI_KLASORU, "yedek");
const yedekAdiGecerli = ad => /^[A-Za-z0-9._-]+\.db$/.test(String(ad || ""));

// Yalnızca bu bilgisayardan, giriş yapmış YÖNETİCİ için. Değilse yanıtı gönderir ve null döner.
function yoneticiOturumu(req, res) {
  if (!yerelMi(req)) { json(res, 403, { ok: false, hata: "Bu işlem yalnızca bu bilgisayardan yapılır" }); return null; }
  const o = oturumDogrula(req);
  if (!o) { json(res, 401, { ok: false, hata: "Oturum gerekli" }); return null; }
  const k = ((kayitOku("durum") || {}).kullanicilar || []).find(x => x.id === o.kullaniciId);
  if (!k || k.rol !== "yonetici") { json(res, 403, { ok: false, hata: "Yalnızca yönetici yapabilir" }); return null; }
  return k;
}

function yedekOlustur(onEk) {
  fs.mkdirSync(YEDEK_KLASORU, { recursive: true });
  const ad = `${onEk}-${new Date().toISOString().replace(/[:.]/g, "-")}.db`;
  const hedef = path.join(YEDEK_KLASORU, ad);
  db.exec(`VACUUM INTO '${hedef.replace(/'/g, "''")}'`);
  return ad;
}

// Ürünler (barkod, ad, kategori, fiyat, stok) lisans anahtarıyla Supabase'e gönderilir; müşterinin web sitesi oradan okur.
// Yalnızca yönetici "Web sitesi" ayarını açtıysa çalışır. Müşteri, satış, şifre gibi başka bilgi gönderilmez.
const WEB_ADRES = "https://dbpbssdrwolssrdaypzw.supabase.co/rest/v1/rpc/web_urun_yukle";
let webCalisiyor = false;
async function webSenkron(zorla) {
  if (webCalisiyor) return { ok: false, hata: "Gönderim sürüyor" };
  const durum = kayitOku("durum") || {};
  if (!zorla && !(durum.ayarlar || {}).webSenkron) return { ok: false, hata: "Kapalı" };
  const l = lisansOku();
  if (!l.anahtar) return { ok: false, hata: "Önce lisans anahtarı girilmeli" };
  if (!lisansBilgi().gecerli) return { ok: false, hata: "Lisans geçersiz" };
  webCalisiyor = true;
  try {
    const kat = new Map((durum.kategoriler || []).map(k => [k.id, k.ad]));
    // Yönetici belirli ürünleri seçtiyse (ayarlar.webSecim = ürün numaraları) yalnızca onlar gönderilir; boşsa hepsi
    const secim = Array.isArray((durum.ayarlar || {}).webSecim) ? new Set(durum.ayarlar.webSecim) : null;
    const urunler = (durum.urunler || []).filter(u => u.aktif && !u.silindi && u.barkod && (!secim || secim.has(u.id)))
      .map(u => ({ barkod: String(u.barkod), ad: u.ad, kategori: kat.get(u.kategori_id) || null, fiyat: u.satis_fiyati, stok: u.stok }));
    const y = await fetch(WEB_ADRES, { method: "POST", headers: { apikey: LISANS_ANAHTAR, "Content-Type": "application/json" },
      body: JSON.stringify({ p_anahtar: l.anahtar, p_urunler: urunler }), signal: AbortSignal.timeout(30000) });
    const r = await y.json();
    const sonuc = r && r.ok ? { ok: true, adet: urunler.length, zaman: Date.now() } : { ok: false, hata: (r && (r.hata || r.message)) || "Gönderilemedi", zaman: Date.now() };
    kayitYaz("web_son", sonuc);
    return sonuc;
  } catch (e) {
    const sonuc = { ok: false, hata: "Sunucuya ulaşılamadı", zaman: Date.now() };
    kayitYaz("web_son", sonuc);
    return sonuc;
  } finally { webCalisiyor = false; }
}
setTimeout(() => webSenkron(false), 20000);
setInterval(() => webSenkron(false), 5 * 60 * 1000).unref();

// Telefon uygulamasıyla bulut eşitleme (ayrıntı: bulut.js)
const bulut = require("./bulut").kur({ kayitOku, kayitYaz, durumuYaz, surum, lisansOku, lisansBilgi });
const tedarikci = require("./tedarikci").kur({ kayitOku, kayitYaz });

const TIPLER = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json", ".png": "image/png", ".svg": "image/svg+xml" };
const TABLOLAR = ["kullanicilar", "kategoriler", "urunler", "stok_hareketleri", "sayimlar", "sayim_kalemleri", "musteriler", "satislar", "satis_kalemleri", "odemeler", "cari_hareketler"];
const KALICI_TABLOLAR = ["satislar", "satis_kalemleri", "odemeler", "stok_hareketleri", "cari_hareketler", "sayimlar", "sayim_kalemleri", "alis_faturalari"];
let kayitDenemeleri = [];

// Kayıt olanlar merkezi bir listeye (Supabase "kayitlar" tablosu) de bildirilir; böylece hangi bilgisayarda kim kaydolduysa
// geliştirici Supabase panelinden görür. Anahtar "yayınlanabilir" türdendir: tabloda yalnızca EKLEME yetkisi var, okuma/silme yok.
// Şifre veya şifre özeti gönderilmez. İnternet yoksa bildirim sırada bekler, sonraki fırsatta gönderilir.
const BULUT_ADRES = "https://dbpbssdrwolssrdaypzw.supabase.co/rest/v1/kayitlar";
const BULUT_ANAHTAR = "sb_publishable_XHbSoSAa11HFP9AAEM3esQ_ziAMPbqX";
async function bulutaBildir(kayit) {
  const sira = (kayitOku("bulut_bekleyen") || []).concat(kayit ? [kayit] : []);
  const kalan = [];
  for (const k of sira) {
    try {
      const y = await fetch(BULUT_ADRES, { method: "POST", headers: { apikey: BULUT_ANAHTAR, "Content-Type": "application/json", Prefer: "return=minimal" }, body: JSON.stringify(k), signal: AbortSignal.timeout(8000) });
      if (!y.ok && y.status >= 500) kalan.push(k); // sunucu hatası: sonra tekrar dene (istemci hatalarında vazgeçilir)
    } catch (e) { kalan.push(k); }
  }
  kayitYaz("bulut_bekleyen", kalan.slice(-200));
}
const oturumlar = new Map(); // token → { kullaniciId, son }
// Oturumlar veritabanında da tutulur: sunucu yeniden başlasa bile kasadaki kullanıcı atılmaz
function oturumlariYukle() {
  const kayitli = (db.prepare("SELECT veri FROM kayit WHERE anahtar = 'oturumlar'").get() || {}).veri;
  if (!kayitli) return;
  for (const [token, o] of Object.entries(JSON.parse(kayitli))) {
    if (Date.now() - o.son < OTURUM_SURESI) oturumlar.set(token, o);
  }
}
function oturumlariKaydet() {
  db.prepare("INSERT OR REPLACE INTO kayit (anahtar, veri, guncelleme) VALUES ('oturumlar', ?, ?)")
    .run(JSON.stringify(Object.fromEntries(oturumlar)), new Date().toISOString());
}
oturumlariYukle();

// ---------- Kayıt okuma / yazma ----------
function kayitOku(anahtar) {
  const satir = db.prepare("SELECT veri FROM kayit WHERE anahtar = ?").get(anahtar);
  return satir ? JSON.parse(satir.veri) : null;
}

function kayitYaz(anahtar, veri) {
  db.prepare("INSERT OR REPLACE INTO kayit (anahtar, veri, guncelleme) VALUES (?, ?, ?)").run(anahtar, JSON.stringify(veri), new Date().toISOString());
}

function surum() {
  const s = kayitOku("surum");
  return s ? s.no : 0;
}

// İlk çalıştırmada örnek veriyi yaz
if (!kayitOku("durum")) {
  const ilk = tohumDurum();
  durumuYaz(ilk, true);
  kayitYaz("surum", { no: 1 });
}

// ---------- Lisans ----------
// Satılan her kopya bir lisans anahtarıyla çalışır. Anahtarın durumu (aktif, bitiş tarihi) geliştiricinin Supabase
// "lisanslar" tablosunda tutulur; uygulama yalnızca kendi anahtarını sorabilir (tabloyu okuyamaz). Süre dolunca veya
// geliştirici anahtarı kapatınca giriş ve veri erişimi durur, veriler silinmez. Anahtar girilmemişse 7 gün deneme süresi vardır.
const LISANS_RPC = "https://dbpbssdrwolssrdaypzw.supabase.co/rest/v1/rpc/lisans_kontrol";
const LISANS_ANAHTAR = "sb_publishable_XHbSoSAa11HFP9AAEM3esQ_ziAMPbqX";
const DENEME_GUN = 7;
const CEVRIMDISI_GUN = 14; // internet bu kadar süre hiç doğrulanamazsa kilitlenir
const GUN = 24 * 3600 * 1000;

function lisansOku() {
  const l = kayitOku("lisans") || {};
  if (!l.deneme_basi) { l.deneme_basi = Date.now(); kayitYaz("lisans", l); }
  return l;
}

function lisansBilgi() {
  const l = lisansOku();
  const bugun = new Date().toISOString().slice(0, 10);
  const bilgi = { gelistirici: !!(l.durum && l.durum.gelistirici), gelistiriciKullanici: (l.durum && l.durum.gelistirici_kullanici) || null, anahtarVar: !!l.anahtar, deneme: !l.anahtar, isletme: (l.durum && l.durum.isletme) || null, bitis: (l.durum && l.durum.bitis) || null };
  if (!l.anahtar) {
    const kalan = Math.ceil((l.deneme_basi + DENEME_GUN * GUN - Date.now()) / GUN);
    return { ...bilgi, gecerli: kalan > 0, kalanGun: Math.max(0, kalan), neden: kalan > 0 ? "" : "deneme-bitti" };
  }
  const d = l.durum;
  if (!d) return { ...bilgi, gecerli: false, neden: "dogrulanmadi" };
  if (d.bulundu === false || d.aktif === false) return { ...bilgi, gecerli: false, neden: "iptal" };
  if (d.bitis && d.bitis < bugun) return { ...bilgi, gecerli: false, neden: "sure-doldu" };
  if (l.son_basari && Date.now() - l.son_basari > CEVRIMDISI_GUN * GUN) return { ...bilgi, gecerli: false, neden: "baglanti" };
  const kalan = d.bitis ? Math.ceil((new Date(d.bitis + "T23:59:59") - Date.now()) / GUN) : null;
  return { ...bilgi, gecerli: true, kalanGun: kalan, neden: "" };
}

const LISANS_MESAJLARI = {
  "deneme-bitti": "Deneme süresi doldu. Devam etmek için lisans anahtarınızı girin.",
  "sure-doldu": "Lisans süreniz doldu. Yenilemek için satıcınızla iletişime geçin.",
  "iptal": "Bu lisans kapatılmış. Satıcınızla iletişime geçin.",
  "dogrulanmadi": "Lisans doğrulanamadı. İnternet bağlantınızı kontrol edin.",
  "baglanti": "Lisans uzun süredir doğrulanamadı. İnternete bağlanıp uygulamayı yeniden açın."
};

async function lisansSor(anahtar) {
  const y = await fetch(LISANS_RPC, {
    method: "POST", headers: { apikey: LISANS_ANAHTAR, "Content-Type": "application/json" },
    body: JSON.stringify({ p_anahtar: anahtar, p_bilgisayar: require("node:os").hostname(), p_surum: guncelleme.surumOku().surum }),
    signal: AbortSignal.timeout(10000)
  });
  if (!y.ok) throw new Error("Lisans sunucusu yanıt vermedi (" + y.status + ")");
  return y.json();
}

// Kayıtlı anahtarın durumunu yeniler (açılışta ve birkaç saatte bir). İnternet yoksa son bilinen durum geçerli kalır.
async function lisansKontrolEt() {
  const l = lisansOku();
  if (!l.anahtar) return;
  try {
    const d = await lisansSor(l.anahtar);
    kayitYaz("lisans", { ...lisansOku(), durum: d, son_kontrol: Date.now(), son_basari: Date.now() });
  } catch (e) { /* çevrimdışı: eski durum korunur */ }
}
setTimeout(() => lisansKontrolEt(), 3000);
setInterval(() => lisansKontrolEt(), 2 * 3600 * 1000).unref();

function lisansEngeli(res) {
  const b = lisansBilgi();
  if (b.gecerli) return false;
  json(res, 402, { ok: false, lisans: true, neden: b.neden, hata: LISANS_MESAJLARI[b.neden] || "Lisans geçersiz" });
  return true;
}

function tabloAlanlari(tablo) {
  return db.prepare(`PRAGMA table_info(${tablo})`).all().map(c => c.name);
}

function degerHazirla(v) {
  if (v === undefined) return null;
  if (typeof v === "boolean") return v ? 1 : 0;
  if (typeof v === "object" && v !== null) return JSON.stringify(v);
  return v;
}

// Durum nesnesini hem JSON kaydı hem normalize tablolar olarak yazar
function durumuYaz(durum, ilkKurulum) {
  const mevcut = kayitOku("durum") || {};
  // Parola özetleri istemciden gelmez, sunucudaki değer korunur
  if (!ilkKurulum && Array.isArray(durum.kullanicilar)) {
    durum.kullanicilar = durum.kullanicilar.map(k => {
      const eski = (mevcut.kullanicilar || []).find(x => x.id === k.id);
      return { ...k, sifre_hash: k.sifre_hash || (eski && eski.sifre_hash) || "" };
    });
  }
  // Satış kayıtları asla silinmez: istemcide eksik olsa bile sunucudaki satırlar korunur.
  // Gelen satırlar aynı id'li olanların üzerine yazar (ör. fişin iptal durumuna geçmesi).
  if (!ilkKurulum) {
    for (const tablo of KALICI_TABLOLAR) {
      const gelen = durum[tablo] || [];
      const gelenIdler = new Set(gelen.map(x => x.id));
      const korunan = (mevcut[tablo] || []).filter(x => !gelenIdler.has(x.id));
      durum[tablo] = [...gelen, ...korunan].sort((a, b) => a.id - b.id);
    }
    // Sayaçlar geriye gitmesin (aynı id tekrar verilmesin)
    durum.sayac = durum.sayac || {};
    for (const [tablo, deger] of Object.entries(mevcut.sayac || {})) {
      durum.sayac[tablo] = Math.max(durum.sayac[tablo] || 0, deger);
    }
  }
  // Asıl veri JSON olarak ("kayit" tablosu) tutulur; normal tablolar yalnızca bir yansımadır. Yansıma yazılamasa bile
  // asıl kayıt mutlaka saklanır, böylece tek bir sorunlu satır yüzünden yapılan değişiklikler kaybolmaz.
  db.exec("BEGIN");
  try {
    // Önce çocuk tablolar silinir (yabancı anahtar hatası olmaması için)
    for (const tablo of [...TABLOLAR].reverse()) db.exec(`DELETE FROM ${tablo}`);
    for (const tablo of TABLOLAR) {
      const alanlar_tablo = tabloAlanlari(tablo);
      for (const satir of durum[tablo] || []) {
        const alanlar = Object.keys(satir).filter(a => alanlar_tablo.includes(a));
        if (!alanlar.length) continue;
        db.prepare(`INSERT OR REPLACE INTO ${tablo} (${alanlar.join(",")}) VALUES (${alanlar.map(() => "?").join(",")})`)
          .run(...alanlar.map(a => degerHazirla(satir[a])));
      }
    }
    db.exec("COMMIT");
  } catch (e) {
    try { db.exec("ROLLBACK"); } catch (e2) { /* işlem zaten bitti */ }
    console.error("Tablo yansıması yazılamadı (veri yine de kaydedildi):", e.message);
    kayitYaz("durum_yansima_hata", { zaman: Date.now(), hata: e.message });
  }
  kayitYaz("durum", durum);
}

// İstemciye giden veride parola özeti olmaz
function istemciVerisi() {
  const d = kayitOku("durum") || {};
  return {
    ...d,
    kullanicilar: (d.kullanicilar || []).map(({ sifre_hash, ...k }) => k),
    _surum: surum()
  };
}

// ---------- Yardımcılar ----------
function json(res, kod, veri) {
  res.writeHead(kod, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(veri));
}

function govdeOku(req) {
  return new Promise((resolve, reject) => {
    let veri = "";
    req.on("data", p => { veri += p; if (veri.length > 20 * 1024 * 1024) reject(new Error("Veri çok büyük")); });
    req.on("end", () => resolve(veri));
    req.on("error", reject);
  });
}

// ---- Yazıcı seçimi (Windows): liste + geçici varsayılan yazıcı. Yazdırma sonrası eski varsayılan geri alınır ----
const { execFile } = require("node:child_process");
function psCalistir(komut, env) {
  return new Promise((ok, hata) => execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", komut], { windowsHide: true, timeout: 15000, env: { ...process.env, ...(env || {}) } }, (e, out) => e ? hata(e) : ok(String(out || "").trim())));
}
function yaziciListele() {
  return psCalistir("Get-CimInstance Win32_Printer | Select-Object Name,Default | ConvertTo-Json -Compress").then(o => {
    const v = o ? JSON.parse(o) : []; return (Array.isArray(v) ? v : [v]).map(p => ({ ad: p.Name, varsayilan: !!p.Default }));
  });
}
function yaziciIsleri() {
  return psCalistir("$l = @(Get-Printer | ForEach-Object { Get-PrintJob -PrinterName $_.Name -ErrorAction SilentlyContinue } | Select-Object ID,PrinterName,DocumentName,JobStatus,TotalPages,Size,@{n='T';e={[string]$_.SubmittedTime}}); if ($l.Count -eq 0) { '[]' } else { ConvertTo-Json -InputObject $l -Compress }").then(o => {
    const a = JSON.parse(o || "[]");
    return a.map(j => ({ id: j.ID, yazici: j.PrinterName, belge: j.DocumentName, durum: String(j.JobStatus || ""), sayfa: j.TotalPages, boyut: j.Size }));
  });
}
let yaziciOnceki = null, yaziciZamanlayici = null;
async function yaziciSec(ad) {
  if (!ad) return;
  const liste = await yaziciListele();
  const hedef = liste.find(p => p.ad === ad);
  if (!hedef) throw new Error("Yazıcı bulunamadı: " + ad);
  if (yaziciOnceki === null) { const v = liste.find(p => p.varsayilan); yaziciOnceki = v ? v.ad : ""; }
  if (!hedef.varsayilan) await psCalistir("(New-Object -ComObject WScript.Network).SetDefaultPrinter($env:YAZICI_AD)", { YAZICI_AD: ad });
  clearTimeout(yaziciZamanlayici);
  yaziciZamanlayici = setTimeout(() => {
    const eski = yaziciOnceki; yaziciOnceki = null;
    if (eski) psCalistir("(New-Object -ComObject WScript.Network).SetDefaultPrinter($env:YAZICI_AD)", { YAZICI_AD: eski }).catch(() => {});
  }, 10000);
}

// HTML belgeyi PDF'e çevirir: bilgisayardaki Chrome (yoksa Edge) görünmez modda sayfayı PDF olarak yazdırır
function pdfUret(html) {
  const os = require("node:os");
  const kok = [process.env.ProgramFiles, process.env["ProgramFiles(x86)"], process.env.LOCALAPPDATA].filter(Boolean);
  const tarayici = [...kok.map(k => path.join(k, "Google", "Chrome", "Application", "chrome.exe")), ...kok.map(k => path.join(k, "Microsoft", "Edge", "Application", "msedge.exe"))].find(p => fs.existsSync(p));
  if (!tarayici) return Promise.reject(new Error("PDF için Chrome ya da Edge bulunamadı"));
  if (!html || html.length > 20 * 1024 * 1024) return Promise.reject(new Error("Belge boş ya da çok büyük"));
  const klasor = fs.mkdtempSync(path.join(os.tmpdir(), "softnest-pdf-"));
  const giris = path.join(klasor, "belge.html"), cikis = path.join(klasor, "belge.pdf");
  fs.writeFileSync(giris, html, "utf8");
  return new Promise((ok, hata) => {
    execFile(tarayici, ["--headless=new", "--disable-gpu", "--no-first-run", "--no-pdf-header-footer", "--user-data-dir=" + path.join(klasor, "profil"),
      "--print-to-pdf=" + cikis, "file:///" + giris.replace(/\\/g, "/")], { windowsHide: true, timeout: 45000, killSignal: "SIGKILL" }, () => {
      try {
        if (!fs.existsSync(cikis)) throw new Error("PDF oluşturulamadı");
        ok(fs.readFileSync(cikis));
      } catch (e) { hata(e); } finally { setTimeout(() => fs.rm(klasor, { recursive: true, force: true }, () => {}), 2000); }
    });
  });
}

function yerelMi(req) {
  const adres = req.socket.remoteAddress || "";
  return adres === "127.0.0.1" || adres === "::1" || adres === "::ffff:127.0.0.1";
}

function oturumDogrula(req) {
  const baslik = req.headers.authorization || "";
  const token = baslik.startsWith("Bearer ") ? baslik.slice(7) : "";
  const oturum = oturumlar.get(token);
  if (!oturum || Date.now() - oturum.son > OTURUM_SURESI) {
    oturumlar.delete(token);
    return null;
  }
  // Kayan süre: her istekte yenilenir, kayıt dakikada en fazla bir kez yazılır
  const onceki = oturum.son;
  oturum.son = Date.now();
  if (oturum.son - onceki > 60 * 1000) oturumlariKaydet();
  return oturum;
}

// ---------- Sunucu ----------
const sunucu = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  // Giriş: kullanıcı adı ve şifre sunucuda doğrulanır
  if (url.pathname === "/api/giris" && req.method === "POST") {
    if (lisansEngeli(res)) return;
    try {
      const { kadi, sifre } = JSON.parse(await govdeOku(req) || "{}");
      const durum = kayitOku("durum") || {};
      const k = (durum.kullanicilar || []).find(x => String(x.kullanici_adi || "").trim().toLowerCase() === String(kadi || "").trim().toLowerCase() && x.aktif && x.sifre_hash === sha256(String(sifre || "")));
      if (!k) return json(res, 401, { ok: false, hata: "Kullanıcı adı veya şifre hatalı" });
      const token = crypto.randomUUID();
      oturumlar.set(token, { kullaniciId: k.id, son: Date.now() });
      oturumlariKaydet();
      return json(res, 200, { ok: true, token, kullanici: { id: k.id, ad_soyad: k.ad_soyad, kullanici_adi: k.kullanici_adi, rol: k.rol } });
    } catch (e) {
      return json(res, 400, { ok: false, hata: "Geçersiz istek" });
    }
  }

  // Lisans durumu herkese açık (kilit ekranı için); anahtar girme de giriş gerektirmez
  if (url.pathname === "/api/lisans" && req.method === "GET") return json(res, 200, lisansBilgi());
  if (url.pathname === "/api/lisans" && req.method === "POST") {
    try {
      const govde = JSON.parse((await govdeOku(req)) || "{}"), anahtar = String(govde.anahtar || "").trim();
      if (anahtar.length < 4 || anahtar.length > 80) return json(res, 400, { ok: false, hata: "Lisans anahtarını girin" });
      let d;
      try { d = await lisansSor(anahtar); } catch (e) { return json(res, 503, { ok: false, hata: "Lisans sunucusuna ulaşılamadı. İnternet bağlantınızı kontrol edin." }); }
      if (!d.bulundu) return json(res, 404, { ok: false, hata: "Lisans anahtarı bulunamadı" });
      if (!d.aktif) return json(res, 403, { ok: false, hata: "Bu lisans kapatılmış" });
      if (d.bitis && d.bitis < new Date().toISOString().slice(0, 10)) return json(res, 403, { ok: false, hata: "Bu lisansın süresi dolmuş (" + d.bitis + ")" });
      kayitYaz("lisans", { ...lisansOku(), anahtar, durum: d, son_kontrol: Date.now(), son_basari: Date.now() });
      // "Lisanslı giriş yap" akışı: lisans girilince bulut eşitlemesi açılır ve işletmenin kullanıcıları/ürünleri bu bilgisayara alınır
      let esitleSonuc = null;
      if (govde.esitle) {
        const durum = kayitOku("durum") || {};
        durum.ayarlar = { ...(durum.ayarlar || {}), bulutEsitleme: true };
        durumuYaz(durum, false);
        kayitYaz("surum", { no: surum() + 1 });
        esitleSonuc = await bulut.esitle(true);
      }
      return json(res, 200, { ok: true, esitleme: esitleSonuc ? !!esitleSonuc.ok : null, ...lisansBilgi() });
    } catch (e) { return json(res, 400, { ok: false, hata: "Geçersiz istek" }); }
  }

  // İlk kurulum: hiç kullanıcı yokken yönetici hesabı ve işletme adı oluşturulur (örnek ürün/kullanıcı yoktur)
  if (url.pathname === "/api/kurulum" && req.method === "GET") {
    const d = kayitOku("durum") || {};
    return json(res, 200, { gerekli: !(d.kullanicilar || []).length, yoneticiVar: (d.kullanicilar || []).some(k => k.rol === "yonetici" && k.aktif) });
  }
  if (url.pathname === "/api/kurulum" && req.method === "POST") {
    if (lisansEngeli(res)) return;
    try {
      const durum = kayitOku("durum") || {};
      if ((durum.kullanicilar || []).length) return json(res, 409, { ok: false, hata: "Kurulum zaten yapılmış" });
      const g = JSON.parse((await govdeOku(req)) || "{}");
      const isletme = String(g.isletme || "").trim(), ad = String(g.ad || "").trim(), kadi = String(g.kadi || "").trim(), sifre = String(g.sifre || "");
      if (ad.length < 2) return json(res, 400, { ok: false, hata: "Ad soyad girin" });
      if (!/^[A-Za-z0-9ÇçĞğİıÖöŞşÜü._-]{3,30}$/.test(kadi)) return json(res, 400, { ok: false, hata: "Kullanıcı adı 3-30 karakter olmalı (harf, rakam, nokta, tire)" });
      if (sifre.length < 4) return json(res, 400, { ok: false, hata: "Şifre en az 4 karakter olmalı" });
      durum.sayac = durum.sayac || {};
      durum.sayac.kullanicilar = 1;
      durum.kullanicilar = [{ id: 1, ad_soyad: ad, kullanici_adi: kadi, sifre_hash: sha256(sifre), rol: "yonetici", aktif: 1 }];
      durum.ayarlar = { ...(durum.ayarlar || {}), ...(isletme ? { isletmeAdi: isletme } : {}) };
      durumuYaz(durum, true);
      kayitYaz("surum", { no: surum() + 1 });
      return json(res, 200, { ok: true });
    } catch (e) { return json(res, 400, { ok: false, hata: "Kurulum yapılamadı" }); }
  }

  // Kayıt ol: giriş yapmadan yeni "Satış" kullanıcısı oluşturur (yönetici rolü verilemez). Kayıt tarihi ve bilgisayar adı tutulur,
  // yönetici bunları Kullanıcılar sayfasında görür, istemediğini pasifleştirir veya siler.
  if (url.pathname === "/api/kayit" && req.method === "POST") {
    if (lisansEngeli(res)) return;
    try {
      const simdi = Date.now();
      kayitDenemeleri = kayitDenemeleri.filter(t => simdi - t < 3600 * 1000);
      if (kayitDenemeleri.length >= 30) return json(res, 429, { ok: false, hata: "Çok fazla kayıt denemesi. Biraz sonra tekrar deneyin" });
      kayitDenemeleri.push(simdi);
      const g = JSON.parse((await govdeOku(req)) || "{}");
      const ad = String(g.ad || "").trim(), kadi = String(g.kadi || "").trim(), sifre = String(g.sifre || "");
      const rol = "yonetici";
      if (ad.length < 2 || ad.length > 60) return json(res, 400, { ok: false, hata: "Ad soyad en az 2 karakter olmalı" });
      if (!/^[A-Za-z0-9ÇçĞğİıÖöŞşÜü._-]{3,30}$/.test(kadi)) return json(res, 400, { ok: false, hata: "Kullanıcı adı 3-30 karakter olmalı (harf, rakam, nokta, tire)" });
      if (sifre.length < 4) return json(res, 400, { ok: false, hata: "Şifre en az 4 karakter olmalı" });
      const durum = kayitOku("durum") || {};
      durum.kullanicilar = durum.kullanicilar || [];
      if (!durum.kullanicilar.length) return json(res, 409, { ok: false, hata: "Önce ilk kurulum yapılmalı" });
      if (durum.kullanicilar.some(k => String(k.kullanici_adi || "").trim().toLowerCase() === kadi.toLowerCase())) return json(res, 409, { ok: false, hata: "Bu kullanıcı adı bu bilgisayarda zaten kayıtlı, başka bir ad seçin" });
      durum.sayac = durum.sayac || {};
      const id = Math.max(durum.sayac.kullanicilar || 0, ...durum.kullanicilar.map(k => k.id || 0)) + 1;
      durum.sayac.kullanicilar = id;
      durum.kullanicilar.push({ id, ad_soyad: ad, kullanici_adi: kadi, sifre_hash: sha256(sifre), rol, aktif: 1, kendi_kaydi: 1, kayit_tarihi: new Date().toISOString(), kayit_bilgisayar: require("node:os").hostname() });
      durumuYaz(durum, false);
      kayitYaz("surum", { no: surum() + 1 });
      bulutaBildir({ kullanici_adi: kadi, ad_soyad: ad, bilgisayar: require("node:os").hostname(), isletme: ((durum.ayarlar || {}).isletmeAdi) || null, surum: guncelleme.surumOku().surum }).catch(() => {});
      return json(res, 200, { ok: true });
    } catch (e) {
      return json(res, 400, { ok: false, hata: "Kayıt yapılamadı" });
    }
  }

  // ---------- Sürüm ve güncelleme ----------
  // Sürüm bilgisi herkese açık. Denetleme ve uygulama yalnızca sunucu bilgisayarından (localhost) yapılabilir.
  // klasor: masaüstü uygulaması, açık sunucunun kendi klasöründen çalışıp çalışmadığını buradan anlar
  if (url.pathname === "/api/surum") return json(res, 200, { surum: guncelleme.surumOku().surum, klasor: KOK });

  // Masaüstü uygulaması kapanırken sunucuyu da kapatır (yalnızca bu bilgisayardan)
  if (url.pathname === "/api/kapat" && req.method === "POST") {
    if (!yerelMi(req)) return json(res, 403, { ok: false });
    json(res, 200, { ok: true });
    setTimeout(() => process.exit(0), 300);
    return;
  }

  // Marka (logo ve işletme adı) giriş ekranında da görünsün diye herkese açık okunur
  if (url.pathname === "/api/marka") {
    const ayarlar = (kayitOku("durum") || {}).ayarlar || {};
    return json(res, 200, { logo: ayarlar.logo || null, isletmeAdi: ayarlar.isletmeAdi || null });
  }

  // Güncelleme kaynağı (yayın klasörü veya web adresi) uygulamadan okunur ve değiştirilir; yalnızca bu bilgisayardan
  if (url.pathname === "/api/guncelleme/ayar") {
    if (!yerelMi(req)) return json(res, 403, { ok: false, hata: "Yalnızca sunucu bilgisayarından" });
    if (req.method === "GET") return json(res, 200, { ok: true, kaynak: guncelleme.ayarOku().kaynak || "" });
    if (req.method === "PUT") {
      try {
        const { kaynak } = JSON.parse((await govdeOku(req)) || "{}");
        return json(res, 200, { ok: true, ...guncelleme.ayarYaz(kaynak) });
      } catch (e) {
        return json(res, 400, { ok: false, hata: e.message });
      }
    }
    return json(res, 405, { ok: false });
  }

  if (url.pathname === "/api/guncelleme/kontrol") {
    if (!yerelMi(req)) return json(res, 403, { durum: "yetkisiz", hata: "Güncelleme yalnızca sunucu bilgisayarından yapılır" });
    return json(res, 200, await guncelleme.kontrolEt());
  }

  if (url.pathname === "/api/guncelleme/uygula" && req.method === "POST") {
    if (!yerelMi(req)) return json(res, 403, { ok: false, hata: "Güncelleme yalnızca sunucu bilgisayarından yapılır" });
    try {
      guncellemeYedegi();
      const sonuc = await guncelleme.uygula();
      json(res, 200, { ok: true, yeni: sonuc.yeni });
      setTimeout(() => guncelleme.yenidenBaslat(), 400); // yanıt gittikten sonra yeni sürümle yeniden başlar
    } catch (e) {
      json(res, 500, { ok: false, hata: e.message });
    }
    return;
  }

  // Deneme verilerini sıfırlar: ürün, kategori, stok, satış/fiş, müşteri ve cari kayıtları silinir.
  // Kullanıcılar ve ayarlar (logo, tema, ekstre tasarımı) kalır. Önce veritabanının yedeği alınır.
  // Yedekler: liste, şimdi yedek al, indir, geri yükle (yalnızca yönetici, yalnızca bu bilgisayardan)
  // SOFTNEST cari bağlantı kodu: bulut adresi + yayınlanabilir anahtar + bu işletmenin lisans anahtarı (yalnızca yönetici görür)
  // Yazıcılar: bu bilgisayardaki Windows yazıcılarını listeler; yazdırmadan önce seçilen yazıcıyı geçici varsayılan yapar
  if (url.pathname === "/api/yazicilar" && req.method === "GET") {
    if (!yerelMi(req) || !oturumDogrula(req)) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    return yaziciListele().then(l => json(res, 200, { ok: true, liste: l }), e => json(res, 200, { ok: false, hata: "Yazıcılar okunamadı: " + e.message }));
  }
  if (url.pathname === "/api/yazdirma-isleri" && req.method === "GET") {
    if (!yerelMi(req) || !oturumDogrula(req)) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    return yaziciIsleri().then(l => json(res, 200, { ok: true, liste: l }), e => json(res, 200, { ok: false, hata: "Yazdırma sırası okunamadı: " + e.message }));
  }
  if (url.pathname === "/api/yazdirma-iptal" && req.method === "POST") {
    if (!yerelMi(req) || !oturumDogrula(req)) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    return govdeOku(req).then(g => { const b = JSON.parse(g || "{}"); return psCalistir("Remove-PrintJob -PrinterName $env:YP -ID ([int]$env:YI)", { YP: String(b.yazici || ""), YI: String(Number(b.id) || 0) }); }).then(() => json(res, 200, { ok: true }), e => json(res, 200, { ok: false, hata: e.message }));
  }
  // Belgeyi (ekstre vb.) PDF olarak döndürür; uygulama bunu indirir
  if (url.pathname === "/api/pdf" && req.method === "POST") {
    if (!yerelMi(req) || !oturumDogrula(req)) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    return govdeOku(req).then(g => pdfUret(String((JSON.parse(g || "{}")).html || ""))).then(pdf => {
      res.writeHead(200, { "Content-Type": "application/pdf", "Content-Length": pdf.length, "Cache-Control": "no-store" });
      res.end(pdf);
    }, e => json(res, 200, { ok: false, hata: e.message }));
  }
  // Tedarikçi fiyat takibi (test aşaması: yalnızca okur, ürünlere dokunmaz). Yalnızca yönetici, yalnızca bu bilgisayardan.
  // Tedarikçi ürün görseli (yalnızca bu bilgisayardan; görseller sitede herkese açık olduğu için oturum istenmez, <img> ile gösterilir)
  if (url.pathname === "/api/tedarikci/gorsel" && req.method === "GET") {
    if (!yerelMi(req)) return json(res, 403, { ok: false });
    return tedarikci.site(url.searchParams.get("site")).gorsel(url.searchParams.get("yol")).then(g => { res.writeHead(200, { "Content-Type": g.tur, "Cache-Control": "max-age=86400" }); res.end(g.veri); }, e => json(res, 404, { ok: false, hata: e.message }));
  }
  if (url.pathname.startsWith("/api/tedarikci/")) {
    if (!yoneticiOturumu(req, res)) return;
    const yol = url.pathname.slice("/api/tedarikci/".length);
    if (yol === "siteler") return json(res, 200, { ok: true, liste: tedarikci.liste() });
    const td = tedarikci.site(url.searchParams.get("site")); // hangi tedarikçi: ?site=yamanlar | yapimarket
    if (yol === "ayar" && req.method === "GET") return json(res, 200, { ok: true, ...td.ayarOku() });
    if (yol === "ayar" && req.method === "PUT") return govdeOku(req).then(g => { td.ayarYaz(JSON.parse(g || "{}")); json(res, 200, { ok: true }); }, e => json(res, 400, { ok: false, hata: e.message }));
    if (yol === "cek" && req.method === "POST") return td.katalogCek().then(s => json(res, 200, s));
    if (yol === "durum") return json(res, 200, { ok: true, ...td.durum() });
    if (yol === "katalog") return json(res, 200, { ok: true, simdi: td.katalog(), onceki: td.katalogOnceki(), eslesme: td.eslesmeler(), yok: td.yoklar() });
    if (yol === "yok" && req.method === "PUT") return govdeOku(req).then(g => { td.yokYaz(JSON.parse(g || "{}")); json(res, 200, { ok: true }); }, e => json(res, 400, { ok: false, hata: e.message }));
    if (yol === "tum") return json(res, 200, { ok: true, ...(td.tum() || { urunler: [] }) });
    if (yol === "eslesme" && req.method === "PUT") return govdeOku(req).then(g => { td.eslesmeYaz(JSON.parse(g || "{}")); json(res, 200, { ok: true }); }, e => json(res, 400, { ok: false, hata: e.message }));
    return json(res, 404, { ok: false });
  }
  if (url.pathname === "/api/yazici-sec" && req.method === "POST") {
    if (!yerelMi(req) || !oturumDogrula(req)) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    return govdeOku(req).then(g => yaziciSec(String((JSON.parse(g || "{}")).ad || ""))).then(() => json(res, 200, { ok: true }), e => json(res, 200, { ok: false, hata: e.message }));
  }
  if (url.pathname === "/api/entegrasyon-kodu" && req.method === "GET") {
    if (!yoneticiOturumu(req, res)) return;
    const l = lisansOku();
    if (!l.anahtar) return json(res, 200, { ok: false, hata: "Önce lisans anahtarı girilmeli (Ayarlar → Lisans)" });
    const veri = { v: 1, url: "https://dbpbssdrwolssrdaypzw.supabase.co/rest/v1/rpc/bulut_gonder", apikey: LISANS_ANAHTAR, lisans: l.anahtar, cihaz: "cari" };
    return json(res, 200, { ok: true, kod: "SNC1-" + Buffer.from(JSON.stringify(veri), "utf8").toString("base64url"), yayinlanabilirAnahtar: LISANS_ANAHTAR });
  }
  if (url.pathname === "/api/yedekler" && req.method === "GET") {
    if (!yoneticiOturumu(req, res)) return;
    fs.mkdirSync(YEDEK_KLASORU, { recursive: true });
    const liste = fs.readdirSync(YEDEK_KLASORU).filter(yedekAdiGecerli).map(ad => { const st = fs.statSync(path.join(YEDEK_KLASORU, ad)); return { ad, boyut: st.size, tarih: st.mtimeMs }; }).sort((a, b) => b.tarih - a.tarih).slice(0, 60);
    return json(res, 200, { ok: true, liste });
  }
  if (url.pathname === "/api/yedek-al" && req.method === "POST") {
    if (!yoneticiOturumu(req, res)) return;
    try {
      const ad = yedekOlustur("elle");
      const elle = fs.readdirSync(YEDEK_KLASORU).filter(f => f.startsWith("elle-")).sort();
      elle.slice(0, Math.max(0, elle.length - 30)).forEach(f => fs.unlinkSync(path.join(YEDEK_KLASORU, f)));
      return json(res, 200, { ok: true, ad });
    } catch (e) { return json(res, 500, { ok: false, hata: e.message }); }
  }
  if (url.pathname === "/api/yedek-indir" && req.method === "GET") {
    if (!yoneticiOturumu(req, res)) return;
    const ad = url.searchParams.get("dosya");
    if (!yedekAdiGecerli(ad) || !fs.existsSync(path.join(YEDEK_KLASORU, ad))) return json(res, 404, { ok: false, hata: "Yedek bulunamadı" });
    res.writeHead(200, { "Content-Type": "application/octet-stream", "Content-Disposition": `attachment; filename="${ad}"` });
    return fs.createReadStream(path.join(YEDEK_KLASORU, ad)).pipe(res);
  }
  if (url.pathname === "/api/yedek-geri-yukle" && req.method === "POST") {
    if (!yoneticiOturumu(req, res)) return;
    try {
      const g = JSON.parse((await govdeOku(req)) || "{}");
      if (g.onay !== "GERI YUKLE") return json(res, 400, { ok: false, hata: "Onay metni hatalı" });
      if (!yedekAdiGecerli(g.dosya) || !fs.existsSync(path.join(YEDEK_KLASORU, g.dosya))) return json(res, 404, { ok: false, hata: "Yedek bulunamadı" });
      const yd = new DatabaseSync(path.join(YEDEK_KLASORU, g.dosya), { readOnly: true });
      let yedekDurum;
      try { const r = yd.prepare("SELECT veri FROM kayit WHERE anahtar = 'durum'").get(); yedekDurum = r && JSON.parse(r.veri); } finally { yd.close(); }
      if (!yedekDurum || !Array.isArray(yedekDurum.kullanicilar)) return json(res, 400, { ok: false, hata: "Bu dosya geçerli bir uygulama yedeği değil" });
      const oncesi = yedekOlustur("geri-yukleme-oncesi");
      durumuYaz(yedekDurum, true);
      kayitYaz("surum", { no: surum() + 1 });
      oturumlar.clear(); oturumlariKaydet();
      return json(res, 200, { ok: true, oncesi });
    } catch (e) { return json(res, 500, { ok: false, hata: e.message }); }
  }

  // Web sitesi bağlantısı: durum, şimdi gönder
  if (url.pathname === "/api/web-durum" && req.method === "GET") {
    if (!yoneticiOturumu(req, res)) return;
    const l = lisansOku();
    return json(res, 200, { ok: true, son: kayitOku("web_son") || null, anahtar: l.anahtar || null, acik: !!((kayitOku("durum") || {}).ayarlar || {}).webSenkron });
  }
  if (url.pathname === "/api/bulut-durum" && req.method === "GET") {
    if (!yoneticiOturumu(req, res)) return;
    const l = lisansOku();
    return json(res, 200, { ok: true, son: kayitOku("bulut_son") || null, anahtar: l.anahtar || null, acik: !!((kayitOku("durum") || {}).ayarlar || {}).bulutEsitleme });
  }
  if (url.pathname === "/api/bulut-esitle" && req.method === "POST") {
    if (!yoneticiOturumu(req, res)) return;
    return json(res, 200, await bulut.esitle(true));
  }
  if (url.pathname === "/api/web-gonder" && req.method === "POST") {
    if (!yoneticiOturumu(req, res)) return;
    return json(res, 200, await webSenkron(true));
  }

  if (url.pathname === "/api/deneme-sifirla" && req.method === "POST") {
    if (!yerelMi(req)) return json(res, 403, { ok: false, hata: "Sıfırlama yalnızca sunucu bilgisayarından yapılır" });
    const oturum = oturumDogrula(req);
    if (!oturum) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    try {
      const durum = kayitOku("durum") || {};
      const kullanici = (durum.kullanicilar || []).find(k => k.id === oturum.kullaniciId);
      if (!kullanici || kullanici.rol !== "yonetici") return json(res, 403, { ok: false, hata: "Yalnızca yönetici sıfırlayabilir" });
      const gelen = JSON.parse((await govdeOku(req)) || "{}");
      if (gelen.onay !== "SIFIRLA") return json(res, 400, { ok: false, hata: "Onay metni hatalı" });
      const klasor = path.join(VERI_KLASORU, "yedek");
      fs.mkdirSync(klasor, { recursive: true });
      const yedek = path.join(klasor, `sifirlama-oncesi-${new Date().toISOString().replace(/[:.]/g, "-")}.db`);
      db.exec(`VACUUM INTO '${yedek.replace(/'/g, "''")}'`);
      durum.sayac = durum.sayac || {};
      // kullanicilar:true ise kullanıcılar da silinir; uygulama ilk kurulum ekranına döner (kendi yöneticinizi oluşturursunuz)
      const kullanicilarDa = gelen.kullanicilar === true;
      for (const tablo of TABLOLAR) {
        if (tablo === "kullanicilar" && !kullanicilarDa) continue;
        durum[tablo] = [];
        durum.sayac[tablo] = 0;
      }
      durum.alis_faturalari = []; durum.sayac.alis_faturalari = 0;
      if (kullanicilarDa) { durum.ayarlar = {}; oturumlar.clear(); oturumlariKaydet(); }
      durumuYaz(durum, true);
      kayitYaz("surum", { no: surum() + 1 });
      return json(res, 200, { ok: true, yedek: path.basename(yedek), kullanicilarSilindi: kullanicilarDa });
    } catch (e) {
      return json(res, 500, { ok: false, hata: e.message });
    }
  }

  if (url.pathname === "/api/durum") {
    const oturum = oturumDogrula(req);
    if (!oturum) return json(res, 401, { ok: false, hata: "Oturum gerekli" });
    if (lisansEngeli(res)) return;

    if (req.method === "GET") return json(res, 200, istemciVerisi());

    if (req.method === "PUT") {
      try {
        const gelen = JSON.parse(await govdeOku(req));
        const beklenen = gelen._surum;
        const su = surum();
        // Başka bir cihaz daha önce yazdıysa yazmayı reddet, güncel veriyi döndür
        if (beklenen !== undefined && beklenen !== su) {
          return json(res, 409, { ok: false, hata: "Veri başka bir cihazda değişti", guncel: istemciVerisi() });
        }
        delete gelen._surum;
        delete gelen._bekleyen;
        durumuYaz(gelen, false);
        kayitYaz("surum", { no: su + 1 });
        gunlukYedek();
        return json(res, 200, { ok: true, _surum: su + 1 });
      } catch (e) {
        return json(res, 400, { ok: false, hata: e.message });
      }
    }
    return json(res, 405, { ok: false });
  }

  // Statik dosyalar: yalnızca uygulama klasörü, veri ve sunucu kodu hariç
  const yol = path.normalize(path.join(KOK, url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname)));
  const yasakli = ["data", "onceki-surum", "server.js", "seed.js", "guncelleme.js", "yayinla.js", "baslat.js", "sifre-sifirla.js", "guncelleme-ayar.json"].map(a => path.join(KOK, a));
  if (!yol.startsWith(KOK) || yasakli.some(y => yol === y || yol.startsWith(y + path.sep))) {
    res.writeHead(403); return res.end("Erişim yok");
  }
  fs.readFile(yol, (hata, icerik) => {
    if (hata) { res.writeHead(404); return res.end("Bulunamadı"); }
    res.writeHead(200, { "Content-Type": TIPLER[path.extname(yol)] || "application/octet-stream", "Cache-Control": "no-cache" });
    res.end(icerik);
  });
});

gunlukYedek();

// Erişim: varsayılan olarak yalnızca bu bilgisayardan (güvenlik duvarı sorusu çıkmaz, ağdaki diğer cihazlar erişemez).
// Aynı sunucuya birden çok kasa bağlanacaksa uygulama-ayar.json içine {"erisim": "tum"} yazılır.
function uygulamaAyari() {
  try { return JSON.parse(fs.readFileSync(path.join(KOK, "uygulama-ayar.json"), "utf8")); } catch (e) { return {}; }
}
const DINLEME_ADRESI = uygulamaAyari().erisim === "tum" ? "0.0.0.0" : "127.0.0.1";

// Güncelleme sonrası yeni süreç eskisi kapanana kadar bekler (port boşalınca dinlemeye başlar)
let dinlemeDenemesi = 0;
sunucu.on("error", e => {
  if (e.code === "EADDRINUSE" && dinlemeDenemesi++ < 60) return setTimeout(() => sunucu.listen(PORT, DINLEME_ADRESI), 500);
  console.error(e);
  process.exit(1);
});
sunucu.on("listening", () => {
  console.log(`Perakende satış ${guncelleme.surumOku().surum} çalışıyor: http://localhost:${PORT} (${DINLEME_ADRESI === "0.0.0.0" ? "ağdan erişime açık" : "yalnızca bu bilgisayar"})`);
});
sunucu.listen(PORT, DINLEME_ADRESI);
