// Yeni sürüm yayınlar: uygulama dosyalarını paketler ve güncelleme kaynağına koyar.
// Kullanım:  node yayinla.js "<değişiklik notları>" [sürüm] [yayın klasörü]
//   Sürüm yazılmazsa son rakam otomatik artar (1.0.0 → 1.0.1). Notlar "|" ile ayrılır.
// Örnek:     node yayinla.js "Fişlerde tarih filtresi eklendi|Barkod etiketi büyütüldü"
// Eski sıra da çalışır: node yayinla.js 1.1.0 "Not" [yayın klasörü]
// Yayın klasörü verilmezse guncelleme-ayar.json içindeki kaynak (klasör ise) kullanılır.
// Sonuç: yayın klasöründe surum.json ve uygulama.zip oluşur. Kasalardaki uygulama açılışta ve çalışırken
// (10 dakikada bir) güncelleme olduğunu sorar.
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const crypto = require("node:crypto");
const { execFileSync } = require("node:child_process");
const { surumOku, ayarOku, karsilastir, KORUNAN } = require("./guncelleme");

const KOK = __dirname;

// Yayın klasörü bir git deposunun (GitHub) içindeyse yeni sürüm otomatik commit edilip gönderilir (push);
// uzaktaki kasalar dosyaları depodan (raw.githubusercontent.com) indirir.
function gitteYayinla(klasor, surum) {
  const git = (...a) => execFileSync("git", ["-C", klasor, ...a], { stdio: "pipe" }).toString().trim();
  try { git("rev-parse", "--is-inside-work-tree"); } catch (e) { return; }
  try {
    git("add", "-A", ".");
    git("commit", "-m", "Surum " + surum, "--", ".");
    git("push");
    console.log("  GitHub : yeni sürüm depoya gönderildi (push).");
  } catch (e) {
    console.error("Uyarı: git ile gönderilemedi: " + String(e.stderr || e.message).trim());
  }
}

function hata(mesaj) {
  console.error("Hata: " + mesaj);
  process.exit(1);
}

// Bağımsız değişkenler: "<notlar>" [sürüm] [klasör]  ya da eski sıra: <sürüm> "<not>" [klasör]
const surumMu = a => /^\d+\.\d+\.\d+$/.test(a || "");
const argumanlar = process.argv.slice(2);
let yeniSurum, not, klasorArg;
if (surumMu(argumanlar[0])) {
  [yeniSurum, not, klasorArg] = argumanlar;
} else {
  not = argumanlar[0];
  if (surumMu(argumanlar[1])) { yeniSurum = argumanlar[1]; klasorArg = argumanlar[2]; } else klasorArg = argumanlar[1];
}
if (!not || !not.trim()) hata('Değişiklik notu yazın (kasada güncelleme penceresinde görünür). Kullanım: node yayinla.js "Not 1|Not 2" [sürüm] [yayın klasörü]');

const mevcut = surumOku();
if (!yeniSurum) {
  // Sürüm verilmediyse son rakam artırılır
  const p = mevcut.surum.split(".").map(Number);
  yeniSurum = `${p[0]}.${p[1]}.${(p[2] || 0) + 1}`;
}
if (karsilastir(yeniSurum, mevcut.surum) <= 0) hata(`Yeni sürüm (${yeniSurum}) mevcut sürümden (${mevcut.surum}) büyük olmalı.`);

// Kaynak web adresiyse (GitHub) yayın, yerel yayin klasörüne (depo kopyası) yazılır ve oradan gönderilir
let kaynak = klasorArg || ayarOku().kaynak;
if (!kaynak) hata("Yayın klasörü belirtilmedi ve guncelleme-ayar.json içinde kaynak yok.");
if (/^https?:\/\//i.test(kaynak) && !klasorArg) kaynak = "../yayin";
const yayinKlasoru = path.resolve(KOK, kaynak);
fs.mkdirSync(yayinKlasoru, { recursive: true });

// 1) Sürüm bilgisini yaz (yeni sürüm notları en başa eklenir)
const tarih = new Date().toISOString().slice(0, 10);
const notlar = not.split("|").map(s => s.trim()).filter(Boolean);
const surumBilgisi = {
  surum: yeniSurum, tarih, notlar,
  gecmis: [{ surum: yeniSurum, tarih, notlar }, ...(mevcut.gecmis || [])]
};
fs.writeFileSync(path.join(KOK, "surum.json"), JSON.stringify(surumBilgisi, null, 2) + "\n");

// 2) Paketlenecek dosyaları geçici klasöre topla
const sahne = fs.mkdtempSync(path.join(os.tmpdir(), "perakende-yayin-"));
try {
  for (const ad of fs.readdirSync(KOK)) {
    if (KORUNAN.has(ad)) continue;
    const kaynakYol = path.join(KOK, ad);
    if (path.resolve(kaynakYol) === yayinKlasoru) continue;
    fs.cpSync(kaynakYol, path.join(sahne, ad), { recursive: true });
  }

  // 3) Zip oluştur
  const zipYolu = path.join(yayinKlasoru, "uygulama.zip");
  fs.rmSync(zipYolu, { force: true });
  execFileSync("powershell", ["-NoProfile", "-NonInteractive", "-Command",
    `Compress-Archive -Path '${path.join(sahne, "*").replace(/'/g, "''")}' -DestinationPath '${zipYolu.replace(/'/g, "''")}' -Force`], { stdio: "pipe" });

  // 4) Kaynağa sürüm bildirimini yaz (en son yazılır, böylece yarım paket duyurulmaz)
  const sha256 = crypto.createHash("sha256").update(fs.readFileSync(zipYolu)).digest("hex");
  fs.writeFileSync(path.join(yayinKlasoru, "surum.json"), JSON.stringify({ ...surumBilgisi, dosya: "uygulama.zip", sha256 }, null, 2) + "\n");

  const boyut = (fs.statSync(zipYolu).size / 1024).toFixed(0);
  console.log(`Sürüm ${yeniSurum} yayınlandı.`);
  console.log(`  Klasör : ${yayinKlasoru}`);
  console.log(`  Paket  : uygulama.zip (${boyut} KB)`);
  console.log(`  Notlar : ${notlar.join(" · ")}`);
  gitteYayinla(yayinKlasoru, yeniSurum);
  console.log("Kasalardaki uygulama bir sonraki açılışta ya da çalışırken en geç 10 dakika içinde 'Güncelleme var, güncellemek ister misiniz?' diye soracak.");
} finally {
  fs.rmSync(sahne, { recursive: true, force: true });
}
