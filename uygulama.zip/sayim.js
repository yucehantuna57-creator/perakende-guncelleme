// Stok sayımı.
// Akış: sayım başlatılır (o anki sistem stoğu kaydedilir) → ürünler barkodla ya da elle sayılır (taslak kendiliğinden saklanır)
// → tamamlanınca sayılan ile sistem stoğu arasındaki fark "sayım" stok hareketi olarak işlenir.
// Fark, sayım başladığı andaki stoğa göre hesaplanır; sayım sürerken yapılan satışlar bozulmaz.

const SAYIM_KAPSAM = { hepsi: "Tüm ürünler", kategori: "Seçilen kategori", stoklu: "Yalnızca stoğu olan ürünler" };
const SAYIM_DURUM = { devam: { ad: "Devam ediyor", sinif: "bilgi" }, tamamlandi: { ad: "Tamamlandı", sinif: "iyi" }, iptal: { ad: "İptal edildi", sinif: "uyari" } };
const yuvarla3 = n => Math.round(n * 1000) / 1000;

function aktifSayim() {
  return DB.bul("sayimlar", s => s.durum === "devam");
}

function sayimKalemleri(sayimId) {
  return DB.liste("sayim_kalemleri", k => k.sayim_id === sayimId).map(k => ({
    k, u: DB.bul("urunler", x => x.id === k.urun_id) || { ad: "Silinmiş ürün", barkod: "", birim: "adet" }
  }));
}

// Sayılmadıysa null, sayıldıysa sayılan - sistem stoğu
function sayimFarki(k) {
  return k.sayilan === null || k.sayilan === undefined ? null : yuvarla3(k.sayilan - k.sistem_stok);
}

function sayimOzeti(kalemler) {
  const o = { toplam: kalemler.length, sayilan: 0, fazla: 0, eksik: 0, esles: 0, netAdet: 0, maliyet: 0 };
  kalemler.forEach(({ k }) => {
    const f = sayimFarki(k);
    if (f === null) return;
    o.sayilan++;
    if (f > 0) o.fazla++; else if (f < 0) o.eksik++; else o.esles++;
    o.netAdet += f;
    o.maliyet += f * (k.maliyet || 0);
  });
  o.kalan = o.toplam - o.sayilan;
  o.netAdet = yuvarla3(o.netAdet);
  o.maliyet = Math.round(o.maliyet * 100) / 100;
  return o;
}

const farkMetni = f => (f === null ? "-" : (f > 0 ? "+" : "") + sayi(f));
const farkSinifi = f => (f === null ? "" : f > 0 ? "sy-fazla" : f < 0 ? "sy-eksik" : "sy-tamam");
const sayimKim = id => (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad || "-";

// Giriş noktası: devam eden sayım varsa onu, yoksa başlangıç ekranını açar
function stokSayimiAc(sayimId) {
  const hedef = sayimId ? DB.bul("sayimlar", s => s.id === sayimId) : aktifSayim();
  if (hedef) sayimEkrani(hedef); else sayimBaslangicEkrani();
}

// ---------- Başlangıç ekranı: yeni sayım ve geçmiş sayımlar ----------
function sayimBaslangicEkrani() {
  const gecmis = DB.liste("sayimlar").sort((a, b) => b.id - a.id);
  const kategoriler = DB.liste("kategoriler");
  const bugun = new Date().toLocaleDateString("tr-TR");
  modalAc(`
    <div class="modal-baslik">Stok sayımı</div>
    <form id="sb-form" class="form" style="margin:10px 0 16px">
      <label>Sayım adı<input name="ad" value="Sayım ${bugun}" required maxlength="60"></label>
      <label>Kapsam<select name="kapsam">${Object.entries(SAYIM_KAPSAM).map(([k, ad]) => `<option value="${k}">${ad}</option>`).join("")}</select></label>
      <label id="sb-kat-kutu" style="visibility:hidden">Kategori<select name="kategori">${kategoriler.map(k => `<option value="${k.id}">${kac("", k.ad)}</option>`).join("")}</select></label>
      <label>Not<input name="aciklama" placeholder="İsteğe bağlı" maxlength="120"></label>
      <div class="hata tam" id="sb-hata"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="sb-kapat">Kapat</button><button class="btn ana" type="submit">Sayımı başlat</button></div>
    </form>
    <div class="baslik-satir"><h2>Geçmiş sayımlar</h2></div>
    <div style="overflow:auto;max-height:38vh">
      <table class="tablo">
        <tr><th>Tarih</th><th>Ad</th><th>Kapsam</th><th>Başlatan</th><th class="sag">Sayılan</th><th class="sag">Fazla / eksik</th><th class="sag">Fark tutarı</th><th>Durum</th><th></th></tr>
        ${gecmis.map(s => {
          const o = sayimOzeti(sayimKalemleri(s.id));
          return `<tr>
            <td>${tarih(s.baslangic)}</td><td>${kac("", s.ad)}</td><td>${SAYIM_KAPSAM[s.kapsam] || ""}</td><td>${kac("", sayimKim(s.kullanici_id))}</td>
            <td class="sag">${o.sayilan} / ${o.toplam}</td><td class="sag">${o.fazla} / ${o.eksik}</td><td class="sag">${para(o.maliyet)}</td>
            <td><span class="rozet ${SAYIM_DURUM[s.durum].sinif}">${SAYIM_DURUM[s.durum].ad}</span></td>
            <td><button class="btn kucuk" data-sayim="${s.id}">${s.durum === "devam" ? "Devam et" : "Aç"}</button></td>
          </tr>`;
        }).join("") || '<tr><td colspan="9">Henüz sayım yapılmadı</td></tr>'}
      </table>
    </div>`, "cok");

  const form = $("sb-form");
  form.elements.kapsam.addEventListener("change", () => { $("sb-kat-kutu").style.visibility = form.elements.kapsam.value === "kategori" ? "visible" : "hidden"; });
  $("sb-kapat").addEventListener("click", modalKapat);
  $("modal-icerik").querySelectorAll("[data-sayim]").forEach(b => b.addEventListener("click", () => stokSayimiAc(Number(b.dataset.sayim))));
  form.addEventListener("submit", e => {
    e.preventDefault();
    if (aktifSayim()) return ($("sb-hata").textContent = "Devam eden bir sayım var. Önce onu tamamlayın veya iptal edin.");
    const kapsam = form.elements.kapsam.value;
    const katId = Number(form.elements.kategori.value) || null;
    const urunler = DB.liste("urunler", u => u.aktif && (kapsam === "hepsi" || (kapsam === "kategori" && u.kategori_id === katId) || (kapsam === "stoklu" && u.stok !== 0)));
    if (!urunler.length) return ($("sb-hata").textContent = "Bu kapsamda sayılacak ürün yok");
    const s = DB.ekle("sayimlar", {
      ad: form.elements.ad.value.trim(), durum: "devam", kapsam, kategori_id: kapsam === "kategori" ? katId : null,
      aciklama: form.elements.aciklama.value.trim(), baslangic: new Date().toISOString(), bitis: null,
      kullanici_id: aktifKullanici.id, tamamlayan_id: null, sayilmayan_islem: null
    });
    // Her ürünün sayım başlangıcındaki stoğu ve alış fiyatı kaydedilir
    DB.topluEkle("sayim_kalemleri", urunler.map(u => ({
      sayim_id: s.id, urun_id: u.id, sistem_stok: u.stok, sayilan: null, maliyet: u.alis_fiyati || 0, uygulanan_fark: null, sayilma_tarihi: null
    })));
    bildir(`Sayım başladı · ${urunler.length} ürün`);
    sayimEkrani(s);
  });
}

// ---------- Sayım ekranı: sayma, filtreleme, fark takibi ----------
let sayimGorunum = { filtre: "hepsi", kategori: "" };

function sayimEkrani(s) {
  const duzenlenir = s.durum === "devam";
  const tum = sayimKalemleri(s.id);
  const kategoriler = DB.liste("kategoriler").filter(k => tum.some(({ u }) => u.kategori_id === k.id));
  const kapsamMetni = SAYIM_KAPSAM[s.kapsam] + (s.kapsam === "kategori" ? ` · ${(DB.bul("kategoriler", k => k.id === s.kategori_id) || {}).ad || ""}` : "");
  sayimGorunum = { filtre: "hepsi", kategori: "" };

  modalAc(`
    <div class="modal-baslik">${kac("", s.ad)} <span class="rozet ${SAYIM_DURUM[s.durum].sinif}">${SAYIM_DURUM[s.durum].ad}</span></div>
    <p style="margin:2px 0 8px;font-size:12px;opacity:0.75">${tarih(s.baslangic)} · ${kac("", sayimKim(s.kullanici_id))} · ${kac("", kapsamMetni)}${s.aciklama ? " · " + kac("", s.aciklama) : ""}${s.bitis ? ` · Bitiş ${tarih(s.bitis)}` : ""}</p>
    <div class="ozet-kutular" id="sy-ozet"></div>
    <div class="filtre" style="margin-bottom:8px">
      <input id="sy-ara" placeholder="${duzenlenir ? "Barkod okutun veya ürün ara" : "Ürün ara"}" autocomplete="off" style="min-width:240px">
      ${duzenlenir ? '<label class="onay-kutusu"><input type="checkbox" id="sy-arti" checked> Okutunca +1 say</label>' : ""}
      <select id="sy-filtre" aria-label="Göster">
        <option value="hepsi">Tüm ürünler</option><option value="sayilmayan">Sayılmayanlar</option>
        <option value="farkli">Farklı olanlar</option><option value="eksik">Eksik çıkanlar</option>
        <option value="fazla">Fazla çıkanlar</option><option value="esles">Eşleşenler</option>
      </select>
      <select id="sy-kat" aria-label="Kategori"><option value="">Tüm kategoriler</option>${kategoriler.map(k => `<option value="${k.id}">${kac("", k.ad)}</option>`).join("")}</select>
    </div>
    <div style="overflow:auto;max-height:44vh">
      <table class="tablo" id="sy-tablo">
        <thead><tr><th>Ürün</th><th>Barkod</th><th class="sag">Sistem stoğu</th><th class="sag">Sayılan</th><th class="sag">Fark</th><th class="sag">Fark tutarı</th><th></th></tr></thead>
        <tbody id="sy-govde"></tbody>
      </table>
    </div>
    <div class="modal-alt" id="sy-alt">
      <button class="btn" id="sy-rapor">Raporu yazdır</button>
      ${duzenlenir ? '<button class="btn tehlike" id="sy-iptal">Sayımı iptal et</button>' : ""}
      <button class="btn" id="sy-kapat">${duzenlenir ? "Sonra devam et" : "Kapat"}</button>
      ${duzenlenir ? '<button class="btn ana" id="sy-tamamla">Sayımı tamamla</button>' : ""}
    </div>`, "cok");

  const satirHtml = ({ k, u }) => {
    const f = sayimFarki(k);
    const fark = f === null ? null : f;
    return `<tr data-k="${k.id}" class="${farkSinifi(fark)}">
      <td>${urunResmi(u).replace('class="foto', 'class="foto sy-foto')}<span class="sy-ad">${kac("", u.ad)}</span></td>
      <td>${kac("", u.barkod)}</td>
      <td class="sag">${sayi(k.sistem_stok)} ${kac("", u.birim || "")}</td>
      <td class="sag">${duzenlenir
        ? `<span class="sy-giris"><button class="btn kucuk" data-eksi="${k.id}" aria-label="Azalt">−</button><input type="number" step="0.001" min="0" class="sy-sayilan" value="${k.sayilan === null || k.sayilan === undefined ? "" : k.sayilan}" placeholder="-" aria-label="Sayılan miktar"><button class="btn kucuk" data-arti="${k.id}" aria-label="Artır">+</button></span>`
        : (k.sayilan === null || k.sayilan === undefined ? "-" : sayi(k.sayilan))}</td>
      <td class="sag sy-fark"><strong>${farkMetni(fark)}</strong></td>
      <td class="sag sy-tutar">${fark === null ? "-" : para(fark * (k.maliyet || 0))}</td>
      <td>${duzenlenir ? `<button class="btn kucuk" data-sifirla="${k.id}">Temizle</button>` : (k.uygulanan_fark !== null && k.uygulanan_fark !== undefined ? `<span class="rozet ${k.uygulanan_fark === 0 ? "" : "bilgi"}">Stoğa işlendi ${farkMetni(k.uygulanan_fark)}</span>` : "")}</td>
    </tr>`;
  };

  const gorunenler = () => {
    const q = $("sy-ara").value.trim().toLowerCase();
    return tum.filter(({ k, u }) => {
      const f = sayimFarki(k);
      if (q && !(u.ad.toLowerCase().includes(q) || (u.barkod || "").includes(q))) return false;
      if (sayimGorunum.kategori && String(u.kategori_id) !== sayimGorunum.kategori) return false;
      switch (sayimGorunum.filtre) {
        case "sayilmayan": return f === null;
        case "farkli": return f !== null && f !== 0;
        case "eksik": return f !== null && f < 0;
        case "fazla": return f !== null && f > 0;
        case "esles": return f === 0;
        default: return true;
      }
    });
  };

  const ozetCiz = () => {
    const o = sayimOzeti(tum);
    $("sy-ozet").innerHTML = `
      <div class="ozet"><small>Sayılan ürün</small><strong>${o.sayilan} / ${o.toplam}</strong></div>
      <div class="ozet"><small>Kalan</small><strong>${o.kalan}</strong></div>
      <div class="ozet"><small>Fazla / eksik / eşleşen</small><strong>${o.fazla} / ${o.eksik} / ${o.esles}</strong></div>
      <div class="ozet"><small>Net fark (adet)</small><strong class="${farkSinifi(o.sayilan ? o.netAdet : null)}">${o.sayilan ? farkMetni(o.netAdet) : "-"}</strong></div>
      <div class="ozet"><small>Fark tutarı (alış)</small><strong class="${farkSinifi(o.sayilan ? o.maliyet : null)}">${para(o.maliyet)}</strong></div>`;
  };

  const govdeCiz = () => {
    const liste = gorunenler();
    $("sy-govde").innerHTML = liste.map(satirHtml).join("") || '<tr><td colspan="7">Bu filtreyle ürün yok</td></tr>';
  };

  // Sayılanı kaydeder, ilgili satırı ve özeti yerinde günceller (yazarken odak kaybolmasın)
  const sayilanYaz = (kalem, deger, satirEl) => {
    kalem.k.sayilan = deger;
    DB.guncelle("sayim_kalemleri", kalem.k.id, { sayilan: deger, sayilma_tarihi: deger === null ? null : new Date().toISOString() });
    const f = sayimFarki(kalem.k);
    if (satirEl) {
      satirEl.className = farkSinifi(f);
      satirEl.querySelector(".sy-fark").innerHTML = `<strong>${farkMetni(f)}</strong>`;
      satirEl.querySelector(".sy-tutar").textContent = f === null ? "-" : para(f * (kalem.k.maliyet || 0));
    }
    ozetCiz();
  };
  const kalemBul = id => tum.find(({ k }) => k.id === id);

  const body = $("sy-govde");
  if (duzenlenir) {
    body.addEventListener("input", e => {
      if (!e.target.classList.contains("sy-sayilan")) return;
      const tr = e.target.closest("tr");
      const ham = e.target.value.trim();
      sayilanYaz(kalemBul(Number(tr.dataset.k)), ham === "" ? null : Math.max(0, Number(ham)), tr);
    });
    body.addEventListener("click", e => {
      const b = e.target.closest("[data-arti], [data-eksi], [data-sifirla]");
      if (!b) return;
      const tr = b.closest("tr");
      const kalem = kalemBul(Number(tr.dataset.k));
      const mevcut = kalem.k.sayilan === null || kalem.k.sayilan === undefined ? 0 : kalem.k.sayilan;
      if (b.dataset.arti) sayilanYaz(kalem, yuvarla3(mevcut + 1), tr);
      if (b.dataset.eksi) sayilanYaz(kalem, Math.max(0, yuvarla3(mevcut - 1)), tr);
      if (b.dataset.sifirla) sayilanYaz(kalem, null, tr);
      const giris = tr.querySelector(".sy-sayilan");
      const k = kalem.k.sayilan;
      giris.value = k === null || k === undefined ? "" : k;
    });
  }

  $("sy-ara").addEventListener("input", govdeCiz);
  $("sy-filtre").addEventListener("change", e => { sayimGorunum.filtre = e.target.value; govdeCiz(); });
  $("sy-kat").addEventListener("change", e => { sayimGorunum.kategori = e.target.value; govdeCiz(); });

  // Barkod okutma: ürünü bulur, istenirse +1 sayar. Kapsamda olmayan ürün için sayıma ekleme sorulur.
  if (duzenlenir) {
    $("sy-ara").addEventListener("keydown", e => {
      if (e.key !== "Enter") return;
      e.preventDefault();
      const metin = $("sy-ara").value.trim();
      if (!metin) return;
      let kalem = tum.find(({ u }) => u.barkod === metin);
      if (!kalem) {
        const urun = DB.bul("urunler", u => u.aktif && u.barkod === metin);
        if (!urun) {
          const eslesen = gorunenler();
          if (eslesen.length === 1) kalem = eslesen[0];
          else {
            // Okuyucuyla yanlış okunan barkod kutuda kalmasın, sonraki okutma ona eklenmesin
            $("sy-ara").value = "";
            govdeCiz();
            return bildir("Bu barkod bulunamadı");
          }
        } else {
          if (!confirm(`"${urun.ad}" bu sayımın kapsamında değil. Sayıma eklensin mi?`)) return;
          const [yeni] = DB.topluEkle("sayim_kalemleri", [{ sayim_id: s.id, urun_id: urun.id, sistem_stok: urun.stok, sayilan: null, maliyet: urun.alis_fiyati || 0, uygulanan_fark: null, sayilma_tarihi: null }]);
          kalem = { k: yeni, u: urun };
          tum.push(kalem);
        }
      }
      if ($("sy-arti").checked) {
        const mevcut = kalem.k.sayilan === null || kalem.k.sayilan === undefined ? 0 : kalem.k.sayilan;
        sayilanYaz(kalem, yuvarla3(mevcut + 1), null);
      }
      $("sy-ara").value = "";
      govdeCiz();
      const tr = body.querySelector(`tr[data-k="${kalem.k.id}"]`);
      if (tr) {
        tr.scrollIntoView({ block: "nearest" });
        tr.classList.add("sy-yanip");
        if (!$("sy-arti").checked) tr.querySelector(".sy-sayilan").focus();
      }
    });
  }

  $("sy-kapat").addEventListener("click", sayimBaslangicEkrani);
  $("sy-rapor").addEventListener("click", () => sayimRaporuYazdir(s, gorunenler(), sayimGorunum.filtre !== "hepsi"));
  if (duzenlenir) {
    $("sy-tamamla").addEventListener("click", () => sayimTamamlaEkrani(s));
    $("sy-iptal").addEventListener("click", () => {
      if (!confirm("Sayım iptal edilsin mi? Girilen sayımlar kayıt olarak kalır, stok değişmez.")) return;
      DB.guncelle("sayimlar", s.id, { durum: "iptal", bitis: new Date().toISOString() });
      bildir("Sayım iptal edildi");
      sayimBaslangicEkrani();
    });
  }
  ozetCiz();
  govdeCiz();
  if (duzenlenir) $("sy-ara").focus();
}

// ---------- Tamamlama: farklar stoğa işlenir ----------
function sayimTamamlaEkrani(s) {
  if (aktifKullanici.rol !== "yonetici") {
    return bildir("Sayımı yalnızca yönetici tamamlayabilir, farklar stoğa işlenir");
  }
  const kalemler = sayimKalemleri(s.id);
  const o = sayimOzeti(kalemler);
  const farklilar = kalemler.filter(({ k }) => { const f = sayimFarki(k); return f !== null && f !== 0; });
  modalAc(`
    <div class="modal-baslik">Sayımı tamamla · ${kac("", s.ad)}</div>
    <div class="ozet-kutular" style="margin-top:10px">
      <div class="ozet"><small>Sayılan ürün</small><strong>${o.sayilan} / ${o.toplam}</strong></div>
      <div class="ozet"><small>Stoğa işlenecek fark</small><strong>${farklilar.length} ürün</strong></div>
      <div class="ozet"><small>Net fark (adet)</small><strong>${farkMetni(o.netAdet)}</strong></div>
      <div class="ozet"><small>Fark tutarı (alış)</small><strong>${para(o.maliyet)}</strong></div>
    </div>
    ${farklilar.length ? `<div style="overflow:auto;max-height:26vh"><table class="tablo"><tr><th>Ürün</th><th class="sag">Sistem</th><th class="sag">Sayılan</th><th class="sag">Fark</th></tr>
      ${farklilar.map(({ k, u }) => `<tr><td>${kac("", u.ad)}</td><td class="sag">${sayi(k.sistem_stok)}</td><td class="sag">${sayi(k.sayilan)}</td><td class="sag ${farkSinifi(sayimFarki(k))}"><strong>${farkMetni(sayimFarki(k))}</strong></td></tr>`).join("")}
    </table></div>` : '<p>Fark yok: tüm sayılan ürünler sistem stoğuyla eşleşiyor.</p>'}
    ${o.kalan ? `<form id="st-form" class="form" style="margin-top:10px">
      <p class="tam"><strong>${o.kalan} ürün sayılmadı.</strong> Bu ürünlerin stoğu ne olsun?</p>
      <label class="tam onay-kutusu"><input type="radio" name="islem" value="koru" checked> Değişmesin (sayılmayanlar olduğu gibi kalsın)</label>
      <label class="tam onay-kutusu"><input type="radio" name="islem" value="sifirla"> Sıfır kabul et (stoğu 0 yap)</label>
    </form>` : ""}
    <p style="font-size:12px;opacity:0.75">Fark, sayım başladığı andaki stoğa göre işlenir. Sayım sürerken yapılan satışlar etkilenmez.</p>
    <div class="modal-alt"><button class="btn" id="st-geri">Geri dön</button><button class="btn ana" id="st-uygula">Farkları stoğa işle ve tamamla</button></div>`, "cok");
  $("st-geri").addEventListener("click", () => sayimEkrani(s));
  $("st-uygula").addEventListener("click", () => {
    const islem = o.kalan ? new FormData($("st-form")).get("islem") : "koru";
    const isleyen = sayimUygula(s, islem);
    bildir(`Sayım tamamlandı · ${isleyen} üründe stok düzeltildi`);
    sayimEkrani(DB.bul("sayimlar", x => x.id === s.id));
    if (aktifSayfa === "stok") stokCiz();
    kasaUrunleriCiz();
  });
}

function sayimUygula(s, sayilmayanIslem) {
  let isleyen = 0;
  sayimKalemleri(s.id).forEach(({ k }) => {
    let fark = sayimFarki(k);
    if (fark === null && sayilmayanIslem === "sifirla") fark = yuvarla3(0 - k.sistem_stok);
    if (fark === null) return;
    if (fark !== 0) {
      DB.stokHareketi(k.urun_id, "sayim", fark, `Sayım: ${s.ad}`, aktifKullanici.id);
      isleyen++;
    }
    DB.guncelle("sayim_kalemleri", k.id, { uygulanan_fark: fark });
  });
  DB.guncelle("sayimlar", s.id, { durum: "tamamlandi", bitis: new Date().toISOString(), tamamlayan_id: aktifKullanici.id, sayilmayan_islem: sayilmayanIslem });
  return isleyen;
}

// ---------- Rapor ----------
function sayimRaporuYazdir(s, kalemler, filtreli) {
  const marka = markaBilgisi();
  const o = sayimOzeti(sayimKalemleri(s.id));
  sayfaIcindeYazdir(`<!doctype html><html><head><meta charset="utf-8"><title>Stok sayım raporu</title>
    <style>
      @page { size: A4; margin: 10mm; }
      body { font-family: Arial, sans-serif; font-size: 12px; color: #111; padding: 8mm 10mm; }
      .ust { display: flex; justify-content: space-between; color: #444; font-size: 11px; }
      .ust img { max-height: 36px; max-width: 120px; vertical-align: middle; margin-right: 8px; }
      h1 { text-align: center; color: #b00000; border-top: 3px solid #b00000; border-bottom: 3px solid #b00000; padding: 5px 0; font-size: 17px; margin: 8px 0 12px; }
      .bilgi { display: flex; flex-wrap: wrap; gap: 4px 28px; margin-bottom: 10px; } .bilgi b { margin-right: 4px; }
      table { width: 100%; border-collapse: collapse; } th { color: #b00000; text-align: left; border-bottom: 2px solid #b00000; padding: 4px 6px; }
      td { padding: 3px 6px; } tr:nth-child(even) td { background: #e6e6f6; } .sag { text-align: right; }
      thead { display: table-header-group; } tr { page-break-inside: avoid; }
      .toplam { margin-top: 12px; border-top: 2px solid #b00000; border-bottom: 2px solid #b00000; padding: 5px 6px; text-align: right; }
    </style></head><body>
    <div class="ust"><div>${marka.logo ? `<img src="${marka.logo}" alt="">` : ""}<strong>${kac("", marka.ad)}</strong></div><div>${tarih(new Date().toISOString())}</div></div>
    <h1>STOK SAYIM RAPORU${s.durum === "devam" ? " (TASLAK)" : s.durum === "iptal" ? " (İPTAL)" : ""}</h1>
    <div class="bilgi">
      <div><b>Sayım:</b>${kac("", s.ad)}</div><div><b>Başlangıç:</b>${tarih(s.baslangic)}</div>${s.bitis ? `<div><b>Bitiş:</b>${tarih(s.bitis)}</div>` : ""}
      <div><b>Başlatan:</b>${kac("", sayimKim(s.kullanici_id))}</div>${s.tamamlayan_id ? `<div><b>Tamamlayan:</b>${kac("", sayimKim(s.tamamlayan_id))}</div>` : ""}
      <div><b>Kapsam:</b>${SAYIM_KAPSAM[s.kapsam]}</div>${filtreli ? "<div><b>Liste:</b>Filtrelenmiş görünüm</div>" : ""}
    </div>
    <table><thead><tr><th>Ürün</th><th>Barkod</th><th class="sag">Sistem stoğu</th><th class="sag">Sayılan</th><th class="sag">Fark</th><th class="sag">Fark tutarı</th></tr></thead><tbody>
      ${kalemler.map(({ k, u }) => {
        const f = sayimFarki(k);
        return `<tr><td>${kac("", u.ad)}</td><td>${kac("", u.barkod)}</td><td class="sag">${sayi(k.sistem_stok)}</td><td class="sag">${k.sayilan === null || k.sayilan === undefined ? "-" : sayi(k.sayilan)}</td><td class="sag">${farkMetni(f)}</td><td class="sag">${f === null ? "-" : sayi2(f * (k.maliyet || 0))}</td></tr>`;
      }).join("") || '<tr><td colspan="6">Ürün yok</td></tr>'}
    </tbody></table>
    <div class="toplam">Sayılan <b>${o.sayilan}/${o.toplam}</b> &nbsp; Fazla <b>${o.fazla}</b> &nbsp; Eksik <b>${o.eksik}</b> &nbsp; Net fark <b>${farkMetni(o.netAdet)}</b> &nbsp; Fark tutarı <b>${sayi2(o.maliyet)} TL</b></div>
    </body></html>`);
}
