// ---------- Yardımcılar ----------
const $ = id => document.getElementById(id);
const para = n => Number(n || 0).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
const sayi = n => Number(n || 0).toLocaleString("tr-TR", { maximumFractionDigits: 3 });
const tarih = iso => new Date(iso).toLocaleString("tr-TR", { dateStyle: "short", timeStyle: "short" });
const kac = (alan, deger) => String(deger ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

function bildir(mesaj) {
  const b = $("bildirim");
  b.textContent = mesaj;
  b.classList.add("acik");
  clearTimeout(bildir.t);
  bildir.t = setTimeout(() => b.classList.remove("acik"), 1800);
}

function modalAc(html, genis) {
  // genis: true → geniş pencere, "cok" → ekranın büyük kısmını kaplayan (tasarım ekranı)
  $("modal-icerik").classList.toggle("genis", genis === true);
  $("modal-icerik").classList.toggle("cok-genis", genis === "cok");
  $("modal-icerik").innerHTML = html;
  $("modal").style.display = "flex";
}
function modalKapat() {
  $("modal").style.display = "none";
}

// ---------- Oturum ----------
let aktifKullanici = null;
const ROL_YETKI = { yonetici: ["kasa", "fis", "stok", "urunler", "musteri", "rapor", "kullanici", "ayar"], kasiyer: ["kasa", "fis", "musteri", "ayar"] };

async function tohumla() {
  if (DB.liste("kullanicilar").length) return;
  const ozet = await sifreOzeti("1234");
  DB.ekle("kullanicilar", { ad_soyad: "Yönetici", kullanici_adi: "admin", sifre_hash: ozet, rol: "yonetici", aktif: 1 });
  DB.ekle("kullanicilar", { ad_soyad: "Kasiyer Ayşe", kullanici_adi: "ayse", sifre_hash: ozet, rol: "kasiyer", aktif: 1 });
  const kat = ["Süt", "Ekmek", "İçecek", "Temizlik", "Atıştırmalık"].map(ad => DB.ekle("kategoriler", { ad }));
  const kid = ad => kat.find(k => k.ad === ad).id;
  [
    ["8690001", "Süt 1 L", "Süt", 42.5, 35, 20, 50, 10],
    ["8690002", "Beyaz peynir 500 g", "Süt", 118, 95, 1, 20, 5],
    ["8690003", "Ekmek", "Ekmek", 12, 8, 1, 60, 15],
    ["8690004", "Simit", "Ekmek", 15, 10, 1, 40, 10],
    ["8690005", "Su 1,5 L", "İçecek", 15, 10, 10, 80, 20],
    ["8690006", "Çay 500 g", "İçecek", 96, 80, 1, 25, 5],
    ["8690007", "Deterjan 3 kg", "Temizlik", 249, 200, 20, 12, 3],
    ["8690008", "Bulaşık süngeri", "Temizlik", 18.5, 12, 20, 30, 8],
    ["8690009", "Cips 150 g", "Atıştırmalık", 34.5, 25, 20, 45, 10],
    ["8690010", "Çikolata", "Atıştırmalık", 27, 19, 20, 4, 10]
  ].forEach(([barkod, ad, kategori, fiyat, alis, kdv, stok, kritik]) => {
    const u = DB.ekle("urunler", { barkod, ad, kategori_id: kid(kategori), satis_fiyati: fiyat, alis_fiyati: alis, kdv_orani: kdv, birim: "adet", stok: 0, kritik_stok: kritik, aktif: 1 });
    DB.stokHareketi(u.id, "giris", stok, "Açılış stoku", null);
  });
  DB.ekle("musteriler", { ad_soyad: "Mehmet Kaya", telefon: "0500 000 00 00", vergi_no: "", aktif: 1 });
}

// Stok menüsünde kritik veya eksi stoktaki ürün sayısı kırmızı rozetle görünür
function menuRozetleri() {
  const dugme = document.querySelector('#menu [data-sayfa="stok"]');
  if (!dugme) return;
  const kritik = DB.liste("urunler", u => u.aktif && u.stok <= u.kritik_stok).length;
  let rozet = dugme.querySelector(".rozet-sayi");
  if (!kritik) { if (rozet) rozet.remove(); return; }
  if (!rozet) {
    rozet = document.createElement("span");
    rozet.className = "rozet-sayi";
    dugme.appendChild(rozet);
  }
  rozet.textContent = kritik;
  rozet.title = `${kritik} ürün kritik veya eksi stokta`;
}

function yetkiUygula() {
  const izinli = ROL_YETKI[aktifKullanici.rol];
  document.querySelectorAll("#menu button").forEach(b => {
    b.style.display = izinli.includes(b.dataset.sayfa) ? "" : "none";
  });
  const rolAdi = aktifKullanici.rol === "yonetici" ? "Yönetici" : "Satış";
  $("kim").innerHTML = `<span class="avatar">${kac("", aktifKullanici.ad_soyad.trim().charAt(0).toLocaleUpperCase("tr"))}</span>
    <span class="kim-metin"><span class="kim-ad">${kac("", aktifKullanici.ad_soyad)}</span><span class="kim-rol">${rolAdi}</span></span>`;
  menuRozetleri();
}

// "Beni hatırla": kullanıcı adı ve şifre bu bilgisayarda saklanır, giriş ekranında hazır gelir
function girisDoldur() {
  try {
    const k = JSON.parse(localStorage.getItem("girisHatirla") || "null");
    $("g-hatirla").checked = !!k || localStorage.getItem("girisHatirlaKapali") !== "1";
    if (k) { $("g-kadi").value = k.k || ""; $("g-sifre").value = atob(k.s || ""); }
  } catch (e) { /* kayıt okunamazsa alanlar boş kalır */ }
}
function girisKaydet(kadi, sifre) {
  try {
    if ($("g-hatirla").checked) { localStorage.setItem("girisHatirla", JSON.stringify({ k: kadi, s: btoa(sifre) })); localStorage.removeItem("girisHatirlaKapali"); }
    else { localStorage.removeItem("girisHatirla"); localStorage.setItem("girisHatirlaKapali", "1"); }
  } catch (e) { /* saklanamazsa giriş yine çalışır */ }
}

// Giriş kapısı: önce lisans, sonra ilk kurulum, sonra normal giriş. Hangi formun görüneceğini belirler.
const GIRIS_FORMLARI = ["giris-form", "kayit-form", "kurulum-form", "lisans-form"];
function girisFormuGoster(ad) { GIRIS_FORMLARI.forEach(f => $(f).classList.toggle("gizli", f !== ad)); }
async function lisansBilgisi() { try { return await (await fetch("/api/lisans", { cache: "no-store" })).json(); } catch (e) { return null; } }
const LISANS_MESAJLARI = {
  "deneme-bitti": "Deneme süresi doldu. Devam etmek için lisans anahtarınızı girin.",
  "sure-doldu": "Lisans süreniz doldu. Yenilemek için satıcınızla iletişime geçin, yeni anahtarınız varsa girin.",
  "iptal": "Bu lisans kapatılmış. Satıcınızla iletişime geçin.",
  "dogrulanmadi": "Lisans doğrulanamadı. İnternet bağlantınızı kontrol edip anahtarınızı girin.",
  "baglanti": "Lisans uzun süredir doğrulanamadı. İnternete bağlanıp anahtarınızı tekrar girin."
};
function lisansEkraniGoster(neden) {
  $("giris").classList.remove("gizli");
  $("uygulama").classList.add("gizli");
  $("li-mesaj").textContent = LISANS_MESAJLARI[neden] || "Bu uygulamayı kullanmak için lisans anahtarı gerekli.";
  $("li-hata").textContent = "";
  girisFormuGoster("lisans-form");
}
async function girisEkraniHazirla() {
  const l = await lisansBilgisi();
  if (l && !l.gecerli) return lisansEkraniGoster(l.neden);
  let gerekli = false;
  try { gerekli = (await (await fetch("/api/kurulum", { cache: "no-store" })).json()).gerekli; } catch (e) { /* sunucu yoksa normal giriş */ }
  girisFormuGoster(gerekli ? "kurulum-form" : "giris-form");
  const sonra = $("giris-form");
  if (!gerekli && l && l.deneme && l.kalanGun != null && !$("deneme-not")) {
    const n = document.createElement("div");
    n.id = "deneme-not"; n.className = "kurulum-not"; n.textContent = "Deneme sürümü: " + l.kalanGun + " gün kaldı";
    sonra.insertBefore(n, $("g-hata"));
  }
}
async function kurulumYap(e) {
  e.preventDefault();
  if ($("ku-sifre").value !== $("ku-sifre2").value) { $("ku-hata").textContent = "Şifreler aynı değil"; return; }
  const govde = { isletme: $("ku-isletme").value.trim(), ad: $("ku-ad").value.trim(), kadi: $("ku-kadi").value.trim(), sifre: $("ku-sifre").value };
  try {
    const yanit = await fetch("/api/kurulum", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(govde) });
    const s = await yanit.json();
    if (!s.ok) { if (s.lisans) return lisansEkraniGoster(s.neden); $("ku-hata").textContent = s.hata; return; }
  } catch (err) { $("ku-hata").textContent = "Sunucuya ulaşılamadı"; return; }
  girisFormuGoster("giris-form");
  $("g-kadi").value = govde.kadi; $("g-sifre").value = govde.sifre;
  $("giris-form").requestSubmit();
}
async function lisansEtkinlestir(e) {
  e.preventDefault();
  $("li-hata").textContent = "";
  try {
    const yanit = await fetch("/api/lisans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ anahtar: $("li-anahtar").value.trim() }) });
    const s = await yanit.json();
    if (!s.ok) { $("li-hata").textContent = s.hata; return; }
  } catch (err) { $("li-hata").textContent = "Sunucuya ulaşılamadı"; return; }
  $("li-anahtar").value = "";
  await girisEkraniHazirla();
  const oturum = DB.token();
  if (oturum && aktifKullanici) { $("giris").classList.add("gizli"); $("uygulama").classList.remove("gizli"); }
}

// Kayıt ol: sunucuda "Satış" kullanıcısı oluşturur, ardından aynı bilgilerle giriş yapar
function kayitEkraniGoster(ac) {
  girisFormuGoster(ac ? "kayit-form" : "giris-form");
  $("kt-hata").textContent = "";
  if (ac) $("kt-ad").focus();
}
async function kayitOl(e) {
  e.preventDefault();
  const ad = $("kt-ad").value.trim(), kadi = $("kt-kadi").value.trim(), sifre = $("kt-sifre").value;
  if (sifre !== $("kt-sifre2").value) { $("kt-hata").textContent = "Şifreler aynı değil"; return; }
  try {
    const yanit = await (await fetch("/api/kayit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ad, kadi, sifre }) })).json();
    if (!yanit.ok) { $("kt-hata").textContent = yanit.hata; return; }
  } catch (err) { $("kt-hata").textContent = "Sunucuya ulaşılamadı"; return; }
  kayitEkraniGoster(false);
  $("g-kadi").value = kadi; $("g-sifre").value = sifre;
  $("giris-form").requestSubmit();
}

async function girisYap(e) {
  e.preventDefault();
  const kadi = $("g-kadi").value.trim();
  const sifre = $("g-sifre").value;
  let k = null;
  const sunucu = await DB.sunucuGirisi(kadi, sifre);
  if (sunucu && !sunucu.ok) {
    if (sunucu.lisans) { const l = await lisansBilgisi(); return lisansEkraniGoster(l && l.neden); }
    $("g-hata").textContent = sunucu.hata; return;
  }
  if (sunucu && sunucu.ok) {
    await DB.yukle();
    k = DB.bul("kullanicilar", x => x.id === sunucu.kullanici.id);
  } else {
    // Sunucu yoksa yerel kopya ile giriş
    const ozet = await sifreOzeti(sifre);
    k = DB.bul("kullanicilar", x => String(x.kullanici_adi || "").trim().toLowerCase() === kadi.toLowerCase() && x.sifre_hash === ozet && x.aktif);
  }
  if (!k) { $("g-hata").textContent = "Kullanıcı adı veya şifre hatalı"; return; }
  $("g-hata").textContent = "";
  girisKaydet(kadi, sifre);
  $("g-sifre").value = "";
  aktifKullanici = k;
  sessionStorage.setItem("oturum", String(k.id));
  oturumAc(true);
}

// Şifre girildikten sonra açılış animasyonu oynar, ardından kasa ekranı açılır.
// Sayfa yenilenince kayıtlı oturum varsa animasyon atlanır.
function oturumAc(animasyonlu) {
  $("giris").classList.add("gizli");
  const ac = () => {
    $("uygulama").classList.remove("gizli");
    yetkiUygula();
    satisSekmeleriniYukle();
    sayfaGoster("kasa");
  };
  if (!animasyonlu) return ac();
  const a = $("acilis");
  a.classList.remove("oynat");
  void a.offsetWidth; // animasyonu baştan başlatmak için
  a.classList.add("oynat");
  setTimeout(() => {
    a.classList.remove("oynat");
    ac();
  }, 2600);
}

function cikis() {
  setTimeout(girisDoldur, 0);
  sessionStorage.removeItem("oturum");
  DB.tokenYaz(null);
  satisSekmeleriniSakla(); // bekleyen satışlar çıkışta silinmez
  aktifKullanici = null;
  $("uygulama").classList.add("gizli");
  $("giris").classList.remove("gizli");
}

// ---------- Sayfa geçişi ----------
let aktifSayfa = "kasa";
function sayfaGoster(ad) {
  aktifSayfa = ad;
  menuRozetleri();
  // Sayfa değişince açık yan paneller kapanır
  urunPaneliKapat();
  kategoriPaneliKapat();
  document.querySelectorAll(".sayfa").forEach(s => s.classList.add("gizli"));
  $("s-" + ad).classList.remove("gizli");
  document.querySelectorAll("#menu button").forEach(b => b.classList.toggle("aktif", b.dataset.sayfa === ad));
  const cizen = { kasa: kasaCiz, fis: fislerCiz, stok: stokCiz, urunler: urunlerCiz, musteri: musteriCiz, rapor: raporCiz, kullanici: kullaniciCiz, ayar: ayarCiz };
  if (cizen[ad]) cizen[ad]();
}

// ---------- KASA ----------
let sepet = [];
let seciliKategori = ""; // boşsa ilk kategori seçilir
let indirim = { tur: "yuzde", deger: 0 };

// ---------- Çoklu satış (bekleyen müşteriler) ----------
// Her sekme kendi sepetini, indirimini ve müşterisini tutar. "+" ile yeni satış açılır, mevcut satış beklemeye alınır.
const SEKME_ANAHTARI = "kasaSatisSekmeleri";
const bosIndirim = () => ({ tur: "yuzde", deger: 0 });
let satisSekmeleri = [{ id: 1, sepet: [], indirim: bosIndirim(), musteriId: null }];
let aktifSekme = 1;
let sekmeSayaci = 1;

function aktifSekmeyiKaydet() {
  const s = satisSekmeleri.find(x => x.id === aktifSekme);
  if (!s) return;
  s.sepet = sepet;
  s.indirim = indirim;
  s.musteriId = seciliMusteriId;
}

function satisSekmeleriniSakla() {
  aktifSekmeyiKaydet();
  try { localStorage.setItem(SEKME_ANAHTARI, JSON.stringify({ satisSekmeleri, aktifSekme, sekmeSayaci })); } catch (e) {}
}

// Sayfa yenilense ya da çıkış yapılsa bile bekleyen satışlar korunur
function satisSekmeleriniYukle() {
  try {
    const k = JSON.parse(localStorage.getItem(SEKME_ANAHTARI));
    if (k && Array.isArray(k.satisSekmeleri) && k.satisSekmeleri.length && k.satisSekmeleri.some(x => x.id === k.aktifSekme)) {
      satisSekmeleri = k.satisSekmeleri;
      aktifSekme = k.aktifSekme;
      sekmeSayaci = Math.max(k.sekmeSayaci || 1, ...satisSekmeleri.map(x => x.id));
    }
  } catch (e) {}
  const s = satisSekmeleri.find(x => x.id === aktifSekme) || satisSekmeleri[0];
  aktifSekme = s.id;
  sepet = s.sepet;
  indirim = s.indirim;
  seciliMusteriId = s.musteriId;
}

function sekmeyiAc(id) {
  const s = satisSekmeleri.find(x => x.id === id);
  if (!s) return;
  aktifSekme = id;
  sepet = s.sepet;
  indirim = s.indirim;
  seciliMusteriId = s.musteriId;
  kasaCiz();
}

function sekmeyeGec(id) {
  if (id === aktifSekme) return;
  aktifSekmeyiKaydet();
  sekmeyiAc(id);
}

function yeniSatis() {
  aktifSekmeyiKaydet();
  sekmeSayaci += 1;
  satisSekmeleri.push({ id: sekmeSayaci, sepet: [], indirim: bosIndirim(), musteriId: null });
  sekmeyiAc(sekmeSayaci);
  // Barkod okuyucu yazabilsin diye arama kutusuna odaklanılır ama ürün paneli kendiliğinden açılmaz
  // (tıklamanın kendi odak değişikliğinden sonra çalışsın diye bir sonraki turda yapılır)
  setTimeout(() => {
    sessizOdak = true;
    $("arama").focus();
    sessizOdak = false;
  }, 0);
}

let sessizOdak = false;

// Sekmeyi kapatır. Doluysa sepet iptal fişi olarak kaydedilir.
function sekmeKapat(id) {
  if (satisSekmeleri.length === 1) return bildir("Son satış kapatılamaz");
  sekmeyeGec(id);
  if (sepet.length) {
    if (!confirm("Bu bekleyen satış iptal edilsin mi? İptal fişi olarak kaydedilir.")) return;
    sepetIptalKaydet("Bekleyen satış iptali");
  }
  satisSekmeleri = satisSekmeleri.filter(x => x.id !== id);
  sekmeyiAc(satisSekmeleri[0].id);
}

function sekmeleriCiz() {
  const kap = $("satis-sekmeleri");
  if (!kap) return;
  kap.innerHTML = satisSekmeleri.map(s => {
    const m = s.musteriId && DB.bul("musteriler", x => x.id === s.musteriId);
    const adet = s.sepet.reduce((t, k) => t + k.adet, 0);
    return `<button class="satis-sekme ${s.id === aktifSekme ? "aktif" : ""}" data-sek="${s.id}" title="${s.sepet.length ? para(s.sepet.reduce((t, k) => t + k.fiyat * k.adet, 0)) : "Boş satış"}">
      <span class="sekme-ad">${m ? kac("", m.ad_soyad) : "Satış " + s.id}</span>${adet ? `<span class="sekme-adet">${adet}</span>` : ""}
      ${satisSekmeleri.length > 1 ? `<span class="sekme-kapat" data-kapat="${s.id}" aria-label="Satışı kapat">×</span>` : ""}
    </button>`;
  }).join("") + '<button class="satis-sekme yeni" id="yeni-satis" title="Yeni satış (mevcut satış beklemeye alınır)" aria-label="Yeni satış">+</button>';
}

function sepetToplami() { return sepet.reduce((t, s) => t + s.fiyat * s.adet, 0); }
function indirimTutari() {
  const ara = sepetToplami();
  const t = indirim.tur === "yuzde" ? ara * indirim.deger / 100 : indirim.deger;
  return Math.min(ara, Math.max(0, Math.round(t * 100) / 100));
}
function genelToplam() { return sepetToplami() - indirimTutari(); }

function sepeteEkle(urunId) {
  const u = DB.bul("urunler", x => x.id === urunId);
  if (!u || !u.aktif) return;
  // Stok yetersiz olsa da satış yapılır, stok eksiye düşer
  const satir = sepet.find(s => s.id === urunId);
  if (satir) satir.adet += 1;
  else sepet.push({ id: u.id, ad: u.ad, fiyat: u.satis_fiyati, adet: 1 });
  sepetiCiz();
}

function adetDegistir(id, fark) {
  const satir = sepet.find(s => s.id === id);
  if (!satir) return;
  satir.adet += fark;
  if (satir.adet <= 0) sepet = sepet.filter(s => s.id !== id);
  sepetiCiz();
}

function sepetiCiz() {
  $("satirlar").innerHTML = sepet.length
    ? sepet.map(s => `
      <div class="satir">
        ${urunResmi(DB.bul("urunler", x => x.id === s.id))}
        <div>
          <div class="adi">${kac("", s.ad)}</div>
          <div class="alt">
            <button class="adet" data-id="${s.id}" data-fark="-1">−</button>
            <span>${s.adet}</span>
            <button class="adet" data-id="${s.id}" data-fark="1">+</button>
            <span>× ${para(s.fiyat)}</span>
          </div>
          <button class="sil" data-sil="${s.id}">Satırı sil</button>
        </div>
        <div class="tutar">${para(s.fiyat * s.adet)}</div>
      </div>`).join("")
    : '<div class="bos">Sepet boş. Ürün seçin veya barkod okutun.</div>';
  $("sepet-adet").textContent = sepet.reduce((t, s) => t + s.adet, 0) + " ürün";
  $("toplam").textContent = para(genelToplam());
  $("odeme-toplam").textContent = para(genelToplam());
  const ind = indirimTutari();
  $("indirim-bilgi").textContent = ind > 0
    ? `Ara toplam ${para(sepetToplami())} · İndirim -${para(ind)}${indirim.tur === "yuzde" ? ` (%${indirim.deger})` : ""}`
    : "";
  satisSekmeleriniSakla();
  sekmeleriCiz();
}

// İndirim butonu: kaç indirim yapılacağı sorulur (yüzde veya tutar)
function indirimSor() {
  if (sepet.length === 0) return bildir("Sepet boş");
  const ara = sepetToplami();
  modalAc(`
    <div class="modal-baslik">İndirim</div>
    <p>Ara toplam <strong>${para(ara)}</strong></p>
    <form id="in-form" class="form">
      <label>İndirim miktarı<input name="deger" type="number" step="0.01" min="0" value="${indirim.deger || ""}" required></label>
      <label>Türü<select name="tur"><option value="yuzde" ${indirim.tur === "yuzde" ? "selected" : ""}>Yüzde (%)</option><option value="tutar" ${indirim.tur === "tutar" ? "selected" : ""}>Tutar (TL)</option></select></label>
      <div class="tam hizli-indirim">
        ${[5, 10, 15, 20].map(y => `<button type="button" class="btn" data-yuzde="${y}">%${y}</button>`).join("")}
      </div>
      <div class="tam hata" id="in-hata"></div>
      <div class="modal-alt tam">
        <button type="button" class="btn" id="in-vazgec">Vazgeç</button>
        ${indirimTutari() > 0 ? '<button type="button" class="btn tehlike" id="in-kaldir">İndirimi kaldır</button>' : ""}
        <button class="btn ana" type="submit">Uygula</button>
      </div>
    </form>`);
  const form = $("in-form");
  form.elements.deger.focus();
  form.querySelectorAll("[data-yuzde]").forEach(b => b.addEventListener("click", () => {
    form.elements.deger.value = b.dataset.yuzde;
    form.elements.tur.value = "yuzde";
    $("in-hata").textContent = "";
  }));
  $("in-vazgec").addEventListener("click", modalKapat);
  if ($("in-kaldir")) $("in-kaldir").addEventListener("click", () => {
    indirim = { tur: "yuzde", deger: 0 };
    modalKapat();
    sepetiCiz();
    bildir("İndirim kaldırıldı");
  });
  form.addEventListener("submit", e => {
    e.preventDefault();
    const deger = Number(form.elements.deger.value);
    const tur = form.elements.tur.value;
    if (!(deger > 0)) return ($("in-hata").textContent = "Pozitif bir miktar girin");
    if (tur === "yuzde" && deger > 100) return ($("in-hata").textContent = "Yüzde 100'den büyük olamaz");
    if (tur === "tutar" && deger > ara) return ($("in-hata").textContent = "İndirim ara toplamdan büyük olamaz");
    indirim = { tur, deger };
    modalKapat();
    sepetiCiz();
    bildir(`İndirim uygulandı: -${para(indirimTutari())}`);
  });
}

function kasaUrunleriCiz() {
  const arama = $("arama").value.trim().toLowerCase();
  // Yalnızca yöneticinin tanımladığı kategoriler gösterilir ("Tümü" butonu yok). Seçili kategori yoksa ilk kategori açılır.
  const kategoriler = DB.liste("kategoriler");
  if (!kategoriler.some(k => k.ad === seciliKategori)) seciliKategori = kategoriler.length ? kategoriler[0].ad : "";
  const kat = kategoriler.find(k => k.ad === seciliKategori);
  // Arama yazılmışsa kategoriden bağımsız tüm ürünlerde aranır (barkod okutma için)
  const liste = DB.liste("urunler", u => u.aktif &&
    (arama
      ? u.ad.toLowerCase().includes(arama) || u.barkod.includes(arama)
      : !kategoriler.length || (kat && u.kategori_id === kat.id)));
  $("urun-listesi").innerHTML = liste.length
    ? liste.map(u => `<button class="urun ${u.stok <= 0 ? "tukendi" : ""}" data-urun="${u.id}">${urunResmi(u)}<div class="ad">${kac("", u.ad)}</div><div class="fiyat">${para(u.satis_fiyati)}</div><div class="fiyat">Stok: ${sayi(u.stok)}</div></button>`).join("")
    : `<div class="bos">${arama ? "Eşleşen ürün yok." : "Bu kategoride ürün yok."}</div>`;
  $("kategoriler").innerHTML = kategoriler.map(k =>
    `<button class="kat ${k.ad === seciliKategori ? "secili" : ""}" data-kat="${kac("", k.ad)}">${kac("", k.ad)}</button>`).join("");
}

function kasaCiz() {
  menuRozetleri(); // satıştan sonra stok değişmiş olabilir
  sepetiCiz();
  kasaUrunleriCiz();
  kasaMusteriDurumu();
}

// Fiyat sorgu kutusu: göz düğmesine basılınca açılır, okutulan barkodun ürün fiyatını gösterir (sepete eklemez)
let fiyatModu = false;
function fiyatKutusuAc(ac) {
  fiyatModu = ac;
  $("fiyat-gor").classList.toggle("aktif", ac);
  $("fiyat-kutu").classList.toggle("acik", ac);
  if (ac) {
    $("fiyat-kutu-icerik").innerHTML = '<div class="fk-bos"><div class="fk-ikon">▥</div>Barkodu okutun</div>';
    $("arama").value = "";
    sessizOdak = true; $("arama").focus(); sessizOdak = false;
  }
}
function fiyatGoster(metin) {
  const k = $("fiyat-kutu-icerik");
  const u = DB.bul("urunler", x => x.barkod === metin);
  $("arama").value = "";
  if (!u) { k.innerHTML = '<div class="fk-bos hata">Ürün bulunamadı<small>' + kac("", metin) + '</small></div>'; return; }
  const stok = Number(u.stok || 0);
  k.innerHTML = '<div class="fk-urun">' + urunResmi(u) + '<div class="fk-ad">' + kac("", u.ad) + '</div><div class="fk-fiyat">' + para(u.satis_fiyati) + '</div>' +
    '<div class="fk-alt"><span>Barkod: ' + kac("", u.barkod || "-") + '</span><span class="' + (stok <= 0 ? "az" : "") + '">Stok: ' + stok + '</span></div></div>';
}

function barkodIsle(metin) {
  if (fiyatModu) return fiyatGoster(metin);
  const u = DB.bul("urunler", x => x.barkod === metin);
  if (!u) return urunPaneli(metin);
  sepeteEkle(u.id);
  $("arama").value = "";
  kasaUrunleriCiz();
  bildir(u.ad + " eklendi");
}

function fisNo() {
  const n = DB.liste("satislar").length + 1;
  return `F${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${String(n).padStart(5, "0")}`;
}

function satisTamamla(yontem) {
  if (sepet.length === 0) return bildir("Sepet boş");
  let musteriId = null;
  if (yontem === "acik_hesap" && seciliMusteriId) return kaydetSatis("acik_hesap", seciliMusteriId);
  if (yontem === "acik_hesap") {
    const musteriler = DB.liste("musteriler", m => m.aktif);
    if (musteriler.length === 0) return bildir("Önce müşteri ekleyin");
    $("musteri-sec").innerHTML = musteriler.map(m => `<option value="${m.id}">${kac("", m.ad_soyad)}</option>`).join("");
    $("odeme-panel").style.display = "none";
    $("musteri-panel").style.display = "flex";
    return;
  }
  musteriId = null;
  kaydetSatis(yontem, musteriId);
}

function kaydetSatis(yontem, musteriId) {
  const araT = sepetToplami();
  const toplam = genelToplam();
  // Stok kontrolü yok: yetersiz stokta da satış yapılır ve stok eksiye düşer
  const satis = DB.ekle("satislar", {
    fis_no: fisNo(), kasa_no: DB.ayarOku("kasaNo", "1"), kullanici_id: aktifKullanici.id,
    musteri_id: musteriId, ara_toplam: araT, indirim: araT - toplam, toplam, durum: "tamamlandi",
    tarih: new Date().toISOString()
  });
  sepet.forEach(s => {
    DB.ekle("satis_kalemleri", { satis_id: satis.id, urun_id: s.id, miktar: s.adet, birim_fiyat: s.fiyat, tutar: s.fiyat * s.adet });
    DB.stokHareketi(s.id, "satis", -s.adet, satis.fis_no, aktifKullanici.id);
  });
  DB.ekle("odemeler", { satis_id: satis.id, yontem, tutar: toplam });
  if (yontem === "acik_hesap") {
    cariKaydet(musteriId, "borc", toplam, { satisId: satis.id, islem: "satis", aciklama: satis.fis_no });
  }
  sepet = [];
  indirim = { tur: "yuzde", deger: 0 };
  seciliMusteriId = null;
  panelKapat();
  kasaCiz();
  if (DB.ayarOku("otomatikFis", true)) fisSor(satis);
  bildir(`${satis.fis_no} kesildi · ${para(toplam)}`);
}

// ---------- Müşteri ve fiyat sorgulama (kasa) ----------
let seciliMusteriId = null;

function kasaMusteriDurumu() {
  const m = seciliMusteriId && DB.bul("musteriler", x => x.id === seciliMusteriId);
  $("musteri-chip-ad").textContent = m ? m.ad_soyad : "Müşteri yok";
  $("musteri-chip").classList.toggle("dolu", !!m);
  $("musteri-temizle").hidden = !m;
  satisSekmeleriniSakla();
  sekmeleriCiz();
}

function musteriAra() {
  modalAc(`
    <div class="modal-baslik">Müşteri seç</div>
    <input id="ma-ara" placeholder="Ad veya telefon" style="margin-top:10px;height:36px;border-radius:8px;border:1px solid var(--line);padding:0 10px;background:var(--surface);color:var(--fg)">
    <div id="ma-liste" style="margin-top:8px;display:flex;flex-direction:column;gap:6px;max-height:50vh;overflow:auto"></div>
    <div class="modal-alt"><button class="btn" id="ma-temizle">Seçimi kaldır</button><button class="btn" id="ma-kapat">Kapat</button></div>`);
  const listele = () => {
    const q = $("ma-ara").value.trim().toLowerCase();
    $("ma-liste").innerHTML = DB.liste("musteriler", m => m.aktif && (!q || m.ad_soyad.toLowerCase().includes(q) || (m.telefon || "").includes(q)))
      .map(m => `<button class="btn" data-mid="${m.id}" style="text-align:left">${kac("", m.ad_soyad)} <small>${kac("", m.telefon)}</small> · borç ${para(cariBakiye(m.id))}</button>`).join("")
      || '<div class="bos">Müşteri bulunamadı</div>';
  };
  $("ma-ara").addEventListener("input", listele);
  $("ma-liste").addEventListener("click", e => {
    const b = e.target.closest("[data-mid]");
    if (!b) return;
    seciliMusteriId = Number(b.dataset.mid);
    kasaMusteriDurumu();
    modalKapat();
    bildir("Müşteri seçildi");
  });
  $("ma-temizle").addEventListener("click", () => { seciliMusteriId = null; kasaMusteriDurumu(); modalKapat(); });
  $("ma-kapat").addEventListener("click", modalKapat);
  listele();
  $("ma-ara").focus();
}

// ---------- Sağdan açılan ürün paneli ----------
let cekmeceSecili = null;
let ekleKategorisi = null; // kategoriden "Yeni ürün oluştur" ile açılınca forma hazır gelen kategori
let cekmeceSekme = ""; // boş: listeye tıklayınca ürün sepete eklenir

// Paneller üst menünün altından başlar (sayfaya göre menü yüksekliği değişebilir)
function panelKonumu() {
  document.documentElement.style.setProperty("--panel-ust", document.querySelector(".ust").offsetHeight + "px");
}

// Ürünler sayfasındaki butonlar: ürün ekle, düzenle ve barkod yazdır sekmeleriyle paneli açar
function urunAyarlariAc(sekme, urunId) {
  cekmeceSekme = sekme || "duzenle";
  urunPaneli("");
  if (urunId) {
    cekmeceSecili = DB.bul("urunler", x => x.id === urunId) || null;
    cekmeceListele();
    cekmeceIcerigi();
  }
}

function urunPaneli(ara) {
  panelKonumu();
  $("kat-paneli").classList.remove("acik");
  $("cekmece").classList.add("acik");
  if (ara !== undefined) $("c-ara").value = ara;
  cekmeceListele();
  cekmeceIcerigi();
}

let cekmeceMusteri = null; // "Cari güncelle" sekmesinde seçili müşteri

function urunPaneliKapat() {
  ekleKategorisi = null;
  $("cekmece").classList.remove("acik");
  cekmeceSecili = null;
  cekmeceMusteri = null;
}

function cekmeceListele() {
  const q = $("c-ara").value.trim().toLowerCase();
  $("c-ara").placeholder = cekmeceSekme === "cari" ? "Müşteri adı veya telefon" : "Ürün adı veya barkod";

  // Cari güncelle sekmesinde liste müşterileri gösterir
  if (cekmeceSekme === "cari") {
    const musteriler = DB.liste("musteriler", m => m.aktif && (!q || m.ad_soyad.toLowerCase().includes(q) || (m.telefon || "").includes(q)));
    $("c-liste").innerHTML = musteriler.length
      ? musteriler.map(m => `<button class="c-satir ${cekmeceMusteri && cekmeceMusteri.id === m.id ? "secili" : ""}" data-mid="${m.id}">
          <span>${kac("", m.ad_soyad)}</span><small>${kac("", m.telefon)}</small><span class="fiyat">${para(cariBakiye(m.id))}</span></button>`).join("")
      : '<div class="bos">Müşteri bulunamadı</div>';
    return;
  }

  const liste = DB.liste("urunler", u => !q || u.ad.toLowerCase().includes(q) || u.barkod.includes(q)).slice(0, 60);
  $("c-liste").innerHTML = liste.length
    ? liste.map(u => `<button class="c-satir ${cekmeceSecili && cekmeceSecili.id === u.id ? "secili" : ""}" data-cid="${u.id}">
        <span>${kac("", u.ad)}</span><small>${u.barkod}</small><span class="fiyat">${para(u.satis_fiyati)}</span></button>`).join("")
    : '<div class="bos">Ürün bulunamadı</div>';
}

function cekmeceSekmeCiz() {
  const yonetici = aktifKullanici && aktifKullanici.rol === "yonetici";
  document.querySelectorAll(".sekme").forEach(b => {
    // Satış kullanıcısı ürün ekleyemez, düzenleyemez, stok güncelleyemez (yalnızca yönetici)
    b.hidden = !yonetici && ["ekle", "duzenle", "stok"].includes(b.dataset.sekme);
    const aktif = b.dataset.sekme === cekmeceSekme;
    b.classList.toggle("aktif", aktif);
    b.setAttribute("aria-selected", aktif);
  });
}

// Seçili ürünün stokunu günceller (giriş, çıkış, sayım düzeltmesi, iade)
function stokFormuCiz(kutu, u) {
  kutu.innerHTML = `
    <form id="cu-form" class="form">
      <p class="tam">${kac("", u.ad)} · mevcut stok <strong>${sayi(u.stok)} ${kac("", u.birim)}</strong></p>
      <label>İşlem<select name="tur">
        <option value="giris">Giriş (alım)</option>
        <option value="cikis">Çıkış (fire, zayi)</option>
        <option value="sayim">Sayım düzeltmesi (yeni miktar)</option>
        <option value="iade">İade (müşteriden)</option>
      </select></label>
      <label>Miktar<input name="miktar" type="number" step="0.001" min="0" required></label>
      <label class="tam">Açıklama<input name="aciklama" placeholder="Fatura no, sebep"></label>
      <div class="hata tam" id="cs-hata"></div>
    </form>`;
  $("c-kaydet").textContent = "Stok güncelle";
  $("cu-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const tur = f.get("tur");
    const miktar = Number(f.get("miktar"));
    const aciklama = f.get("aciklama");
    if (!(miktar >= 0)) return ($("cs-hata").textContent = "Geçerli bir miktar girin");
    if (tur === "sayim") DB.stokHareketi(u.id, "sayim", miktar - u.stok, aciklama || "Sayım", aktifKullanici.id);
    else if (tur === "cikis") {
      if (miktar > u.stok) return ($("cs-hata").textContent = "Çıkış miktarı mevcut stoktan büyük olamaz");
      DB.stokHareketi(u.id, "cikis", -miktar, aciklama, aktifKullanici.id);
    } else DB.stokHareketi(u.id, tur, miktar, aciklama, aktifKullanici.id);
    bildir("Stok güncellendi");
    cekmeceListele();
    cekmeceIcerigi();
    kasaUrunleriCiz();
    if (aktifSayfa === "stok") stokCiz();
  });
}

// Seçili müşterinin cari hesabını günceller (tahsilat veya borç ekleme)
function cariFormuCiz(kutu, m) {
  kutu.innerHTML = `
    <form id="cu-form" class="form">
      <p class="tam">${kac("", m.ad_soyad)} · mevcut borç <strong>${para(cariBakiye(m.id))}</strong></p>
      <label>İşlem<select name="tur">
        <option value="tahsilat">Tahsilat (borç düşer)</option>
        <option value="borc">Borç ekle</option>
      </select></label>
      <label>Tutar<input name="tutar" type="number" step="0.01" min="0.01" required></label>
      <label id="cs-yontem-kutu">Ödeme yöntemi<select name="yontem">${Object.entries(YONTEM_AD).map(([k, ad]) => `<option value="${k}">${ad}</option>`).join("")}</select></label>
      <label class="tam">Açıklama<input name="aciklama" placeholder="Not"></label>
      <div class="hata tam" id="cs-hata"></div>
    </form>`;
  $("c-kaydet").textContent = "Cari güncelle";
  // Ödeme yöntemi yalnızca tahsilatta sorulur
  const yontemKutusu = $("cs-yontem-kutu");
  const turSecici = $("cu-form").elements.tur;
  const yontemGoster = () => { yontemKutusu.style.visibility = turSecici.value === "tahsilat" ? "visible" : "hidden"; };
  turSecici.addEventListener("change", yontemGoster);
  yontemGoster();
  $("cu-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const tur = f.get("tur");
    const tutar = Number(f.get("tutar"));
    if (!(tutar > 0)) return ($("cs-hata").textContent = "Pozitif bir tutar girin");
    if (tur === "tahsilat" && tutar > cariBakiye(m.id) + 0.005) return ($("cs-hata").textContent = "Tahsilat mevcut borçtan büyük olamaz");
    cariKaydet(m.id, tur, tutar, {
      islem: tur === "tahsilat" ? "tahsilat" : "borc_duzeltme",
      yontem: tur === "tahsilat" ? f.get("yontem") : null,
      aciklama: f.get("aciklama") || (tur === "tahsilat" ? "Tahsilat" : "Borç düzeltme")
    });
    bildir("Cari hesap güncellendi");
    cekmeceListele();
    cekmeceIcerigi();
    if (aktifSayfa === "musteri") musteriCiz();
  });
}

function cekmeceIcerigi() {
  cekmeceSekmeCiz();
  const yonetici = aktifKullanici && aktifKullanici.rol === "yonetici";
  const kutu = $("c-icerik");

  // Sekme seçili değilse ya da ürün seçilmediyse alt alan gizlenir, liste tüm yüksekliği kullanır
  const urunGerekli = ["duzenle", "barkod", "stok"].includes(cekmeceSekme);
  const altAlanBos = !cekmeceSekme || (urunGerekli && !cekmeceSecili) || (cekmeceSekme === "cari" && !cekmeceMusteri);
  $("cekmece").classList.toggle("liste-genis", altAlanBos);
  // Kaydet butonu yalnızca form açıkken görünür (panelin en altında)
  const formAcik = (yonetici && (cekmeceSekme === "ekle" || cekmeceSekme === "duzenle") && (cekmeceSekme === "ekle" || cekmeceSecili))
    || (cekmeceSekme === "stok" && cekmeceSecili) || (cekmeceSekme === "cari" && cekmeceMusteri);
  $("c-alt").classList.toggle("gorunur", !!formAcik);
  if (altAlanBos) {
    kutu.innerHTML = "";
    return;
  }

  if (cekmeceSekme === "stok") {
    stokFormuCiz(kutu, cekmeceSecili);
    return;
  }

  if (cekmeceSekme === "cari") {
    cariFormuCiz(kutu, cekmeceMusteri);
    return;
  }

  if (cekmeceSekme === "duzenle") {
    if (!yonetici) { kutu.innerHTML = '<div class="bos">Ürün düzenleme yalnızca yönetici içindir</div>'; return; }
    urunFormuCiz(kutu, cekmeceSecili);
    return;
  }

  if (cekmeceSekme === "ekle") {
    if (!yonetici) { kutu.innerHTML = '<div class="bos">Yeni ürün ekleme yalnızca yönetici içindir</div>'; return; }
    urunFormuCiz(kutu, null);
    return;
  }

  // Barkod yazdır
  kutu.innerHTML = `
    <div class="etiket">
      <div class="ad">${kac("", cekmeceSecili.ad)}</div>
      <svg id="etiket-svg"></svg>
      <div>${para(cekmeceSecili.satis_fiyati)}</div>
    </div>
    <div class="modal-alt" style="margin-top:10px"><button class="btn ana" id="etiket-yazdir">Etiketi yazdır</button></div>`;
  barkodCiz($("etiket-svg"), cekmeceSecili.barkod);
  $("etiket-yazdir").addEventListener("click", () => etiketYazdir(cekmeceSecili));
}

// ---------- Ürün fotoğrafı ----------
// Seçilen görsel küçültülüp (en fazla 200 px) JPEG olarak ürün kaydına yazılır
function resmiKucult(dosya, maks = 200, bicim = "image/jpeg") {
  return new Promise((coz, red) => {
    const okuyucu = new FileReader();
    okuyucu.onload = () => {
      const img = new Image();
      img.onload = () => {
        const oran = Math.min(1, maks / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * oran);
        c.height = Math.round(img.height * oran);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        coz(c.toDataURL(bicim, 0.8));
      };
      img.onerror = () => red(new Error("Görsel okunamadı"));
      img.src = okuyucu.result;
    };
    okuyucu.onerror = () => red(new Error("Dosya okunamadı"));
    okuyucu.readAsDataURL(dosya);
  });
}

async function resimSonucu(f, mevcut) {
  if (f.get("resimKaldir")) return null;
  const dosya = f.get("resimDosya");
  if (dosya && dosya.size > 0) {
    try { return await resmiKucult(dosya); } catch (e) { bildir("Fotoğraf okunamadı"); }
  }
  return mevcut || null;
}

function urunResmi(u) {
  if (u && u.resim) return `<img class="foto" src="${u.resim}" alt="">`;
  return `<div class="foto foto-yer">${kac("", ((u && u.ad) || "?").trim().charAt(0).toUpperCase())}</div>`;
}

function resimAlani(mevcut) {
  return `<label class="tam">Fotoğraf<input type="file" name="resimDosya" accept="image/*"></label>
    ${mevcut ? `<div class="tam resim-mevcut"><img class="foto" src="${mevcut}" alt=""><label><input type="checkbox" name="resimKaldir"> Fotoğrafı kaldır</label></div>` : ""}`;
}

function urunFormuCiz(kutu, u) {
  const kategoriler = DB.liste("kategoriler");
  const yeni = !u;
  const d = u || { ad: "", barkod: "", kategori_id: ekleKategorisi, satis_fiyati: "", alis_fiyati: "", kdv_orani: 20, birim: "adet", kritik_stok: 0 };
  kutu.innerHTML = `
    <form id="cu-form" class="form">
      <label class="tam">Ürün adı<input name="ad" value="${kac("", d.ad)}" required></label>
      <label>Barkod<input name="barkod" value="${kac("", d.barkod)}" required></label>
      <label>Kategori<select name="kategori"><option value="" ${d.kategori_id ? "" : "selected"}>Kategori yok</option>${kategoriler.map(k => `<option value="${k.id}" ${k.id === d.kategori_id ? "selected" : ""}>${kac("", k.ad)}</option>`).join("")}</select></label>
      <label>Satış fiyatı<input name="satis" type="number" step="0.01" min="0" value="${d.satis_fiyati}" required></label>
      <label>Alış fiyatı<input name="alis" type="number" step="0.01" min="0" value="${d.alis_fiyati}"></label>
      <label>KDV %<input name="kdv" type="number" value="${d.kdv_orani}"></label>
      <label>Kritik stok<input name="kritik" type="number" step="0.001" min="0" value="${d.kritik_stok}"></label>
      ${yeni ? '<label>Açılış stoku<input name="stok" type="number" step="0.001" min="0" value="0"></label>' : `<label>Stok<input value="${sayi(d.stok)}" disabled></label>`}
      ${resimAlani(d.resim)}
    </form>`;
  $("c-kaydet").textContent = yeni ? "Ürünü ekle" : "Kaydet";
  $("cu-form").addEventListener("submit", async e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const barkod = f.get("barkod").trim();
    if (DB.bul("urunler", x => !x.silindi && x.barkod === barkod && (!u || x.id !== u.id))) return bildir("Bu barkod zaten kayıtlı");
    const alanlar = {
      ad: f.get("ad").trim(), barkod, kategori_id: f.get("kategori") ? Number(f.get("kategori")) : null,
      satis_fiyati: Number(f.get("satis")), alis_fiyati: Number(f.get("alis") || 0),
      kdv_orani: Number(f.get("kdv")), kritik_stok: Number(f.get("kritik") || 0), aktif: 1,
      resim: await resimSonucu(f, u ? u.resim : null)
    };
    if (u) {
      DB.guncelle("urunler", u.id, alanlar);
      bildir("Ürün güncellendi");
    } else {
      const yeniUrun = DB.ekle("urunler", { ...alanlar, birim: "adet", stok: 0 });
      const acilis = Number(f.get("stok") || 0);
      if (acilis > 0) DB.stokHareketi(yeniUrun.id, "giris", acilis, "Açılış stoku", aktifKullanici.id);
      cekmeceSecili = yeniUrun;
      cekmeceSekme = "duzenle";
      bildir("Ürün eklendi");
    }
    cekmeceListele();
    cekmeceIcerigi();
    kasaUrunleriCiz();
    if (aktifSayfa === "urunler") urunlerCizSayfa();
  });
}

function barkodCiz(svg, metin) {
  if (window.JsBarcode) {
    JsBarcode(svg, metin, { format: "CODE128", width: 2, height: 60, displayValue: true, fontSize: 14, margin: 4 });
  } else {
    svg.outerHTML = `<div style="font-family:monospace;font-size:20px;letter-spacing:2px">${kac("", metin)}</div>`;
  }
}

function etiketYazdir(u) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  barkodCiz(svg, u.barkod);
  sayfaIcindeYazdir(`<!doctype html><html><head><meta charset="utf-8"><title>Etiket</title>
    <style>body{font-family:Arial,sans-serif;text-align:center;margin:8px;width:260px}.ad{font-size:13px;font-weight:bold}.fiyat{font-size:18px;font-weight:bold;margin-top:4px}</style>
    </head><body><div class="ad">${kac("", u.ad)}</div>${svg.outerHTML}<div class="fiyat">${para(u.satis_fiyati)}</div>
    </body></html>`);
}

// ---------- Fiş yazdırma (termal yazıcı, 58/80 mm) ----------
function fisYazdir(satisId) {
  const s = DB.bul("satislar", x => x.id === satisId);
  if (!s) return;
  const kalemler = DB.liste("satis_kalemleri", k => k.satis_id === satisId);
  const odeme = DB.bul("odemeler", o => o.satis_id === satisId);
  const etiket = { nakit: "Nakit", kart: "Kart", acik_hesap: "Açık hesap" };
  const satirlar = kalemler.map(k => {
    const u = DB.bul("urunler", x => x.id === k.urun_id);
    return `<tr><td colspan="2">${kac("", u ? u.ad : "")}</td></tr>
      <tr><td>${sayi(k.miktar)} x ${para(k.birim_fiyat)}</td><td style="text-align:right">${para(k.tutar)}</td></tr>`;
  }).join("");
  sayfaIcindeYazdir(`<!doctype html><html><head><meta charset="utf-8"><title>${s.fis_no}</title>
    <style>
      body { font-family: 'Courier New', monospace; font-size: 12px; width: 280px; margin: 0 auto; padding: 8px; }
      h1 { font-size: 14px; text-align: center; margin: 4px 0; }
      table { width: 100%; border-collapse: collapse; }
      td { padding: 2px 0; vertical-align: top; }
      .ortala { text-align: center; }
      .cizgi { border-top: 1px dashed #000; margin: 6px 0; }
      .toplam td { font-size: 14px; font-weight: bold; }
    </style></head><body>
    ${fisBasligi()}
    <div class="ortala">Kasa ${kac("", s.kasa_no)} · ${tarih(s.tarih)}</div>
    <div class="ortala">Fiş: ${s.fis_no}</div>
    <div class="cizgi"></div>
    <table>${satirlar}</table>
    <div class="cizgi"></div>
    <table>
      <tr><td>Ara toplam</td><td style="text-align:right">${para(s.ara_toplam)}</td></tr>
      ${s.indirim > 0 ? `<tr><td>İndirim</td><td style="text-align:right">-${para(s.indirim)}</td></tr>` : ""}
      <tr class="toplam"><td>TOPLAM</td><td style="text-align:right">${para(s.toplam)}</td></tr>
      <tr><td>Ödeme</td><td style="text-align:right">${etiket[odeme ? odeme.yontem : "nakit"] || ""}</td></tr>
    </table>
    <div class="cizgi"></div>
    <div class="ortala">Bizi tercih ettiğiniz için teşekkürler</div>
    </body></html>`);
}

// Yeni pencere açmadan, sayfa içindeki gizli bir çerçeveden yazdırır
function sayfaIcindeYazdir(html) {
  const cerceve = document.createElement("iframe");
  cerceve.setAttribute("aria-hidden", "true");
  cerceve.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
  document.body.appendChild(cerceve);
  const temizle = () => setTimeout(() => cerceve.remove(), 1000);
  cerceve.onload = () => {
    const pencere = cerceve.contentWindow;
    pencere.onafterprint = temizle;
    pencere.focus();
    pencere.print();
    setTimeout(temizle, 60000);
  };
  cerceve.srcdoc = html;
}

// Satıştan sonra uygulama kendisi sorar: fiş yazdırılsın mı?
function fisSor(satis) {
  modalAc(`
    <div class="modal-baslik">${satis.fis_no} kesildi</div>
    <p>Toplam <strong>${para(satis.toplam)}</strong>. Fiş yazdırılsın mı?</p>
    <div class="modal-alt">
      <button class="btn" id="fs-hayir">Yazdırma</button>
      <button class="btn ana" id="fs-evet">Yazdır</button>
    </div>`);
  $("fs-hayir").addEventListener("click", modalKapat);
  $("fs-evet").addEventListener("click", () => { modalKapat(); fisYazdir(satis.id); });
  $("fs-evet").focus();
}

function panelKapat() {
  $("odeme-panel").style.display = "none";
  $("musteri-panel").style.display = "none";
}

// ---------- STOK ----------
let stokFiltre = "";
function stokCiz() {
  const urunler = DB.liste("urunler").filter(u => u.ad.toLowerCase().includes(stokFiltre.toLowerCase()) || u.barkod.includes(stokFiltre));
  const kritik = DB.liste("urunler", u => u.stok <= u.kritik_stok).length;
  const deger = DB.liste("urunler").reduce((t, u) => t + Math.max(0, u.stok) * u.alis_fiyati, 0);
  const sonHareket = DB.liste("stok_hareketleri").slice(-12).reverse();
  const urunAd = id => (DB.bul("urunler", x => x.id === id) || {}).ad || "";
  $("s-stok").innerHTML = `
    <div class="baslik-satir">
      <h2>Stok</h2>
      <div class="filtre"><input id="stok-ara" placeholder="Ürün veya barkod ara" value="${kac("", stokFiltre)}"><button class="btn" id="stok-say">Stok say${aktifSayim() ? " (devam ediyor)" : ""}</button></div>
    </div>
    <div class="ozet-kutular">
      <div class="ozet"><small>Ürün sayısı</small><strong>${DB.liste("urunler").length}</strong></div>
      <div class="ozet"><small>Kritik stok</small><strong>${kritik}</strong></div>
      <div class="ozet"><small>Stok maliyeti</small><strong>${para(deger)}</strong></div>
    </div>
    <div class="baslik-satir"><h2>Stok girişi / çıkışı</h2></div>
    <form id="stok-form" class="form" style="margin-bottom:16px">
      <label>Ürün<select name="urun">${DB.liste("urunler").map(u => `<option value="${u.id}">${kac("", u.ad)}</option>`).join("")}</select></label>
      <label>İşlem<select name="tur"><option value="giris">Giriş (alım)</option><option value="cikis">Çıkış (fire, zayi)</option><option value="sayim">Sayım düzeltmesi (yeni miktar)</option><option value="iade">İade (müşteriden)</option></select></label>
      <label>Miktar<input name="miktar" type="number" step="0.001" min="0" required></label>
      <label>Açıklama<input name="aciklama" placeholder="Fatura no, sebep"></label>
      <div class="tam"><button class="btn ana" type="submit">Kaydet</button></div>
    </form>
    <div class="baslik-satir"><h2>Ürünler</h2></div>
    <table class="tablo">
      <tr><th>Ürün</th><th class="sag">Stok</th><th class="sag">Kritik</th><th>Durum</th></tr>
      ${urunler.map(u => `<tr><td>${kac("", u.ad)}</td><td class="sag">${sayi(u.stok)} ${u.birim}</td><td class="sag">${sayi(u.kritik_stok)}</td><td>${u.stok < 0 ? '<span class="rozet uyari">Eksi stok</span>' : u.stok <= u.kritik_stok ? '<span class="rozet uyari">Kritik</span>' : '<span class="rozet">Yeterli</span>'}</td></tr>`).join("")}
    </table>
    <div class="baslik-satir" style="margin-top:16px"><h2>Son hareketler</h2></div>
    <table class="tablo">
      <tr><th>Tarih</th><th>Ürün</th><th>Tür</th><th class="sag">Miktar</th><th>Açıklama</th></tr>
      ${sonHareket.map(h => `<tr><td>${tarih(h.tarih)}</td><td>${kac("", urunAd(h.urun_id))}</td><td>${h.tur}</td><td class="sag">${sayi(h.miktar)}</td><td>${kac("", h.aciklama)}</td></tr>`).join("")}
    </table>`;
  $("stok-ara").addEventListener("input", e => { stokFiltre = e.target.value; stokCiz(); });
  $("stok-say").addEventListener("click", () => stokSayimiAc());
  $("stok-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const urunId = Number(f.get("urun"));
    const tur = f.get("tur");
    const miktar = Number(f.get("miktar"));
    const aciklama = f.get("aciklama");
    const u = DB.bul("urunler", x => x.id === urunId);
    if (!u || !(miktar >= 0)) return;
    if (tur === "sayim") {
      DB.stokHareketi(urunId, "sayim", miktar - u.stok, aciklama || "Sayım", aktifKullanici.id);
    } else if (tur === "cikis") {
      if (miktar > u.stok) return bildir("Stok yetersiz");
      DB.stokHareketi(urunId, "cikis", -miktar, aciklama, aktifKullanici.id);
    } else {
      DB.stokHareketi(urunId, tur, miktar, aciklama, aktifKullanici.id);
    }
    bildir("Stok güncellendi");
    stokCiz();
  });
}

// ---------- ÜRÜNLER (yönetici) ----------
function urunlerCizSayfa() {
  const kategoriler = DB.liste("kategoriler");
  $("s-urunler").innerHTML = `
    <div class="baslik-satir">
      <h2>Ürünler</h2>
      <div class="sekmeler">
        <button class="sekme" id="u-yeni">Ürün ekle</button>
        <button class="sekme" id="u-duzenle">Ürünü düzenle</button>
        <button class="sekme" id="u-stok">Stok güncelle</button>
        <button class="sekme" id="u-say">Stok say${aktifSayim() ? " (devam ediyor)" : ""}</button>
        <button class="sekme" id="u-cari">Cari güncelle</button>
        <button class="sekme" id="u-barkod">Barkod yazdır</button>
      </div>
    </div>
    <table class="tablo">
      <tr><th>Barkod</th><th>Ad</th><th>Kategori</th><th class="sag">Satış</th><th class="sag">Alış</th><th class="sag">KDV</th><th></th></tr>
      ${DB.liste("urunler").map(u => `<tr>
        <td>${u.barkod}</td><td>${kac("", u.ad)}</td>
        <td>${kac("", (kategoriler.find(k => k.id === u.kategori_id) || {}).ad || "—")}</td>
        <td class="sag">${para(u.satis_fiyati)}</td><td class="sag">${para(u.alis_fiyati)}</td><td class="sag">%${u.kdv_orani}</td>
        <td><button class="btn kucuk" data-duzenle="${u.id}">Düzenle</button> <button class="btn kucuk" data-barkod="${u.id}">Barkod</button> <button class="btn kucuk" data-pasif="${u.id}">${u.aktif ? "Pasifleştir" : "Aktifleştir"}</button> <button class="btn kucuk tehlike" data-urun-sil="${u.id}">Sil</button></td>
      </tr>`).join("")}
    </table>`;
  // Ürün ayarları bu sayfada: sağdan yarım açılan panelde ekleme, düzenleme ve barkod yazdırma
  $("u-yeni").addEventListener("click", () => urunAyarlariAc("ekle"));
  $("u-duzenle").addEventListener("click", () => urunAyarlariAc("duzenle"));
  $("u-stok").addEventListener("click", () => urunAyarlariAc("stok"));
  $("u-say").addEventListener("click", () => stokSayimiAc());
  $("u-cari").addEventListener("click", () => urunAyarlariAc("cari"));
  $("u-barkod").addEventListener("click", () => urunAyarlariAc("barkod"));
  $("s-urunler").querySelectorAll("[data-duzenle]").forEach(b => b.addEventListener("click", () => urunAyarlariAc("duzenle", Number(b.dataset.duzenle))));
  $("s-urunler").querySelectorAll("[data-barkod]").forEach(b => b.addEventListener("click", () => urunAyarlariAc("barkod", Number(b.dataset.barkod))));
  $("s-urunler").querySelectorAll("[data-urun-sil]").forEach(b => b.addEventListener("click", () => urunSil(Number(b.dataset.urunSil))));
  $("s-urunler").querySelectorAll("[data-pasif]").forEach(b => b.addEventListener("click", () => {
    const u = DB.bul("urunler", x => x.id === Number(b.dataset.pasif));
    DB.guncelle("urunler", u.id, { aktif: u.aktif ? 0 : 1 });
    urunlerCizSayfa();
  }));
}
function urunSil(id) {
  const u = DB.bul("urunler", x => x.id === id);
  if (!u) return;
  modalAc(`
    <div class="modal-baslik">Ürünü sil · ${kac("", u.ad)}</div>
    <p style="margin:10px 0">Bu ürün listelerden, kategoriden ve kasadan kalkar. Geçmiş satış fişleri ve stok hareketleri bozulmaz. Silinsin mi?</p>
    <div class="modal-alt tam"><button type="button" class="btn" id="us-vazgec">Vazgeç</button><button type="button" class="btn tehlike" id="us-sil">Evet, sil</button></div>`);
  $("us-vazgec").addEventListener("click", modalKapat);
  $("us-sil").addEventListener("click", () => {
    DB.guncelle("urunler", id, { silindi: 1, aktif: 0, kategori_id: null });
    modalKapat();
    urunlerCizSayfa();
    kasaUrunleriCiz();
    bildir("Ürün silindi");
  });
}
function urunlerCiz() { urunlerCizSayfa(); }

// ---------- MÜŞTERİLER / CARİ ----------
function cariBakiye(musteriId) {
  return DB.liste("cari_hareketler", h => h.musteri_id === musteriId).reduce((t, h) => t + (h.tur === "borc" ? h.tutar : -h.tutar), 0);
}

// Cari işlem türleri: açık hesaba satış, tahsilat, elle borç düzeltme ve iptal edilen fişin ters kaydı
const CARI_ISLEM = {
  satis: { ad: "Açık hesap satışı", sinif: "uyari" },
  tahsilat: { ad: "Tahsilat", sinif: "iyi" },
  borc_duzeltme: { ad: "Borç düzeltme", sinif: "uyari" },
  fis_iptali: { ad: "Fiş iptali", sinif: "bilgi" }
};
const YONTEM_AD = { nakit: "Nakit", kart: "Kart", havale: "Havale / EFT" };

// Eski kayıtlarda "islem" alanı yok: türden ve fişe bağlı olmasından anlaşılır
function cariIslemi(h) {
  if (h.islem) return h.islem;
  if (h.tur === "borc") return h.satis_id ? "satis" : "borc_duzeltme";
  return h.satis_id ? "fis_iptali" : "tahsilat";
}

// Eski kayıtlarda kullanıcı ve yöntem alanı yok: fişe bağlı satışlarda fişi kesen kasiyer ve "Açık hesap" gösterilir
function cariKullaniciAdi(h) {
  const id = h.kullanici_id || (h.satis_id && (DB.bul("satislar", s => s.id === h.satis_id) || {}).kullanici_id);
  return (id && (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad) || "-";
}

function cariYontemAdi(h) {
  if (h.yontem) return YONTEM_AD[h.yontem] || h.yontem;
  return cariIslemi(h) === "satis" ? "Açık hesap" : "-";
}

// Tek yerden kayıt: kim yaptığı ve ödeme yöntemi de saklanır
function cariKaydet(musteriId, tur, tutar, ayrinti) {
  return DB.ekle("cari_hareketler", {
    musteri_id: musteriId, tur, tutar,
    satis_id: ayrinti.satisId || null,
    aciklama: ayrinti.aciklama || "",
    islem: ayrinti.islem,
    yontem: ayrinti.yontem || null,
    kullanici_id: aktifKullanici ? aktifKullanici.id : null,
    tarih: new Date().toISOString()
  });
}

// Hareketleri eskiden yeniye dizip her satırın sonundaki bakiyeyi hesaplar
function cariOzet(musteriId) {
  const hareketler = DB.liste("cari_hareketler", h => h.musteri_id === musteriId)
    .sort((a, b) => a.tarih.localeCompare(b.tarih) || a.id - b.id);
  let bakiye = 0;
  const satirlar = hareketler.map(h => {
    bakiye = Math.round((bakiye + (h.tur === "borc" ? h.tutar : -h.tutar)) * 100) / 100;
    return { ...h, islemTuru: cariIslemi(h), bakiye };
  });
  const topla = islem => satirlar.filter(h => h.islemTuru === islem).reduce((t, h) => t + h.tutar, 0);
  return {
    satirlar, bakiye,
    satis: topla("satis"), tahsilat: topla("tahsilat"), duzeltme: topla("borc_duzeltme"), iptal: topla("fis_iptali"),
    son: satirlar.length ? satirlar[satirlar.length - 1].tarih : null
  };
}

function musteriCiz() {
  const musteriler = DB.liste("musteriler", m => m.aktif).map(m => ({ m, o: cariOzet(m.id) }));
  const toplamAlacak = musteriler.reduce((t, x) => t + x.o.bakiye, 0);
  const borclu = musteriler.filter(x => x.o.bakiye > 0.005).length;
  $("s-musteri").innerHTML = `
    <div class="baslik-satir"><h2>Müşteriler ve açık hesap</h2><button class="btn ana" id="m-yeni">Yeni müşteri</button></div>
    <div class="ozet-kutular">
      <div class="ozet"><small>Toplam alacak</small><strong>${para(toplamAlacak)}</strong></div>
      <div class="ozet"><small>Borçlu müşteri</small><strong>${borclu}</strong></div>
      <div class="ozet"><small>Müşteri sayısı</small><strong>${musteriler.length}</strong></div>
    </div>
    <table class="tablo">
      <tr><th>Ad soyad</th><th>Telefon</th><th class="sag">Açık hesap satışı</th><th class="sag">Tahsilat</th><th class="sag">Bakiye (borç)</th><th>Son hareket</th><th></th></tr>
      ${musteriler.map(({ m, o }) => `<tr>
        <td>${kac("", m.ad_soyad)}</td><td>${kac("", m.telefon)}</td>
        <td class="sag">${para(o.satis)}</td><td class="sag">${para(o.tahsilat)}</td>
        <td class="sag"><strong>${para(o.bakiye)}</strong></td>
        <td>${o.son ? tarih(o.son) : "-"}</td>
        <td><button class="btn kucuk" data-tahsilat="${m.id}">Tahsilat</button> <button class="btn kucuk" data-hareket="${m.id}">Hareketler</button></td>
      </tr>`).join("") || '<tr><td colspan="7">Müşteri yok</td></tr>'}
    </table>`;
  $("m-yeni").addEventListener("click", musteriFormu);
  $("s-musteri").querySelectorAll("[data-tahsilat]").forEach(b => b.addEventListener("click", () => tahsilatFormu(Number(b.dataset.tahsilat))));
  $("s-musteri").querySelectorAll("[data-hareket]").forEach(b => b.addEventListener("click", () => cariDetay(Number(b.dataset.hareket))));
}

function musteriFormu() {
  modalAc(`
    <div class="modal-baslik">Yeni müşteri</div>
    <form id="m-form" class="form" style="margin-top:10px">
      <label class="tam">Ad soyad<input name="ad" required></label>
      <label>Telefon<input name="tel"></label>
      <label>Vergi no<input name="vergi"></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="m-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  $("m-vazgec").addEventListener("click", modalKapat);
  $("m-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    DB.ekle("musteriler", { ad_soyad: f.get("ad"), telefon: f.get("tel"), vergi_no: f.get("vergi"), aktif: 1 });
    modalKapat();
    musteriCiz();
    bildir("Müşteri eklendi");
  });
}

function tahsilatFormu(musteriId) {
  const m = DB.bul("musteriler", x => x.id === musteriId);
  modalAc(`
    <div class="modal-baslik">Tahsilat · ${kac("", m.ad_soyad)}</div>
    <p>Mevcut borç: <strong>${para(cariBakiye(musteriId))}</strong></p>
    <form id="t-form" class="form">
      <label>Tutar<input name="tutar" type="number" step="0.01" min="0.01" required></label>
      <label>Ödeme yöntemi<select name="yontem">${Object.entries(YONTEM_AD).map(([k, ad]) => `<option value="${k}">${ad}</option>`).join("")}</select></label>
      <label class="tam">Açıklama<input name="aciklama" placeholder="Not (isteğe bağlı)"></label>
      <div class="hata tam" id="t-hata"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="t-vazgec">Vazgeç</button><button class="btn ana" type="submit">Tahsil et</button></div>
    </form>`);
  $("t-vazgec").addEventListener("click", modalKapat);
  $("t-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const tutar = Number(f.get("tutar"));
    if (!(tutar > 0)) return;
    if (tutar > cariBakiye(musteriId) + 0.005) return ($("t-hata").textContent = "Tahsilat mevcut borçtan büyük olamaz");
    cariKaydet(musteriId, "tahsilat", tutar, { islem: "tahsilat", yontem: f.get("yontem"), aciklama: f.get("aciklama") || "Tahsilat" });
    modalKapat();
    musteriCiz();
    bildir("Tahsilat kaydedildi");
  });
}

// Cari hesap hareketleri: işlem türü, fiş, kullanıcı, ödeme yöntemi ve her satırdan sonraki bakiye
function cariDetay(musteriId, filtre) {
  const f = filtre || { bas: "", bit: "", islem: "hepsi", detay: false };
  const m = DB.bul("musteriler", x => x.id === musteriId);
  const o = cariOzet(musteriId);
  const gorunen = o.satirlar.filter(h =>
    (!f.bas || yerelGun(h.tarih) >= f.bas) && (!f.bit || yerelGun(h.tarih) <= f.bit) && (f.islem === "hepsi" || h.islemTuru === f.islem));
  const borcToplam = gorunen.filter(h => h.tur === "borc").reduce((t, h) => t + h.tutar, 0);
  const alacakToplam = gorunen.filter(h => h.tur === "tahsilat").reduce((t, h) => t + h.tutar, 0);
  const fisNoDe = id => (DB.bul("satislar", s => s.id === id) || {}).fis_no || "";

  modalAc(`
    <div class="modal-baslik">${kac("", m.ad_soyad)} · hesap hareketleri</div>
    <p style="margin:2px 0 8px;font-size:12px;opacity:0.75">${kac("", m.telefon || "Telefon yok")}${m.vergi_no ? " · Vergi no " + kac("", m.vergi_no) : ""}</p>
    <div class="ozet-kutular">
      <div class="ozet"><small>Açık hesap satışı</small><strong>${para(o.satis)}</strong></div>
      <div class="ozet"><small>Tahsilat</small><strong>${para(o.tahsilat)}</strong></div>
      <div class="ozet"><small>İptal / düzeltme</small><strong>${para(o.iptal)} / ${para(o.duzeltme)}</strong></div>
      <div class="ozet"><small>Güncel bakiye (borç)</small><strong>${para(o.bakiye)}</strong></div>
    </div>
    <div class="filtre" style="margin-bottom:10px">
      <input type="date" id="cd-bas" value="${f.bas}" aria-label="Başlangıç tarihi">
      <input type="date" id="cd-bit" value="${f.bit}" aria-label="Bitiş tarihi">
      <select id="cd-islem" aria-label="İşlem türü">
        <option value="hepsi">Tüm işlemler</option>
        ${Object.entries(CARI_ISLEM).map(([k, v]) => `<option value="${k}" ${f.islem === k ? "selected" : ""}>${v.ad}</option>`).join("")}
      </select>
      <label class="onay-kutusu"><input type="checkbox" id="cd-detay" ${f.detay ? "checked" : ""}> Fiş içeriklerini göster</label>
      <button class="btn" id="cd-temizle">Filtreyi temizle</button>
    </div>
    <div style="overflow:auto;max-height:46vh">
      <table class="tablo">
        <tr><th>Tarih</th><th>İşlem</th><th>Fiş / açıklama</th><th>Yöntem</th><th>Kullanıcı</th><th class="sag">Borç</th><th class="sag">Alacak</th><th class="sag">Bakiye</th></tr>
        ${[...gorunen].reverse().map(h => `<tr>
          <td>${tarih(h.tarih)}</td>
          <td><span class="rozet ${CARI_ISLEM[h.islemTuru].sinif}">${CARI_ISLEM[h.islemTuru].ad}</span></td>
          <td>${h.satis_id ? `<button class="baglanti" data-fis="${h.satis_id}">${kac("", fisNoDe(h.satis_id))}</button> ` : ""}${kac("", h.aciklama && h.aciklama !== fisNoDe(h.satis_id) ? h.aciklama : "")}</td>
          <td>${kac("", cariYontemAdi(h))}</td>
          <td>${kac("", cariKullaniciAdi(h))}</td>
          <td class="sag">${h.tur === "borc" ? para(h.tutar) : ""}</td>
          <td class="sag">${h.tur === "tahsilat" ? para(h.tutar) : ""}</td>
          <td class="sag"><strong>${para(h.bakiye)}</strong></td>
        </tr>${f.detay && h.satis_id ? `<tr class="alt-satir"><td></td><td colspan="7">${fisKalemTablosu(h.satis_id)}</td></tr>` : ""}`).join("") || '<tr><td colspan="8">Bu filtreyle hareket yok</td></tr>'}
        ${gorunen.length ? `<tr><th colspan="5">Listelenen toplam</th><th class="sag">${para(borcToplam)}</th><th class="sag">${para(alacakToplam)}</th><th></th></tr>` : ""}
      </table>
    </div>
    <div class="modal-alt">
      <button class="btn" id="cd-yazdir">Ekstre yazdır</button>
      <button class="btn" id="cd-yazdir-detay">Detaylı ekstre yazdır</button>
      ${aktifKullanici.rol === "yonetici" ? '<button class="btn" id="cd-tasarim">Ekstre tasarımı</button>' : ""}
      <button class="btn" id="cd-tahsilat">Tahsilat al</button>
      <button class="btn" id="c-kapat">Kapat</button>
    </div>`, true);

  const yenile = () => cariDetay(musteriId, { bas: $("cd-bas").value, bit: $("cd-bit").value, islem: $("cd-islem").value, detay: $("cd-detay").checked });
  ["cd-bas", "cd-bit", "cd-islem", "cd-detay"].forEach(id => $(id).addEventListener("change", yenile));
  $("cd-temizle").addEventListener("click", () => cariDetay(musteriId));
  $("modal-icerik").querySelectorAll("[data-fis]").forEach(b => b.addEventListener("click", () => fisDetay(Number(b.dataset.fis), () => cariDetay(musteriId, f))));
  $("cd-yazdir").addEventListener("click", () => cariEkstreYazdir(m, o, gorunen, f, false));
  $("cd-yazdir-detay").addEventListener("click", () => cariEkstreYazdir(m, o, gorunen, f, true));
  if ($("cd-tasarim")) $("cd-tasarim").addEventListener("click", () => ekstreTasarimiAc({ m, o, satirlar: gorunen, f, geri: () => cariDetay(musteriId, f) }));
  $("cd-tahsilat").addEventListener("click", () => tahsilatFormu(musteriId));
  $("c-kapat").addEventListener("click", modalKapat);
}

// Müşteri cari hesap ekstresi (A4): listelenen hareketler ve satır sonu bakiyeleri
// Bir fişin içeriği: ürün, adet, birim fiyat, tutar, varsa indirim ve fiş toplamı
function fisKalemTablosu(satisId) {
  const s = DB.bul("satislar", x => x.id === satisId);
  const kalemler = DB.liste("satis_kalemleri", k => k.satis_id === satisId);
  if (!s || !kalemler.length) return '<span class="fis-kalem-yok">Fiş içeriği bulunamadı</span>';
  const ad = id => (DB.bul("urunler", u => u.id === id) || {}).ad || "Silinmiş ürün";
  return `<table class="fis-kalem">
    <tr><th>Ürün</th><th class="sag">Adet</th><th class="sag">Birim fiyat</th><th class="sag">Tutar</th></tr>
    ${kalemler.map(k => `<tr><td>${kac("", ad(k.urun_id))}</td><td class="sag">${sayi(k.miktar)}</td><td class="sag">${para(k.birim_fiyat)}</td><td class="sag">${para(k.tutar)}</td></tr>`).join("")}
    ${s.indirim > 0 ? `<tr><td colspan="3">İndirim</td><td class="sag">-${para(s.indirim)}</td></tr>` : ""}
    <tr><th colspan="3">Fiş toplamı${s.durum === "iptal" ? " (iptal edildi)" : ""}</th><th class="sag">${para(s.toplam)}</th></tr>
  </table>`;
}

// ---------- RAPORLAR ----------
// Gösterge paneli: dönem seçimi, 3 halka grafik (fiş sayısı, satış toplamı, tahsilat) ve günlük satış çizgisi
let raporDonem = "bugun", raporBas = "", raporSon = "", raporKasa = "";
const RAPOR_DONEMLERI = [["bugun", "Bugün"], ["hafta", "Bu Hafta"], ["ay", "Bu Ay"], ["3ay", "Son 3 Ay"], ["6ay", "Son 6 Ay"], ["yil", "1 Yıl"], ["tarih", "Tarih Seç"]];

function yerelGun(d) { return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
function raporAraligi() {
  const bugun = new Date(); bugun.setHours(0, 0, 0, 0);
  const geri = gun => { const d = new Date(bugun); d.setDate(d.getDate() - gun); return d; };
  let bas = bugun;
  if (raporDonem === "hafta") bas = geri((bugun.getDay() + 6) % 7);
  else if (raporDonem === "ay") bas = new Date(bugun.getFullYear(), bugun.getMonth(), 1);
  else if (raporDonem === "3ay") bas = geri(90);
  else if (raporDonem === "6ay") bas = geri(180);
  else if (raporDonem === "yil") bas = geri(365);
  if (raporDonem === "tarih") return { bas: raporBas || yerelGun(bugun), son: raporSon || yerelGun(bugun) };
  return { bas: yerelGun(bas), son: yerelGun(new Date()) };
}
// Kayıt tarihini yerel güne çevirir (kayıtlar ISO ya da "YYYY-MM-DD HH:MM:SS" olabilir)
function kayitGunu(t) {
  const s = String(t || "");
  const d = new Date(s.includes("T") || s.includes("Z") ? s : s.replace(" ", "T") + "Z");
  return isNaN(d) ? s.slice(0, 10) : yerelGun(d);
}

function halkaGrafik(baslik, merkez, dilimler) {
  const toplam = dilimler.reduce((t, d) => t + d.deger, 0);
  const R = 70, C = 2 * Math.PI * R;
  let ofset = 0;
  const halkalar = toplam > 0
    ? dilimler.filter(d => d.deger > 0).map(d => {
      const uzunluk = d.deger / toplam * C;
      const s = `<circle cx="100" cy="100" r="${R}" fill="none" stroke="${d.renk}" stroke-width="26" stroke-dasharray="${uzunluk} ${C - uzunluk}" stroke-dashoffset="${-ofset}" transform="rotate(-90 100 100)"><title>${kac("", d.ad)}: ${d.yazi}</title></circle>`;
      ofset += uzunluk;
      return s;
    }).join("")
    : `<circle cx="100" cy="100" r="${R}" fill="none" stroke="var(--line, #d8dee8)" stroke-width="26"/>`;
  return `<div class="halka">
    <svg viewBox="0 0 200 200" role="img" aria-label="${kac("", baslik)}">${halkalar}
      <text x="100" y="92" text-anchor="middle" class="halka-baslik">${kac("", baslik)}</text>
      <text x="100" y="116" text-anchor="middle" class="halka-deger">${kac("", merkez)}</text>
    </svg>
    <div class="halka-liste">${dilimler.map(d => `<span><i style="background:${d.renk}"></i>${kac("", d.ad)}: [${kac("", d.yazi)}]</span>`).join("")}</div>
  </div>`;
}

function satisCizgisi(gunler) {
  const G = 640, Y = 220, sol = 62, alt = 28, ust = 12, sag = 14;
  const en = Math.max(...gunler.map(g => g.toplam), 1);
  const adim = (() => { const ham = en / 4, us = Math.pow(10, Math.floor(Math.log10(ham))); const n = ham / us; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * us; })();
  const tavan = adim * Math.ceil(en / adim);
  const x = i => sol + (gunler.length === 1 ? (G - sol - sag) / 2 : i * (G - sol - sag) / (gunler.length - 1));
  const y = v => ust + (1 - v / tavan) * (Y - ust - alt);
  const izgara = [];
  for (let v = 0; v <= tavan + 0.001; v += adim) izgara.push(`<line x1="${sol}" x2="${G - sag}" y1="${y(v)}" y2="${y(v)}" class="cz-izgara"/><text x="${sol - 8}" y="${y(v) + 4}" text-anchor="end" class="cz-yazi">${Number(v).toLocaleString("tr-TR")} ₺</text>`);
  const noktalar = gunler.map((g, i) => x(i) + "," + y(g.toplam));
  const alan = gunler.length > 1 ? `<polygon points="${x(0)},${y(0)} ${noktalar.join(" ")} ${x(gunler.length - 1)},${y(0)}" class="cz-alan"/>` : "";
  const etiketAdim = Math.max(1, Math.ceil(gunler.length / 8));
  const etiketler = gunler.map((g, i) => i % etiketAdim === 0 || i === gunler.length - 1 ? `<text x="${x(i)}" y="${Y - 8}" text-anchor="middle" class="cz-yazi">${g.gun.slice(8)}.${g.gun.slice(5, 7)}</text>` : "").join("");
  return `<svg viewBox="0 0 ${G} ${Y}" class="cizgi-grafik" role="img" aria-label="Satışlar">${izgara.join("")}${alan}
    <polyline points="${noktalar.join(" ")}" class="cz-cizgi"/>
    ${gunler.map((g, i) => `<circle cx="${x(i)}" cy="${y(g.toplam)}" r="4" class="cz-nokta"><title>${g.gun}: ${para(g.toplam)}</title></circle>`).join("")}${etiketler}</svg>`;
}

function raporPanosu() {
  const { bas, son } = raporAraligi();
  const icinde = s => { const g = kayitGunu(s.tarih); return g >= bas && g <= son && (!raporKasa || String(s.kasa_no) === raporKasa); };
  const hepsi = DB.liste("satislar", s => icinde(s));
  const tamam = hepsi.filter(s => s.durum === "tamamlandi");
  const iptal = hepsi.filter(s => s.durum === "iptal");
  const toplam = l => l.reduce((t, s) => t + Number(s.toplam || 0), 0);
  const tamamIdleri = new Set(tamam.map(s => s.id));
  const odeme = y => DB.liste("odemeler", o => o.yontem === y && tamamIdleri.has(o.satis_id)).reduce((t, o) => t + Number(o.tutar || 0), 0);
  const nakit = odeme("nakit"), kart = odeme("kart"), veresiye = odeme("acik_hesap");

  // Günlük satış toplamları (aralıktaki her gün)
  const gunToplam = {};
  tamam.forEach(s => { const g = kayitGunu(s.tarih); gunToplam[g] = (gunToplam[g] || 0) + Number(s.toplam || 0); });
  const gunler = [];
  for (let d = new Date(bas + "T00:00:00"); yerelGun(d) <= son && gunler.length < 400; d.setDate(d.getDate() + 1)) gunler.push({ gun: yerelGun(d), toplam: gunToplam[yerelGun(d)] || 0 });

  const kasalar = [...new Set(DB.liste("satislar").map(s => String(s.kasa_no)))].sort();
  const toplamAcik = DB.liste("musteriler").reduce((t, m) => t + cariBakiye(m.id), 0);
  return `<div class="baslik-satir"><h2>Gösterge paneli</h2></div>
    <div class="donemler" id="rapor-donemler">
      ${RAPOR_DONEMLERI.map(([k, ad]) => `<button class="donem ${raporDonem === k ? "aktif" : ""}" data-donem="${k}">${ad}</button>`).join("")}
      ${raporDonem === "tarih" ? `<input type="date" id="rapor-bas" value="${bas}"> – <input type="date" id="rapor-son" value="${son}">` : ""}
      <select id="rapor-kasa" aria-label="Kasa seç"><option value="">Tüm kasalar</option>${kasalar.map(k => `<option value="${kac("", k)}" ${k === raporKasa ? "selected" : ""}>Kasa ${kac("", k)}</option>`).join("")}</select>
    </div>
    <div class="halkalar">
      ${halkaGrafik("Fiş Sayısı", tamam.length + iptal.length + " Adet", [
        { ad: "Satış fişi", deger: tamam.length, renk: "#d4a514", yazi: String(tamam.length) },
        { ad: "İptal fiş", deger: iptal.length, renk: "#a31d1d", yazi: String(iptal.length) }])}
      ${halkaGrafik("Satış Toplam", para(toplam(tamam)), [
        { ad: "Satış toplamı", deger: toplam(tamam), renk: "#d4a514", yazi: para(toplam(tamam)) },
        { ad: "İptal fiş toplamı", deger: toplam(iptal), renk: "#a31d1d", yazi: para(toplam(iptal)) }])}
      ${halkaGrafik("Tahsilat Toplam", para(nakit + kart), [
        { ad: "Nakit", deger: nakit, renk: "#2e9e5b", yazi: para(nakit) },
        { ad: "Kart", deger: kart, renk: "#3b7dd8", yazi: para(kart) },
        { ad: "Veresiye", deger: veresiye, renk: "#e07b39", yazi: para(veresiye) }])}
    </div>
    <div class="baslik-satir"><h2>Satışlar</h2><span class="rapor-not">Toplam açık hesap alacağı: <strong>${para(toplamAcik)}</strong></span></div>
    ${satisCizgisi(gunler)}`;
}

function raporCiz() {
  const bugun = new Date().toISOString().slice(0, 10);
  const satislar = DB.liste("satislar", s => s.durum === "tamamlandi");
  const bugunSatislar = satislar.filter(s => s.tarih.slice(0, 10) === bugun);
  const ciro = bugunSatislar.reduce((t, s) => t + s.toplam, 0);
  const nakit = DB.liste("odemeler").filter(o => o.yontem === "nakit" && bugunSatislar.some(s => s.id === o.satis_id)).reduce((t, o) => t + o.tutar, 0);
  const kart = DB.liste("odemeler").filter(o => o.yontem === "kart" && bugunSatislar.some(s => s.id === o.satis_id)).reduce((t, o) => t + o.tutar, 0);
  const acik = DB.liste("odemeler").filter(o => o.yontem === "acik_hesap" && bugunSatislar.some(s => s.id === o.satis_id)).reduce((t, o) => t + o.tutar, 0);
  const toplamAcik = DB.liste("musteriler").reduce((t, m) => t + cariBakiye(m.id), 0);

  // En çok satan
  const adet = {};
  const gecerliSatislar = new Set(satislar.map(s => s.id));
  DB.liste("satis_kalemleri", k => gecerliSatislar.has(k.satis_id)).forEach(k => { adet[k.urun_id] = (adet[k.urun_id] || 0) + k.miktar; });
  const enCok = Object.entries(adet).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([id, m]) => ({ ad: (DB.bul("urunler", x => x.id === Number(id)) || {}).ad || "", m }));

  $("s-rapor").innerHTML = `
    ${raporPanosu()}
    <div class="baslik-satir"><h2>En çok satan ürünler</h2></div>
    <table class="tablo" style="margin-bottom:16px">
      <tr><th>Ürün</th><th class="sag">Satılan</th></tr>
      ${enCok.map(x => `<tr><td>${kac("", x.ad)}</td><td class="sag">${sayi(x.m)}</td></tr>`).join("") || '<tr><td colspan="2">Henüz satış yok</td></tr>'}
    </table>
    <div class="baslik-satir"><h2>Satış fişleri</h2></div>
    <table class="tablo">
      <tr><th>Fiş no</th><th>Tarih</th><th>Kasiyer</th><th class="sag">Toplam</th><th>Durum</th><th></th></tr>
      ${DB.liste("satislar").reverse().slice(0, 50).map(s => `<tr>
        <td>${s.fis_no}</td><td>${tarih(s.tarih)}</td>
        <td>${kac("", (DB.bul("kullanicilar", x => x.id === s.kullanici_id) || {}).ad_soyad)}</td>
        <td class="sag">${para(s.toplam)}</td>
        <td>${s.durum === "iptal" ? '<span class="rozet uyari">İptal</span>' : '<span class="rozet">Tamam</span>'}</td>
        <td>${s.durum === "tamamlandi" && aktifKullanici.rol === "yonetici" ? `<button class="btn kucuk tehlike" data-iptal="${s.id}">Fişi iptal et</button>` : ""}</td>
      </tr>`).join("") || '<tr><td colspan="6">Fiş yok</td></tr>'}
    </table>`;
  $("s-rapor").querySelectorAll("[data-iptal]").forEach(b => b.addEventListener("click", () => fisIptal(Number(b.dataset.iptal))));
  $("s-rapor").querySelectorAll("[data-donem]").forEach(b => b.addEventListener("click", () => { raporDonem = b.dataset.donem; raporCiz(); }));
  if ($("rapor-bas")) $("rapor-bas").addEventListener("change", e => { raporBas = e.target.value; raporCiz(); });
  if ($("rapor-son")) $("rapor-son").addEventListener("change", e => { raporSon = e.target.value; raporCiz(); });
  $("rapor-kasa").addEventListener("change", e => { raporKasa = e.target.value; raporCiz(); });
}

// Kesilmiş fişin iptali: neden sorulur, stok geri yüklenir, kayıt Fişler sayfasında kalır
function fisIptal(satisId) {
  const s = DB.bul("satislar", x => x.id === satisId);
  if (!s || s.durum === "iptal") return;
  modalAc(`
    <div class="modal-baslik">Fişi iptal et · ${s.fis_no}</div>
    <p>Toplam ${para(s.toplam)}. Stok geri yüklenir, açık hesap borcu varsa silinir. Fiş silinmez, iptal olarak kaydedilir.</p>
    <form id="ip-form" class="form">
      <label class="tam">İptal nedeni<input name="neden" placeholder="Örn. yanlış ürün, müşteri vazgeçti" required></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="ip-vazgec">Vazgeç</button><button class="btn tehlike" type="submit">Fişi iptal et</button></div>
    </form>`);
  $("ip-vazgec").addEventListener("click", modalKapat);
  $("ip-form").addEventListener("submit", e => {
    e.preventDefault();
    const neden = new FormData(e.target).get("neden").trim();
    if (!neden) return;
    DB.liste("satis_kalemleri", k => k.satis_id === satisId).forEach(k => {
      DB.stokHareketi(k.urun_id, "iade", k.miktar, "İptal: " + s.fis_no, aktifKullanici.id);
    });
    DB.guncelle("satislar", satisId, {
      durum: "iptal", iptal_turu: "fis", iptal_nedeni: neden,
      iptal_tarihi: new Date().toISOString(), iptal_eden_id: aktifKullanici.id
    });
    // Açık hesap borcu için ters kayıt
    DB.liste("cari_hareketler", h => h.satis_id === satisId && h.tur === "borc").forEach(h => {
      cariKaydet(h.musteri_id, "tahsilat", h.tutar, { satisId, islem: "fis_iptali", aciklama: `İptal: ${s.fis_no} (${neden})` });
    });
    modalKapat();
    sayfaGoster(aktifSayfa);
    bildir("Fiş iptal edildi, stok geri yüklendi");
  });
}

// Ödeme alınmadan vazgeçilen sepet de iptal fişi olarak kaydedilir (stok ve ödeme etkilenmez)
function sepetIptalKaydet(neden) {
  const araT = sepetToplami();
  const satis = DB.ekle("satislar", {
    fis_no: fisNo(), kasa_no: DB.ayarOku("kasaNo", "1"), kullanici_id: aktifKullanici.id,
    musteri_id: seciliMusteriId, ara_toplam: araT, indirim: araT - genelToplam(), toplam: genelToplam(),
    durum: "iptal", iptal_turu: "sepet", iptal_nedeni: neden || "Sepet iptali",
    iptal_tarihi: new Date().toISOString(), iptal_eden_id: aktifKullanici.id, tarih: new Date().toISOString()
  });
  sepet.forEach(s => DB.ekle("satis_kalemleri", { satis_id: satis.id, urun_id: s.id, miktar: s.adet, birim_fiyat: s.fiyat, tutar: s.fiyat * s.adet }));
  return satis;
}

// ---------- FİŞLER ----------
let fisTarih = null; // YYYY-MM-DD, boşsa bugün
let fisDurumFiltresi = "hepsi";

function yerelGun(iso) {
  const d = new Date(iso);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function fislerCiz() {
  const bugun = yerelGun(new Date().toISOString());
  if (!fisTarih) fisTarih = bugun;
  const gunSatislari = DB.liste("satislar", s => yerelGun(s.tarih) === fisTarih).reverse();
  const liste = gunSatislari.filter(s => fisDurumFiltresi === "hepsi" || (fisDurumFiltresi === "iptal" ? s.durum === "iptal" : s.durum === "tamamlandi"));
  const tamam = gunSatislari.filter(s => s.durum === "tamamlandi");
  const iptaller = gunSatislari.filter(s => s.durum === "iptal");
  const ciro = tamam.reduce((t, s) => t + s.toplam, 0);
  const yontemAd = { nakit: "Nakit", kart: "Kart", acik_hesap: "Açık hesap" };
  const kasiyer = id => (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad || "";
  const yonetici = aktifKullanici.rol === "yonetici";

  $("s-fis").innerHTML = `
    <div class="baslik-satir">
      <h2>Fişler</h2>
      <div class="filtre">
        <input type="date" id="fis-tarih" value="${fisTarih}">
        <select id="fis-durum">
          <option value="hepsi" ${fisDurumFiltresi === "hepsi" ? "selected" : ""}>Tümü</option>
          <option value="tamam" ${fisDurumFiltresi === "tamam" ? "selected" : ""}>Satışlar</option>
          <option value="iptal" ${fisDurumFiltresi === "iptal" ? "selected" : ""}>İptaller</option>
        </select>
        <button class="btn" id="fis-bugun">Bugün</button>
      </div>
    </div>
    <div class="ozet-kutular">
      <div class="ozet"><small>Satış fişi</small><strong>${tamam.length}</strong></div>
      <div class="ozet"><small>Ciro</small><strong>${para(ciro)}</strong></div>
      <div class="ozet"><small>İptal edilen</small><strong>${iptaller.length}</strong></div>
    </div>
    <table class="tablo">
      <tr><th>Fiş no</th><th>Saat</th><th>Kasiyer</th><th>Ödeme</th><th class="sag">Toplam</th><th>Durum</th><th></th></tr>
      ${liste.map(s => {
        const odeme = DB.bul("odemeler", o => o.satis_id === s.id);
        return `<tr>
          <td>${s.fis_no}</td>
          <td>${new Date(s.tarih).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}</td>
          <td>${kac("", kasiyer(s.kullanici_id))}</td>
          <td>${odeme ? yontemAd[odeme.yontem] : "-"}</td>
          <td class="sag">${para(s.toplam)}</td>
          <td>${s.durum === "iptal" ? `<span class="rozet uyari">${s.iptal_turu === "sepet" ? "Sepet iptali" : "İptal"}</span>` : '<span class="rozet">Tamam</span>'}</td>
          <td>
            <button class="btn kucuk" data-detay="${s.id}">Detay</button>
            ${s.durum === "tamamlandi" ? `<button class="btn kucuk" data-yazdir="${s.id}">Yazdır</button>` : ""}
            ${s.durum === "tamamlandi" && yonetici ? `<button class="btn kucuk tehlike" data-iptal="${s.id}">İptal et</button>` : ""}
          </td>
        </tr>`;
      }).join("") || '<tr><td colspan="7">Bu tarihte fiş yok</td></tr>'}
    </table>`;

  $("fis-tarih").addEventListener("change", e => { fisTarih = e.target.value || bugun; fislerCiz(); });
  $("fis-durum").addEventListener("change", e => { fisDurumFiltresi = e.target.value; fislerCiz(); });
  $("fis-bugun").addEventListener("click", () => { fisTarih = bugun; fislerCiz(); });
  $("s-fis").querySelectorAll("[data-detay]").forEach(b => b.addEventListener("click", () => fisDetay(Number(b.dataset.detay))));
  $("s-fis").querySelectorAll("[data-yazdir]").forEach(b => b.addEventListener("click", () => fisYazdir(Number(b.dataset.yazdir))));
  $("s-fis").querySelectorAll("[data-iptal]").forEach(b => b.addEventListener("click", () => fisIptal(Number(b.dataset.iptal))));
}

function fisDetay(satisId, geri) {
  const s = DB.bul("satislar", x => x.id === satisId);
  if (!s) return;
  const kalemler = DB.liste("satis_kalemleri", k => k.satis_id === satisId);
  const kim = id => (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad || "";
  const musteri = s.musteri_id ? (DB.bul("musteriler", m => m.id === s.musteri_id) || {}).ad_soyad : "";
  modalAc(`
    <div class="modal-baslik">${s.fis_no} · ${tarih(s.tarih)}</div>
    <p>Kasiyer: ${kac("", kim(s.kullanici_id))}${musteri ? ` · Müşteri: ${kac("", musteri)}` : ""}</p>
    ${s.durum === "iptal" ? `<p class="hata">${s.iptal_turu === "sepet" ? "Sepet iptali" : "Fiş iptali"}: ${kac("", s.iptal_nedeni)} · ${tarih(s.iptal_tarihi)} · ${kac("", kim(s.iptal_eden_id))}</p>` : ""}
    <table class="tablo">
      <tr><th>Ürün</th><th class="sag">Adet</th><th class="sag">Fiyat</th><th class="sag">Tutar</th></tr>
      ${kalemler.map(k => `<tr><td>${kac("", (DB.bul("urunler", u => u.id === k.urun_id) || {}).ad)}</td><td class="sag">${sayi(k.miktar)}</td><td class="sag">${para(k.birim_fiyat)}</td><td class="sag">${para(k.tutar)}</td></tr>`).join("")}
      <tr><th colspan="3">Toplam</th><th class="sag">${para(s.toplam)}</th></tr>
    </table>
    <div class="modal-alt"><button class="btn" id="fd-kapat">${geri ? "Geri dön" : "Kapat"}</button></div>`);
  $("fd-kapat").addEventListener("click", geri || modalKapat);
}

// ---------- KULLANICILAR (yönetici) ----------
function kullaniciCiz() {
  $("s-kullanici").innerHTML = `
    <div class="baslik-satir"><h2>Kullanıcılar</h2><button class="btn ana" id="k-yeni">Yeni kullanıcı</button></div>
    <p class="rapor-not" style="margin:0 0 10px">Kayıt olanlar: <strong>${DB.liste("kullanicilar", k => k.kendi_kaydi).length}</strong> kişi · son 7 günde: <strong>${DB.liste("kullanicilar", k => k.kendi_kaydi && Date.now() - new Date(k.kayit_tarihi) < 7 * 864e5).length}</strong></p>
    <table class="tablo">
      <tr><th>Ad soyad</th><th>Kullanıcı adı</th><th>Rol</th><th>Kayıt</th><th>Durum</th><th></th></tr>
      ${DB.liste("kullanicilar").map(k => `<tr>
        <td>${kac("", k.ad_soyad)}</td><td>${kac("", k.kullanici_adi)}</td>
        <td>${k.rol === "yonetici" ? "Yönetici" : "Satış"}</td>
        <td>${k.kendi_kaydi ? `<span class="rozet uyari">Kendi kaydı</span> <small>${kac("", tarih(k.kayit_tarihi))} · ${kac("", k.kayit_bilgisayar || "")}</small>` : "—"}</td>
        <td>${k.aktif ? '<span class="rozet">Aktif</span>' : '<span class="rozet uyari">Pasif</span>'}</td>
        <td><button class="btn kucuk" data-sifre="${k.id}">Şifre değiştir</button> <button class="btn kucuk" data-durum="${k.id}">${k.aktif ? "Pasifleştir" : "Aktifleştir"}</button> <button class="btn kucuk" data-rol="${k.id}">${k.rol === "yonetici" ? "Satışa çevir" : "Yönetici yap"}</button> <button class="btn kucuk tehlike" data-kul-sil="${k.id}">Sil</button></td>
      </tr>`).join("")}
    </table>`;
  $("k-yeni").addEventListener("click", kullaniciFormu);
  $("s-kullanici").querySelectorAll("[data-sifre]").forEach(b => b.addEventListener("click", () => sifreFormu(Number(b.dataset.sifre))));
  $("s-kullanici").querySelectorAll("[data-rol]").forEach(b => b.addEventListener("click", () => {
    const k = DB.bul("kullanicilar", x => x.id === Number(b.dataset.rol));
    if (!k) return;
    if (k.id === aktifKullanici.id) return bildir("Kendi rolünüzü değiştiremezsiniz");
    DB.guncelle("kullanicilar", k.id, { rol: k.rol === "yonetici" ? "kasiyer" : "yonetici" });
    kullaniciCiz();
  }));
  $("s-kullanici").querySelectorAll("[data-kul-sil]").forEach(b => b.addEventListener("click", () => {
    const k = DB.bul("kullanicilar", x => x.id === Number(b.dataset.kulSil));
    if (!k) return;
    if (k.id === aktifKullanici.id) return bildir("Kendi hesabınızı silemezsiniz");
    if (DB.liste("kullanicilar", x => x.rol === "yonetici" && x.aktif && x.id !== k.id).length === 0 && k.rol === "yonetici") return bildir("Son yöneticiyi silemezsiniz");
    // Geçmiş kayıtlar (fiş, stok, cari, sayım) kullanıcıya bağlıysa silinemez, pasifleştirilir
    const kullanildi = ["satislar", "stok_hareketleri", "cari_hareketler", "sayimlar"].some(t => DB.liste(t).some(x => x.kullanici_id === k.id || x.iptal_eden_id === k.id || x.tamamlayan_id === k.id));
    if (kullanildi) return bildir("Bu kullanıcının geçmiş satış/stok kayıtları var, silinemez. Pasifleştirebilirsiniz.");
    if (!confirm(k.ad_soyad + " kullanıcısı silinecek. Emin misiniz?")) return;
    DB.sil("kullanicilar", k.id);
    kullaniciCiz();
    bildir("Kullanıcı silindi");
  }));
  $("s-kullanici").querySelectorAll("[data-durum]").forEach(b => b.addEventListener("click", () => {
    const k = DB.bul("kullanicilar", x => x.id === Number(b.dataset.durum));
    if (k.id === aktifKullanici.id) return bildir("Kendi hesabınızı pasifleştiremezsiniz");
    DB.guncelle("kullanicilar", k.id, { aktif: k.aktif ? 0 : 1 });
    kullaniciCiz();
  }));
}

function kullaniciFormu() {
  modalAc(`
    <div class="modal-baslik">Yeni kullanıcı</div>
    <form id="k-form" class="form" style="margin-top:10px">
      <label>Ad soyad<input name="ad" required></label>
      <label>Kullanıcı adı<input name="kadi" required></label>
      <label>Şifre<input name="sifre" type="password" minlength="4" required></label>
      <label>Rol<select name="rol"><option value="kasiyer">Satış (satış yapar)</option><option value="yonetici">Yönetici (stok ve yönetim)</option></select></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="k-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  $("k-vazgec").addEventListener("click", modalKapat);
  $("k-form").addEventListener("submit", async e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const yeniKadi = String(f.get("kadi")).trim();
    if (DB.bul("kullanicilar", x => String(x.kullanici_adi || "").trim().toLowerCase() === yeniKadi.toLowerCase())) return bildir("Bu kullanıcı adı alınmış");
    DB.ekle("kullanicilar", { ad_soyad: String(f.get("ad")).trim(), kullanici_adi: yeniKadi, sifre_hash: await sifreOzeti(f.get("sifre")), rol: f.get("rol"), aktif: 1 });
    modalKapat();
    kullaniciCiz();
    bildir("Kullanıcı eklendi");
  });
}

function sifreFormu(id) {
  const k = DB.bul("kullanicilar", x => x.id === id);
  modalAc(`
    <div class="modal-baslik">Şifre değiştir · ${kac("", k.kullanici_adi)}</div>
    <form id="s-form" class="form" style="margin-top:10px">
      <label class="tam">Yeni şifre<input name="sifre" type="password" minlength="4" required></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="s-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  $("s-vazgec").addEventListener("click", modalKapat);
  $("s-form").addEventListener("submit", async e => {
    e.preventDefault();
    DB.guncelle("kullanicilar", id, { sifre_hash: await sifreOzeti(new FormData(e.target).get("sifre")) });
    modalKapat();
    bildir("Şifre güncellendi");
  });
}

// ---------- AYARLAR ----------
// Temalar: renk değişkenleri styles.css içindeki .tema-N sınıflarında; burada seçim kartlarındaki önizleme renkleri bulunur.
const TEMALAR = [
  { id: 1, ad: "Kurumsal mavi", ust: "#1F3A5F", vurgu: "#1F3A5F", sayfa: "#F5F7FA", yuzey: "#ffffff" },
  { id: 2, ad: "Doğal yeşil", ust: "#2D6A4F", vurgu: "#2D6A4F", sayfa: "#FEFAE0", yuzey: "#ffffff" },
  { id: 3, ad: "Canlı kampanya", ust: "#D62839", vurgu: "#D62839", sayfa: "#ffffff", yuzey: "#FFF8E1" },
  { id: 4, ad: "Gece altın", ust: "#0B0F1A", vurgu: "#D4AF37", sayfa: "#111827", yuzey: "#1F2937" },
  { id: 5, ad: "Okyanus mavisi", ust: "#0369A1", vurgu: "#0369A1", sayfa: "#F0F9FF", yuzey: "#ffffff" },
  { id: 6, ad: "Pastel sadakat", ust: "#7C3AED", vurgu: "#7C3AED", sayfa: "#FAF5FF", yuzey: "#ffffff" },
  { id: 7, ad: "Sıcak kahverengi", ust: "#78350F", vurgu: "#B45309", sayfa: "#FDF6EC", yuzey: "#ffffff" },
  { id: 8, ad: "Minimal gri", ust: "#F3F4F6", vurgu: "#111827", sayfa: "#ffffff", yuzey: "#ffffff" },
  { id: 9, ad: "Çok şubeli teal", ust: "#0F766E", vurgu: "#0F766E", sayfa: "#F0FDFA", yuzey: "#ffffff" },
  { id: 10, ad: "Sezon kırmızısı", ust: "#B91C1C", vurgu: "#B91C1C", sayfa: "#FFF7ED", yuzey: "#ffffff" },
  { id: 11, ad: "Gece mavisi", ust: "#070C16", vurgu: "#38BDF8", sayfa: "#0B1220", yuzey: "#131C2E" },
  { id: 12, ad: "Gece yeşili", ust: "#07100C", vurgu: "#22C55E", sayfa: "#0B1511", yuzey: "#12201A" }
];

function temaSec(no) {
  const gecerli = TEMALAR.some(t => t.id === Number(no)) ? Number(no) : 1;
  document.body.className = "tema-" + gecerli;
  DB.ayarYaz("tema", String(gecerli));
  temaListesiCiz();
}

// Üst çubuktaki Tema butonu: basınca tüm temalar sıralanır, birine tıklayınca anında uygulanır ve kaydedilir
function temaListesiCiz() {
  const aktif = Number(DB.ayarOku("tema", "1"));
  $("tema-liste").innerHTML = TEMALAR.map(t => `
    <button class="tema-oge ${t.id === aktif ? "secili" : ""}" role="menuitemradio" aria-checked="${t.id === aktif}" data-tema-sec="${t.id}">
      <span class="tema-onizleme" style="background:${t.sayfa}"><span class="tema-cubuk" style="background:${t.ust}"></span><span class="tema-govde"><span class="tema-kutu" style="background:${t.yuzey}"></span><span class="tema-dugme-mini" style="background:${t.vurgu}"></span></span></span>
      <span class="tema-ad-metin">${t.id}. ${t.ad}</span><span class="tik">✓</span>
    </button>`).join("");
}

function temaListesiAc(ac) {
  $("tema-liste").hidden = !ac;
  $("tema-dugme").setAttribute("aria-expanded", String(ac));
  document.querySelector(".ust").classList.toggle("menu-acik", ac);
}

// ---------- Güncelleme ----------
// Uygulama açılınca yeni sürüm olup olmadığına bakılır. Varsa güncellensin mi diye sorulur;
// güncelleme bitince sunucu yeniden başlar ve uygulama yeni sürümle açılır.
function guncellemePaneliGoster(html) {
  $("guncelleme-icerik").innerHTML = html;
  $("guncelleme-panel").style.display = "flex";
}

function guncellemePaneliKapat() {
  $("guncelleme-panel").style.display = "none";
}

function guncellemeMesaji(baslik, metin) {
  guncellemePaneliGoster(`<div class="panel-baslik">${kac("", baslik)}</div><p>${kac("", metin)}</p><button class="btn ana" id="gm-tamam">Tamam</button>`);
  $("gm-tamam").addEventListener("click", guncellemePaneliKapat);
}

// "Sonra" denen sürüm, uygulama kapanıp açılana kadar çalışırken tekrar sorulmaz
let ertelenenSurum = null;
let sonGuncellemeDenetimi = 0;

async function guncellemeKontrolu(sessiz, periyodik) {
  let s;
  sonGuncellemeDenetimi = Date.now();
  try {
    s = await (await fetch("/api/guncelleme/kontrol", { cache: "no-store" })).json();
  } catch (e) {
    if (!sessiz) guncellemeMesaji("Sunucuya ulaşılamadı", "Sunucunun çalıştığından emin olun.");
    return;
  }
  if (s.durum === "var") {
    if (periyodik && s.yeni === ertelenenSurum) return;
    return guncellemeSor(s);
  }
  if (sessiz) return;
  if (s.durum === "guncel") guncellemeMesaji("Uygulama güncel", `Kurulu sürüm ${s.mevcut}.`);
  else if (s.durum === "kaynak-yok") guncellemeMesaji("Güncelleme kaynağı ayarlanmamış", "Lütfen yöneticinizle görüşün.");
  else if (s.durum === "yetkisiz") guncellemeMesaji("Güncelleme yapılamıyor", "Güncelleme yalnızca sunucu bilgisayarındaki uygulamadan yapılır.");
  else guncellemeMesaji("Güncelleme denetlenemedi", s.hata || "Kaynağa ulaşılamadı.");
}

function guncellemeSor(s) {
  guncellemePaneliGoster(`
    <div class="panel-baslik">Güncelleme var</div>
    <p>Yeni sürüm <strong>${kac("", s.yeni)}</strong> hazır (şu an ${kac("", s.mevcut)}). Güncellemek ister misiniz?</p>
    ${s.notlar && s.notlar.length ? `<ul class="guncelleme-notlar">${s.notlar.map(n => `<li>${kac("", n)}</li>`).join("")}</ul>` : ""}
    <p class="guncelleme-alt">Güncelleme birkaç saniye sürer. Verileriniz korunur, bitince uygulama açılır.</p>
    <div class="modal-alt"><button class="btn" id="g-sonra">Sonra</button><button class="btn ana" id="g-simdi">Şimdi güncelle</button></div>`);
  $("g-sonra").addEventListener("click", () => { ertelenenSurum = s.yeni; guncellemePaneliKapat(); });
  $("g-simdi").addEventListener("click", () => guncellemeyiUygula(s.yeni));
}

async function guncellemeyiUygula(yeni) {
  guncellemePaneliGoster('<div class="panel-baslik">Güncelleniyor...</div><p>Lütfen pencereyi kapatmayın. Güncelleme bitince uygulama yeniden açılacak.</p><div class="ilerleme"><span></span></div>');
  try {
    const sonuc = await (await fetch("/api/guncelleme/uygula", { method: "POST" })).json();
    if (!sonuc.ok) throw new Error(sonuc.hata || "Güncelleme başarısız");
  } catch (e) {
    return guncellemeMesaji("Güncelleme yapılamadı", e.message + ". Uygulama eski sürümle çalışmaya devam ediyor.");
  }
  // Sunucu yeni sürümle yeniden açılana kadar bekle, sonra sayfayı yenile (uygulama yeni sürümle açılır)
  for (let i = 0; i < 90; i++) {
    await new Promise(r => setTimeout(r, 700));
    try {
      const s = await (await fetch("/api/surum", { cache: "no-store" })).json();
      if (s.surum === yeni) return location.reload();
    } catch (e) { /* sunucu yeniden başlıyor */ }
  }
  guncellemeMesaji("Uygulama yeniden başlamadı", "Masaüstündeki Perakende Satış simgesine tekrar tıklayın.");
}

// ---------- Marka: logo ve işletme adı ----------
// Logo giriş ekranında, açılış animasyonunda, üst menüde, fişte ve cari ekstrede kullanılır.
const VARSAYILAN_ISLETME = "Perakende satış";
let marka = { logo: null, isletmeAdi: null };

function markaBilgisi() {
  return { logo: marka.logo || null, ad: (marka.isletmeAdi || "").trim() || VARSAYILAN_ISLETME };
}

function markayiUygula(yeni) {
  if (yeni) marka = { logo: yeni.logo || null, isletmeAdi: yeni.isletmeAdi || null };
  const { logo, ad } = markaBilgisi();
  document.title = ad;
  $("giris-logo").innerHTML = logo ? `<img src="${logo}" alt="">` : "";
  $("giris-baslik").textContent = ad;
  $("ust-marka").innerHTML = logo ? `<img src="${logo}" alt="">` : "";
  $("ust-marka").title = ad;
}

// Kayıtlı marka: önce tarayıcıdaki kopya, sonra sunucudaki (giriş yapmadan da görünsün diye)
async function markayiYukle() {
  markayiUygula({ logo: DB.ayarOku("logo", null), isletmeAdi: DB.ayarOku("isletmeAdi", null) });
  try {
    const m = await (await fetch("/api/marka", { cache: "no-store" })).json();
    if (m.logo || m.isletmeAdi) markayiUygula(m);
  } catch (e) { /* sunucu yoksa yerel kopya yeter */ }
}

function markaBolumu() {
  if (aktifKullanici.rol !== "yonetici") return "";
  const { logo, ad } = markaBilgisi();
  return `
    <div class="baslik-satir"><h2>Logo ve işletme adı</h2></div>
    <div class="marka-kutu">
      <div class="marka-onizleme">${logo ? `<img src="${logo}" alt="Logo">` : '<span>Logo yok</span>'}</div>
      <div class="marka-form">
        <label>İşletme adı<input id="marka-ad" value="${kac("", marka.isletmeAdi || "")}" placeholder="${VARSAYILAN_ISLETME}" maxlength="40"></label>
        <div class="filtre">
          <label class="btn" style="cursor:pointer">${logo ? "Logoyu değiştir" : "Logo ekle"}<input id="marka-dosya" type="file" accept="image/*" hidden></label>
          ${logo ? '<button class="btn tehlike" id="marka-sil">Logoyu sil</button>' : ""}
          <button class="btn ana" id="marka-kaydet">Adı kaydet</button>
        </div>
        <small style="opacity:0.75">Logo giriş ekranında, açılış animasyonunda, üst menüde, fişte ve cari ekstrede görünür. Resim otomatik küçültülür.</small>
      </div>
    </div>`;
}

// Fiş başlığı: logo (siyah-beyaz yazıcıda gri tonlu) ve işletme adı
function fisBasligi() {
  const { logo, ad } = markaBilgisi();
  return `${logo ? `<div class="ortala"><img src="${logo}" alt="" style="max-height:56px;max-width:200px;filter:grayscale(1)"></div>` : ""}<h1>${kac("", ad.toLocaleUpperCase("tr"))}</h1>`;
}

function markaOlaylari() {
  if (!$("marka-kaydet")) return;
  $("marka-kaydet").addEventListener("click", () => {
    const ad = $("marka-ad").value.trim();
    DB.ayarYaz("isletmeAdi", ad);
    markayiUygula({ logo: marka.logo, isletmeAdi: ad });
    bildir("İşletme adı kaydedildi");
  });
  $("marka-dosya").addEventListener("change", async e => {
    const dosya = e.target.files[0];
    if (!dosya) return;
    if (!dosya.type.startsWith("image/")) return bildir("Lütfen bir resim dosyası seçin");
    if (dosya.size > 8 * 1024 * 1024) return bildir("Resim 8 MB'tan büyük olamaz");
    try {
      const logo = await resmiKucult(dosya, 256, "image/png"); // PNG: saydam arka plan korunur
      DB.ayarYaz("logo", logo);
      markayiUygula({ logo, isletmeAdi: marka.isletmeAdi });
      ayarCiz();
      bildir("Logo kaydedildi");
    } catch (err) {
      bildir("Resim okunamadı");
    }
  });
  if ($("marka-sil")) $("marka-sil").addEventListener("click", () => {
    if (!confirm("Logo silinsin mi?")) return;
    DB.ayarYaz("logo", null);
    markayiUygula({ logo: null, isletmeAdi: marka.isletmeAdi });
    ayarCiz();
    bildir("Logo silindi");
  });
}

// Uygulama açıkken de yeni sürüm olup olmadığına bakılır: 10 dakikada bir ve pencereye dönüldüğünde.
// Satış sırasında (sepet doluyken) ya da başka bir pencere açıkken rahatsız edilmez.
function guncellemeDenetimiBaslat() {
  const uygunMu = () => aktifKullanici && sepet.length === 0
    && $("modal").style.display !== "flex" && $("guncelleme-panel").style.display !== "flex";
  const dene = () => { if (uygunMu()) guncellemeKontrolu(true, true); };
  setInterval(dene, 10 * 60 * 1000);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && Date.now() - sonGuncellemeDenetimi > 2 * 60 * 1000) dene();
  });
}

async function surumuGoster(hedef) {
  try {
    const s = await (await fetch("/api/surum", { cache: "no-store" })).json();
    hedef.textContent = "Sürüm " + s.surum;
  } catch (e) { hedef.textContent = ""; }
}

// ---------- Kategori ayarları paneli (yönetici): kasadaki sağ taraftaki kategori butonlarının yanındaki dişli ----------
function kategoriPaneliAc() {
  if (!aktifKullanici || aktifKullanici.rol !== "yonetici") return;
  panelKonumu();
  $("cekmece").classList.remove("acik");
  $("kat-paneli").classList.add("acik");
  kategoriPaneliListele();
}

function kategoriPaneliKapat() {
  $("kat-paneli").classList.remove("acik");
}

function kategoriPaneliListele() {
  const urunSayisi = id => DB.liste("urunler", u => u.kategori_id === id).length;
  $("kat-liste").innerHTML = DB.liste("kategoriler").map(k => `
    <div class="kat-satir">
      <div><strong>${kac("", k.ad)}</strong><small>${urunSayisi(k.id)} ürün</small></div>
      <div class="kat-islem">
        <button class="btn kucuk ana" data-kat-urun="${k.id}">+ Ürün ekle</button>
        <button class="btn kucuk" data-kat-duzenle="${k.id}">Düzenle</button>
        <button class="btn kucuk tehlike" data-kat-sil="${k.id}">Sil</button>
      </div>
    </div>`).join("") || '<div class="bos">Kategori yok. "Yeni kategori" ile ekleyin.</div>';
}

// Kategori değişince kasadaki butonlar ve açık panel güncellenir
function kategoriYenile() {
  kasaUrunleriCiz();
  if ($("kat-paneli").classList.contains("acik")) kategoriPaneliListele();
}

function kategoriFormu(id) {
  const k = id ? DB.bul("kategoriler", x => x.id === id) : null;
  modalAc(`
    <div class="modal-baslik">${k ? "Kategoriyi düzenle" : "Yeni kategori"}</div>
    <form id="kf" class="form" style="margin-top:10px">
      <label class="tam">Kategori adı<input name="ad" value="${kac("", k ? k.ad : "")}" maxlength="30" required></label>
      <div class="hata tam" id="kf-hata"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="kf-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  const form = $("kf");
  form.elements.ad.focus();
  $("kf-vazgec").addEventListener("click", modalKapat);
  form.addEventListener("submit", e => {
    e.preventDefault();
    const ad = form.elements.ad.value.trim();
    if (!ad) return ($("kf-hata").textContent = "Kategori adı boş olamaz");
    const ayni = DB.bul("kategoriler", x => x.id !== id && x.ad.toLocaleLowerCase("tr") === ad.toLocaleLowerCase("tr"));
    if (ayni) return ($("kf-hata").textContent = "Bu isimde bir kategori zaten var");
    if (k) {
      if (seciliKategori === k.ad) seciliKategori = ad;
      DB.guncelle("kategoriler", id, { ad });
    } else {
      DB.ekle("kategoriler", { ad });
    }
    modalKapat();
    kategoriYenile();
    bildir(k ? "Kategori güncellendi" : "Kategori eklendi");
  });
}

// Seçilen kategoriye mevcut ürünleri ekler (arama + çoklu seçim); ürün başka kategorideyse taşınır
function kategoriyeUrunEkle(id) {
  const k = DB.bul("kategoriler", x => x.id === id);
  if (!k) return;
  const katAdi = kid => (DB.bul("kategoriler", x => x.id === kid) || {}).ad || "Kategori yok";
  const adaylar = DB.liste("urunler", u => u.aktif && u.kategori_id !== id);
  modalAc(`
    <div class="modal-baslik">${kac("", k.ad)} kategorisine ürün ekle</div>
    <div class="form" style="margin-top:10px">
      <input id="ke-ara" class="arama" placeholder="Ürün adı veya barkod ara" autocomplete="off">
      <div id="ke-liste" class="ke-liste">${
        adaylar.map(u => `<label class="ke-satir" data-ad="${kac("", (u.ad + " " + u.barkod).toLowerCase())}"><input type="checkbox" value="${u.id}"><span class="ke-ad">${kac("", u.ad)}<small>${kac("", u.barkod)} · şu an: ${kac("", katAdi(u.kategori_id))}</small></span><span class="ke-fiyat">${para(u.satis_fiyati)}</span></label>`).join("")
        || '<div class="bos">Eklenecek başka ürün yok</div>'}</div>
      <div class="modal-alt tam">
        <button type="button" class="btn" id="ke-yeni">Yeni ürün oluştur</button>
        <button type="button" class="btn" id="ke-vazgec">Vazgeç</button>
        <button type="button" class="btn ana" id="ke-ekle">Seçilenleri ekle</button>
      </div>
    </div>`);
  $("ke-ara").focus();
  $("ke-ara").addEventListener("input", () => {
    const q = $("ke-ara").value.trim().toLowerCase();
    $("ke-liste").querySelectorAll(".ke-satir").forEach(s => { s.hidden = q !== "" && !s.dataset.ad.includes(q); });
  });
  $("ke-vazgec").addEventListener("click", modalKapat);
  $("ke-ekle").addEventListener("click", () => {
    const secilen = [...$("ke-liste").querySelectorAll("input:checked")].map(i => Number(i.value));
    if (!secilen.length) return bildir("Önce ürün seçin");
    secilen.forEach(uid => DB.guncelle("urunler", uid, { kategori_id: id }));
    modalKapat();
    kategoriYenile();
    bildir(`${secilen.length} ürün "${k.ad}" kategorisine eklendi`);
  });
  // Yeni ürün: ürün ekleme sekmesi bu kategori seçili olarak açılır
  $("ke-yeni").addEventListener("click", () => {
    modalKapat();
    kategoriPaneliKapat();
    ekleKategorisi = id;
    urunAyarlariAc("ekle");
  });
}

function kategoriSil(id) {
  const k = DB.bul("kategoriler", x => x.id === id);
  if (!k) return;
  const urunler = DB.liste("urunler", u => u.kategori_id === id);
  const diger = DB.liste("kategoriler", x => x.id !== id);
  
  modalAc(`
    <div class="modal-baslik">Kategoriyi sil · ${kac("", k.ad)}</div>
    <form id="ks" class="form" style="margin-top:10px">
      ${urunler.length
        ? `<p class="tam">Bu kategoride <strong>${urunler.length} ürün</strong> var. Silmeden önce ürünlerin taşınacağı kategoriyi seçin.</p>
           <label class="tam">Ürünler şuraya taşınsın<select name="hedef"><option value="">Kategorisiz bırak</option>${diger.map(x => `<option value="${x.id}">${kac("", x.ad)}</option>`).join("")}</select></label>`
        : '<p class="tam">Bu kategoride ürün yok. Kategori silinecek.</p>'}
      <div class="modal-alt tam"><button type="button" class="btn" id="ks-vazgec">Vazgeç</button><button class="btn tehlike" type="submit">Kategoriyi sil</button></div>
    </form>`);
  $("ks-vazgec").addEventListener("click", modalKapat);
  $("ks").addEventListener("submit", e => {
    e.preventDefault();
    if (urunler.length) {
      const secim = new FormData(e.target).get("hedef");
      const hedef = secim ? Number(secim) : null;
      urunler.forEach(u => DB.guncelle("urunler", u.id, { kategori_id: hedef }));
    }
    DB.sil("kategoriler", id);
    if (seciliKategori === k.ad) seciliKategori = ""; // ilk kategoriye döner
    modalKapat();
    kategoriYenile();
    bildir(urunler.length ? `Kategori silindi, ${urunler.length} ürün taşındı` : "Kategori silindi");
  });
}

function ayarCiz() {
  const tema = DB.ayarOku("tema", "1");
  $("s-ayar").innerHTML = `
    <div class="baslik-satir"><h2>Ayarlar</h2></div>
    <div class="baslik-satir"><h2>Tema</h2><span style="font-size:12px;opacity:0.75">Seçiminiz kaydedilir ve her açılışta kullanılır</span></div>
    <div class="tema-izgara">
      ${TEMALAR.map(t => `
        <button class="tema-kart ${tema === String(t.id) ? "secili" : ""}" data-tema="${t.id}" aria-pressed="${tema === String(t.id)}">
          <span class="tema-onizleme" style="background:${t.sayfa}">
            <span class="tema-cubuk" style="background:${t.ust}"></span>
            <span class="tema-govde"><span class="tema-kutu" style="background:${t.yuzey}"></span><span class="tema-dugme" style="background:${t.vurgu}"></span></span>
          </span>
          <span class="tema-ad"><b>${t.id}</b> ${t.ad}</span>
        </button>`).join("")}
    </div>
    <table class="tablo" style="margin-bottom:16px">
      <tr><th>Kasa no</th><td><input id="kasa-no" value="${kac("", DB.ayarOku("kasaNo", "1"))}" style="width:80px;height:32px"> <button class="btn" id="kasa-kaydet">Kaydet</button></td></tr>
    </table>
    ${markaBolumu()}
    ${aktifKullanici.rol === "yonetici" ? `
      <div class="baslik-satir"><h2>Kategori</h2></div>
      <div class="ayar-kutular">
        <button class="ayar-kutu" id="ayar-kategori"><strong>Kategori ayarları</strong><small>Kasadaki kategori butonlarını ekle, düzenle, sil</small></button>
        <button class="ayar-kutu" id="ayar-ekstre"><strong>Ekstre tasarımı</strong><small>Cari hesap ekstresinin ve detaylı ekstrenin görünümünü düzenle</small></button>
      </div>` : ""}
    ${aktifKullanici.rol === "yonetici" ? `
      <div class="baslik-satir"><h2>Lisans</h2></div>
      <div class="filtre" style="margin-bottom:16px">
        <span id="lisans-ozet">Yükleniyor...</span>
        <button class="btn" id="lisans-degistir">Lisans anahtarını değiştir</button>
      </div>
      <div class="baslik-satir"><h2>Güncelleme</h2></div>
      <div class="filtre" style="margin-bottom:8px">
        <span id="ayar-surum">Sürüm</span>
        <button class="btn" id="guncelle-kontrol">Güncellemeleri denetle</button>
      </div>
      ` : ""}
    <div class="baslik-satir"><h2>Veri</h2></div>
    <div class="filtre">
      <button class="btn" id="yedek-al">Yedek al (JSON)</button>
      <label class="btn" style="cursor:pointer">Yedekten yükle<input id="yedek-yukle" type="file" accept="application/json" hidden></label>
      <button class="btn tehlike" id="sifirla">Deneme verilerini sıfırla</button>
    </div>`;
  $("s-ayar").querySelectorAll("[data-tema]").forEach(b => b.addEventListener("click", () => { temaSec(b.dataset.tema); ayarCiz(); }));
  $("kasa-kaydet").addEventListener("click", () => { DB.ayarYaz("kasaNo", $("kasa-no").value.trim() || "1"); bildir("Kasa no kaydedildi"); });
  if ($("ayar-kategori")) $("ayar-kategori").addEventListener("click", kategoriPaneliAc);
  if ($("ayar-ekstre")) $("ayar-ekstre").addEventListener("click", () => ekstreTasarimiAc({}));
  markaOlaylari();
  if ($("lisans-ozet")) {
    lisansBilgisi().then(l => {
      if (!l || !$("lisans-ozet")) return;
      $("lisans-ozet").textContent = l.deneme ? "Deneme sürümü · " + l.kalanGun + " gün kaldı"
        : (l.isletme ? l.isletme + " · " : "") + "Lisans aktif" + (l.bitis ? " · bitiş: " + l.bitis + (l.kalanGun != null ? " (" + l.kalanGun + " gün)" : "") : "");
    });
    $("lisans-degistir").addEventListener("click", async () => {
      const anahtar = prompt("Yeni lisans anahtarını girin:");
      if (!anahtar) return;
      try {
        const s = await (await fetch("/api/lisans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ anahtar: anahtar.trim() }) })).json();
        bildir(s.ok ? "Lisans etkinleştirildi" : "Lisans: " + s.hata);
        if (s.ok) ayarCiz();
      } catch (e) { bildir("Sunucuya ulaşılamadı"); }
    });
  }
  if ($("guncelle-kontrol")) {
    surumuGoster($("ayar-surum"));
    $("guncelle-kontrol").addEventListener("click", () => guncellemeKontrolu(false));
  }
  $("yedek-al").addEventListener("click", () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([DB.disaAktar()], { type: "application/json" }));
    a.download = "perakende-yedek.json";
    a.click();
  });
  $("yedek-yukle").addEventListener("change", async e => {
    const dosya = e.target.files[0];
    if (!dosya || !confirm("Mevcut veri yedekle değiştirilecek. Devam edilsin mi?")) return;
    DB.iceAktar(await dosya.text());
    bildir("Yedek yüklendi, yeniden giriş yapın");
    cikis();
  });
  $("sifirla").addEventListener("click", async () => {
    if (DB.sunucuVarMi()) {
      if (aktifKullanici.rol !== "yonetici") return bildir("Yalnızca yönetici sıfırlayabilir");
      const onay = prompt("DENEME VERİLERİNİ SIFIRLA. Tüm ürünler, kategoriler, stoklar, satış fişleri, müşteriler ve cari kayıtlar silinir. Kullanıcılar ve ayarlar kalır. Önce otomatik yedek alınır. Onaylamak için SIFIRLA yazın:");
      if (onay !== "SIFIRLA") return onay === null ? null : bildir("Onay metni yanlış, sıfırlanmadı");
      try {
        const yanit = await (await fetch("/api/deneme-sifirla", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + (DB.token() || "") }, body: JSON.stringify({ onay }) })).json();
        if (!yanit.ok) return bildir("Sıfırlanamadı: " + yanit.hata);
      } catch (e) { return bildir("Sıfırlanamadı: sunucuya ulaşılamadı"); }
      DB.sifirla();
      try { localStorage.removeItem("kasaSatisSekmeleri"); } catch (e) { /* önemli değil */ }
      return location.reload();
    }
    if (!confirm("Bu tarayıcıdaki tüm veriler silinecek. Bu işlem geri alınamaz.")) return;
    DB.sifirla();
    location.reload();
  });
}

// ---------- BAŞLATMA ----------
async function baslat() {
  // Sunucu oturumu varsa veriyi sunucudan al, yoksa yerel örnek veriyi hazırla
  const sunucudanYuklendi = await DB.yukle();
  let sunucuYanitVeriyor = sunucudanYuklendi;
  if (!sunucudanYuklendi) {
    sunucuYanitVeriyor = await DB.sunucuErisilebilir();
    // Sunucu varsa ama oturum geçersizse yeniden giriş gerekir. Yerel kopya sunucu yerine kullanılmaz.
    if (sunucuYanitVeriyor) sessionStorage.removeItem("oturum");
    else await tohumla();
  }

  // Oturum süresi dolarsa kayıtlar tarayıcıda saklanır, giriş yapılınca sunucuya işlenir
  DB.onOturumDustu = () => {
    bildir("Oturum süresi doldu. Kayıtlar saklandı, tekrar giriş yapın");
    cikis();
  };

  // Başka cihaz veriyi değiştirirse ekranı güncel veriyle yeniden çiz
  DB.onCakisma = () => {
    bildir("Veri başka bir cihazda değişti, güncellendi");
    if (aktifKullanici) {
      aktifKullanici = DB.bul("kullanicilar", x => x.id === aktifKullanici.id) || aktifKullanici;
      sayfaGoster(aktifSayfa);
    }
  };

  // Uygulama açılınca yeni sürüm varsa güncellensin mi diye sorulur (güncelleme sonrası açılış)
  markayiYukle();
  surumuGoster($("surum-yazi"));
  guncellemeKontrolu(true);
  guncellemeDenetimiBaslat();

  // Kayıtlı oturum varsa doğrudan kasa, yoksa giriş ekranı (animasyon girişten sonra oynar)
  const oturum = sessionStorage.getItem("oturum");
  const kayitliKullanici = oturum && DB.bul("kullanicilar", x => x.id === Number(oturum) && x.aktif);
  if (kayitliKullanici) { aktifKullanici = kayitliKullanici; oturumAc(false); }
  else { await girisEkraniHazirla(); $("giris").classList.remove("gizli"); }

  $("musteri-ara").addEventListener("click", musteriAra);
  // Üstteki müşteri kutusu: tıklayınca müşteri seçilir, × ile kaldırılır
  $("musteri-chip").addEventListener("click", e => {
    if (e.target.closest("#musteri-temizle")) {
      seciliMusteriId = null;
      kasaMusteriDurumu();
      return;
    }
    musteriAra();
  });
  // Satış sekmeleri: geçiş, yeni satış (+) ve kapatma
  $("satis-sekmeleri").addEventListener("click", e => {
    const kapat = e.target.closest("[data-kapat]");
    if (kapat) return sekmeKapat(Number(kapat.dataset.kapat));
    if (e.target.closest("#yeni-satis")) return yeniSatis();
    const sek = e.target.closest("[data-sek]");
    if (sek) sekmeyeGec(Number(sek.dataset.sek));
  });
  // Barkod / arama kutusuna tıklanınca ürün paneli yarım açılır
  $("arama").addEventListener("focus", () => { if (!sessizOdak && !fiyatModu) urunPaneli($("arama").value.trim()); });
  $("arama").addEventListener("click", () => {
    if (!fiyatModu && !$("cekmece").classList.contains("acik")) urunPaneli($("arama").value.trim());
  });
  $("fiyat-gor").addEventListener("click", () => fiyatKutusuAc(!fiyatModu));
  $("fiyat-kutu-kapat").addEventListener("click", () => fiyatKutusuAc(false));
  $("cekmece-kapat").addEventListener("click", urunPaneliKapat);
  document.addEventListener("keydown", e => { if (e.key === "Escape") { urunPaneliKapat(); kategoriPaneliKapat(); } });
  $("kat-kapat").addEventListener("click", kategoriPaneliKapat);
  $("kat-yeni").addEventListener("click", () => kategoriFormu());
  $("kat-liste").addEventListener("click", e => {
    const u = e.target.closest("[data-kat-urun]");
    if (u) return kategoriyeUrunEkle(Number(u.dataset.katUrun));
    const d = e.target.closest("[data-kat-duzenle]");
    if (d) return kategoriFormu(Number(d.dataset.katDuzenle));
    const s = e.target.closest("[data-kat-sil]");
    if (s) kategoriSil(Number(s.dataset.katSil));
  });
  // Arama yalnızca listeyi süzer. Açık formu (ürün ekle, düzenle, stok, cari) silmez ve seçimi bozmaz.
  $("c-ara").addEventListener("input", cekmeceListele);
  // Enter: tek sonuç varsa (ör. barkod okutunca) o satıra tıklanmış gibi davranır
  $("c-ara").addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const sonuclar = document.querySelectorAll("#c-liste [data-cid], #c-liste [data-mid]");
    if (sonuclar.length === 1) sonuclar[0].click();
  });
  $("c-liste").addEventListener("click", e => {
    // Cari güncelle sekmesinde listeden müşteri seçilir
    const m = e.target.closest("[data-mid]");
    if (m) {
      cekmeceMusteri = DB.bul("musteriler", x => x.id === Number(m.dataset.mid)) || null;
      cekmeceListele();
      cekmeceIcerigi();
      return;
    }
    const b = e.target.closest("[data-cid]");
    if (!b) return;
    const urun = DB.bul("urunler", x => x.id === Number(b.dataset.cid));
    // Düzenle, stok veya barkod sekmesi açıksa (ya da kasa dışındaki bir sayfadaysak) ürün seçilir, aksi halde sepete eklenir
    if (["duzenle", "stok", "barkod"].includes(cekmeceSekme) || aktifSayfa !== "kasa") {
      if (!cekmeceSekme) cekmeceSekme = "duzenle";
      cekmeceSecili = urun;
      cekmeceListele();
      cekmeceIcerigi();
      return;
    }
    if (urun && urun.aktif) {
      sepeteEkle(urun.id);
      bildir(urun.ad + " sepete eklendi");
    } else {
      bildir("Bu ürün pasif");
    }
  });
  // Sekmeye tekrar basınca seçim kalkar ve liste sepete ekleme moduna döner
  document.querySelectorAll(".sekme").forEach(b => b.addEventListener("click", () => {
    cekmeceSekme = cekmeceSekme === b.dataset.sekme ? "" : b.dataset.sekme;
    cekmeceListele(); // Cari güncelle sekmesinde liste müşteri olur
    cekmeceIcerigi();
  }));

  $("giris-form").addEventListener("submit", girisYap);
  girisDoldur();
  $("g-kayit-ac").addEventListener("click", () => kayitEkraniGoster(true));
  $("kt-geri").addEventListener("click", () => kayitEkraniGoster(false));
  $("kayit-form").addEventListener("submit", kayitOl);
  $("kurulum-form").addEventListener("submit", kurulumYap);
  $("lisans-form").addEventListener("submit", lisansEtkinlestir);
  // Lisans giriş yapılmışken biterse oturum kapanır ve kilit ekranı açılır
  DB.onLisans = async () => { const l = await lisansBilgisi(); cikis(); lisansEkraniGoster(l && l.neden); };
  setInterval(async () => {
    if (!aktifKullanici) return;
    const l = await lisansBilgisi();
    if (l && !l.gecerli) DB.onLisans();
  }, 10 * 60 * 1000);
  $("cikis").addEventListener("click", cikis);
  document.querySelectorAll("#menu button").forEach(b => b.addEventListener("click", () => sayfaGoster(b.dataset.sayfa)));

  // Tema
  document.body.className = "tema-" + DB.ayarOku("tema", "1");
  temaListesiCiz();
  $("tema-dugme").addEventListener("click", e => { e.stopPropagation(); temaListesiAc($("tema-liste").hidden); });
  $("tema-liste").addEventListener("click", e => {
    const oge = e.target.closest("[data-tema-sec]");
    if (!oge) return;
    temaSec(oge.dataset.temaSec);
    temaListesiAc(false);
    if (aktifSayfa === "ayar") ayarCiz(); // Ayarlar sayfasındaki seçili kart güncellensin
  });
  document.addEventListener("click", e => { if (!e.target.closest(".tema-menu")) temaListesiAc(false); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") temaListesiAc(false); });

  // Kasa olayları
  $("arama").addEventListener("input", kasaUrunleriCiz);
  $("arama").addEventListener("keydown", e => {
    if (e.key === "Enter") barkodIsle(e.target.value.trim());
  });
  document.addEventListener("keydown", e => { if (e.key === "F4" && $("fiyat-gor")) { e.preventDefault(); fiyatKutusuAc(!fiyatModu); } });
  document.addEventListener("keydown", e => { if (e.key === "F2") { e.preventDefault(); $("arama").focus(); } });
  $("urun-listesi").addEventListener("click", e => {
    const b = e.target.closest("[data-urun]");
    if (b) sepeteEkle(Number(b.dataset.urun));
  });
  $("kategoriler").addEventListener("click", e => {
    const b = e.target.closest("[data-kat]");
    if (!b) return;
    seciliKategori = b.dataset.kat;
    kasaUrunleriCiz();
  });
  $("satirlar").addEventListener("click", e => {
    const a = e.target.closest("[data-fark]");
    if (a) return adetDegistir(Number(a.dataset.id), Number(a.dataset.fark));
    const s = e.target.closest("[data-sil]");
    if (s) { sepet = sepet.filter(x => x.id !== Number(s.dataset.sil)); sepetiCiz(); }
  });
  $("odeme-ac").addEventListener("click", () => {
    if (sepet.length === 0) return bildir("Sepet boş");
    $("odeme-toplam").textContent = para(genelToplam());
    $("odeme-panel").style.display = "flex";
  });
  $("odeme-kapat").addEventListener("click", panelKapat);
  document.querySelectorAll("[data-yontem]").forEach(b => b.addEventListener("click", () => satisTamamla(b.dataset.yontem)));
  $("musteri-kapat").addEventListener("click", () => { panelKapat(); $("odeme-panel").style.display = "flex"; });
  $("musteri-onay").addEventListener("click", () => {
    const id = Number($("musteri-sec").value);
    kaydetSatis("acik_hesap", id);
  });
  $("fis-iptal").addEventListener("click", () => {
    if (sepet.length === 0) return bildir("İptal edilecek sepet yok");
    if (!confirm("Mevcut sepet iptal edilsin mi? İptal fişi olarak kaydedilir.")) return;
    const kayit = sepetIptalKaydet("Sepet iptali");
    sepet = [];
    indirim = { tur: "yuzde", deger: 0 };
    seciliMusteriId = null;
    kasaCiz();
    bildir(kayit.fis_no + " iptal olarak kaydedildi");
  });
  $("indirim").addEventListener("click", indirimSor);

  // Modal dışına tıklayınca kapat
  $("modal").addEventListener("click", e => { if (e.target === $("modal")) modalKapat(); });
}

document.addEventListener("DOMContentLoaded", baslat);
