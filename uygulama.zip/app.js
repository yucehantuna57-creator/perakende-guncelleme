// ---------- Yardımcılar ----------
const $ = id => document.getElementById(id);
const para = n => Number(n || 0).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " TL";
const sayi = n => Number(n || 0).toLocaleString("tr-TR", { maximumFractionDigits: 3 });
const tarih = iso => new Date(iso).toLocaleString("tr-TR", { dateStyle: "short", timeStyle: "short" });
const kac = (alan, deger) => String(deger ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

function bildir(mesaj) {
  const b = $("bildirim");
  b.textContent = mesaj;
  b.classList.add("acik");
  clearTimeout(bildir.t);
  bildir.t = setTimeout(() => b.classList.remove("acik"), 1800);
}

function modalAc(html, genis) {
  // genis: true → geniş pencere, "cok" → ekranın büyük kısmını kaplayan (tasarım ekranı)
  $("modal-icerik").classList.toggle("genis", genis === true);
  $("modal-icerik").classList.toggle("cok-genis", genis === "cok");
  $("modal-icerik").innerHTML = html;
  $("modal").style.display = "flex";
}
// Küçük uygulama içi pencere: metin sorar ya da onay ister. Sonuç: girdi metni / true (onay) / null (vazgeç)
function kucukPencere({ baslik, mesaj, girdi, yer, evet, hayir, bos, deger, sayisal }) {
  return new Promise(coz => {
    const kap = document.createElement("div");
    kap.className = "kp-kaplama";
    kap.innerHTML = `<div class="kp-kutu" role="dialog"><div class="kp-baslik">${kac("", baslik || "")}</div>${mesaj ? `<div class="kp-mesaj">${kac("", mesaj)}</div>` : ""}${girdi ? `<input class="kp-girdi" placeholder="${kac("", yer || "")}" value="${kac("", deger || "")}"${sayisal ? ' inputmode="decimal"' : ""} autocomplete="off">` : ""}<div class="kp-dugmeler"><button type="button" class="btn" data-kp="hayir">${kac("", hayir || "Vazgeç")}</button><button type="button" class="btn ana" data-kp="evet">${kac("", evet || "Tamam")}</button></div></div>`;
    document.body.appendChild(kap);
    const input = kap.querySelector(".kp-girdi");
    const bitir = s => { kap.remove(); coz(s); };
    const tamam = () => bitir(girdi ? ((input.value || "").trim() || (bos ? "" : null)) : true);
    kap.addEventListener("click", e => { const b = e.target.closest("[data-kp]"); if (b) return b.dataset.kp === "evet" ? tamam() : bitir(null); if (e.target === kap) bitir(null); });
    kap.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); tamam(); } else if (e.key === "Escape") bitir(null); });
    (input || kap.querySelector('[data-kp="evet"]')).focus();
    if (input && deger) input.select();
  });
}
// Stoktan ürün seçme penceresi (fatura satırını stoktaki bir ürünle eşleştirmek için). Sonuç: ürün numarası / null
function urunAraPenceresi(baslangic) {
  return new Promise(coz => {
    const kap = document.createElement("div");
    kap.className = "kp-kaplama";
    kap.innerHTML = `<div class="kp-kutu" style="width:min(640px,100%)"><div class="kp-baslik">Stoktan ürün seç</div><input class="kp-girdi" placeholder="Ürün adı veya barkod ara" autocomplete="off" value="${kac("", baslangic || "")}"><div class="kp-liste"></div><div class="kp-dugmeler"><button type="button" class="btn" data-kp="hayir">Vazgeç</button></div></div>`;
    document.body.appendChild(kap);
    const input = kap.querySelector(".kp-girdi"), liste = kap.querySelector(".kp-liste");
    const bitir = s => { kap.remove(); coz(s); };
    const ciz = () => {
      const q = trKucuk(input.value.trim());
      const l = DB.liste("urunler", u => u.aktif && (!q || trKucuk(u.ad).includes(q) || String(u.barkod || "").includes(q))).sort((x, y) => String(x.ad).localeCompare(String(y.ad), "tr")).slice(0, 60);
      liste.innerHTML = l.map(u => `<button type="button" class="kp-urun" data-id="${u.id}"><span>${kac("", u.ad)}<small>${kac("", u.barkod)} · stok ${sayi(u.stok)}</small></span><b>${para(u.satis_fiyati)}</b></button>`).join("") || '<div class="kp-bos">Eşleşen ürün yok</div>';
    };
    input.addEventListener("input", ciz);
    kap.addEventListener("click", e => { const b = e.target.closest("[data-id]"); if (b) return bitir(Number(b.dataset.id)); if (e.target.closest('[data-kp="hayir"]') || e.target === kap) bitir(null); });
    kap.addEventListener("keydown", e => { if (e.key === "Escape") bitir(null); else if (e.key === "Enter") { const ilk = liste.querySelector("[data-id]"); if (ilk) bitir(Number(ilk.dataset.id)); } });
    ciz(); input.focus(); input.select();
  });
}
function modalKapat() {
  $("modal").style.display = "none";
}

// ---------- Oturum ----------
let aktifKullanici = null;
const ROL_YETKI = { yonetici: ["kasa", "fis", "stok", "urunler", "fatura", "musteri", "rapor", "kullanici", "ayar"], kasiyer: ["kasa", "fis", "musteri", "ayar"] };

// Örnek veri yoktur: yeni kurulum boş başlar, ilk kurulum ekranı yönetici hesabını oluşturur.
async function tohumla() {}

// Stok menüsünde kritik veya eksi stoktaki ürün sayısı kırmızı rozetle görünür
function menuRozetleri() {
  const dugme = document.querySelector('#menu [data-sayfa="stok"]');
  if (!dugme) return;
  const kritik = DB.liste("urunler", u => u.aktif && u.stok <= u.kritik_stok).length;
  let rozet = dugme.querySelector(".rozet-sayi");
  if (!kritik) { if (rozet) rozet.remove(); return; }
  if (!rozet) {
    rozet = document.createElement("span");
    rozet.className = "rozet-sayi";
    dugme.appendChild(rozet);
  }
  rozet.textContent = kritik;
  rozet.title = `${kritik} ürün kritik veya eksi stokta`;
}

function yetkiUygula() {
  const izinli = ROL_YETKI[aktifKullanici.rol];
  document.querySelectorAll("#menu button").forEach(b => {
    b.style.display = izinli.includes(b.dataset.sayfa) ? "" : "none";
  });
  const rolAdi = aktifKullanici.rol === "yonetici" ? "Yönetici" : "Satış";
  $("kim").innerHTML = `<span class="avatar">${kac("", aktifKullanici.ad_soyad.trim().charAt(0).toLocaleUpperCase("tr"))}</span>
    <span class="kim-metin"><span class="kim-ad">${kac("", aktifKullanici.ad_soyad)}</span><span class="kim-rol">${rolAdi}</span></span>`;
  menuRozetleri();
}

// "Beni hatırla": kullanıcı adı ve şifre bu bilgisayarda saklanır, giriş ekranında hazır gelir
function girisDoldur() {
  try {
    const k = JSON.parse(localStorage.getItem("girisHatirla") || "null");
    $("g-hatirla").checked = !!k || localStorage.getItem("girisHatirlaKapali") !== "1";
    if (k) { $("g-kadi").value = k.k || ""; $("g-sifre").value = atob(k.s || ""); }
  } catch (e) { /* kayıt okunamazsa alanlar boş kalır */ }
}
function girisKaydet(kadi, sifre) {
  try {
    if ($("g-hatirla").checked) { localStorage.setItem("girisHatirla", JSON.stringify({ k: kadi, s: btoa(sifre) })); localStorage.removeItem("girisHatirlaKapali"); }
    else { localStorage.removeItem("girisHatirla"); localStorage.setItem("girisHatirlaKapali", "1"); }
  } catch (e) { /* saklanamazsa giriş yine çalışır */ }
}

// Geliştirici paneli: yalnızca geliştirici lisansıyla etkinleştirilmiş kurulumda VE o lisansta tanımlı kullanıcı adıyla
// giriş yapılmışsa görünür (müşterilerin kurulumunda ve diğer kullanıcılarda hiç çıkmaz). Anahtar üretmek için ayrıca üretici parolası gerekir.
const LISANS_URET_ADRES = "https://dbpbssdrwolssrdaypzw.supabase.co/rest/v1/rpc/lisans_uret";
const LISANS_URET_ANAHTAR = "sb_publishable_XHbSoSAa11HFP9AAEM3esQ_ziAMPbqX";
function geliştiriciPaneliGoster(l) {
  if (!l || !l.gelistirici || !l.gelistiriciKullanici || !aktifKullanici || aktifKullanici.rol !== "yonetici") return;
  if (String(aktifKullanici.kullanici_adi).trim().toLowerCase() !== String(l.gelistiriciKullanici).trim().toLowerCase()) return;
  if ($("gel-panel")) return;
  let gecmis = [];
  try { gecmis = JSON.parse(localStorage.getItem("lisansGecmis") || "[]"); } catch (e) { /* liste boş başlar */ }
  const kutu = document.createElement("div");
  kutu.id = "gel-panel";
  kutu.innerHTML = `
    <div class="baslik-satir"><h2>Geliştirici paneli · Lisans üret</h2></div>
    <div class="gel-kart">
      <div class="gel-satir"><input id="gel-isletme" placeholder="İşletme adı (örn. Ali Market)" autocomplete="off"><input id="gel-gun" type="number" min="1" value="365" aria-label="Gün"></div>
      <div class="gel-gunler">${[[30, "30 gün"], [90, "3 ay"], [180, "6 ay"], [365, "1 yıl"], [730, "2 yıl"]].map(([g, ad]) => `<button type="button" class="btn kucuk" data-gel-gun="${g}">${ad}</button>`).join("")}</div>
      <input id="gel-parola" type="password" placeholder="Üretici parolası" autocomplete="off">
      <button class="btn ana" id="gel-uret">Anahtar üret</button>
      <div class="hata" id="gel-hata"></div>
      <div id="gel-sonuc" class="gel-sonuc" hidden>
        <div class="gel-isletme" id="gel-s-isletme"></div><div class="gel-anahtar" id="gel-s-anahtar"></div><div class="gel-bitis" id="gel-s-bitis"></div>
        <button class="btn kucuk" id="gel-kopya">Anahtarı kopyala</button>
      </div>
      <div class="gel-liste" id="gel-liste"></div>
    </div>`;
  $("s-ayar").appendChild(kutu);
  lisansListesiEkle(kutu);
  const listeCiz = () => { $("gel-liste").innerHTML = gecmis.length ? "<small>Bu bilgisayardan üretilenler</small>" + gecmis.map(g => `<div><span>${kac("", g.isletme)}</span><span><b>${kac("", g.anahtar)}</b> · ${kac("", g.bitis)}</span></div>`).join("") : ""; };
  listeCiz();
  kutu.querySelectorAll("[data-gel-gun]").forEach(b => b.addEventListener("click", () => { $("gel-gun").value = b.dataset.gelGun; }));
  $("gel-uret").addEventListener("click", async () => {
    $("gel-hata").textContent = ""; $("gel-sonuc").hidden = true;
    const isletme = $("gel-isletme").value.trim(), gun = parseInt($("gel-gun").value, 10), parola = $("gel-parola").value;
    if (!isletme) return ($("gel-hata").textContent = "İşletme adını yazın");
    if (!(gun >= 1)) return ($("gel-hata").textContent = "Gün sayısı en az 1 olmalı");
    if (!parola) return ($("gel-hata").textContent = "Üretici parolasını yazın");
    $("gel-uret").disabled = true;
    try {
      const y = await fetch(LISANS_URET_ADRES, { method: "POST", headers: { apikey: LISANS_URET_ANAHTAR, "Content-Type": "application/json" }, body: JSON.stringify({ p_parola: parola, p_isletme: isletme, p_gun: gun }) });
      const r = await y.json();
      if (!y.ok || !r.ok) throw new Error(r.hata || r.message || "Üretilemedi");
      $("gel-s-isletme").textContent = r.isletme; $("gel-s-anahtar").textContent = r.anahtar; $("gel-s-bitis").textContent = "Geçerlilik bitişi: " + r.bitis;
      $("gel-sonuc").hidden = false;
      gecmis.unshift({ isletme: r.isletme, anahtar: r.anahtar, bitis: r.bitis });
      try { localStorage.setItem("lisansGecmis", JSON.stringify(gecmis.slice(0, 50))); } catch (e) { /* saklanamazsa liste yalnızca bu oturumda kalır */ }
      listeCiz();
    } catch (e) { $("gel-hata").textContent = e.message; }
    $("gel-uret").disabled = false;
  });
  $("gel-kopya").addEventListener("click", async () => { try { await navigator.clipboard.writeText($("gel-s-anahtar").textContent); bildir("Anahtar kopyalandı"); } catch (e) { /* kopyalanamadı */ } });
}

// Giriş kapısı: önce lisans, sonra ilk kurulum, sonra normal giriş. Hangi formun görüneceğini belirler.
const GIRIS_FORMLARI = ["giris-form", "kayit-form", "kurulum-form", "lisans-form"];
function girisFormuGoster(ad) { GIRIS_FORMLARI.forEach(f => $(f).classList.toggle("gizli", f !== ad)); }
async function lisansBilgisi() { try { return await (await fetch("/api/lisans", { cache: "no-store" })).json(); } catch (e) { return null; } }
const LISANS_MESAJLARI = {
  "deneme-bitti": "Deneme süresi doldu. Devam etmek için lisans anahtarınızı girin.",
  "sure-doldu": "Lisans süreniz doldu. Yenilemek için satıcınızla iletişime geçin, yeni anahtarınız varsa girin.",
  "iptal": "Bu lisans kapatılmış. Satıcınızla iletişime geçin.",
  "dogrulanmadi": "Lisans doğrulanamadı. İnternet bağlantınızı kontrol edip anahtarınızı girin.",
  "baglanti": "Lisans uzun süredir doğrulanamadı. İnternete bağlanıp anahtarınızı tekrar girin."
};
function lisansEkraniGoster(neden) {
  $("giris").classList.remove("gizli");
  $("uygulama").classList.add("gizli");
  $("li-mesaj").textContent = LISANS_MESAJLARI[neden] || "Bu uygulamayı kullanmak için lisans anahtarı gerekli.";
  $("li-hata").textContent = "";
  girisFormuGoster("lisans-form");
}
async function girisEkraniHazirla() {
  const l = await lisansBilgisi();
  if (l && !l.gecerli) return lisansEkraniGoster(l.neden);
  let gerekli = false;
  try {
    const k = await (await fetch("/api/kurulum", { cache: "no-store" })).json();
    gerekli = k.gerekli;
    // Bu bilgisayarda zaten yönetici varsa kayıt ekranında "Yönetici" seçeneği gösterilmez
    const yon = document.querySelector('input[name="kt-rol"][value="yonetici"]');
    if (yon) { yon.closest("label").hidden = !!k.yoneticiVar; if (k.yoneticiVar) document.querySelector('input[name="kt-rol"][value="kasiyer"]').checked = true; }
  } catch (e) { /* sunucu yoksa normal giriş */ }
  girisFormuGoster(gerekli ? "kurulum-form" : "giris-form");
  const sonra = $("giris-form");
  if (!gerekli && l && l.deneme && l.kalanGun != null && !$("deneme-not")) {
    const n = document.createElement("div");
    n.id = "deneme-not"; n.className = "kurulum-not"; n.textContent = "Deneme sürümü: " + l.kalanGun + " gün kaldı";
    sonra.insertBefore(n, $("g-hata"));
  }
}
async function kurulumYap(e) {
  e.preventDefault();
  if ($("ku-sifre").value !== $("ku-sifre2").value) { $("ku-hata").textContent = "Şifreler aynı değil"; return; }
  const govde = { isletme: $("ku-isletme").value.trim(), ad: $("ku-ad").value.trim(), kadi: $("ku-kadi").value.trim(), sifre: $("ku-sifre").value };
  try {
    const yanit = await fetch("/api/kurulum", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(govde) });
    const s = await yanit.json();
    if (!s.ok) { if (s.lisans) return lisansEkraniGoster(s.neden); $("ku-hata").textContent = s.hata; return; }
  } catch (err) { $("ku-hata").textContent = "Sunucuya ulaşılamadı"; return; }
  girisFormuGoster("giris-form");
  $("g-kadi").value = govde.kadi; $("g-sifre").value = govde.sifre;
  $("giris-form").requestSubmit();
}
let lisansliGiris = false; // "Lisanslı giriş yap" bağlantısından geldiyse lisanstan sonra hesaplar buluttan alınır
async function lisansEtkinlestir(e) {
  e.preventDefault();
  $("li-hata").textContent = "";
  try {
    const yanit = await fetch("/api/lisans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ anahtar: $("li-anahtar").value.trim(), esitle: lisansliGiris }) });
    const s = await yanit.json();
    if (!s.ok) { $("li-hata").textContent = s.hata; return; }
    if (lisansliGiris) { bildir(s.esitleme ? "Lisans etkinleştirildi, hesaplar alındı. Şimdi giriş yapabilirsiniz." : "Lisans etkinleştirildi. Hesaplar alınamadıysa biraz bekleyip tekrar deneyin.", 5000); lisansliGiris = false; }
  } catch (err) { $("li-hata").textContent = "Sunucuya ulaşılamadı"; return; }
  $("li-anahtar").value = "";
  // Kayıt lisans yüzünden yapılamadıysa şimdi tamamlanır ve giriş yapılır
  if (bekleyenKayit) {
    const govde = bekleyenKayit; bekleyenKayit = null;
    try {
      const k = await kayitGonder(govde);
      if (k.ok) { girisFormuGoster("giris-form"); $("g-kadi").value = govde.kadi; $("g-sifre").value = govde.sifre; $("giris-form").requestSubmit(); return; }
      girisFormuGoster("giris-form"); $("g-hata").textContent = "Kayıt tamamlanamadı: " + k.hata; return;
    } catch (err) { /* normal akışa düş */ }
  }
  await girisEkraniHazirla();
  const oturum = DB.token();
  if (oturum && aktifKullanici) { $("giris").classList.add("gizli"); $("uygulama").classList.remove("gizli"); }
}

// Kayıt ol: sunucuda "Satış" kullanıcısı oluşturur, ardından aynı bilgilerle giriş yapar
function kayitEkraniGoster(ac) {
  girisFormuGoster(ac ? "kayit-form" : "giris-form");
  $("kt-hata").textContent = "";
  if (ac) $("kt-ad").focus();
}
let bekleyenKayit = null;
async function kayitGonder(govde) {
  const yanit = await (await fetch("/api/kayit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(govde) })).json();
  return yanit;
}
async function kayitOl(e) {
  e.preventDefault();
  const ad = $("kt-ad").value.trim(), kadi = $("kt-kadi").value.trim(), sifre = $("kt-sifre").value;
  if (sifre !== $("kt-sifre2").value) { $("kt-hata").textContent = "Şifreler aynı değil"; return; }
  try {
    const govde = { ad, kadi, sifre };
    const yanit = await kayitGonder(govde);
    if (!yanit.ok) { if (yanit.lisans) { bekleyenKayit = govde; const l = await lisansBilgisi(); return lisansEkraniGoster(l && l.neden); } $("kt-hata").textContent = yanit.hata; return; }
  } catch (err) { $("kt-hata").textContent = "Sunucuya ulaşılamadı"; return; }
  kayitEkraniGoster(false);
  $("g-kadi").value = kadi; $("g-sifre").value = sifre;
  $("giris-form").requestSubmit();
}

async function girisYap(e) {
  e.preventDefault();
  const kadi = $("g-kadi").value.trim();
  const sifre = $("g-sifre").value;
  let k = null;
  const sunucu = await DB.sunucuGirisi(kadi, sifre);
  if (sunucu && !sunucu.ok) {
    if (sunucu.lisans) { const l = await lisansBilgisi(); return lisansEkraniGoster(l && l.neden); }
    $("g-hata").textContent = sunucu.hata; return;
  }
  if (sunucu && sunucu.ok) {
    await DB.yukle();
    k = DB.bul("kullanicilar", x => x.id === sunucu.kullanici.id);
  } else {
    // Sunucu yoksa yerel kopya ile giriş
    const ozet = await sifreOzeti(sifre);
    k = DB.bul("kullanicilar", x => String(x.kullanici_adi || "").trim().toLowerCase() === kadi.toLowerCase() && x.sifre_hash === ozet && x.aktif);
  }
  if (!k) { $("g-hata").textContent = "Kullanıcı adı veya şifre hatalı"; return; }
  $("g-hata").textContent = "";
  girisKaydet(kadi, sifre);
  $("g-sifre").value = "";
  aktifKullanici = k;
  sessionStorage.setItem("oturum", String(k.id));
  oturumAc(true);
}

// Şifre girildikten sonra açılış animasyonu oynar, ardından kasa ekranı açılır.
// Sayfa yenilenince kayıtlı oturum varsa animasyon atlanır.
// Onarım: açık hesap ödemesi olan ama müşterinin carisine borcu yazılmamış satışlar (1.0.98 öncesi kayıt çakışmasında
// borç kaydı atılabiliyordu). Eksik borç satışın kendi tarihiyle yazılır; her girişte çalışır, düzgün kayıtlara dokunmaz.
function eksikCariBorclariniOnar() {
  let n = 0;
  // Telefon satışları (kasa no "M…") hariç: onların borcu buluttan ayrıca gelir, burada yazılırsa iki kez sayılabilir
  DB.liste("satislar", s => s.durum === "tamamlandi" && !s.iade && s.musteri_id && !String(s.kasa_no || "").startsWith("M")).forEach(s => {
    const acik = DB.liste("odemeler", o => o.satis_id === s.id && o.yontem === "acik_hesap").reduce((t, o) => t + Number(o.tutar || 0), 0);
    if (!(acik > 0.005) || DB.bul("cari_hareketler", h => h.satis_id === s.id && h.tur === "borc")) return;
    DB.ekle("cari_hareketler", { musteri_id: s.musteri_id, tur: "borc", tutar: Math.round(acik * 100) / 100, satis_id: s.id, aciklama: s.fis_no + " (onarıldı)", islem: "satis", yontem: null, kullanici_id: s.kullanici_id || null, tarih: s.tarih });
    n++;
  });
  if (n) bildir(n + " açık hesap satışı müşteri carisine işlendi (eksik kayıt onarıldı)", 6000);
}

// Onarım: eski sürümlerdeki numara çakışmasından kalan, aynı numaralı iki müşteri/ürün/kategori.
// Seçilen müşteri başka bir müşteri olarak görünüyordu (ör. İbrahim Altuner → "deneme 1"). İlk kayıt numarasını korur,
// sonrakiler yeni numara alır. Eski hareketler ilk kayıtta kalır; etkilenenler yöneticiye bildirilir.
function ciftNumaralariOnar() {
  const v = DB.veri(), duzelen = [];
  for (const t of ["musteriler", "urunler", "kategoriler"]) {
    const gorulen = new Set();
    let enBuyuk = Math.max(0, ...(v[t] || []).map(x => x.id).filter(n => n < 1e9), (v.sayac || {})[t] < 1e9 ? v.sayac[t] : 0);
    (v[t] || []).forEach(x => {
      if (!gorulen.has(x.id)) return gorulen.add(x.id);
      const ilk = v[t].find(y => y.id === x.id);
      x.id = ++enBuyuk;
      duzelen.push((x.ad_soyad || x.ad) + " (aynı numaradaki: " + (ilk.ad_soyad || ilk.ad) + ")");
    });
    if (enBuyuk) { v.sayac = v.sayac || {}; v.sayac[t] = enBuyuk; }
  }
  if (!duzelen.length) return;
  DB.kaydet();
  setTimeout(() => modalAc(`<div class="modal-baslik">Kayıt numarası onarıldı</div>
    <p>Eski bir hata yüzünden aşağıdaki kayıtlar başka bir kayıtla aynı numarayı taşıyordu. Bu yüzden seçince başka isim görünüyordu. Şimdi ayrıldılar.</p>
    <ul>${duzelen.map(d => `<li>${kac("", d)}</li>`).join("")}</ul>
    <p style="font-size:13px;opacity:.8">Bu müşterilerin cari hareketlerini kontrol edin: eski hareketler parantez içindeki kayıtta kalmış olabilir.</p>
    <div class="modal-alt"><button class="btn ana" onclick="modalKapat()">Tamam</button></div>`), 1500);
}

function oturumAc(animasyonlu) {
  try { ciftNumaralariOnar(); } catch (e) { console.error("Numara onarımı:", e); }
  try { eksikCariBorclariniOnar(); } catch (e) { console.error("Cari onarımı:", e); }
  $("giris").classList.add("gizli");
  const ac = () => {
    $("uygulama").classList.remove("gizli");
    yetkiUygula();
    satisSekmeleriniYukle();
    sayfaGoster("kasa");
  };
  if (!animasyonlu) return ac();
  const a = $("acilis");
  a.classList.remove("oynat");
  void a.offsetWidth; // animasyonu baştan başlatmak için
  a.classList.add("oynat");
  setTimeout(() => {
    a.classList.remove("oynat");
    ac();
  }, 2600);
}

function cikis() {
  setTimeout(girisDoldur, 0);
  sessionStorage.removeItem("oturum");
  DB.tokenYaz(null);
  satisSekmeleriniSakla(); // bekleyen satışlar çıkışta silinmez
  aktifKullanici = null;
  $("uygulama").classList.add("gizli");
  $("giris").classList.remove("gizli");
}

// ---------- Sayfa geçişi ----------
let aktifSayfa = "kasa";
function sayfaGoster(ad) {
  aktifSayfa = ad;
  menuRozetleri();
  // Sayfa değişince açık yan paneller kapanır
  urunPaneliKapat();
  kategoriPaneliKapat();
  document.querySelectorAll(".sayfa").forEach(s => s.classList.add("gizli"));
  $("s-" + ad).classList.remove("gizli");
  document.querySelectorAll("#menu button").forEach(b => b.classList.toggle("aktif", b.dataset.sayfa === ad));
  const cizen = { kasa: kasaCiz, fis: fislerCiz, stok: stokCiz, urunler: urunlerCiz, musteri: musteriCiz, fatura: faturaCiz, rapor: raporCiz, kullanici: kullaniciCiz, ayar: ayarCiz };
  if (cizen[ad]) cizen[ad]();
}

// ---------- Beklemeye al ----------
// Mevcut satış (sepet, indirim, müşteri) isimlendirilip beklemeye alınır, yeni boş satış açılır. Bekleyenler yeniden açılsa da kaybolmaz.
async function beklemeyeAl() {
  if (!sepet.length) return bildir("Sepet boş");
  const ad = await kucukPencere({ baslik: "Beklemeye al", mesaj: "Bu satış beklerken bir isim verin (ör. müşteri adı). Boş bırakabilirsiniz.", girdi: true, bos: true, yer: "Ör. Ahmet Bey", evet: "Beklemeye al" });
  if (ad === null) return;
  aktifSekmeyiKaydet();
  const s = satisSekmeleri.find(x => x.id === aktifSekme);
  if (s) { s.ad = ad; s.bekliyor = true; s.zaman = Date.now(); }
  yeniSatis();
  bildir("Satış beklemeye alındı" + (ad ? ": " + ad : ""));
}
function bekleyenSatislar() { return satisSekmeleri.filter(s => s.id !== aktifSekme && s.sepet.length); }
function bekleyenlerPenceresi() {
  aktifSekmeyiKaydet();
  const l = bekleyenSatislar();
  modalAc(`
    <div class="modal-baslik">Bekleyen satışlar</div>
    <div style="margin:10px 0;display:flex;flex-direction:column;gap:8px">
      ${l.map(s => {
        const m = s.musteriId && DB.bul("musteriler", x => x.id === s.musteriId);
        const top = s.sepet.reduce((t, k) => t + k.fiyat * k.adet, 0), adet = s.sepet.length;
        return `<div class="bekleyen-kart"><div style="flex:1;min-width:0"><strong>${kac("", s.ad || (m ? m.ad_soyad : "Satış " + s.id))}</strong><small>${adet} kalem · ${para(top)}${s.zaman ? " · " + new Date(s.zaman).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) : ""}</small></div><button class="btn ana kucuk" data-devam="${s.id}">Devam et</button><button class="btn kucuk tehlike" data-sil-bekleyen="${s.id}">Sil</button></div>`;
      }).join("") || '<div class="bos">Bekleyen satış yok</div>'}
    </div>
    <div class="modal-alt"><button class="btn" id="bk-kapat">Kapat</button></div>`);
  $("bk-kapat").addEventListener("click", modalKapat);
  $("modal-icerik").querySelectorAll("[data-devam]").forEach(b => b.addEventListener("click", () => { modalKapat(); sekmeyeGec(Number(b.dataset.devam)); }));
  $("modal-icerik").querySelectorAll("[data-sil-bekleyen]").forEach(b => b.addEventListener("click", async () => {
    const id = Number(b.dataset.silBekleyen);
    if (!(await kucukPencere({ baslik: "Bekleyen satış silinsin mi?", mesaj: "Sepet iptal fişi olarak kaydedilir.", evet: "Evet, sil" }))) return;
    sekmeyeGec(id); sepetIptalKaydet("Bekleyen satış iptali");
    satisSekmeleri = satisSekmeleri.filter(x => x.id !== id);
    sekmeyiAc(satisSekmeleri[0].id);
    bekleyenlerPenceresi();
  }));
}

// ---------- Terazi (tartılı ürünler) ----------
// Birimi kg/metre/litre olan ürünlerde miktar kesirli girilir; etiketli terazi barkodu (2 + 6 hane ürün kodu + 5 hane değer) otomatik okunur.
const OLCU_BIRIMLERI = { kg: "kg", metre: "m", litre: "L" };
const olcuMu = u => !!(u && OLCU_BIRIMLERI[u.birim]);
function miktarCoz(metin, birim) {
  const m = /^([\d]+(?:\.\d+)?)\s*(g|gr|kg)?$/.exec(String(metin || "").trim().toLowerCase().replace(",", "."));
  if (!m) return 0;
  let v = parseFloat(m[1]);
  if (birim === "kg" && (m[2] === "g" || m[2] === "gr")) v /= 1000;
  return v > 0 ? Math.round(v * 1000) / 1000 : 0;
}
function teraziCoz(kod) {
  if (!/^2\d{12}$/.test(String(kod))) return null;
  const plu = Number(kod.slice(1, 7)), deger = Number(kod.slice(7, 12));
  const u = DB.bul("urunler", x => x.aktif && x.plu && Number(x.plu) === plu);
  if (!u || !deger) return null;
  const miktar = DB.ayarOku("teraziDeger", "agirlik") === "tutar" ? Math.round((deger / 100) / (u.satis_fiyati || 1) * 1000) / 1000 : deger / 1000;
  return miktar > 0 ? { urun: u, miktar } : null;
}
async function agirlikSor(u, mevcut) {
  const birim = OLCU_BIRIMLERI[u.birim] || "";
  const g = await kucukPencere({ baslik: "Tartı · " + u.ad, mesaj: `Miktarı girin (${birim}). ${u.birim === "kg" ? "Gram için örn. 350g yazabilirsiniz." : ""}`, girdi: true, yer: "Ör. 0,750", evet: mevcut ? "Güncelle" : "Sepete ekle" });
  return g ? miktarCoz(g, u.birim) : 0;
}
const satirTutari = s => Math.round(s.fiyat * s.adet * 100) / 100;

// ---------- İade ----------
function iadeEdilenler(satisId) {
  const m = {};
  DB.liste("satislar", x => x.iade_fis_id === satisId && x.durum === "tamamlandi").forEach(r => DB.liste("satis_kalemleri", k => k.satis_id === r.id).forEach(k => { m[k.urun_id] = (m[k.urun_id] || 0) + Math.abs(k.miktar); }));
  return m;
}
function fisIade(satisId) {
  const s = DB.bul("satislar", x => x.id === satisId);
  if (!s || s.durum !== "tamamlandi" || s.iade) return;
  const onceki = iadeEdilenler(satisId), odeme = DB.bul("odemeler", o => o.satis_id === satisId);
  const oran = s.ara_toplam > 0 ? s.toplam / s.ara_toplam : 1;
  const satirlar = DB.liste("satis_kalemleri", k => k.satis_id === satisId).map(k => {
    const u = DB.bul("urunler", x => x.id === k.urun_id) || {};
    return { urun_id: k.urun_id, ad: u.ad || "Silinmiş ürün", birim: u.birim, kalan: Math.round((k.miktar - (onceki[k.urun_id] || 0)) * 1000) / 1000, net: k.birim_fiyat * oran, q: 0 };
  }).filter(r => r.kalan > 0);
  if (!satirlar.length) return bildir("Bu fişteki ürünlerin tamamı daha önce iade edilmiş");
  const yontemler = [["nakit", "Nakit iade"], ["kart", "Karta iade"]].concat(s.musteri_id ? [["acik_hesap", "Müşteri hesabından düş"]] : []);
  const varsayilan = odeme && yontemler.some(y => y[0] === odeme.yontem) ? odeme.yontem : "nakit";
  modalAc(`
    <div class="modal-baslik">İade al · ${s.fis_no}</div>
    <p style="margin:6px 0;font-size:13px;opacity:.75">İade edilecek ürünlerin miktarını girin. Ürünler stoğa geri girer.</p>
    <table class="tablo" id="ia-tablo">
      <tr><th>Ürün</th><th class="sag">Satılan (kalan)</th><th class="sag">Birim fiyat</th><th style="width:150px">İade miktarı</th></tr>
      ${satirlar.map((r, i) => `<tr><td>${kac("", r.ad)}</td><td class="sag">${sayi(r.kalan)}${OLCU_BIRIMLERI[r.birim] ? " " + OLCU_BIRIMLERI[r.birim] : ""}</td><td class="sag">${para(r.net)}</td><td><div style="display:flex;gap:6px"><input type="number" min="0" max="${r.kalan}" step="${OLCU_BIRIMLERI[r.birim] ? "0.001" : "1"}" value="0" data-q="${i}" style="width:90px"><button type="button" class="btn kucuk" data-hepsi="${i}">Hepsi</button></div></td></tr>`).join("")}
    </table>
    <div class="filtre" style="margin:10px 0"><label>İade şekli <select id="ia-yontem">${yontemler.map(y => `<option value="${y[0]}" ${y[0] === varsayilan ? "selected" : ""}>${y[1]}</option>`).join("")}</select></label><span id="ia-toplam" style="margin-left:auto;font-size:18px;font-weight:700"></span></div>
    <div class="hata" id="ia-hata"></div>
    <div class="modal-alt"><button class="btn" id="ia-vazgec">Vazgeç</button><button class="btn tehlike" id="ia-onay">İadeyi kaydet</button></div>`);
  const hesapla = () => {
    let t = 0;
    $("modal-icerik").querySelectorAll("[data-q]").forEach(inp => { const r = satirlar[Number(inp.dataset.q)]; r.q = Math.max(0, Math.min(r.kalan, Number(inp.value) || 0)); t += Math.round(r.q * r.net * 100) / 100; });
    $("ia-toplam").textContent = "İade: " + para(t);
    return Math.round(t * 100) / 100;
  };
  $("modal-icerik").querySelectorAll("[data-q]").forEach(inp => inp.addEventListener("input", hesapla));
  $("modal-icerik").querySelectorAll("[data-hepsi]").forEach(b => b.addEventListener("click", () => { const i = Number(b.dataset.hepsi); $("modal-icerik").querySelector(`[data-q="${i}"]`).value = satirlar[i].kalan; hesapla(); }));
  hesapla();
  $("ia-vazgec").addEventListener("click", modalKapat);
  $("ia-onay").addEventListener("click", () => {
    const toplam = hesapla();
    if (!(toplam > 0)) return ($("ia-hata").textContent = "İade edilecek bir miktar girin");
    const yontem = $("ia-yontem").value, tarihIso = new Date().toISOString();
    const n = DB.liste("satislar", x => x.iade).length + 1;
    const fisNo = `I${tarihIso.slice(0, 10).replace(/-/g, "")}-${String(n).padStart(5, "0")}`;
    const iade = DB.ekle("satislar", { fis_no: fisNo, kasa_no: DB.ayarOku("kasaNo", "1"), kullanici_id: aktifKullanici.id, musteri_id: s.musteri_id || null, ara_toplam: -toplam, indirim: 0, toplam: -toplam, durum: "tamamlandi", iade: 1, iade_fis_id: s.id, tarih: tarihIso });
    satirlar.filter(r => r.q > 0).forEach(r => {
      DB.ekle("satis_kalemleri", { satis_id: iade.id, urun_id: r.urun_id, miktar: -r.q, birim_fiyat: Math.round(r.net * 100) / 100, tutar: -Math.round(r.q * r.net * 100) / 100 });
      DB.stokHareketi(r.urun_id, "iade", r.q, "İade " + s.fis_no, aktifKullanici.id);
    });
    DB.ekle("odemeler", { satis_id: iade.id, yontem, tutar: -toplam });
    if (yontem === "acik_hesap" && s.musteri_id) cariKaydet(s.musteri_id, "tahsilat", toplam, { satisId: iade.id, aciklama: "İade " + s.fis_no, islem: "iade" });
    modalKapat(); kasaUrunleriCiz(); menuRozetleri();
    if (aktifSayfa === "fis") fislerCiz();
    bildir("İade kaydedildi: " + para(toplam));
  });
}

// ---------- KASA ----------
let sepet = [];
let seciliKategori = ""; // boşsa ilk kategori seçilir
let indirim = { tur: "yuzde", deger: 0 };

// ---------- Çoklu satış (bekleyen müşteriler) ----------
// Her sekme kendi sepetini, indirimini ve müşterisini tutar. "+" ile yeni satış açılır, mevcut satış beklemeye alınır.
const SEKME_ANAHTARI = "kasaSatisSekmeleri";
const bosIndirim = () => ({ tur: "yuzde", deger: 0 });
let satisSekmeleri = [{ id: 1, sepet: [], indirim: bosIndirim(), musteriId: null }];
let aktifSekme = 1;
let sekmeSayaci = 1;

function aktifSekmeyiKaydet() {
  const s = satisSekmeleri.find(x => x.id === aktifSekme);
  if (!s) return;
  s.sepet = sepet;
  s.indirim = indirim;
  s.musteriId = seciliMusteriId;
}

function satisSekmeleriniSakla() {
  aktifSekmeyiKaydet();
  try { localStorage.setItem(SEKME_ANAHTARI, JSON.stringify({ satisSekmeleri, aktifSekme, sekmeSayaci })); } catch (e) {}
}

// Sayfa yenilense ya da çıkış yapılsa bile bekleyen satışlar korunur
function satisSekmeleriniYukle() {
  try {
    const k = JSON.parse(localStorage.getItem(SEKME_ANAHTARI));
    if (k && Array.isArray(k.satisSekmeleri) && k.satisSekmeleri.length && k.satisSekmeleri.some(x => x.id === k.aktifSekme)) {
      satisSekmeleri = k.satisSekmeleri;
      aktifSekme = k.aktifSekme;
      sekmeSayaci = Math.max(k.sekmeSayaci || 1, ...satisSekmeleri.map(x => x.id));
    }
  } catch (e) {}
  const s = satisSekmeleri.find(x => x.id === aktifSekme) || satisSekmeleri[0];
  aktifSekme = s.id;
  sepet = s.sepet;
  indirim = s.indirim;
  seciliMusteriId = s.musteriId;
}

function sekmeyiAc(id) {
  const s = satisSekmeleri.find(x => x.id === id);
  if (!s) return;
  aktifSekme = id;
  sepet = s.sepet;
  indirim = s.indirim;
  seciliMusteriId = s.musteriId;
  kasaCiz();
}

function sekmeyeGec(id) {
  if (id === aktifSekme) return;
  aktifSekmeyiKaydet();
  sekmeyiAc(id);
}

function yeniSatis() {
  aktifSekmeyiKaydet();
  sekmeSayaci += 1;
  satisSekmeleri.push({ id: sekmeSayaci, sepet: [], indirim: bosIndirim(), musteriId: null });
  sekmeyiAc(sekmeSayaci);
  // Barkod okuyucu yazabilsin diye arama kutusuna odaklanılır ama ürün paneli kendiliğinden açılmaz
  // (tıklamanın kendi odak değişikliğinden sonra çalışsın diye bir sonraki turda yapılır)
  setTimeout(() => {
    sessizOdak = true;
    $("arama").focus();
    sessizOdak = false;
  }, 0);
}

let sessizOdak = false;

// Sekmeyi kapatır. Doluysa sepet iptal fişi olarak kaydedilir.
async function sekmeKapat(id) {
  if (satisSekmeleri.length === 1) return bildir("Son satış kapatılamaz");
  sekmeyeGec(id);
  if (sepet.length) {
    if (!await kucukPencere({ baslik: "Satış iptal edilsin mi?", mesaj: "Bu bekleyen satış iptal fişi olarak kaydedilir.", evet: "İptal et", hayir: "Vazgeç" })) return;
    sepetIptalKaydet("Bekleyen satış iptali");
  }
  satisSekmeleri = satisSekmeleri.filter(x => x.id !== id);
  sekmeyiAc(satisSekmeleri[0].id);
}

function sekmeleriCiz() {
  const bb = $("bekleyenler-ac");
  if (bb) { const n = bekleyenSatislar().length; bb.textContent = n ? `Bekleyenler (${n})` : "Bekleyenler"; bb.classList.toggle("dolu", n > 0); }
  const kap = $("satis-sekmeleri");
  if (!kap) return;
  kap.innerHTML = satisSekmeleri.map(s => {
    const m = s.musteriId && DB.bul("musteriler", x => x.id === s.musteriId);
    const adet = s.sepet.reduce((t, k) => t + k.adet, 0);
    return `<button class="satis-sekme ${s.id === aktifSekme ? "aktif" : ""}" data-sek="${s.id}" title="${s.sepet.length ? para(s.sepet.reduce((t, k) => t + k.fiyat * k.adet, 0)) : "Boş satış"}">
      <span class="sekme-ad">${s.ad ? kac("", s.ad) : m ? kac("", m.ad_soyad) : "Satış " + s.id}</span>${adet ? `<span class="sekme-adet">${adet}</span>` : ""}
      ${satisSekmeleri.length > 1 ? `<span class="sekme-kapat" data-kapat="${s.id}" aria-label="Satışı kapat">×</span>` : ""}
    </button>`;
  }).join("") + '<button class="satis-sekme yeni" id="yeni-satis" title="Yeni satış (mevcut satış beklemeye alınır)" aria-label="Yeni satış">+</button>';
}

function sepetToplami() { return sepet.reduce((t, s) => t + satirTutari(s), 0); }
function indirimTutari() {
  const ara = sepetToplami();
  const t = indirim.tur === "yuzde" ? ara * indirim.deger / 100 : indirim.deger;
  return Math.min(ara, Math.max(0, Math.round(t * 100) / 100));
}
function genelToplam() { return sepetToplami() - indirimTutari(); }

async function sepeteEkle(urunId, miktar) {
  const u = DB.bul("urunler", x => x.id === urunId);
  if (!u || !u.aktif) return;
  let m = 1;
  if (olcuMu(u)) { m = miktar || await agirlikSor(u, false); if (!m) return; }
  else if (miktar) m = miktar;
  // Stok yetersiz olsa da satış yapılır, stok eksiye düşer
  const satir = sepet.find(s => s.id === urunId);
  if (satir) satir.adet = Math.round((satir.adet + m) * 1000) / 1000;
  else sepet.push({ id: u.id, ad: u.ad, fiyat: u.satis_fiyati, adet: m, birim: u.birim });
  sepetiCiz();
}

// Sepet satırında fiyat ya da adet küçük pencereyle yazılır. Fiyat yalnızca bu satış içindir, ürünün kayıtlı fiyatı değişmez.
function listeFiyati(s) { const u = DB.bul("urunler", x => x.id === s.id); return u ? Number(u.satis_fiyati) : s.fiyat; }
function sayiCoz(metin) {
  let t = String(metin || "").trim().replace(/[^\d.,]/g, "");
  t = t.includes(",") || /\.\d{3}$/.test(t) ? t.replace(/\./g, "").replace(",", ".") : t; // 1.250,50 ya da 2.5
  const v = Number(t);
  return t && isFinite(v) && v >= 0 ? v : null;
}
async function satirSayiSor(id, alan) {
  const satir = sepet.find(s => s.id === id); if (!satir) return;
  const fiyat = alan === "fiyat";
  const m = await kucukPencere({ baslik: fiyat ? "Bu satış için fiyat" : "Adet", mesaj: satir.ad + (fiyat ? " · kayıtlı fiyat " + para(listeFiyati(satir)) : ""), girdi: true, sayisal: true,
    deger: fiyat ? para(satir.fiyat).replace(/[^\d.,]/g, "") : sayi(satir.adet) });
  if (m === null) return $("arama").focus();
  const v = sayiCoz(m);
  if (v === null) { bildir("Geçerli bir sayı yazın"); return $("arama").focus(); }
  if (fiyat) satir.fiyat = Math.round(v * 100) / 100;
  else { satir.adet = Math.round(v * 1000) / 1000; if (satir.adet <= 0) sepet = sepet.filter(s => s !== satir); }
  sepetiCiz(); $("arama").focus();
}

function adetDegistir(id, fark) {
  const satir = sepet.find(s => s.id === id);
  if (!satir) return;
  satir.adet += fark;
  if (satir.adet <= 0) sepet = sepet.filter(s => s.id !== id);
  sepetiCiz();
}

function sepetiCiz() {
  $("satirlar").innerHTML = sepet.length
    ? sepet.map(s => `
      <div class="satir">
        ${urunResmi(DB.bul("urunler", x => x.id === s.id))}
        <div>
          <div class="adi">${kac("", s.ad)}</div>
          <div class="alt">
            ${OLCU_BIRIMLERI[s.birim] ? `<button class="adet agirlik" data-agirlik="${s.id}" title="Miktarı değiştir">${sayi(s.adet)} ${OLCU_BIRIMLERI[s.birim]} ✎</button>` : `<button class="adet" data-id="${s.id}" data-fark="-1">−</button>
            <button class="adet-yaz" data-adet-yaz="${s.id}" title="Adedi yaz">${sayi(s.adet)}</button>
            <button class="adet" data-id="${s.id}" data-fark="1">+</button>`}
            <span>×</span><button class="fiyat-yaz" data-fiyat-yaz="${s.id}" title="Bu satış için fiyatı değiştir">${para(s.fiyat)}</button>${listeFiyati(s) !== s.fiyat ? `<s>${para(listeFiyati(s))}</s>` : ""}
          </div>
        </div>
        <div class="tutar">${para(satirTutari(s))}</div>
        <button class="sil" data-sil="${s.id}" title="Satırı sil" aria-label="Satırı sil">✕</button>
      </div>`).join("")
    : '<div class="bos">Sepet boş. Ürün seçin veya barkod okutun.</div>';
  $("sepet-adet").textContent = sepet.length + " kalem";
  $("toplam").textContent = para(genelToplam());
  $("odeme-toplam").textContent = para(genelToplam());
  const ind = indirimTutari();
  $("indirim-bilgi").textContent = ind > 0
    ? `Ara toplam ${para(sepetToplami())} · İndirim -${para(ind)}${indirim.tur === "yuzde" ? ` (%${indirim.deger})` : ""}`
    : "";
  satisSekmeleriniSakla();
  sekmeleriCiz();
}

// İndirim butonu: kaç indirim yapılacağı sorulur (yüzde veya tutar)
function indirimSor() {
  if (sepet.length === 0) return bildir("Sepet boş");
  const ara = sepetToplami();
  modalAc(`
    <div class="modal-baslik">İndirim</div>
    <p>Ara toplam <strong>${para(ara)}</strong></p>
    <form id="in-form" class="form">
      <label>İndirim miktarı<input name="deger" type="number" step="0.01" min="0" value="${indirim.deger || ""}" required></label>
      <label>Türü<select name="tur"><option value="yuzde" ${indirim.tur === "yuzde" ? "selected" : ""}>Yüzde (%)</option><option value="tutar" ${indirim.tur === "tutar" ? "selected" : ""}>Tutar (TL)</option></select></label>
      <div class="tam hizli-indirim">
        ${[5, 10, 15, 20].map(y => `<button type="button" class="btn" data-yuzde="${y}">%${y}</button>`).join("")}
      </div>
      <div class="tam hata" id="in-hata"></div>
      <div class="modal-alt tam">
        <button type="button" class="btn" id="in-vazgec">Vazgeç</button>
        ${indirimTutari() > 0 ? '<button type="button" class="btn tehlike" id="in-kaldir">İndirimi kaldır</button>' : ""}
        <button class="btn ana" type="submit">Uygula</button>
      </div>
    </form>`);
  const form = $("in-form");
  form.elements.deger.focus();
  form.querySelectorAll("[data-yuzde]").forEach(b => b.addEventListener("click", () => {
    form.elements.deger.value = b.dataset.yuzde;
    form.elements.tur.value = "yuzde";
    $("in-hata").textContent = "";
  }));
  $("in-vazgec").addEventListener("click", modalKapat);
  if ($("in-kaldir")) $("in-kaldir").addEventListener("click", () => {
    indirim = { tur: "yuzde", deger: 0 };
    modalKapat();
    sepetiCiz();
    bildir("İndirim kaldırıldı");
  });
  form.addEventListener("submit", e => {
    e.preventDefault();
    const deger = Number(form.elements.deger.value);
    const tur = form.elements.tur.value;
    if (!(deger > 0)) return ($("in-hata").textContent = "Pozitif bir miktar girin");
    if (tur === "yuzde" && deger > 100) return ($("in-hata").textContent = "Yüzde 100'den büyük olamaz");
    if (tur === "tutar" && deger > ara) return ($("in-hata").textContent = "İndirim ara toplamdan büyük olamaz");
    indirim = { tur, deger };
    modalKapat();
    sepetiCiz();
    bildir(`İndirim uygulandı: -${para(indirimTutari())}`);
  });
}

// Türkçe harfleri (İ/I, ı/i) tutarlı küçültür: "KÖPEK" yazan ürün "köpek" ile bulunur
const trKucuk = m => String(m || "").toLocaleLowerCase("tr").normalize("NFC");
function kasaUrunleriCiz() {
  const arama = trKucuk($("arama").value.trim());
  // Yalnızca yöneticinin tanımladığı kategoriler gösterilir ("Tümü" butonu yok). Seçili kategori yoksa ilk kategori açılır.
  const kategoriler = siraliKategoriler();
  if (!kategoriler.some(k => k.ad === seciliKategori)) seciliKategori = kategoriler.length ? kategoriler[0].ad : "";
  const kat = kategoriler.find(k => k.ad === seciliKategori);
  // Arama yazılmışsa kategoriden bağımsız tüm ürünlerde aranır (barkod okutma için)
  const liste = DB.liste("urunler", u => u.aktif &&
    (arama
      ? trKucuk(u.ad).includes(arama) || String(u.barkod || "").includes(arama)
      : !kategoriler.length || (kat && u.kategori_id === kat.id)));
  // Kategoriye eklenirken seçilme sırası (kat_sira) korunur; sırası olmayanlar sona, eski düzenleriyle gelir
  if (!arama) liste.sort((x, y) => (x.kat_sira ?? Infinity) - (y.kat_sira ?? Infinity));
  $("urun-listesi").innerHTML = liste.length
    ? liste.map(u => `<button class="urun ${u.stok <= 0 ? "tukendi" : ""}" data-urun="${u.id}">${urunResmi(u)}<div class="ad">${kac("", u.ad)}</div><div class="fiyat">${para(u.satis_fiyati)}</div><div class="fiyat">Stok: ${sayi(u.stok)}</div></button>`).join("")
    : `<div class="bos">${arama ? "Eşleşen ürün yok." : "Bu kategoride ürün yok."}</div>`;
  $("kategoriler").innerHTML = kategoriler.map(k =>
    `<button class="kat ${k.ad === seciliKategori ? "secili" : ""}" data-kat="${kac("", k.ad)}">${kac("", k.ad)}</button>`).join("");
}

function kasaCiz() {
  menuRozetleri(); // satıştan sonra stok değişmiş olabilir
  sepetiCiz();
  kasaUrunleriCiz();
  kasaMusteriDurumu();
}

// Fiyat sorgu kutusu: göz düğmesine basılınca açılır, okutulan barkodun ürün fiyatını gösterir (sepete eklemez)
let fiyatModu = false;
function fiyatKutusuAc(ac) {
  fiyatModu = ac;
  $("fiyat-gor").classList.toggle("aktif", ac);
  $("fiyat-kutu").classList.toggle("acik", ac);
  if (ac) {
    $("fiyat-kutu-icerik").innerHTML = '<div class="fk-bos"><div class="fk-ikon">▥</div>Barkodu okutun</div>';
    $("arama").value = "";
    sessizOdak = true; $("arama").focus(); sessizOdak = false;
  }
}
function fiyatGoster(metin) {
  const k = $("fiyat-kutu-icerik");
  const u = DB.bul("urunler", x => x.barkod === metin);
  $("arama").value = "";
  if (!u) { k.innerHTML = '<div class="fk-bos hata">Ürün bulunamadı<small>' + kac("", metin) + '</small></div>'; return; }
  const stok = Number(u.stok || 0);
  k.innerHTML = '<div class="fk-urun">' + urunResmi(u) + '<div class="fk-ad">' + kac("", u.ad) + '</div><div class="fk-fiyat">' + para(u.satis_fiyati) + '</div>' +
    '<div class="fk-alt"><span>Barkod: ' + kac("", u.barkod || "-") + '</span><span class="' + (stok <= 0 ? "az" : "") + '">Stok: ' + stok + '</span></div></div>';
}

// Hızlı kayıt: kayıtsız barkod okutulunca ad ve fiyatı girilip ürün kaydedilir ve sepete eklenir
function hizliKayit(barkod) {
  if (!aktifKullanici || aktifKullanici.rol !== "yonetici") return bildir("Bu barkod kayıtlı değil. Ürünü yönetici eklemeli: " + barkod, 4000);
  const kategoriler = siraliKategoriler();
  modalAc(`
    <div class="modal-baslik">Ürün kayıtlı değil · hızlı kayıt</div>
    <p style="margin:8px 0">Barkod <strong>${kac("", barkod)}</strong> stokta bulunamadı. Ürünü kaydedip sepete ekleyelim mi?</p>
    <form id="hk-form" class="form" style="margin-top:8px">
      <label class="tam">Ürün adı<input name="ad" required autocomplete="off"></label>
      <label>Satış fiyatı<input name="satis" type="number" step="0.01" min="0" required></label>
      <label>Alış fiyatı<input name="alis" type="number" step="0.01" min="0"></label>
      <label>KDV %<input name="kdv" type="number" value="20"></label>
      <label>Stok (açılış)<input name="stok" type="number" step="0.001" min="0" value="0"></label>
      <label class="tam">Kategori<select name="kategori"><option value="">Kategori yok</option>${kategoriler.map(k => `<option value="${k.id}" ${k.ad === seciliKategori ? "selected" : ""}>${kac("", k.ad)}</option>`).join("")}</select></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="hk-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet ve sepete ekle</button></div>
    </form>`);
  const form = $("hk-form");
  form.elements.ad.focus();
  $("hk-vazgec").addEventListener("click", () => { modalKapat(); sessizOdak = true; $("arama").focus(); sessizOdak = false; });
  form.addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(form);
    if (DB.bul("urunler", x => !x.silindi && x.barkod === barkod)) { modalKapat(); return bildir("Bu barkod zaten kayıtlı"); }
    const yeni = DB.ekle("urunler", { barkod, ad: String(f.get("ad")).trim(), kategori_id: f.get("kategori") ? Number(f.get("kategori")) : null, satis_fiyati: Number(f.get("satis")), alis_fiyati: Number(f.get("alis") || 0), kdv_orani: Number(f.get("kdv") || 20), kritik_stok: 0, birim: "adet", plu: "", stok: 0, aktif: 1 });
    const acilis = Number(f.get("stok") || 0);
    if (acilis > 0) DB.stokHareketi(yeni.id, "giris", acilis, "Açılış stoku (hızlı kayıt)", aktifKullanici.id);
    modalKapat();
    sepeteEkle(yeni.id);
    $("arama").value = ""; kasaUrunleriCiz(); sessizOdak = true; $("arama").focus(); sessizOdak = false;
    bildir(yeni.ad + " kaydedildi ve sepete eklendi");
  });
}

function barkodIsle(metin) {
  if (fiyatModu) return fiyatGoster(metin);
  // "5*8690001" yazılırsa o ürün 5 adet eklenir
  let adet = 1;
  const carpan = /^(\d{1,3})\s*[*xX]\s*(.+)$/.exec(metin);
  if (carpan && !DB.bul("urunler", x => x.barkod === metin)) { adet = Math.max(1, Number(carpan[1])); metin = carpan[2].trim(); }
  let u = DB.bul("urunler", x => x.barkod === metin && x.aktif);
  if (!u) {
    const t = teraziCoz(metin);
    if (t) { sepeteEkle(t.urun.id, t.miktar); bip(true); $("arama").value = ""; kasaUrunleriCiz(); $("arama").focus(); return bildir(t.urun.ad + " · " + sayi(t.miktar) + " " + (OLCU_BIRIMLERI[t.urun.birim] || "")); }
    bip(false);
    // Okutulan barkod stokta yoksa hızlı kayıt penceresi açılır; arama kutusu kendiliğinden temizlenir
    if (/^\d{6,14}$/.test(metin)) { $("arama").value = ""; kasaUrunleriCiz(); return hizliKayit(metin); }
    return urunPaneli(metin);
  }
  if (olcuMu(u)) { sepeteEkle(u.id); $("arama").value = ""; $("arama").focus(); return; }
  const satir = sepet.find(s => s.id === u.id);
  if (satir) satir.adet += adet; else sepet.push({ id: u.id, ad: u.ad, fiyat: u.satis_fiyati, adet, birim: u.birim });
  sepetiCiz();
  bip(true);
  $("arama").value = "";
  kasaUrunleriCiz();
  $("arama").focus();
  bildir(adet > 1 ? adet + " x " + u.ad + " eklendi" : u.ad + " eklendi");
}

function fisNo() {
  const n = DB.liste("satislar").length + 1;
  return `F${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${String(n).padStart(5, "0")}`;
}

function satisTamamla(yontem) {
  if (sepet.length === 0) return bildir("Sepet boş");
  let musteriId = null;
  if (yontem === "acik_hesap" && seciliMusteriId) return kaydetSatis("acik_hesap", seciliMusteriId);
  if (yontem === "acik_hesap") {
    // Eskiden açılır kutuda ilk müşteri seçili geliyordu; "Seç ve öde" denince satış yanlış kişiye yazılıyordu.
    // Artık aranabilir liste açılır, satış yalnızca bir müşteriye tıklanınca kaydedilir.
    if (!DB.liste("musteriler", m => m.aktif && !m.tedarikci).length) return bildir("Önce müşteri ekleyin");
    $("odeme-panel").style.display = "none";
    return acikHesapMusteriSec(id => kaydetSatis("acik_hesap", id));
  }
  musteriId = null;
  kaydetSatis(yontem, musteriId);
}

// Açık hesap müşterisi: aranabilir liste, bakiye görünür; müşteriye tıklanınca sonra(id) çağrılır
function acikHesapMusteriSec(sonra) {
  modalAc(`
    <div class="modal-baslik">Açık hesap · ${para(genelToplam())} · müşteri seçin</div>
    <input id="ahm-ara" placeholder="Müşteri adı veya telefon" autocomplete="off" style="margin-top:10px;height:42px;border-radius:8px;border:1px solid var(--line);padding:0 12px;background:var(--surface);color:var(--fg);font-size:15px">
    <div id="ahm-liste" style="margin-top:8px;display:flex;flex-direction:column;gap:6px;max-height:52vh;overflow:auto"></div>
    <div class="modal-alt"><button class="btn" id="ahm-geri">Geri</button></div>`);
  const listele = () => {
    const q = trKucuk($("ahm-ara").value.trim());
    const l = DB.liste("musteriler", m => m.aktif && !m.tedarikci && (!q || trKucuk(m.ad_soyad).includes(q) || String(m.telefon || "").includes(q)))
      .sort((x, y) => String(x.ad_soyad).localeCompare(String(y.ad_soyad), "tr")).slice(0, 80);
    $("ahm-liste").innerHTML = l.map(m => `<button class="btn" data-ahm="${m.id}" style="text-align:left;display:flex;justify-content:space-between;height:auto;padding:10px 12px"><span>${kac("", m.ad_soyad)} <small style="opacity:.6">${kac("", m.telefon)}</small></span><small>bakiye ${para(cariBakiye(m.id))}</small></button>`).join("") || '<div class="bos">Müşteri bulunamadı</div>';
  };
  $("ahm-ara").addEventListener("input", listele);
  $("ahm-ara").addEventListener("keydown", e => { if (e.key === "Enter") { const ilk = $("ahm-liste").querySelectorAll("[data-ahm]"); if (ilk.length === 1) ilk[0].click(); } });
  $("ahm-liste").addEventListener("click", e => { const b = e.target.closest("[data-ahm]"); if (!b) return; modalKapat(); sonra(Number(b.dataset.ahm)); });
  $("ahm-geri").addEventListener("click", () => { modalKapat(); $("odeme-toplam").textContent = para(genelToplam()); $("odeme-panel").style.display = "flex"; });
  listele(); $("ahm-ara").focus();
}

// Parçalı ödeme: toplam nakit, kart ve açık hesaba bölünür (ör. 500 = 200 nakit + 100 kart + 200 açık hesap)
function parcaliOdeme() {
  if (sepet.length === 0) return bildir("Sepet boş");
  const toplam = genelToplam();
  const musteriler = DB.liste("musteriler", m => m.aktif && !m.tedarikci);
  panelKapat();
  modalAc(`
    <div class="modal-baslik">Parçalı ödeme · ${para(toplam)}</div>
    <form id="po-form" class="form" style="margin-top:10px">
      <label>Nakit (TL)<input name="nakit" inputmode="decimal" autocomplete="off"></label>
      <label>Kart (TL)<input name="kart" inputmode="decimal" autocomplete="off"></label>
      <label>Açık hesap (TL)<input name="acik_hesap" inputmode="decimal" autocomplete="off"></label>
      <label id="po-musteri-alan" hidden>Açık hesap müşterisi<select name="musteri"><option value="">Müşteri seçin</option>${musteriler.map(m => `<option value="${m.id}" ${m.id === seciliMusteriId ? "selected" : ""}>${kac("", m.ad_soyad)}</option>`).join("")}</select></label>
      <div class="tam" id="po-kalan" style="font-size:18px;font-weight:700"></div>
      <div class="hata tam" id="po-hata"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="po-vazgec">Geri</button><button class="btn ana" type="submit">Ödemeyi tamamla</button></div>
    </form>`);
  const f = $("po-form"), YONT = ["nakit", "kart", "acik_hesap"];
  const oku = () => YONT.map(y => ({ yontem: y, tutar: Math.round((sayiCoz(f[y].value) || 0) * 100) / 100 }));
  const guncelle = () => {
    const p = oku(), girilen = p.reduce((t, x) => t + x.tutar, 0), kalan = Math.round((toplam - girilen) * 100) / 100;
    $("po-musteri-alan").hidden = !(p[2].tutar > 0);
    $("po-kalan").textContent = Math.abs(kalan) < 0.005 ? "Tamam ✓" : kalan > 0 ? "Kalan: " + para(kalan) : "Fazla: " + para(-kalan);
    $("po-kalan").style.color = Math.abs(kalan) < 0.005 ? "var(--yesil, #1e8e4e)" : "";
    return { p, kalan };
  };
  // Bir kutuya girilince kalan tutar boş olan ilk kutuya önerilir (Enter ile geçilir)
  YONT.forEach(y => f[y].addEventListener("input", guncelle));
  f.addEventListener("keydown", e => {
    if (e.key !== "Enter" || !YONT.includes(e.target.name)) return;
    const { kalan } = guncelle(), sonraki = YONT[YONT.indexOf(e.target.name) + 1];
    if (sonraki && Math.abs(kalan) >= 0.005) { e.preventDefault(); if (!f[sonraki].value && kalan > 0) f[sonraki].value = String(kalan).replace(".", ","); f[sonraki].focus(); f[sonraki].select(); guncelle(); }
  });
  $("po-vazgec").addEventListener("click", () => { modalKapat(); $("odeme-toplam").textContent = para(toplam); $("odeme-panel").style.display = "flex"; });
  f.addEventListener("submit", e => {
    e.preventDefault();
    const { p, kalan } = guncelle();
    if (Math.abs(kalan) >= 0.005) return ($("po-hata").textContent = kalan > 0 ? "Tutarlar toplamı tutmuyor, " + para(kalan) + " eksik" : "Tutarlar toplamdan " + para(-kalan) + " fazla");
    const parcalar = p.filter(x => x.tutar > 0);
    if (parcalar.length === 0) return ($("po-hata").textContent = "Tutar girin");
    const musteriId = Number(f.musteri.value) || null;
    if (p[2].tutar > 0 && !musteriId) return ($("po-hata").textContent = "Açık hesap kısmı için müşteri seçin");
    modalKapat();
    kaydetSatis(parcalar.length === 1 ? parcalar[0].yontem : "parcali", p[2].tutar > 0 ? musteriId : null, parcalar);
  });
  guncelle(); f.nakit.focus();
}

// Fişin ödeme yazısı: tek yöntemse adı, parçalıysa "Nakit 200 + Kart 100 + Açık hesap 200"
function odemeYazisi(satisId) {
  const ad = { nakit: "Nakit", kart: "Kart", acik_hesap: "Açık hesap" };
  const l = DB.liste("odemeler", o => o.satis_id === satisId);
  if (l.length <= 1) return l.length ? ad[l[0].yontem] || l[0].yontem : "-";
  return l.map(o => (ad[o.yontem] || o.yontem) + " " + para(Math.abs(o.tutar))).join(" + ");
}

function kaydetSatis(yontem, musteriId, parcalar) {
  const araT = sepetToplami();
  const toplam = genelToplam();
  parcalar = parcalar || [{ yontem, tutar: toplam }];
  const acikTutar = parcalar.filter(p => p.yontem === "acik_hesap").reduce((t, p) => t + p.tutar, 0);
  // Müşterinin borç limiti varsa aşılırken uyarılır
  if (acikTutar > 0 && musteriId) {
    const mm = DB.bul("musteriler", x => x.id === musteriId);
    if (mm && mm.borc_limiti > 0 && cariBakiye(musteriId) + acikTutar > mm.borc_limiti + 0.005 &&
      !confirm(mm.ad_soyad + " için borç limiti (" + para(mm.borc_limiti) + ") aşılıyor. Yeni bakiye " + para(cariBakiye(musteriId) + acikTutar) + " olacak. Yine de satış yapılsın mı?")) return;
  }
  // Stok kontrolü yok: yetersiz stokta da satış yapılır ve stok eksiye düşer
  const satis = DB.ekle("satislar", {
    fis_no: fisNo(), kasa_no: DB.ayarOku("kasaNo", "1"), kullanici_id: aktifKullanici.id,
    musteri_id: musteriId, ara_toplam: araT, indirim: araT - toplam, toplam, durum: "tamamlandi",
    tarih: new Date().toISOString()
  });
  sepet.forEach(s => {
    DB.ekle("satis_kalemleri", { satis_id: satis.id, urun_id: s.id, miktar: s.adet, birim_fiyat: s.fiyat, tutar: satirTutari(s) });
    DB.stokHareketi(s.id, "satis", -s.adet, satis.fis_no, aktifKullanici.id);
  });
  parcalar.forEach(p => DB.ekle("odemeler", { satis_id: satis.id, yontem: p.yontem, tutar: p.tutar }));
  if (acikTutar > 0) {
    cariKaydet(musteriId, "borc", acikTutar, { satisId: satis.id, islem: "satis", aciklama: satis.fis_no + (parcalar.length > 1 ? " (parçalı)" : "") });
  }
  sepet = [];
  indirim = { tur: "yuzde", deger: 0 };
  seciliMusteriId = null;
  panelKapat();
  kasaCiz();
  fisSonrasi(satis);
  bildir(`${satis.fis_no} kesildi · ${para(toplam)}`);
}

// ---------- Müşteri ve fiyat sorgulama (kasa) ----------
let seciliMusteriId = null;

function kasaMusteriDurumu() {
  const m = seciliMusteriId && DB.bul("musteriler", x => x.id === seciliMusteriId);
  $("musteri-chip-ad").textContent = m ? m.ad_soyad : "Müşteri yok";
  $("musteri-chip").classList.toggle("dolu", !!m);
  $("musteri-temizle").hidden = !m;
  satisSekmeleriniSakla();
  sekmeleriCiz();
}

function musteriAra() {
  modalAc(`
    <div class="modal-baslik">Müşteri seç</div>
    <input id="ma-ara" placeholder="Ad veya telefon" style="margin-top:10px;height:36px;border-radius:8px;border:1px solid var(--line);padding:0 10px;background:var(--surface);color:var(--fg)">
    <div id="ma-liste" style="margin-top:8px;display:flex;flex-direction:column;gap:6px;max-height:50vh;overflow:auto"></div>
    <div class="modal-alt"><button class="btn ana" id="ma-yeni">+ Yeni müşteri ekle</button><button class="btn" id="ma-temizle">Seçimi kaldır</button><button class="btn" id="ma-kapat">Kapat</button></div>`);
  const listele = () => {
    const q = $("ma-ara").value.trim().toLowerCase();
    $("ma-liste").innerHTML = DB.liste("musteriler", m => m.aktif && (!q || m.ad_soyad.toLowerCase().includes(q) || (m.telefon || "").includes(q)))
      .map(m => `<button class="btn" data-mid="${m.id}" style="text-align:left">${kac("", m.ad_soyad)} <small>${kac("", m.telefon)}</small> · borç ${para(cariBakiye(m.id))}</button>`).join("")
      || '<div class="bos">Müşteri bulunamadı</div>';
  };
  $("ma-ara").addEventListener("input", listele);
  $("ma-liste").addEventListener("click", e => {
    const b = e.target.closest("[data-mid]");
    if (!b) return;
    seciliMusteriId = Number(b.dataset.mid);
    kasaMusteriDurumu();
    modalKapat();
    bildir("Müşteri seçildi");
  });
  $("ma-yeni").addEventListener("click", () => {
    const yaz = $("ma-ara").value.trim();
    musteriFormu(null, yeni => { seciliMusteriId = yeni.id; kasaMusteriDurumu(); bildir(yeni.ad_soyad + " seçildi"); });
    if (yaz) { const alan = document.querySelector('#m-form [name="ad"]'); if (alan && !/^[\d\s+()-]+$/.test(yaz)) alan.value = yaz; else { const t = document.querySelector('#m-form [name="tel"]'); if (t) t.value = yaz; } }
  });
  $("ma-temizle").addEventListener("click", () => { seciliMusteriId = null; kasaMusteriDurumu(); modalKapat(); });
  $("ma-kapat").addEventListener("click", modalKapat);
  listele();
  $("ma-ara").focus();
}

// ---------- Sağdan açılan ürün paneli ----------
let cekmeceSecili = null;
let ekleKategorisi = null; // kategoriden "Yeni ürün oluştur" ile açılınca forma hazır gelen kategori
let cekmeceSekme = ""; // boş: listeye tıklayınca ürün sepete eklenir

// Paneller üst menünün altından başlar (sayfaya göre menü yüksekliği değişebilir)
function panelKonumu() {
  document.documentElement.style.setProperty("--panel-ust", document.querySelector(".ust").offsetHeight + "px");
}

// Ürünler sayfasındaki butonlar: ürün ekle, düzenle ve barkod yazdır sekmeleriyle paneli açar
function urunAyarlariAc(sekme, urunId) {
  cekmeceSekme = sekme || "duzenle";
  urunPaneli("");
  if (urunId) {
    cekmeceSecili = DB.bul("urunler", x => x.id === urunId) || null;
    cekmeceListele();
    cekmeceIcerigi();
  }
}

// Panel ekran dışındayken içine odaklanılırsa tarayıcı kapsayan kutuları yana kaydırabiliyor (ekran beyaz kalıyordu): sıfırlanır
function yanKaymayiSifirla() {
  for (let e = $("cekmece"); e; e = e.parentElement) if (e.scrollLeft) e.scrollLeft = 0;
  if (document.scrollingElement) document.scrollingElement.scrollLeft = 0;
}
function urunPaneli(ara) {
  panelKonumu();
  $("kat-paneli").classList.remove("acik");
  $("cekmece").classList.add("acik");
  yanKaymayiSifirla(); setTimeout(yanKaymayiSifirla, 300); // açılma animasyonu 0.25 sn
  if (ara !== undefined) $("c-ara").value = ara;
  cekmeceListele();
  cekmeceIcerigi();
}

let cekmeceMusteri = null; // "Cari güncelle" sekmesinde seçili müşteri

function urunPaneliKapat() {
  ekleKategorisi = null;
  $("cekmece").classList.remove("acik");
  cekmeceSecili = null;
  cekmeceMusteri = null;
}

function cekmeceListele() {
  const q = $("c-ara").value.trim().toLowerCase();
  $("c-ara").placeholder = cekmeceSekme === "cari" ? "Müşteri adı veya telefon" : "Ürün adı veya barkod";

  // Cari güncelle sekmesinde liste müşterileri gösterir
  if (cekmeceSekme === "cari") {
    const musteriler = DB.liste("musteriler", m => m.aktif && (!q || m.ad_soyad.toLowerCase().includes(q) || (m.telefon || "").includes(q)));
    $("c-liste").innerHTML = musteriler.length
      ? musteriler.map(m => `<button class="c-satir ${cekmeceMusteri && cekmeceMusteri.id === m.id ? "secili" : ""}" data-mid="${m.id}">
          <span>${kac("", m.ad_soyad)}</span><small>${kac("", m.telefon)}</small><span class="fiyat">${para(cariBakiye(m.id))}</span></button>`).join("")
      : '<div class="bos">Müşteri bulunamadı</div>';
    return;
  }

  const liste = DB.liste("urunler", u => !q || u.ad.toLowerCase().includes(q) || u.barkod.includes(q)).slice(0, 60);
  $("c-liste").innerHTML = liste.length
    ? liste.map(u => `<button class="c-satir ${cekmeceSecili && cekmeceSecili.id === u.id ? "secili" : ""}" data-cid="${u.id}">
        <span>${kac("", u.ad)}</span><small>${u.barkod}</small><span class="fiyat">${para(u.satis_fiyati)}</span></button>`).join("")
    : '<div class="bos">Ürün bulunamadı</div>';
}

function cekmeceSekmeCiz() {
  const yonetici = aktifKullanici && aktifKullanici.rol === "yonetici";
  document.querySelectorAll(".sekme").forEach(b => {
    // Satış kullanıcısı ürün ekleyemez, düzenleyemez, stok güncelleyemez (yalnızca yönetici)
    b.hidden = !yonetici && ["ekle", "duzenle", "stok"].includes(b.dataset.sekme);
    const aktif = b.dataset.sekme === cekmeceSekme;
    b.classList.toggle("aktif", aktif);
    b.setAttribute("aria-selected", aktif);
  });
}

// Seçili ürünün stokunu günceller (giriş, çıkış, sayım düzeltmesi, iade)
function stokFormuCiz(kutu, u) {
  kutu.innerHTML = `
    <form id="cu-form" class="form">
      <p class="tam">${kac("", u.ad)} · mevcut stok <strong>${sayi(u.stok)} ${kac("", u.birim)}</strong></p>
      <label>İşlem<select name="tur">
        <option value="giris">Giriş (alım)</option>
        <option value="cikis">Çıkış (fire, zayi)</option>
        <option value="sayim">Sayım düzeltmesi (yeni miktar)</option>
        <option value="iade">İade (müşteriden)</option>
      </select></label>
      <label>Miktar<input name="miktar" type="number" step="0.001" min="0" required></label>
      <label class="tam">Açıklama<input name="aciklama" placeholder="Fatura no, sebep"></label>
      <div class="hata tam" id="cs-hata"></div>
    </form>`;
  $("c-kaydet").textContent = "Stok güncelle";
  $("cu-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const tur = f.get("tur");
    const miktar = Number(f.get("miktar"));
    const aciklama = f.get("aciklama");
    if (!(miktar >= 0)) return ($("cs-hata").textContent = "Geçerli bir miktar girin");
    if (tur === "sayim") DB.stokHareketi(u.id, "sayim", miktar - u.stok, aciklama || "Sayım", aktifKullanici.id);
    else if (tur === "cikis") {
      if (miktar > u.stok) return ($("cs-hata").textContent = "Çıkış miktarı mevcut stoktan büyük olamaz");
      DB.stokHareketi(u.id, "cikis", -miktar, aciklama, aktifKullanici.id);
    } else DB.stokHareketi(u.id, tur, miktar, aciklama, aktifKullanici.id);
    bildir("Stok güncellendi");
    cekmeceListele();
    cekmeceIcerigi();
    kasaUrunleriCiz();
    if (aktifSayfa === "stok") stokCiz();
  });
}

// Seçili müşterinin cari hesabını günceller (tahsilat veya borç ekleme)
function cariFormuCiz(kutu, m) {
  kutu.innerHTML = `
    <form id="cu-form" class="form">
      <p class="tam">${kac("", m.ad_soyad)} · mevcut borç <strong>${para(cariBakiye(m.id))}</strong></p>
      <label>İşlem<select name="tur">
        <option value="tahsilat">Tahsilat (borç düşer)</option>
        <option value="borc">Borç ekle</option>
      </select></label>
      <label>Tutar<input name="tutar" type="number" step="0.01" min="0.01" required></label>
      <label id="cs-yontem-kutu">Ödeme yöntemi<select name="yontem">${Object.entries(YONTEM_AD).map(([k, ad]) => `<option value="${k}">${ad}</option>`).join("")}</select></label>
      <label class="tam">Açıklama<input name="aciklama" placeholder="Not"></label>
      <div class="hata tam" id="cs-hata"></div>
    </form>`;
  $("c-kaydet").textContent = "Cari güncelle";
  // Ödeme yöntemi yalnızca tahsilatta sorulur
  const yontemKutusu = $("cs-yontem-kutu");
  const turSecici = $("cu-form").elements.tur;
  const yontemGoster = () => { yontemKutusu.style.visibility = turSecici.value === "tahsilat" ? "visible" : "hidden"; };
  turSecici.addEventListener("change", yontemGoster);
  yontemGoster();
  $("cu-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const tur = f.get("tur");
    const tutar = Number(f.get("tutar"));
    if (!(tutar > 0)) return ($("cs-hata").textContent = "Pozitif bir tutar girin");
    if (tur === "tahsilat" && tutar > cariBakiye(m.id) + 0.005) return ($("cs-hata").textContent = "Tahsilat mevcut borçtan büyük olamaz");
    cariKaydet(m.id, tur, tutar, {
      islem: tur === "tahsilat" ? "tahsilat" : "borc_duzeltme",
      yontem: tur === "tahsilat" ? f.get("yontem") : null,
      aciklama: f.get("aciklama") || (tur === "tahsilat" ? "Tahsilat" : "Borç düzeltme")
    });
    bildir("Cari hesap güncellendi");
    cekmeceListele();
    cekmeceIcerigi();
    if (aktifSayfa === "musteri") musteriCiz();
  });
}

function cekmeceIcerigi() {
  cekmeceSekmeCiz();
  const yonetici = aktifKullanici && aktifKullanici.rol === "yonetici";
  const kutu = $("c-icerik");

  // Sekme seçili değilse ya da ürün seçilmediyse alt alan gizlenir, liste tüm yüksekliği kullanır
  const urunGerekli = ["duzenle", "barkod", "stok"].includes(cekmeceSekme);
  const altAlanBos = !cekmeceSekme || (urunGerekli && !cekmeceSecili) || (cekmeceSekme === "cari" && !cekmeceMusteri);
  $("cekmece").classList.toggle("liste-genis", altAlanBos);
  // Kaydet butonu yalnızca form açıkken görünür (panelin en altında)
  const formAcik = (yonetici && (cekmeceSekme === "ekle" || cekmeceSekme === "duzenle") && (cekmeceSekme === "ekle" || cekmeceSecili))
    || (cekmeceSekme === "stok" && cekmeceSecili) || (cekmeceSekme === "cari" && cekmeceMusteri);
  $("c-alt").classList.toggle("gorunur", !!formAcik);
  if (altAlanBos) {
    kutu.innerHTML = "";
    return;
  }

  if (cekmeceSekme === "stok") {
    stokFormuCiz(kutu, cekmeceSecili);
    return;
  }

  if (cekmeceSekme === "cari") {
    cariFormuCiz(kutu, cekmeceMusteri);
    return;
  }

  if (cekmeceSekme === "duzenle") {
    if (!yonetici) { kutu.innerHTML = '<div class="bos">Ürün düzenleme yalnızca yönetici içindir</div>'; return; }
    const secili = cekmeceSecili; cekmeceSecili = null;
    kutu.innerHTML = ""; $("cekmece").classList.add("liste-genis"); $("c-alt").classList.remove("gorunur");
    urunPenceresi(secili);
    return;
  }

  if (cekmeceSekme === "ekle") {
    if (!yonetici) { kutu.innerHTML = '<div class="bos">Yeni ürün ekleme yalnızca yönetici içindir</div>'; return; }
    yeniUrunPenceresi();
    return;
  }

  // Barkod / raf etiketi yazdır
  const ea = etiketAyari(), urun = cekmeceSecili;
  const boyutlar = ["40x30", "50x30", "50x40", "60x40", "70x50", "100x50"];
  kutu.innerHTML = `
    <div class="et-ayar">
      <label>Etiket türü<select id="et-tur"><option value="barkod" ${ea.tur === "barkod" ? "selected" : ""}>Barkod etiketi (ürüne yapıştır)</option><option value="raf" ${ea.tur === "raf" ? "selected" : ""}>Raf etiketi (büyük fiyat)</option></select></label>
      <label>Boyut (mm)<select id="et-boyut">${boyutlar.map(b => `<option value="${b}" ${ea.boyut === b ? "selected" : ""}>${b.replace("x", " × ")}</option>`).join("")}</select></label>
      <label>Adet<input id="et-adet" type="number" min="1" max="200" value="${ea.adet}"></label>
      <label class="onay-kutusu"><input id="et-fiyat" type="checkbox" ${ea.fiyat ? "checked" : ""}> Barkod etiketinde fiyat göster</label>
    </div>
    <div class="et-onizle"><iframe id="et-iframe" title="Önizleme"></iframe></div>
    <div class="modal-alt" style="margin-top:10px"><button class="btn ana" id="etiket-yazdir">Etiketi yazdır</button></div>`;
  const oku = () => ({ tur: $("et-tur").value, boyut: $("et-boyut").value, adet: Math.max(1, Math.min(200, Number($("et-adet").value) || 1)), fiyat: $("et-fiyat").checked });
  const goster = () => {
    const o = oku(); etiketAyariYaz(o);
    const [w, h] = o.boyut.split("x").map(Number);
    const f = $("et-iframe"); f.style.width = Math.round(w * 3.78 + 4) + "px"; f.style.height = Math.round(h * 3.78 + 4) + "px";
    f.srcdoc = etiketHtml(urun, { ...o, adet: 1 }, true);
  };
  ["et-tur", "et-boyut", "et-adet", "et-fiyat"].forEach(i => $(i).addEventListener("input", goster));
  goster();
  $("etiket-yazdir").addEventListener("click", () => etiketYazdir(urun, oku()));
}

// ---------- Ürün fotoğrafı ----------
// Seçilen görsel küçültülüp (en fazla 200 px) JPEG olarak ürün kaydına yazılır
function resmiKucult(dosya, maks = 200, bicim = "image/jpeg") {
  return new Promise((coz, red) => {
    const okuyucu = new FileReader();
    okuyucu.onload = () => {
      const img = new Image();
      img.onload = () => {
        const oran = Math.min(1, maks / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * oran);
        c.height = Math.round(img.height * oran);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        coz(c.toDataURL(bicim, 0.8));
      };
      img.onerror = () => red(new Error("Görsel okunamadı"));
      img.src = okuyucu.result;
    };
    okuyucu.onerror = () => red(new Error("Dosya okunamadı"));
    okuyucu.readAsDataURL(dosya);
  });
}

async function resimSonucu(f, mevcut) {
  if (f.get("resimKaldir")) return null;
  const dosya = f.get("resimDosya");
  if (dosya && dosya.size > 0) {
    try { return await resmiKucult(dosya); } catch (e) { bildir("Fotoğraf okunamadı"); }
  }
  return mevcut || null;
}

function urunResmi(u) {
  if (u && u.resim) return `<img class="foto" src="${u.resim}" alt="">`;
  return `<div class="foto foto-yer">${kac("", ((u && u.ad) || "?").trim().charAt(0).toUpperCase())}</div>`;
}

function resimAlani(mevcut) {
  return `<label class="tam">Fotoğraf<input type="file" name="resimDosya" accept="image/*"></label>
    ${mevcut ? `<div class="tam resim-mevcut"><img class="foto" src="${mevcut}" alt=""><label><input type="checkbox" name="resimKaldir"> Fotoğrafı kaldır</label></div>` : ""}`;
}

// "Ürün ekle": ekranı kaplayan yan panel yerine küçük bir pencerede açılır
function yeniUrunPenceresi() {
  const kat = ekleKategorisi;
  urunPaneliKapat();
  ekleKategorisi = kat;
  cekmeceSekme = "";
  urunPenceresi(null);
}
// Ürün ekleme / düzenleme formu: küçük pencerede. sonra: pencere kapanınca çağrılır (ör. kategori listesine geri dönmek için)
let urunPenceresiSonra = null;
function urunPenceresiBitti() { const f = urunPenceresiSonra; urunPenceresiSonra = null; if (f) f(); }
function urunPenceresi(u, sonra) {
  urunPenceresiSonra = sonra || null;
  modalAc(`<div class="modal-baslik">${u ? "Ürünü düzenle" : "Yeni ürün"}</div>
    <div id="yu-kutu" style="margin-top:8px;max-height:68vh;overflow:auto;padding-right:4px"></div>
    <div class="modal-alt"><button type="button" class="btn" id="yu-vazgec">Vazgeç</button><button type="submit" form="cu-form" class="btn ana">${u ? "Kaydet" : "Ürünü ekle"}</button></div>`, true);
  urunFormuCiz($("yu-kutu"), u);
  ekleKategorisi = null;
  $("yu-vazgec").addEventListener("click", () => { modalKapat(); urunPenceresiBitti(); });
  const ilk = document.querySelector('#yu-kutu [name="ad"]'); if (ilk) ilk.focus();
}

function urunFormuCiz(kutu, u) {
  const kategoriler = siraliKategoriler();
  const yeni = !u;
  const d = u || { ad: "", barkod: "", kategori_id: ekleKategorisi, satis_fiyati: "", alis_fiyati: "", kdv_orani: 20, birim: "adet", kritik_stok: 0 };
  kutu.innerHTML = `
    <form id="cu-form" class="form">
      <label class="tam">Ürün adı<input name="ad" value="${kac("", d.ad)}" required></label>
      <label class="tam">Barkod<input name="barkod" id="cu-barkod" value="${kac("", d.barkod)}" required><div style="display:flex;gap:6px;margin-top:6px"><button type="button" class="btn kucuk" id="cu-ean13">EAN-13 oluştur</button><button type="button" class="btn kucuk" id="cu-ean8">EAN-8 oluştur</button></div></label>
      <label>Kategori<div style="display:flex;gap:6px"><select name="kategori" id="cu-kat" style="flex:1"><option value="" ${d.kategori_id ? "" : "selected"}>Kategori yok</option>${kategoriler.map(k => `<option value="${k.id}" ${k.id === d.kategori_id ? "selected" : ""}>${kac("", k.ad)}</option>`).join("")}</select><button type="button" class="btn" id="cu-kat-ekle" title="Yeni kategori ekle" style="white-space:nowrap">+ Yeni</button></div></label>
      <label>Satış fiyatı<input name="satis" type="number" step="0.01" min="0" value="${d.satis_fiyati}" required></label>
      <label>Alış fiyatı<input name="alis" type="number" step="0.01" min="0" value="${d.alis_fiyati}"></label>
      <label>KDV %<input name="kdv" type="number" value="${d.kdv_orani}"></label>
      <label>Kritik stok<input name="kritik" type="number" step="0.001" min="0" value="${d.kritik_stok}"></label>
      <label>Satış birimi<select name="birim">${[["adet", "Adet"], ["kg", "Kilogram (tartılı)"], ["metre", "Metre"], ["litre", "Litre"]].map(([v, ad]) => `<option value="${v}" ${(d.birim || "adet") === v ? "selected" : ""}>${ad}</option>`).join("")}</select></label>
      <label>Terazi (PLU) kodu<input name="plu" inputmode="numeric" value="${kac("", d.plu || "")}" placeholder="Etiketli tartı için"></label>
      ${yeni ? '<label>Açılış stoku<input name="stok" type="number" step="0.001" min="0" value="0"></label>' : `<label>Stok<input value="${sayi(d.stok)}" disabled></label>`}
      ${resimAlani(d.resim)}
    </form>`;
  $("c-kaydet").textContent = yeni ? "Ürünü ekle" : "Kaydet";
  ["13", "8"].forEach(n => $("cu-ean" + n).addEventListener("click", async () => {
    const alan = $("cu-barkod");
    if (alan.value.trim() && !(await kucukPencere({ baslik: "Barkod değişsin mi?", mesaj: "Barkod alanında zaten bir barkod var. Yenisiyle değiştirilsin mi?", evet: "Değiştir" }))) return;
    alan.value = eanUret(Number(n));
    bildir("EAN-" + n + " barkod oluşturuldu: " + alan.value);
  }));
  $("cu-kat-ekle").addEventListener("click", async () => {
    const ad = await kucukPencere({ baslik: "Kategori oluştur", girdi: true, yer: "Kategori adı", evet: "Oluştur" });
    if (!ad) return;
    const temiz = ad.slice(0, 30);
    let k = DB.liste("kategoriler").find(x => String(x.ad).toLocaleLowerCase("tr") === temiz.toLocaleLowerCase("tr"));
    if (!k) { k = DB.ekle("kategoriler", { ad: temiz }); bildir("Kategori eklendi: " + temiz); kasaUrunleriCiz(); }
    const sec = $("cu-kat");
    if (![...sec.options].some(o => o.value === String(k.id))) sec.add(new Option(k.ad, k.id));
    sec.value = String(k.id);
  });
  // Barkod okuyucu okuduktan sonra Enter gönderir: form kaydedilip pencere kapanmasın, imleç fiyata geçsin
  $("cu-barkod").addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    e.preventDefault(); e.stopPropagation();
    const sonraki = document.querySelector("#cu-form [name=\"satis\"]"); if (sonraki) { sonraki.focus(); sonraki.select(); }
  });
  $("cu-form").addEventListener("submit", async e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const barkod = f.get("barkod").trim();
    if (DB.bul("urunler", x => !x.silindi && x.barkod === barkod && (!u || x.id !== u.id))) return bildir("Bu barkod zaten kayıtlı");
    const alanlar = {
      ad: f.get("ad").trim(), barkod, kategori_id: f.get("kategori") ? Number(f.get("kategori")) : null,
      satis_fiyati: Number(f.get("satis")), alis_fiyati: Number(f.get("alis") || 0),
      kdv_orani: Number(f.get("kdv")), kritik_stok: Number(f.get("kritik") || 0), aktif: 1, birim: f.get("birim") || "adet", plu: String(f.get("plu") || "").trim(),
      resim: await resimSonucu(f, u ? u.resim : null)
    };
    if (u) {
      DB.guncelle("urunler", u.id, alanlar);
      bildir("Ürün güncellendi");
      if (kutu.id === "yu-kutu") { modalKapat(); cekmeceListele(); kasaUrunleriCiz(); if (aktifSayfa === "urunler") urunlerCizSayfa(); urunPenceresiBitti(); return; }
    } else {
      const yeniUrun = DB.ekle("urunler", { ...alanlar, stok: 0 });
      const acilis = Number(f.get("stok") || 0);
      if (acilis > 0) DB.stokHareketi(yeniUrun.id, "giris", acilis, "Açılış stoku", aktifKullanici.id);
      bildir("Ürün eklendi");
      if (kutu.id === "yu-kutu") { modalKapat(); cekmeceSekme = ""; cekmeceSecili = null; kasaUrunleriCiz(); if (aktifSayfa === "urunler") urunlerCizSayfa(); urunPenceresiBitti(); return; }
      cekmeceSecili = yeniUrun;
      cekmeceSekme = "duzenle";
    }
    cekmeceListele();
    cekmeceIcerigi();
    kasaUrunleriCiz();
    if (aktifSayfa === "urunler") urunlerCizSayfa();
  });
}

function barkodCiz(svg, metin) {
  if (window.JsBarcode) {
    JsBarcode(svg, metin, { format: "CODE128", width: 2, height: 60, displayValue: true, fontSize: 14, margin: 4 });
  } else {
    svg.outerHTML = `<div style="font-family:monospace;font-size:20px;letter-spacing:2px">${kac("", metin)}</div>`;
  }
}

function etiketAyari() { try { return { tur: "barkod", boyut: "50x30", adet: 1, fiyat: true, ...JSON.parse(localStorage.getItem("etiket_ayar") || "{}") }; } catch (e) { return { tur: "barkod", boyut: "50x30", adet: 1, fiyat: true }; } }
function etiketAyariYaz(o) { try { localStorage.setItem("etiket_ayar", JSON.stringify(o)); } catch (e) {} }
// Etiketler: sayfa boyutu = etiket boyutu; her etiket ayrı sayfa (etiket yazıcısı rulosu). EAN-13 / EAN-8 barkodlar kendi biçiminde çizilir.
function etiketBarkodSvg(barkod, yuk, genislikPx) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  const b = String(barkod || "");
  const bicim = /^\d{13}$/.test(b) ? "EAN13" : /^\d{8}$/.test(b) ? "EAN8" : "CODE128";
  const dene = bc => JsBarcode(svg, b, { format: bc, width: 2, height: yuk, displayValue: true, fontSize: 14, margin: 0, textMargin: 1 });
  try { if (!window.JsBarcode) throw 0; try { dene(bicim); } catch (e) { dene("CODE128"); } } catch (e) { return `<div style="font-family:monospace;font-size:14px">${kac("", b)}</div>`; }
  svg.setAttribute("style", "width:100%;height:auto;max-height:100%");
  return svg.outerHTML;
}
function etiketHtmlTek(u, o, onizleme) {
  const [w, h] = String(o.boyut || "50x30").split("x").map(Number);
  const kucuk = h <= 30;
  const tarihYaz = new Date().toLocaleDateString("tr-TR");
  const ad = kac("", u.ad);
  let govde;
  if (o.tur === "raf") {
    const tam = Math.floor(Number(u.satis_fiyati)), kurus = String(Math.round((Number(u.satis_fiyati) - tam) * 100)).padStart(2, "0");
    govde = `<div class="ad raf">${ad}</div>
      <div class="fiyat"><span class="para">${tam.toLocaleString("tr-TR")}</span><span class="kurus">,${kurus}</span><span class="tl"> TL</span></div>
      <div class="alt"><div class="bk">${etiketBarkodSvg(u.barkod, 30)}</div><div class="tarih">${tarihYaz}</div></div>`;
  } else {
    govde = `<div class="ad">${ad}</div><div class="bk">${etiketBarkodSvg(u.barkod, kucuk ? 34 : 50)}</div>${o.fiyat ? `<div class="f">${para(u.satis_fiyati)}</div>` : ""}`;
  }
  const bir = `<div class="et ${o.tur}">${govde}</div>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>Etiket</title><style>
    @page { size: ${w}mm ${h}mm; margin: 0; }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; font-family: Arial, Helvetica, sans-serif; color: #000; background: #fff; }
    .et { width: ${w}mm; height: ${h}mm; padding: 1.5mm 2mm; display: flex; flex-direction: column; align-items: center; justify-content: space-between; text-align: center; overflow: hidden; page-break-after: always; ${onizleme ? "border: 1px dashed #999;" : ""} }
    .et:last-child { page-break-after: auto; }
    .ad { font-weight: 700; font-size: ${kucuk ? 9 : 11}px; line-height: 1.1; max-height: 2.3em; overflow: hidden; width: 100%; }
    .bk { flex: 1; min-height: 0; width: 100%; display: flex; align-items: center; justify-content: center; }
    .f { font-weight: 800; font-size: ${kucuk ? 14 : 18}px; line-height: 1; }
    .raf .ad.raf { font-size: ${kucuk ? 12 : 16}px; max-height: 2.3em; }
    .raf .fiyat { flex: 1; display: flex; align-items: center; justify-content: center; font-weight: 900; line-height: 1; }
    .raf .para { font-size: ${Math.round(h * 1.5)}px; } .raf .kurus { font-size: ${Math.round(h * 0.75)}px; align-self: flex-start; margin-top: ${Math.round(h * 0.25)}px; } .raf .tl { font-size: ${Math.round(h * 0.55)}px; align-self: flex-end; }
    .raf .alt { display: flex; align-items: flex-end; width: 100%; gap: 4px; height: ${kucuk ? 22 : 30}px; } .raf .alt .bk { flex: 1; height: 100%; } .raf .tarih { font-size: 8px; white-space: nowrap; }
  </style></head><body>${Array.from({ length: Math.max(1, o.adet || 1) }, () => bir).join("")}</body></html>`;
}
// Tek ürün ya da ürün listesi için etiket sayfası (listedeki her ürün "adet" kadar basılır)
function etiketHtml(u, o, onizleme) {
  const liste = Array.isArray(u) ? u : [u];
  const belgeler = liste.map(x => etiketHtmlTek(x, o, onizleme));
  if (belgeler.length === 1) return belgeler[0];
  const bas = belgeler[0].indexOf("<body>") + 6;
  return belgeler[0].slice(0, bas) + belgeler.map(d => d.slice(d.indexOf("<body>") + 6, d.lastIndexOf("</body>"))).join("") + "</body></html>";
}
// Ürünler sayfası: birden çok ürün için toplu etiket (kategoriye ya da aramaya göre süz, işaretle, yazdır)
function topluEtiketPenceresi() {
  const ea = etiketAyari();
  const kategoriler = siraliKategoriler();
  const secili = new Set();
  modalAc(`<div class="modal-baslik">Toplu etiket yazdır</div>
    <div class="et-ayar" style="margin-top:10px">
      <label>Kategori<select id="te-kat"><option value="">Tüm ürünler</option>${kategoriler.map(k => `<option value="${k.id}">${kac("", k.ad)}</option>`).join("")}<option value="yok">Kategorisiz</option></select></label>
      <label>Ara<input id="te-ara" placeholder="Ürün adı veya barkod" autocomplete="off"></label>
      <label>Etiket türü<select id="te-tur"><option value="barkod" ${ea.tur === "barkod" ? "selected" : ""}>Barkod etiketi</option><option value="raf" ${ea.tur === "raf" ? "selected" : ""}>Raf etiketi</option></select></label>
      <label>Boyut (mm)<select id="te-boyut">${["40x30", "50x30", "50x40", "60x40", "70x50", "100x50"].map(b => `<option value="${b}" ${ea.boyut === b ? "selected" : ""}>${b.replace("x", " × ")}</option>`).join("")}</select></label>
      <label>Ürün başına adet<input id="te-adet" type="number" min="1" max="50" value="1"></label>
      <label class="onay-kutusu"><input id="te-hepsi" type="checkbox"> Listedekilerin hepsini seç</label>
    </div>
    <div id="te-liste" style="max-height:38vh;overflow:auto;border:1px solid var(--line);border-radius:8px"></div>
    <div class="modal-alt"><span id="te-say" style="margin-right:auto;align-self:center;font-size:13px"></span><button class="btn" id="te-vazgec">Vazgeç</button><button class="btn ana" id="te-yazdir">Etiketleri yazdır</button></div>`, true);
  let gorunen = [];
  const sayiGuncelle = () => { $("te-say").textContent = secili.size + " ürün seçili · " + secili.size * (Math.max(1, Number($("te-adet").value) || 1)) + " etiket"; $("te-yazdir").disabled = !secili.size; };
  const listele = () => {
    const q = trKucuk($("te-ara").value.trim()), kat = $("te-kat").value;
    gorunen = DB.liste("urunler", u => u.aktif && (!q || trKucuk(u.ad).includes(q) || String(u.barkod || "").includes(q)) && (!kat || (kat === "yok" ? !u.kategori_id : String(u.kategori_id) === kat))).sort((x, y) => String(x.ad).localeCompare(String(y.ad), "tr")).slice(0, 500);
    $("te-liste").innerHTML = gorunen.map(u => `<label class="te-satir"><input type="checkbox" data-te="${u.id}" ${secili.has(u.id) ? "checked" : ""}><span>${kac("", u.ad)}<small>${kac("", u.barkod)}</small></span><b>${para(u.satis_fiyati)}</b></label>`).join("") || '<div class="bos" style="padding:14px">Ürün bulunamadı</div>';
    $("te-hepsi").checked = gorunen.length > 0 && gorunen.every(u => secili.has(u.id));
    sayiGuncelle();
  };
  $("te-kat").addEventListener("change", listele); $("te-ara").addEventListener("input", listele);
  $("te-adet").addEventListener("input", sayiGuncelle);
  $("te-hepsi").addEventListener("change", e => { gorunen.forEach(u => e.target.checked ? secili.add(u.id) : secili.delete(u.id)); listele(); });
  $("te-liste").addEventListener("change", e => { const c = e.target.closest("[data-te]"); if (!c) return; c.checked ? secili.add(Number(c.dataset.te)) : secili.delete(Number(c.dataset.te)); $("te-hepsi").checked = gorunen.every(u => secili.has(u.id)); sayiGuncelle(); });
  $("te-vazgec").addEventListener("click", modalKapat);
  $("te-yazdir").addEventListener("click", () => {
    const o = { ...ea, tur: $("te-tur").value, boyut: $("te-boyut").value, adet: Math.max(1, Math.min(50, Number($("te-adet").value) || 1)) };
    etiketAyariYaz({ ...ea, tur: o.tur, boyut: o.boyut });
    const urunler = DB.liste("urunler", u => secili.has(u.id));
    modalKapat();
    sayfaIcindeYazdir(etiketHtml(urunler, o), "etiket");
    bildir(urunler.length + " ürün için " + urunler.length * o.adet + " etiket yazıcıya gönderildi");
  });
  listele();
}
function etiketYazdir(u, o) {
  sayfaIcindeYazdir(etiketHtml(u, o || etiketAyari()), "etiket");
}

// ---------- Fiş yazdırma (termal yazıcı, 58/80 mm) ----------
function fisYazdir(satisId) {
  const s = DB.bul("satislar", x => x.id === satisId);
  if (!s) return;
  const kalemler = DB.liste("satis_kalemleri", k => k.satis_id === satisId);
  const odeme = DB.bul("odemeler", o => o.satis_id === satisId);
  const etiket = { nakit: "Nakit", kart: "Kart", acik_hesap: "Açık hesap" };
  const satirlar = kalemler.map(k => {
    const u = DB.bul("urunler", x => x.id === k.urun_id);
    return `<tr><td colspan="2">${kac("", u ? u.ad : "")}</td></tr>
      <tr><td>${sayi(k.miktar)} x ${para(k.birim_fiyat)}</td><td style="text-align:right">${para(k.tutar)}</td></tr>`;
  }).join("");
  const kas = DB.bul("kullanicilar", x => x.id === s.kullanici_id);
  sayfaIcindeYazdir(fisSablon({
    fisNo: s.fis_no,
    bilgi: [["Kasa " + (s.kasa_no || ""), tarih(s.tarih)], ["Fiş no", s.fis_no], ...(kas ? [["Kasiyer", kas.ad_soyad]] : []), ...(s.musteri_id ? [["Müşteri", (DB.bul("musteriler", m => m.id === s.musteri_id) || {}).ad_soyad || ""]] : [])],
    kalemler: kalemler.map(k => { const u = DB.bul("urunler", x => x.id === k.urun_id); return { ad: u ? u.ad : "", adet: sayi(k.miktar) + (OLCU_BIRIMLERI[u && u.birim] ? " " + OLCU_BIRIMLERI[u.birim] : ""), fiyat: k.birim_fiyat, tutar: k.tutar }; }),
    toplamlar: [["Ara toplam", para(s.ara_toplam)], ...(s.indirim > 0 ? [["İndirim", "-" + para(s.indirim)]] : []), ["Kalem", String(kalemler.length)]],
    toplam: s.toplam, odeme: odeme ? odemeYazisi(satisId) : etiket.nakit
  }), "fis");
}

// Yeni pencere açmadan, sayfa içindeki gizli bir çerçeveden yazdırır
// tur: "fis" (termal fiş), "etiket" (barkod etiketi), "belge" (ekstre, gün sonu vb.). Yazıcı seçimi her bilgisayarda ayrı tutulur.
const YAZICI_TURLERI = { fis: "Fiş yazıcısı", etiket: "Etiket yazıcısı", belge: "Belge / ekstre yazıcısı" };
function yaziciAyari() { try { return JSON.parse(localStorage.getItem("yazici_ayar") || "{}") || {}; } catch (e) { return {}; } }
function yaziciAyariYaz(a) { try { localStorage.setItem("yazici_ayar", JSON.stringify(a)); } catch (e) {} }
async function sayfaIcindeYazdir(html, tur) {
  const ad = yaziciAyari()[tur || "belge"];
  if (ad) {
    try {
      const y = await fetch("/api/yazici-sec", { method: "POST", headers: { "Content-Type": "application/json", ...tokenli() }, body: JSON.stringify({ ad }) });
      const c = await y.json();
      if (!c.ok) bildir((c.hata || "Yazıcı seçilemedi") + " · varsayılan yazıcı kullanılıyor");
    } catch (e) { bildir("Yazıcı seçilemedi · varsayılan yazıcı kullanılıyor"); }
  }
  yazdirCerceve(html);
  yaziciRozetIzle();
}
function yazdirCerceve(html) {
  const cerceve = document.createElement("iframe");
  cerceve.setAttribute("aria-hidden", "true");
  cerceve.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;";
  document.body.appendChild(cerceve);
  const temizle = () => setTimeout(() => cerceve.remove(), 1000);
  cerceve.onload = () => {
    const pencere = cerceve.contentWindow;
    pencere.onafterprint = temizle;
    pencere.focus();
    pencere.print();
    setTimeout(temizle, 60000);
  };
  cerceve.srcdoc = html;
}

// Satıştan sonra uygulama kendisi sorar: fiş yazdırılsın mı?
function fisSor(satis) {
  modalAc(`
    <div class="modal-baslik">${satis.fis_no} kesildi</div>
    <p>Toplam <strong>${para(satis.toplam)}</strong>. Fiş yazdırılsın mı?</p>
    <div class="modal-alt">
      <button class="btn" id="fs-hayir">Yazdırma</button>
      <button class="btn ana" id="fs-evet">Yazdır</button>
    </div>`);
  $("fs-hayir").addEventListener("click", modalKapat);
  $("fs-evet").addEventListener("click", () => { modalKapat(); fisYazdir(satis.id); });
  $("fs-evet").focus();
}

function panelKapat() {
  $("odeme-panel").style.display = "none";
  $("musteri-panel").style.display = "none";
}

// ---------- STOK ----------
let stokFiltre = "";
function stokCiz() {
  const urunler = DB.liste("urunler").filter(u => u.ad.toLowerCase().includes(stokFiltre.toLowerCase()) || u.barkod.includes(stokFiltre));
  const kritik = DB.liste("urunler", u => u.stok <= u.kritik_stok).length;
  const deger = DB.liste("urunler").reduce((t, u) => t + Math.max(0, u.stok) * u.alis_fiyati, 0);
  const sonHareket = DB.liste("stok_hareketleri").slice(-12).reverse();
  const urunAd = id => (DB.bul("urunler", x => x.id === id) || {}).ad || "";
  $("s-stok").innerHTML = `
    <div class="baslik-satir">
      <h2>Stok</h2>
      <div class="filtre"><input id="stok-ara" placeholder="Ürün veya barkod ara" value="${kac("", stokFiltre)}"><button class="btn" id="stok-say">Stok say${aktifSayim() ? " (devam ediyor)" : ""}</button></div>
    </div>
    <div class="ozet-kutular">
      <div class="ozet"><small>Ürün sayısı</small><strong>${DB.liste("urunler").length}</strong></div>
      <div class="ozet"><small>Kritik stok</small><strong>${kritik}</strong></div>
      <div class="ozet"><small>Stok maliyeti</small><strong>${para(deger)}</strong></div>
    </div>
    <div class="baslik-satir"><h2>Stok girişi / çıkışı</h2></div>
    <form id="stok-form" class="form" style="margin-bottom:16px">
      <label>Ürün<select name="urun">${DB.liste("urunler").map(u => `<option value="${u.id}">${kac("", u.ad)}</option>`).join("")}</select></label>
      <label>İşlem<select name="tur"><option value="giris">Giriş (alım)</option><option value="cikis">Çıkış (fire, zayi)</option><option value="sayim">Sayım düzeltmesi (yeni miktar)</option><option value="iade">İade (müşteriden)</option></select></label>
      <label>Miktar<input name="miktar" type="number" step="0.001" min="0" required></label>
      <label>Açıklama<input name="aciklama" placeholder="Fatura no, sebep"></label>
      <div class="tam"><button class="btn ana" type="submit">Kaydet</button></div>
    </form>
    <div class="baslik-satir"><h2>Ürünler</h2></div>
    <table class="tablo">
      <tr><th>Ürün</th><th class="sag">Stok</th><th class="sag">Kritik</th><th>Durum</th></tr>
      ${urunler.map(u => `<tr><td>${kac("", u.ad)}</td><td class="sag"><input class="stok-duzenle" data-stok-id="${u.id}" type="number" step="0.001" value="${u.stok}" style="width:90px;text-align:right"> ${u.birim}</td><td class="sag"><input class="stok-duzenle" data-kritik-id="${u.id}" type="number" step="0.001" min="0" value="${u.kritik_stok || 0}" style="width:70px;text-align:right"></td><td>${u.stok < 0 ? '<span class="rozet uyari">Eksi stok</span>' : u.stok <= u.kritik_stok ? '<span class="rozet uyari">Kritik</span>' : '<span class="rozet">Yeterli</span>'}</td></tr>`).join("")}
    </table>
    <div class="baslik-satir" style="margin-top:16px"><h2>Son hareketler</h2></div>
    <table class="tablo">
      <tr><th>Tarih</th><th>Ürün</th><th>Tür</th><th class="sag">Miktar</th><th>Açıklama</th></tr>
      ${sonHareket.map(h => `<tr><td>${tarih(h.tarih)}</td><td>${kac("", urunAd(h.urun_id))}</td><td>${h.tur}</td><td class="sag">${sayi(h.miktar)}</td><td>${kac("", h.aciklama)}</td></tr>`).join("")}
    </table>`;
  $("stok-ara").addEventListener("input", e => { stokFiltre = e.target.value; stokCiz(); });
  $("stok-say").addEventListener("click", () => stokSayimiAc());
  // Tablodaki stok ve kritik stok kutuları doğrudan düzenlenir (stok değişimi "sayım düzeltmesi" hareketi olarak kaydedilir)
  $("s-stok").querySelectorAll("[data-stok-id]").forEach(i => i.addEventListener("change", () => {
    const u = DB.bul("urunler", x => x.id === Number(i.dataset.stokId)), yeni = Number(i.value);
    if (!u || i.value === "" || !isFinite(yeni)) return stokCiz();
    const fark = Math.round((yeni - u.stok) * 1000) / 1000;
    if (fark) DB.stokHareketi(u.id, "sayim", fark, "Elle düzeltme", aktifKullanici.id);
    bildir(u.ad + " stoku " + sayi(yeni) + " yapıldı");
    stokCiz();
  }));
  $("s-stok").querySelectorAll("[data-kritik-id]").forEach(i => i.addEventListener("change", () => {
    const u = DB.bul("urunler", x => x.id === Number(i.dataset.kritikId)), yeni = Number(i.value);
    if (!u || i.value === "" || !(yeni >= 0)) return stokCiz();
    DB.guncelle("urunler", u.id, { kritik_stok: yeni });
    stokCiz();
  }));
  $("stok-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const urunId = Number(f.get("urun"));
    const tur = f.get("tur");
    const miktar = Number(f.get("miktar"));
    const aciklama = f.get("aciklama");
    const u = DB.bul("urunler", x => x.id === urunId);
    if (!u || !(miktar >= 0)) return;
    if (tur === "sayim") {
      DB.stokHareketi(urunId, "sayim", miktar - u.stok, aciklama || "Sayım", aktifKullanici.id);
    } else if (tur === "cikis") {
      if (miktar > u.stok) return bildir("Stok yetersiz");
      DB.stokHareketi(urunId, "cikis", -miktar, aciklama, aktifKullanici.id);
    } else {
      DB.stokHareketi(urunId, tur, miktar, aciklama, aktifKullanici.id);
    }
    bildir("Stok güncellendi");
    stokCiz();
  });
}

// ---------- ÜRÜNLER (yönetici) ----------
let topluSilModu = false;
let urunFiltre = "";
const topluSecili = new Set();
function urunlerCizSayfa() {
  const kategoriler = siraliKategoriler();
  const aranan = trKucuk(urunFiltre.trim());
  const liste = DB.liste("urunler", u => !aranan || trKucuk(u.ad).includes(aranan) || String(u.barkod || "").includes(aranan));
  const hepsiSecili = liste.length > 0 && liste.every(u => topluSecili.has(u.id));
  $("s-urunler").innerHTML = `
    <div class="baslik-satir">
      <h2>Ürünler</h2>
      <div style="flex:1;display:flex;justify-content:center;min-width:180px"><input id="u-ara" type="search" placeholder="Ürün veya barkod ara" value="${kac("", urunFiltre)}" autocomplete="off" style="width:100%;max-width:380px;height:38px;padding:0 14px;border-radius:19px"></div>
      <div class="sekmeler">
        ${topluSilModu ? `<label class="sekme" style="cursor:pointer"><input type="checkbox" id="u-hepsi" ${hepsiSecili ? "checked" : ""}> Tümünü seç</label>
        <button class="sekme tehlike" id="u-toplu-onay" ${topluSecili.size ? "" : "disabled"}>Seçilileri sil (${topluSecili.size})</button>
        <button class="sekme" id="u-toplu-vazgec">Vazgeç</button>` : `<button class="sekme" id="u-toplu">Toplu sil</button>`}
        <button class="sekme" id="u-yeni">Ürün ekle</button>
        <button class="sekme" id="u-duzenle">Ürünü düzenle</button>
        <button class="sekme" id="u-stok">Stok güncelle</button>
        <button class="sekme" id="u-say">Stok say${aktifSayim() ? " (devam ediyor)" : ""}</button>
        <button class="sekme" id="u-cari">Cari güncelle</button>
        <button class="sekme" id="u-barkod">Barkod yazdır</button>
        <button class="sekme" id="u-toplu-etiket">Toplu etiket</button>
        <button class="sekme" id="u-barkod-birlestir">Barkod birleştir</button>
      </div>
    </div>
    <table class="tablo">
      <tr>${topluSilModu ? "<th></th>" : ""}<th>Barkod</th><th>Ad</th><th>Kategori</th><th class="sag">Satış</th><th class="sag">Alış</th><th class="sag">KDV</th><th></th></tr>
      ${liste.map(u => `<tr data-urun-id="${u.id}" style="cursor:pointer">
        ${topluSilModu ? `<td><input type="checkbox" data-sec="${u.id}" ${topluSecili.has(u.id) ? "checked" : ""}></td>` : ""}
        <td>${u.barkod}</td><td>${kac("", u.ad)}</td>
        <td>${kac("", (kategoriler.find(k => k.id === u.kategori_id) || {}).ad || "—")}</td>
        <td class="sag">${para(u.satis_fiyati)}</td><td class="sag">${para(u.alis_fiyati)}</td><td class="sag">%${u.kdv_orani}</td>
        <td><button class="btn kucuk" data-duzenle="${u.id}">Düzenle</button> <button class="btn kucuk" data-barkod="${u.id}">Barkod</button> <button class="btn kucuk" data-pasif="${u.id}">${u.aktif ? "Pasifleştir" : "Aktifleştir"}</button> <button class="btn kucuk tehlike" data-urun-sil="${u.id}">Sil</button></td>
      </tr>`).join("")}
    </table>`;
  // Ürün ayarları bu sayfada: sağdan yarım açılan panelde ekleme, düzenleme ve barkod yazdırma
  if ($("u-ara")) {
    let zaman;
    $("u-ara").addEventListener("input", e => {
      urunFiltre = e.target.value;
      clearTimeout(zaman);
      zaman = setTimeout(() => { urunlerCizSayfa(); const k = $("u-ara"); k.focus(); k.setSelectionRange(k.value.length, k.value.length); }, 200);
    });
  }
  if ($("u-toplu")) $("u-toplu").addEventListener("click", () => { topluSilModu = true; topluSecili.clear(); urunlerCizSayfa(); });
  if ($("u-toplu-vazgec")) $("u-toplu-vazgec").addEventListener("click", () => { topluSilModu = false; topluSecili.clear(); urunlerCizSayfa(); });
  if ($("u-hepsi")) $("u-hepsi").addEventListener("change", e => { topluSecili.clear(); if (e.target.checked) liste.forEach(u => topluSecili.add(u.id)); urunlerCizSayfa(); });
  $("s-urunler").querySelectorAll("[data-sec]").forEach(c => c.addEventListener("change", () => { const id = Number(c.dataset.sec); c.checked ? topluSecili.add(id) : topluSecili.delete(id); urunlerCizSayfa(); }));
  if ($("u-toplu-onay")) $("u-toplu-onay").addEventListener("click", () => {
    const n = topluSecili.size;
    modalAc(`
      <div class="modal-baslik">${n} ürünü sil</div>
      <p style="margin:10px 0">Seçilen <strong>${n}</strong> ürün listelerden, kategoriden ve kasadan kalkar. Geçmiş satış fişleri ve stok hareketleri bozulmaz. Silinsin mi?</p>
      <div class="modal-alt tam"><button type="button" class="btn" id="ts-vazgec">Vazgeç</button><button type="button" class="btn tehlike" id="ts-sil">Evet, ${n} ürünü sil</button></div>`);
    $("ts-vazgec").addEventListener("click", modalKapat);
    $("ts-sil").addEventListener("click", () => {
      topluSecili.forEach(id => DB.guncelle("urunler", id, { silindi: 1, aktif: 0, kategori_id: null }));
      topluSilModu = false; topluSecili.clear();
      modalKapat(); urunlerCizSayfa(); kasaUrunleriCiz();
      bildir(n + " ürün silindi");
    });
  });
  $("u-yeni").addEventListener("click", () => urunAyarlariAc("ekle"));
  $("u-duzenle").addEventListener("click", () => urunAyarlariAc("duzenle"));
  $("u-stok").addEventListener("click", () => urunAyarlariAc("stok"));
  $("u-say").addEventListener("click", () => stokSayimiAc());
  $("u-cari").addEventListener("click", () => urunAyarlariAc("cari"));
  $("u-barkod").addEventListener("click", () => urunAyarlariAc("barkod"));
  $("u-toplu-etiket").addEventListener("click", topluEtiketPenceresi);
  $("u-barkod-birlestir").addEventListener("click", barkodBirlestirAc);
  $("s-urunler").querySelectorAll("tr[data-urun-id]").forEach(tr => tr.addEventListener("click", e => {
    if (topluSilModu || e.target.closest("button, input, a, label, select")) return;
    urunAyarlariAc("duzenle", Number(tr.dataset.urunId));
  }));
  $("s-urunler").querySelectorAll("[data-duzenle]").forEach(b => b.addEventListener("click", () => urunAyarlariAc("duzenle", Number(b.dataset.duzenle))));
  $("s-urunler").querySelectorAll("[data-barkod]").forEach(b => b.addEventListener("click", () => urunAyarlariAc("barkod", Number(b.dataset.barkod))));
  $("s-urunler").querySelectorAll("[data-urun-sil]").forEach(b => b.addEventListener("click", () => urunSil(Number(b.dataset.urunSil))));
  $("s-urunler").querySelectorAll("[data-pasif]").forEach(b => b.addEventListener("click", () => {
    const u = DB.bul("urunler", x => x.id === Number(b.dataset.pasif));
    DB.guncelle("urunler", u.id, { aktif: u.aktif ? 0 : 1 });
    urunlerCizSayfa();
  }));
}
function urunSil(id) {
  const u = DB.bul("urunler", x => x.id === id);
  if (!u) return;
  modalAc(`
    <div class="modal-baslik">Ürünü sil · ${kac("", u.ad)}</div>
    <p style="margin:10px 0">Bu ürün listelerden, kategoriden ve kasadan kalkar. Geçmiş satış fişleri ve stok hareketleri bozulmaz. Silinsin mi?</p>
    <div class="modal-alt tam"><button type="button" class="btn" id="us-vazgec">Vazgeç</button><button type="button" class="btn tehlike" id="us-sil">Evet, sil</button></div>`);
  $("us-vazgec").addEventListener("click", modalKapat);
  $("us-sil").addEventListener("click", () => {
    DB.guncelle("urunler", id, { silindi: 1, aktif: 0, kategori_id: null });
    modalKapat();
    urunlerCizSayfa();
    kasaUrunleriCiz();
    bildir("Ürün silindi");
  });
}
// EAN-13 / EAN-8: son hane kontrol hanesidir. Mağaza içi kullanım için "2" ile başlayan (20-29) numaralar üretilir.
function eanKontrolHanesi(gövde) {
  let t = 0;
  for (let i = 0; i < gövde.length; i++) { const r = Number(gövde[gövde.length - 1 - i]); t += r * (i % 2 === 0 ? 3 : 1); }
  return String((10 - (t % 10)) % 10);
}
function eanUret(uzunluk) {
  const var_mi = new Set(DB.liste("urunler").map(u => String(u.barkod)));
  for (let deneme = 0; deneme < 500; deneme++) {
    let g = "2";
    while (g.length < uzunluk - 1) g += Math.floor(Math.random() * 10);
    const kod = g + eanKontrolHanesi(g);
    if (!var_mi.has(kod)) return kod;
  }
  return "";
}
function urunlerCiz() { urunlerCizSayfa(); }

// ---------- ALIŞ FATURASI ----------
function alisKalemTablosu(f) {
  return `<table class="fis-kalem">
    <tr><th>Ürün</th><th class="sag">Adet</th><th class="sag">Birim fiyat</th><th class="sag">KDV</th><th class="sag">Tutar</th></tr>
    ${f.kalemler.map(k => `<tr><td>${kac("", k.ad)}${k.fatura_ad ? ` <small style="opacity:.6">(faturada: ${kac("", k.fatura_ad)})</small>` : ""}</td><td class="sag">${sayi(k.adet)}</td><td class="sag">${para(k.fiyat)}</td><td class="sag">%${k.kdv}</td><td class="sag">${para(k.tutar)}</td></tr>`).join("")}
    <tr><td colspan="4">Ara toplam ${para(f.ara_toplam)} · KDV ${para(f.kdv_tutari)}</td><td class="sag"><strong>${para(f.toplam)}</strong></td></tr>
  </table>`;
}
const ODEME_AD = { acik_hesap: "Açık hesap (vadeli)", nakit: "Nakit ödendi", kart: "Kart ödendi", havale: "Havale / EFT ödendi" };
// Faturalar sayfası: altında "Alış faturası" ve "Satış faturası" sekmeleri
let faturaSekme = "alis";
function faturaCiz() {
  $("s-fatura").innerHTML = `
    <div class="baslik-satir"><h2>Faturalar</h2>
      <div><button class="btn ${faturaSekme === "alis" ? "ana" : ""}" id="fs-alis">Alış faturası</button> <button class="btn ${faturaSekme === "satis" ? "ana" : ""}" id="fs-satis">Satış faturası</button></div>
    </div>
    <div id="fatura-icerik"></div>`;
  $("fs-alis").addEventListener("click", () => { faturaSekme = "alis"; faturaCiz(); });
  $("fs-satis").addEventListener("click", () => { faturaSekme = "satis"; faturaCiz(); });
  if (faturaSekme === "satis") satisFaturaCiz(); else alisFaturaCiz();
}

// Satış faturası: kesilen satış fişleri listelenir (e-Arşiv ile fatura kesme entegrasyonu hazırlanınca buradan yapılacak)
function satisFaturaCiz() {
  const liste = DB.liste("satislar").slice().sort((x, y) => y.id - x.id).slice(0, 300);
  const musteriAd = id => (DB.bul("musteriler", m => m.id === id) || {}).ad_soyad || "Perakende";
  $("fatura-icerik").innerHTML = `
    <p style="font-size:13px;opacity:.75;margin:0 0 10px">Satışlarınız (son 300 fiş). NES e-Arşiv ile otomatik fatura kesme yakında bu sekmeden yapılacak.</p>
    <table class="tablo">
      <tr><th>Tarih</th><th>Fiş no</th><th>Müşteri</th><th class="sag">Toplam</th><th>Durum</th></tr>
      ${liste.map(s => `<tr><td>${tarih(s.tarih)}</td><td>${kac("", s.fis_no)}</td><td>${kac("", musteriAd(s.musteri_id))}</td><td class="sag"><strong>${para(s.toplam)}</strong></td><td>${s.durum === "iptal" ? '<span class="rozet uyari">İptal</span>' : '<span class="rozet">Satıldı</span>'}</td></tr>`).join("") || '<tr><td colspan="5">Henüz satış yok</td></tr>'}
    </table>`;
}

function alisFaturaCiz() {
  const liste = DB.veri().alis_faturalari.filter(f => f.durum !== "birlesti").sort((a, b) => b.id - a.id);
  const aktif = liste.filter(f => f.durum === "aktif");
  const bekleyen = liste.filter(f => f.durum === "onay_bekliyor");
  const ay = new Date().toISOString().slice(0, 7);
  const aylik = aktif.filter(f => f.tarih.slice(0, 7) === ay).reduce((t, f) => t + f.toplam, 0);
  const borc = DB.liste("musteriler", m => m.tedarikci).reduce((t, m) => t + Math.max(0, -cariOzet(m.id).bakiye), 0);
  $("fatura-icerik").innerHTML = `
    <div class="baslik-satir"><h2>Alış faturaları</h2><div><label class="btn" style="cursor:pointer">Dosyadan yükle (XML / Excel / PDF)<input id="f-dosya" type="file" accept=".xml,.xlsx,.csv,.pdf" hidden></label> <button class="btn ana" id="f-yeni">Yeni alış faturası</button></div></div>
    ${bekleyen.length ? `<p style="margin:0 0 10px;padding:8px 12px;border-radius:8px;background:rgba(255,190,0,.16)"><strong>${bekleyen.length} fatura</strong> onayınızı bekliyor. Satırdaki "İncele ve işle" ile ürünleri kontrol edip stoğa ve tedarikçi carisine işleyin.</p>` : ""}
    <div class="ozet-kutular">
      <div class="ozet"><small>Bu ay alış</small><strong>${para(aylik)}</strong></div>
      <div class="ozet"><small>Tedarikçilere borcumuz</small><strong>${para(borc)}</strong></div>
      <div class="ozet"><small>Fatura sayısı</small><strong>${aktif.length}</strong></div>
    </div>
    <p style="font-size:13px;opacity:.75;margin:0 0 10px">SOFTNEST cari'den gelen faturalar buraya otomatik düşer. Fatura işlenince ürün stoğu artar, alış fiyatı güncellenir ve tedarikçi carisine yazılır.</p>
    <table class="tablo">
      <tr><th>Tarih</th><th>Fatura no</th><th>Tedarikçi</th><th>Kaynak</th><th>Ödeme</th><th class="sag">Toplam</th><th>Durum</th><th></th></tr>
      ${liste.map(f => `<tr>
        <td>${tarih(f.tarih)}</td><td>${kac("", f.fatura_no)}</td><td>${kac("", f.tedarikci_ad)}</td>
        <td>${f.kaynak === "cari" ? "SOFTNEST cari" : "Elle"}</td><td>${ODEME_AD[f.odeme] || f.odeme}</td>
        <td class="sag"><strong>${para(f.toplam)}</strong></td>
        <td>${f.durum === "iptal" ? '<span class="rozet uyari">İptal</span>' : f.durum === "onay_bekliyor" ? '<span class="rozet uyari">Onay bekliyor</span>' : '<span class="rozet">İşlendi</span>'}</td>
        <td>${f.durum === "onay_bekliyor" ? `<button class="btn kucuk ana" data-f-esles="${f.id}">İncele ve işle</button>` : `<button class="btn kucuk" data-f-gor="${f.id}">Görüntüle</button> ${f.durum === "iptal" ? "" : `<button class="btn kucuk" data-f-duzenle="${f.id}">Düzenle</button> <button class="btn kucuk tehlike" data-f-iptal="${f.id}">İptal</button>`}`}</td>
      </tr>`).join("") || '<tr><td colspan="8">Henüz alış faturası yok</td></tr>'}
    </table>`;
  $("f-yeni").addEventListener("click", () => faturaFormu());
  $("f-dosya").addEventListener("change", e => { const d = e.target.files[0]; e.target.value = ""; faturaDosyasiYukle(d); });
  $("s-fatura").querySelectorAll("[data-f-esles]").forEach(b => b.addEventListener("click", () => { const f = DB.veri().alis_faturalari.find(x => x.id === Number(b.dataset.fEsles)); if (f) faturaFormu({ ...f.ham, kaynak: f.kaynak, dis_id: f.dis_id }, f.id); }));
  $("s-fatura").querySelectorAll("[data-f-duzenle]").forEach(b => b.addEventListener("click", () => {
    const f = DB.veri().alis_faturalari.find(x => x.id === Number(b.dataset.fDuzenle));
    if (!f) return;
    faturaFormu({ fatura_no: f.fatura_no, tarih: f.tarih, odeme: f.odeme, kaynak: f.kaynak, dis_id: f.dis_id, tedarikci: { ad: f.tedarikci_ad }, kalemler: f.kalemler.map(k => ({ barkod: k.barkod, ad: k.fatura_ad || k.ad, adet: k.adet, fiyat: k.fiyat, kdv: k.kdv, urun_id: k.urun_id })), uyari: "Düzenleme: kaydedince eski fatura geri alınır (stok ve cari), düzeltilmiş fatura yeniden işlenir." }, null, f.id);
  }));
  $("s-fatura").querySelectorAll("[data-f-gor]").forEach(b => b.addEventListener("click", () => faturaGor(Number(b.dataset.fGor))));
  $("s-fatura").querySelectorAll("[data-f-iptal]").forEach(b => b.addEventListener("click", () => faturaIptalEt(Number(b.dataset.fIptal))));
}

function faturaGor(id, geri) {
  const f = DB.veri().alis_faturalari.find(x => x.id === id);
  if (!f) return;
  modalAc(`
    <div class="modal-baslik">Alış faturası · ${kac("", f.fatura_no)}</div>
    <p style="margin:8px 0">${kac("", f.tedarikci_ad)} · ${tarih(f.tarih)} · ${ODEME_AD[f.odeme] || f.odeme}${f.durum === "iptal" ? " · <strong>İPTAL</strong>" : ""}</p>
    <table class="tablo"><tr><th>Barkod</th><th>Ürün</th><th class="sag">Adet</th><th class="sag">Birim fiyat</th><th class="sag">KDV</th><th class="sag">Tutar</th></tr>
      ${f.kalemler.map(k => `<tr><td>${kac("", k.barkod)}</td><td>${kac("", k.ad)}</td><td class="sag">${sayi(k.adet)}</td><td class="sag">${para(k.fiyat)}</td><td class="sag">%${k.kdv}</td><td class="sag">${para(k.tutar)}</td></tr>`).join("")}
    </table>
    <p style="text-align:right;margin:10px 0">Ara toplam ${para(f.ara_toplam)} · KDV ${para(f.kdv_tutari)} · <strong>Toplam ${para(f.toplam)}</strong></p>
    <div class="modal-alt tam"><button type="button" class="btn" id="fg-kapat">Kapat</button></div>`);
  $("fg-kapat").addEventListener("click", geri || modalKapat);
}

function faturaIptalEt(id) {
  const f = DB.veri().alis_faturalari.find(x => x.id === id);
  if (!f) return;
  modalAc(`
    <div class="modal-baslik">Faturayı iptal et · ${kac("", f.fatura_no)}</div>
    <p style="margin:10px 0">Faturadaki ürünlerin stok girişi geri alınır ve tedarikçi carisine ters kayıt yazılır. Fatura kaydı silinmez, "İptal" olarak kalır. Devam edilsin mi?</p>
    <div class="modal-alt tam"><button type="button" class="btn" id="fi-vazgec">Vazgeç</button><button type="button" class="btn tehlike" id="fi-onay">Evet, iptal et</button></div>`);
  $("fi-vazgec").addEventListener("click", modalKapat);
  $("fi-onay").addEventListener("click", () => {
    FATURA.faturaIptal(DB.veri(), id);
    DB.kaydet(); modalKapat(); faturaCiz(); menuRozetleri();
    bildir("Fatura iptal edildi, stok geri alındı");
  });
}

// Fatura formu: elle giriş, dosyadan yükleme (XML/Excel/PDF) ve bulutta eşleştirme bekleyen faturalar için ortaktır.
// Faturadaki ürün adı stoktakinden farklı yazılmış olabilir: benzer stok ürünü bulunur, "aynı ürün mü?" diye sorulur
// ve onaylanırsa stoktaki ad geçerli olur (eşleşme sonraki faturalar için hatırlanır).
function faturaFormu(ilk, bekleyenId, duzenleId) {
  ilk = ilk || {};
  const tedarikciler = DB.liste("musteriler", m => m.tedarikci);
  const bugun = new Date().toISOString().slice(0, 10);
  const yeniSatir = () => ({ barkod: "", ad: "", adet: 1, fiyat: 0, kdv: 20, satis: "", urun_id: null, onay: true, adaylar: [] });
  const eslestir = s => {
    s.adaylar = FATURA.adaylar(DB.veri(), { barkod: s.barkod, ad: s.ad }, 6);
    const ust = s.adaylar[0];
    if (ust && ust.skor >= 0.95) { s.urun_id = ust.urun.id; s.onay = true; }
    else if (ust && ust.skor >= 0.5) { s.urun_id = ust.urun.id; s.onay = false; }
    else { s.urun_id = null; s.onay = true; }
  };
  const satirlar = (ilk.kalemler && ilk.kalemler.length ? ilk.kalemler : [null]).map(k => {
    const s = yeniSatir();
    if (k) { s.barkod = k.barkod || ""; s.ad = k.ad || ""; s.adet = k.adet; s.fiyat = k.fiyat; s.kdv = k.kdv === undefined ? 20 : k.kdv; if (k.urun_id) { s.urun_id = k.urun_id; } else eslestir(s); }
    return s;
  });
  modalAc(`
    <div class="fa-ust">
      <div><div class="fa-baslik">${duzenleId ? "Faturayı düzenle" : bekleyenId ? "Onay bekleyen fatura" : "Yeni alış faturası"}</div><div class="fa-alt-baslik">Tedarikçi faturasını girin; ürünler stoğa, tutar tedarikçi carisine işlenir.</div></div>
      <button type="button" class="btn" id="fa-vazgec-ust" aria-label="Kapat">✕</button>
    </div>
    ${ilk.uyari ? `<div class="fa-uyari">${kac("", ilk.uyari)}</div>` : ""}
    <form id="fa-form" class="fa-form">
      <section class="fa-bilgi">
        <label class="fa-alan fa-genis">Tedarikçi<input name="ted" list="fa-ted" required value="${kac("", (ilk.tedarikci && ilk.tedarikci.ad) || "")}" placeholder="Firma adı (yeniyse kaydedilir)"><datalist id="fa-ted">${tedarikciler.map(t => `<option value="${kac("", t.ad_soyad)}">`).join("")}</datalist></label>
        <label class="fa-alan">Vergi no<input name="vergi" value="${kac("", (ilk.tedarikci && ilk.tedarikci.vergi_no) || "")}"></label>
        <label class="fa-alan">Fatura no<input name="no" value="${kac("", ilk.fatura_no || "")}" placeholder="boşsa otomatik"></label>
        <label class="fa-alan">Fatura tarihi<input name="tarih" type="date" value="${ilk.tarih ? String(ilk.tarih).slice(0, 10) : bugun}" required></label>
        <label class="fa-alan">Ödeme<select name="odeme">${Object.entries(ODEME_AD).map(([k, v]) => `<option value="${k}" ${k === (ilk.odeme || "acik_hesap") ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      </section>
      <section class="fa-satirlar-kutu"><table class="fa-tablo" id="fa-satirlar"></table></section>
      <div class="fa-satir-ekle-alani"><button type="button" class="btn" id="fa-satir-ekle">+ Ürün satırı ekle</button><span>Faturadaki ad stoktakinden farklıysa benzer ürün önerilir; onayladığınızda stoktaki ad geçerli olur.</span></div>
      <footer class="fa-alt">
        <div id="fa-toplam" class="fa-toplam-kutu"></div>
        <div class="fa-dugmeler"><button type="button" class="btn" id="fa-vazgec">Vazgeç</button><button class="btn ana fa-isle" type="submit">Faturayı işle</button></div>
      </footer>
    </form>`, "cok");
  $("fa-vazgec-ust").addEventListener("click", modalKapat);
  const satirToplami = s => (Number(s.adet) || 0) * (Number(s.fiyat) || 0) * (1 + (Number(s.kdv) || 0) / 100);
  const dahilYaz = s => { const v = (Number(s.fiyat) || 0) * (1 + (Number(s.kdv) || 0) / 100); return v ? String(Math.round(v * 10000) / 10000) : ""; };
  // Fiyat, KDV ya da adet değişince KDV dahil fiyat ve satır toplamı kutuları aynı satırda canlı güncellenir
  const satirGuncelle = (i, kaynak) => {
    const s = satirlar[i], satir = $("fa-satirlar").querySelector(`[data-i="${i}"][data-a="fiyat"]`);
    if (!satir) return;
    const alan = a2 => $("fa-satirlar").querySelector(`[data-i="${i}"][data-a="${a2}"]`);
    if (kaynak === "dahil") { const dh = Number(alan("dahil").value) || 0; s.fiyat = Math.round(dh / (1 + (Number(s.kdv) || 0) / 100) * 10000) / 10000; alan("fiyat").value = s.fiyat || ""; }
    else if (kaynak !== "adet") alan("dahil").value = dahilYaz(s);
    const st = $("fa-st-" + i); if (st) st.textContent = para(satirToplami(s));
  };
  const topla = () => {
    let ara = 0, kdv = 0;
    satirlar.forEach(s => { const n = (Number(s.adet) || 0) * (Number(s.fiyat) || 0); ara += n; kdv += n * (Number(s.kdv) || 0) / 100; });
    const sor = satirlar.filter(s => !s.onay).length;
    $("fa-toplam").innerHTML = (sor ? `<div class="fa-sor">${sor} satırda "aynı ürün mü?" sorusu yanıt bekliyor</div>` : "") + `<div><small>Ara toplam</small><b>${para(ara)}</b></div><div><small>KDV</small><b>${para(kdv)}</b></div><div class="genel"><small>Genel toplam</small><b>${para(ara + kdv)}</b></div>`;
  };
  const ciz = () => {
    $("fa-satirlar").innerHTML = '<thead><tr><th class="c-barkod">Barkod</th><th class="c-ad">Faturadaki ad</th><th class="c-stok">Stoktaki ürün</th><th class="c-adet">Adet</th><th class="c-fiyat">Alış fiyatı (KDV hariç)</th><th class="c-kdv">KDV %</th><th class="c-fiyat">Alış fiyatı (KDV dahil)</th><th class="c-fiyat">Satış fiyatı</th><th class="c-fiyat">Satır toplamı (KDV dahil)</th><th class="c-sil"></th></tr></thead>' + satirlar.map((s, i) => {
      const secili = s.urun_id && DB.bul("urunler", x => x.id === s.urun_id);
      const secenekler = '<option value="">+ Yeni ürün olarak aç</option>' + s.adaylar.map(a => `<option value="${a.urun.id}" ${a.urun.id === s.urun_id ? "selected" : ""}>${kac("", a.urun.ad)} (%${Math.round(a.skor * 100)})</option>`).join("") +
        (secili && !s.adaylar.some(a => a.urun.id === s.urun_id) ? `<option value="${secili.id}" selected>${kac("", secili.ad)}</option>` : "");
      return `<tr class="${s.onay ? "" : "fa-sor-satir"}">
      <td><input data-i="${i}" data-a="barkod" value="${kac("", s.barkod)}" placeholder="Barkod ekle"></td>
      <td><input data-i="${i}" data-a="ad" value="${kac("", s.ad)}"></td>
      <td><select data-i="${i}" data-sec>${secenekler}</select><button type="button" class="fa-ara-btn" data-ara="${i}">🔍 Stoktan ara…</button>
        ${s.onay ? (s.urun_id ? '<div style="font-size:11px;color:#1e8e4e">Stok ürünüyle eşleşti</div>' : '<div style="font-size:11px;opacity:.7">Stokta yok: yeni ürün açılacak</div>') : `<div style="font-size:12px;margin-top:3px"><strong>Aynı ürün mü?</strong> <button type="button" class="btn kucuk" data-evet="${i}">Evet, aynı</button> <button type="button" class="btn kucuk" data-hayir="${i}">Hayır, yeni</button></div>`}</td>
      <td><input data-i="${i}" data-a="adet" type="number" step="0.001" min="0" value="${s.adet}"></td>
      <td><input data-i="${i}" data-a="fiyat" type="number" step="0.01" min="0" value="${s.fiyat}"></td>
      <td><input data-i="${i}" data-a="kdv" type="number" step="1" min="0" value="${s.kdv}"></td>
      <td><input data-i="${i}" data-a="dahil" type="number" step="0.01" min="0" value="${dahilYaz(s)}"></td>
      <td><input data-i="${i}" data-a="satis" type="number" step="0.01" min="0" value="${s.satis !== "" ? s.satis : (secili ? secili.satis_fiyati : "")}" placeholder="${secili ? "" : "yeni ürün"}"></td>
      <td class="fa-st" id="fa-st-${i}">${para(satirToplami(s))}</td>
      <td><button type="button" class="btn kucuk tehlike" data-sil="${i}">×</button></td></tr>`;
    }).join("");
    const tablo = $("fa-satirlar");
    tablo.querySelectorAll("input").forEach(inp => {
      const s = satirlar[Number(inp.dataset.i)];
      inp.addEventListener("input", () => { if (inp.dataset.a !== "dahil") s[inp.dataset.a] = inp.value; satirGuncelle(Number(inp.dataset.i), inp.dataset.a); topla(); });
      if (inp.dataset.a === "barkod" || inp.dataset.a === "ad") inp.addEventListener("change", () => {
        eslestir(s);
        const u = s.urun_id && DB.bul("urunler", x => x.id === s.urun_id);
        if (u && inp.dataset.a === "barkod" && !s.fiyat) s.fiyat = u.alis_fiyati || 0;
        ciz(); topla();
      });
    });
    tablo.querySelectorAll("[data-sec]").forEach(sel => sel.addEventListener("change", () => { const s = satirlar[Number(sel.dataset.i)]; s.urun_id = sel.value ? Number(sel.value) : null; s.onay = true; ciz(); topla(); }));
    tablo.querySelectorAll("[data-ara]").forEach(b => b.addEventListener("click", async () => {
      const s = satirlar[Number(b.dataset.ara)];
      const id = await urunAraPenceresi(s.ad);
      if (!id) return;
      const u = DB.bul("urunler", x => x.id === id); if (!u) return;
      s.urun_id = id; s.onay = true;
      if (!s.adaylar.some(x => x.urun.id === id)) s.adaylar.unshift({ urun: u, skor: FATURA.benzerlik(s.ad, u.ad), neden: "elle" });
      if (!Number(s.fiyat)) s.fiyat = u.alis_fiyati || 0;
      ciz(); topla();
    }));
    tablo.querySelectorAll("[data-evet]").forEach(b => b.addEventListener("click", () => { satirlar[Number(b.dataset.evet)].onay = true; ciz(); topla(); }));
    tablo.querySelectorAll("[data-hayir]").forEach(b => b.addEventListener("click", () => { const s = satirlar[Number(b.dataset.hayir)]; s.urun_id = null; s.onay = true; ciz(); topla(); }));
    tablo.querySelectorAll("[data-sil]").forEach(b => b.addEventListener("click", () => { if (satirlar.length > 1) { satirlar.splice(Number(b.dataset.sil), 1); ciz(); topla(); } }));
  };
  ciz(); topla();
  $("fa-satir-ekle").addEventListener("click", () => { satirlar.push(yeniSatir()); ciz(); topla(); });
  $("fa-vazgec").addEventListener("click", modalKapat);
  $("fa-form").addEventListener("submit", async e => {
    e.preventDefault();
    if (satirlar.some(s => !s.onay)) return bildir('Sarı satırlarda "Aynı ürün mü?" sorusunu yanıtlayın');
    const f = new FormData(e.target), veri = DB.veri();
    const gecerli = satirlar.filter(s => (s.barkod || s.ad || s.urun_id) && Number(s.adet) > 0);
    if (!gecerli.length) return bildir("Faturada ürün satırı yok");
    if (!String(f.get("ted") || "").trim()) return bildir("Tedarikçi adı gerekli");
    const yeniUrun = gecerli.filter(s => !s.urun_id).length;
    const genel = gecerli.reduce((t, s) => t + (Number(s.adet) || 0) * (Number(s.fiyat) || 0) * (1 + (Number(s.kdv) || 0) / 100), 0);
    const odemeAd = ODEME_AD[f.get("odeme")] || "";
    if (!(await kucukPencere({ baslik: "Faturayı işle", evet: "Evet, işle", mesaj:
      (duzenleId ? "Eski fatura geri alınıp bu düzeltilmiş fatura işlenecek.\n\n" : "") +
      gecerli.length + " ürün stoğa girilecek" + (yeniUrun ? " (" + yeniUrun + " tanesi stokta yok, yeni ürün olarak eklenecek)" : "") + ".\n" +
      "Tedarikçi carisine " + para(genel) + " yazılacak (" + odemeAd + ").\n\nÜrünlere ve cariye işlensin mi?" }))) return;
    const kalemler = satirlar.filter(s => (s.barkod || s.ad || s.urun_id) && Number(s.adet) > 0).map(s => {
      const u = s.urun_id && veri.urunler.find(x => x.id === s.urun_id);
      if (u && s.ad && FATURA.adNormal(s.ad).join(" ") !== FATURA.adNormal(u.ad).join(" ")) FATURA.eslesmeHatirla(veri, s.ad, u.id);
      return { urun_id: u ? u.id : null, barkod: u ? u.barkod : s.barkod, ad: u ? u.ad : s.ad, fatura_ad: s.ad, adet: s.adet, fiyat: s.fiyat, kdv: s.kdv, satis_fiyati: s.satis !== "" ? s.satis : undefined };
    });
    // Düzenleme: önce eski fatura geri alınır (stok + cari), sonra düzeltilmiş hâli işlenir
    const eskiFatura = duzenleId ? veri.alis_faturalari.find(x => x.id === duzenleId) : null;
    if (eskiFatura) { FATURA.faturaIptal(veri, duzenleId); eskiFatura.durum = "birlesti"; }
    const sonuc = FATURA.faturaIsle(veri, {
      fatura_no: f.get("no"), tarih: f.get("tarih"), odeme: f.get("odeme"), kaynak: ilk.kaynak || "elle", dis_id: ilk.dis_id,
      tedarikci: { ad: f.get("ted"), vergi_no: f.get("vergi") }, kalemler
    });
    if (sonuc.hata || sonuc.atlandi) { if (eskiFatura) { eskiFatura.durum = "aktif"; DB.kaydet(); } return bildir(sonuc.hata || "Bu fatura daha önce işlenmiş"); }
    if (bekleyenId) { const b = veri.alis_faturalari.find(x => x.id === bekleyenId); if (b) b.durum = "birlesti"; }
    DB.kaydet(); modalKapat(); faturaCiz(); menuRozetleri();
    bildir("Alış faturası işlendi: " + para(sonuc.fatura.toplam));
  });
}

async function faturaDosyasiYukle(dosya) {
  if (!dosya) return;
  try {
    bildir("Fatura dosyası okunuyor...");
    const sonuc = await FATURAOKU.dosyadanOku(dosya);
    faturaFormu(sonuc);
  } catch (e) { bildir(e.message || "Dosya okunamadı"); }
}

// ---------- MÜŞTERİLER / CARİ ----------
function cariBakiye(musteriId) {
  return DB.liste("cari_hareketler", h => h.musteri_id === musteriId).reduce((t, h) => t + (h.tur === "borc" ? h.tutar : -h.tutar), 0);
}

// Cari işlem türleri: açık hesaba satış, tahsilat, elle borç düzeltme ve iptal edilen fişin ters kaydı
const CARI_ISLEM = {
  satis: { ad: "Açık hesap satışı", sinif: "uyari" },
  tahsilat: { ad: "Tahsilat", sinif: "iyi" },
  borc_duzeltme: { ad: "Borç düzeltme", sinif: "uyari" },
  fis_iptali: { ad: "Fiş iptali", sinif: "bilgi" },
  iade: { ad: "İade", sinif: "bilgi" },
  alis_faturasi: { ad: "Alış faturası", sinif: "uyari" },
  tedarikci_odeme: { ad: "Tedarikçi ödemesi", sinif: "iyi" },
  fatura_iptali: { ad: "Fatura iptali", sinif: "bilgi" }
};
const YONTEM_AD = { nakit: "Nakit", kart: "Kart", havale: "Havale / EFT" };

// Eski kayıtlarda "islem" alanı yok: türden ve fişe bağlı olmasından anlaşılır
function cariIslemi(h) {
  if (h.islem) return h.islem;
  if (h.tur === "borc") return h.satis_id ? "satis" : "borc_duzeltme";
  return h.satis_id ? "fis_iptali" : "tahsilat";
}

// Eski kayıtlarda kullanıcı ve yöntem alanı yok: fişe bağlı satışlarda fişi kesen kasiyer ve "Açık hesap" gösterilir
function cariKullaniciAdi(h) {
  const id = h.kullanici_id || (h.satis_id && (DB.bul("satislar", s => s.id === h.satis_id) || {}).kullanici_id);
  return (id && (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad) || "-";
}

function cariYontemAdi(h) {
  if (h.yontem) return YONTEM_AD[h.yontem] || h.yontem;
  return cariIslemi(h) === "satis" ? "Açık hesap" : "-";
}

// Tek yerden kayıt: kim yaptığı ve ödeme yöntemi de saklanır
function cariKaydet(musteriId, tur, tutar, ayrinti) {
  return DB.ekle("cari_hareketler", {
    musteri_id: musteriId, tur, tutar,
    satis_id: ayrinti.satisId || null,
    aciklama: ayrinti.aciklama || "",
    islem: ayrinti.islem,
    yontem: ayrinti.yontem || null,
    kullanici_id: aktifKullanici ? aktifKullanici.id : null,
    tarih: new Date().toISOString()
  });
}

// Hareketleri eskiden yeniye dizip her satırın sonundaki bakiyeyi hesaplar
function cariOzet(musteriId) {
  const hareketler = DB.liste("cari_hareketler", h => h.musteri_id === musteriId)
    .sort((a, b) => a.tarih.localeCompare(b.tarih) || a.id - b.id);
  let bakiye = 0;
  const satirlar = hareketler.map(h => {
    bakiye = Math.round((bakiye + (h.tur === "borc" ? h.tutar : -h.tutar)) * 100) / 100;
    return { ...h, islemTuru: cariIslemi(h), bakiye };
  });
  const topla = islem => satirlar.filter(h => h.islemTuru === islem).reduce((t, h) => t + h.tutar, 0);
  return {
    satirlar, bakiye,
    satis: topla("satis"), tahsilat: topla("tahsilat"), duzeltme: topla("borc_duzeltme"), iptal: topla("fis_iptali"),
    son: satirlar.length ? satirlar[satirlar.length - 1].tarih : null
  };
}

// Küçük yuvarlak (halka) grafik: oran 0..1, ortada büyük değer, altta açıklama
function halkaSvg(oran, renk, merkez, alt) {
  const r = 26, c = 2 * Math.PI * r, o = Math.max(0, Math.min(1, oran || 0));
  return `<div class="halka-kutu"><svg viewBox="0 0 64 64" width="64" height="64" aria-hidden="true"><circle cx="32" cy="32" r="${r}" fill="none" stroke="var(--line, #d9dee8)" stroke-width="7"/><circle cx="32" cy="32" r="${r}" fill="none" stroke="${renk}" stroke-width="7" stroke-linecap="round" stroke-dasharray="${(c * o).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 32 32)"/><text x="32" y="36" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">${merkez}</text></svg><div class="halka-alt">${alt}</div></div>`;
}

let musteriFiltre = "";
// Cariler iki sekmede: "musteri" (satış yapılanlar) ve "firma" (tedarikçi / satıcı firmalar, tedarikci = 1)
let musteriSekme = "musteri";
function musteriCiz() {
  const musteriler = DB.liste("musteriler", m => m.aktif).map(m => ({ m, o: cariOzet(m.id) }));
  const aranan = trKucuk(musteriFiltre.trim());
  const firmaSekmesi = musteriSekme === "firma";
  const gorunen = musteriler.filter(x => !!x.m.tedarikci === firmaSekmesi && (!aranan || trKucuk(x.m.ad_soyad).includes(aranan) || String(x.m.telefon || "").includes(aranan) || String(x.m.vergi_no || "").includes(aranan) || trKucuk(x.m.adres).includes(aranan)));
  const toplamAlacak = musteriler.filter(x => !x.m.tedarikci).reduce((t, x) => t + x.o.bakiye, 0);
  const borclu = musteriler.filter(x => !x.m.tedarikci && x.o.bakiye > 0.005).length;
  const firmalar = musteriler.filter(x => x.m.tedarikci);
  $("s-musteri").innerHTML = `
    <div class="baslik-satir"><h2>${firmaSekmesi ? "Firmalar" : "Müşteriler ve açık hesap"}</h2><div><button class="btn ${firmaSekmesi ? "" : "ana"}" id="ms-musteri">Müşteriler</button> <button class="btn ${firmaSekmesi ? "ana" : ""}" id="ms-firma">Firmalar</button></div><div style="flex:1;display:flex;justify-content:center;min-width:180px"><input id="m-ara" type="search" placeholder="Ad, telefon, vergi no ara" value="${kac("", musteriFiltre)}" autocomplete="off" style="width:100%;max-width:340px;height:38px;padding:0 14px;border-radius:19px"></div><button class="btn ana" id="m-yeni">Yeni cari</button></div>
    ${firmaSekmesi ? `<div class="ozet-serit">
        <div class="mini-ozet"><small>Firma</small><strong>${firmalar.length}</strong><em>tedarikçi / satıcı firma</em></div>
        <div class="mini-ozet"><small>Firmalara borcumuz</small><strong>${para(firmalar.reduce((t, x) => t + Math.max(0, -x.o.bakiye), 0))}</strong><em>${firmalar.filter(x => x.o.bakiye < -0.005).length} firmaya borç</em></div>
        <div class="mini-ozet"><small>Firmalardan alacağımız</small><strong>${para(firmalar.reduce((t, x) => t + Math.max(0, x.o.bakiye), 0))}</strong><em>${firmalar.filter(x => x.o.bakiye > 0.005).length} firma</em></div>
      </div>` : (() => {
      const gercek = musteriler.filter(x => !x.m.tedarikci);
      const satis = gercek.reduce((t, x) => t + x.o.satis, 0), tahsil = gercek.reduce((t, x) => t + x.o.tahsilat, 0);
      const borcluOran = gercek.length ? borclu / gercek.length : 0, tahsilOran = satis > 0 ? Math.min(1, tahsil / satis) : 0;
      const enBorclu = gercek.slice().sort((p, q) => q.o.bakiye - p.o.bakiye)[0];
      const tedBorc = musteriler.filter(x => x.m.tedarikci).reduce((t, x) => t + Math.max(0, -x.o.bakiye), 0);
      return `<div class="ozet-serit">
        ${halkaSvg(borcluOran, "#e0953a", gercek.length ? "%" + Math.round(borcluOran * 100) : "-", "Borçlu müşteri oranı")}
        ${halkaSvg(tahsilOran, "#1e8e4e", satis > 0 ? "%" + Math.round(tahsilOran * 100) : "-", "Tahsilat oranı")}
        <div class="mini-ozet"><small>Toplam alacak</small><strong>${para(toplamAlacak)}</strong><em>${borclu} borçlu müşteri</em></div>
        <div class="mini-ozet"><small>Açık hesap satışı</small><strong>${para(satis)}</strong><em>Tahsilat ${para(tahsil)}</em></div>
        <div class="mini-ozet"><small>Müşteri</small><strong>${gercek.length}</strong><em>${musteriler.length - gercek.length ? (musteriler.length - gercek.length) + " tedarikçi" : "tedarikçi yok"}</em></div>
        <div class="mini-ozet"><small>En yüksek borç</small><strong>${enBorclu && enBorclu.o.bakiye > 0.005 ? para(enBorclu.o.bakiye) : "-"}</strong><em>${enBorclu && enBorclu.o.bakiye > 0.005 ? kac("", enBorclu.m.ad_soyad) : "borçlu yok"}</em></div>
        ${tedBorc > 0 ? `<div class="mini-ozet"><small>Tedarikçiye borcumuz</small><strong>${para(tedBorc)}</strong><em>alış faturaları</em></div>` : ""}
      </div>`;
    })()}
    <table class="tablo">
      <tr><th>${firmaSekmesi ? "Firma" : "Ad soyad"}</th><th>Telefon</th><th class="sag">Açık hesap satışı</th><th class="sag">Tahsilat</th><th class="sag">Bakiye (borç)</th><th>Son hareket</th><th></th></tr>
      ${gorunen.map(({ m, o }) => `<tr>
        <td><button class="baglanti" data-m-detay="${m.id}">${kac("", m.ad_soyad)}</button>${m.tedarikci ? ' <span class="rozet">Tedarikçi</span>' : ""}${m.vergi_no || m.adres ? `<div style="font-size:12px;opacity:.65">${kac("", [m.vergi_no ? "VN " + m.vergi_no : "", m.adres || ""].filter(Boolean).join(" · "))}</div>` : ""}</td><td>${kac("", m.telefon)}</td>
        <td class="sag">${para(o.satis)}</td><td class="sag">${para(o.tahsilat)}</td>
        <td class="sag"><strong>${o.bakiye < -0.005 ? para(-o.bakiye) + " (borcumuz)" : para(o.bakiye)}</strong></td>
        <td>${o.son ? tarih(o.son) : "-"}</td>
        <td><button class="btn kucuk" data-tahsilat="${m.id}">Tahsilat</button> <button class="btn kucuk" data-hareket="${m.id}">Hareketler</button> <button class="btn kucuk" data-m-duzenle="${m.id}">Düzenle</button> <button class="btn kucuk tehlike" data-m-sil="${m.id}">Sil</button></td>
      </tr>`).join("") || `<tr><td colspan="7">${firmaSekmesi ? "Firma yok" : "Müşteri yok"}</td></tr>`}
    </table>`;
  $("ms-musteri").addEventListener("click", () => { musteriSekme = "musteri"; musteriCiz(); });
  $("ms-firma").addEventListener("click", () => { musteriSekme = "firma"; musteriCiz(); });
  $("m-yeni").addEventListener("click", () => musteriFormu());
  { let z; $("m-ara").addEventListener("input", e => { musteriFiltre = e.target.value; clearTimeout(z); z = setTimeout(() => { musteriCiz(); const k = $("m-ara"); k.focus(); k.setSelectionRange(k.value.length, k.value.length); }, 200); }); }
  $("s-musteri").querySelectorAll("[data-m-duzenle]").forEach(b => b.addEventListener("click", () => musteriFormu(DB.bul("musteriler", x => x.id === Number(b.dataset.mDuzenle)))));
  $("s-musteri").querySelectorAll("[data-m-sil]").forEach(b => b.addEventListener("click", () => musteriSil(Number(b.dataset.mSil))));
  $("s-musteri").querySelectorAll("[data-m-detay]").forEach(b => b.addEventListener("click", () => cariDetay(Number(b.dataset.mDetay))));
  $("s-musteri").querySelectorAll("[data-tahsilat]").forEach(b => b.addEventListener("click", () => tahsilatFormu(Number(b.dataset.tahsilat))));
  $("s-musteri").querySelectorAll("[data-hareket]").forEach(b => b.addEventListener("click", () => cariDetay(Number(b.dataset.hareket))));
}

// Müşteri ekle / düzenle: iletişim, vergi ve not bilgileriyle
function musteriFormu(m, sonra) {
  const duzenle = !!(m && m.id);
  m = m || {};
  // Yeni caride tür sorulur (seçilmeden kaydedilmez); kasadan açılınca müşteri seçili gelir, düzenlemede mevcut tür
  const tur = duzenle ? (m.tedarikci ? "firma" : "musteri") : (sonra ? "musteri" : "");
  modalAc(`
    <div class="modal-baslik">${duzenle ? "Cariyi düzenle" : "Yeni cari"}</div>
    <form id="m-form" class="form" style="margin-top:10px">
      <div class="tam cari-tur"><span>Bu cari ne?</span>
        <label class="onay-kutusu"><input type="radio" name="tur" value="musteri" required ${tur === "musteri" ? "checked" : ""}> Müşteri</label>
        <label class="onay-kutusu"><input type="radio" name="tur" value="firma" ${tur === "firma" ? "checked" : ""}> Firma (tedarikçi)</label></div>
      <label class="tam">Ad soyad / unvan<input name="ad" required value="${kac("", m.ad_soyad)}"></label>
      <label>Telefon<input name="tel" type="tel" value="${kac("", m.telefon)}"></label>
      <label>E-posta<input name="eposta" type="email" value="${kac("", m.eposta)}"></label>
      <label>Vergi / TC no<input name="vergi" value="${kac("", m.vergi_no)}"></label>
      <label>Vergi dairesi<input name="vdaire" value="${kac("", m.vergi_dairesi)}"></label>
      <label class="tam">Adres<input name="adres" value="${kac("", m.adres)}"></label>
      <label>Borç limiti (TL, boş = limitsiz)<input name="limit" type="number" min="0" step="0.01" value="${m.borc_limiti || ""}"></label>
      <label class="tam">Not<input name="not" value="${kac("", m.not)}" placeholder="Ör. ödeme günü, özel koşul"></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="m-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  $("m-vazgec").addEventListener("click", modalKapat);
  $("m-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const alanlar = { ad_soyad: String(f.get("ad")).trim(), telefon: f.get("tel"), eposta: f.get("eposta"), vergi_no: f.get("vergi"), vergi_dairesi: f.get("vdaire"), adres: f.get("adres"), borc_limiti: Number(f.get("limit")) || 0, tedarikci: f.get("tur") === "firma" ? 1 : 0, not: f.get("not") };
    if (!f.get("tur")) return bildir("Müşteri mi firma mı seçin");
    if (!alanlar.ad_soyad) return bildir("Ad soyad girin");
    const adi = alanlar.tedarikci ? "Firma" : "Müşteri";
    if (duzenle) { DB.guncelle("musteriler", m.id, alanlar); bildir(adi + " güncellendi"); }
    else { const yeni = DB.ekle("musteriler", { ...alanlar, aktif: 1 }); bildir(adi + " eklendi"); if (sonra) { modalKapat(); return sonra(yeni); } }
    modalKapat();
    musteriSekme = alanlar.tedarikci ? "firma" : "musteri"; // kaydedilen cari hangi sekmedeyse o açılır
    musteriCiz();
  });
}

// Müşteri silme: geçmiş fişler ve cari kayıtları bozulmasın diye müşteri pasifleştirilir (listelerden kalkar)
function musteriSil(id) {
  const m = DB.bul("musteriler", x => x.id === id);
  if (!m) return;
  const bakiye = cariOzet(id).bakiye;
  modalAc(`
    <div class="modal-baslik">Müşteriyi sil · ${kac("", m.ad_soyad)}</div>
    <p style="margin:10px 0">Müşteri listelerden ve kasadaki açık hesap seçiminden kalkar. Geçmiş fişler ve cari hareketleri bozulmaz.</p>
    ${Math.abs(bakiye) > 0.005 ? `<p style="margin:10px 0;color:#c0392b"><strong>Dikkat:</strong> Bu müşterinin ${para(Math.abs(bakiye))} ${bakiye > 0 ? "borcu" : "alacağı"} var.</p>` : ""}
    <div class="modal-alt tam"><button type="button" class="btn" id="ms-vazgec">Vazgeç</button><button type="button" class="btn tehlike" id="ms-sil">Evet, sil</button></div>`);
  $("ms-vazgec").addEventListener("click", modalKapat);
  $("ms-sil").addEventListener("click", () => { DB.guncelle("musteriler", id, { aktif: 0 }); modalKapat(); musteriCiz(); bildir("Müşteri silindi"); });
}

function tahsilatFormu(musteriId) {
  const m = DB.bul("musteriler", x => x.id === musteriId);
  modalAc(`
    <div class="modal-baslik">Tahsilat · ${kac("", m.ad_soyad)}</div>
    <p>Mevcut borç: <strong>${para(cariBakiye(musteriId))}</strong></p>
    <form id="t-form" class="form">
      <label>Tutar<input name="tutar" type="number" step="0.01" min="0.01" required></label>
      <label>Ödeme yöntemi<select name="yontem">${Object.entries(YONTEM_AD).map(([k, ad]) => `<option value="${k}">${ad}</option>`).join("")}</select></label>
      <label class="tam">Açıklama<input name="aciklama" placeholder="Not (isteğe bağlı)"></label>
      <div class="hata tam" id="t-hata"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="t-vazgec">Vazgeç</button><button class="btn ana" type="submit">Tahsil et</button></div>
    </form>`);
  $("t-vazgec").addEventListener("click", modalKapat);
  $("t-form").addEventListener("submit", e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const tutar = Number(f.get("tutar"));
    if (!(tutar > 0)) return;
    if (tutar > cariBakiye(musteriId) + 0.005) return ($("t-hata").textContent = "Tahsilat mevcut borçtan büyük olamaz");
    cariKaydet(musteriId, "tahsilat", tutar, { islem: "tahsilat", yontem: f.get("yontem"), aciklama: f.get("aciklama") || "Tahsilat" });
    modalKapat();
    musteriCiz();
    bildir("Tahsilat kaydedildi");
  });
}

// Cari hesap hareketleri: işlem türü, fiş, kullanıcı, ödeme yöntemi ve her satırdan sonraki bakiye
function cariDetay(musteriId, filtre) {
  const f = filtre || { bas: "", bit: "", islem: "hepsi", detay: false };
  const m = DB.bul("musteriler", x => x.id === musteriId);
  const o = cariOzet(musteriId);
  const gorunen = o.satirlar.filter(h =>
    (!f.bas || yerelGun(h.tarih) >= f.bas) && (!f.bit || yerelGun(h.tarih) <= f.bit) && (f.islem === "hepsi" || h.islemTuru === f.islem));
  const borcToplam = gorunen.filter(h => h.tur === "borc").reduce((t, h) => t + h.tutar, 0);
  const alacakToplam = gorunen.filter(h => h.tur !== "borc").reduce((t, h) => t + h.tutar, 0);
  const faturaBul = h => { const l = DB.veri().alis_faturalari; return (h.fatura_id && l.find(x => x.id === h.fatura_id)) || (h.aciklama && l.find(x => x.durum !== "onay_bekliyor" && x.durum !== "birlesti" && h.aciklama.startsWith("Alış faturası " + x.fatura_no))) || null; };
  const fisNoDe = id => (DB.bul("satislar", s => s.id === id) || {}).fis_no || "";

  modalAc(`
    <div class="modal-baslik">${kac("", m.ad_soyad)} · hesap hareketleri</div>
    <p style="margin:2px 0 8px;font-size:12px;opacity:0.75">${kac("", [m.telefon || "Telefon yok", m.eposta, m.vergi_no ? "Vergi no " + m.vergi_no + (m.vergi_dairesi ? " (" + m.vergi_dairesi + ")" : "") : "", m.adres, m.borc_limiti ? "Limit " + para(m.borc_limiti) : "", m.not ? "Not: " + m.not : ""].filter(Boolean).join(" · "))}</p>
    <div class="ozet-kutular">
      <div class="ozet"><small>Açık hesap satışı</small><strong>${para(o.satis)}</strong></div>
      <div class="ozet"><small>Tahsilat</small><strong>${para(o.tahsilat)}</strong></div>
      <div class="ozet"><small>İptal / düzeltme</small><strong>${para(o.iptal)} / ${para(o.duzeltme)}</strong></div>
      <div class="ozet"><small>Güncel bakiye (borç)</small><strong>${para(o.bakiye)}</strong></div>
    </div>
    <div class="filtre" style="margin-bottom:10px">
      <input type="date" id="cd-bas" value="${f.bas}" aria-label="Başlangıç tarihi">
      <input type="date" id="cd-bit" value="${f.bit}" aria-label="Bitiş tarihi">
      <select id="cd-islem" aria-label="İşlem türü">
        <option value="hepsi">Tüm işlemler</option>
        ${Object.entries(CARI_ISLEM).map(([k, v]) => `<option value="${k}" ${f.islem === k ? "selected" : ""}>${v.ad}</option>`).join("")}
      </select>
      <label class="onay-kutusu"><input type="checkbox" id="cd-detay" ${f.detay ? "checked" : ""}> Fiş içeriklerini göster</label>
      <button class="btn" id="cd-temizle">Filtreyi temizle</button>
    </div>
    <div style="overflow:auto;max-height:46vh">
      <table class="tablo">
        <tr><th>Tarih</th><th>İşlem</th><th>Fiş / açıklama</th><th>Yöntem</th><th>Kullanıcı</th><th class="sag">Borç</th><th class="sag">Alacak</th><th class="sag">Bakiye</th></tr>
        ${[...gorunen].reverse().map(h => `<tr>
          <td>${tarih(h.tarih)}</td>
          <td><span class="rozet ${CARI_ISLEM[h.islemTuru].sinif}">${CARI_ISLEM[h.islemTuru].ad}</span></td>
          <td>${(() => { const af = h.islemTuru === "alis_faturasi" || h.islemTuru === "fatura_iptali" || h.islemTuru === "tedarikci_odeme" ? faturaBul(h) : null; return af ? `<button class="baglanti" data-afatura="${af.id}">Fatura ${kac("", af.fatura_no)} · içeriği gör</button> ` : ""; })()}${h.satis_id ? `<button class="baglanti" data-fis="${h.satis_id}">${kac("", fisNoDe(h.satis_id))}</button> ` : ""}${kac("", h.aciklama && h.aciklama !== fisNoDe(h.satis_id) ? h.aciklama : "")}</td>
          <td>${kac("", cariYontemAdi(h))}</td>
          <td>${kac("", cariKullaniciAdi(h))}</td>
          <td class="sag">${h.tur === "borc" ? para(h.tutar) : ""}</td>
          <td class="sag">${h.tur !== "borc" ? para(h.tutar) : ""}</td>
          <td class="sag"><strong>${para(h.bakiye)}</strong></td>
        </tr>${f.detay && h.islemTuru === "alis_faturasi" && faturaBul(h) ? `<tr class="alt-satir"><td></td><td colspan="7">${alisKalemTablosu(faturaBul(h))}</td></tr>` : ""}${f.detay && h.satis_id ? `<tr class="alt-satir"><td></td><td colspan="7">${fisKalemTablosu(h.satis_id)}</td></tr>` : ""}`).join("") || '<tr><td colspan="8">Bu filtreyle hareket yok</td></tr>'}
        ${gorunen.length ? `<tr><th colspan="5">Listelenen toplam</th><th class="sag">${para(borcToplam)}</th><th class="sag">${para(alacakToplam)}</th><th></th></tr>` : ""}
      </table>
    </div>
    <div class="modal-alt">
      <button class="btn" id="cd-yazdir">Ekstre yazdır</button>
      <button class="btn" id="cd-yazdir-detay">Detaylı ekstre yazdır</button>
      ${aktifKullanici.rol === "yonetici" ? '<button class="btn" id="cd-tasarim">Ekstre tasarımı</button>' : ""}
      <button class="btn" id="cd-duzenle">Müşteriyi düzenle</button>
      <button class="btn" id="cd-tahsilat">Tahsilat al</button>
      <button class="btn" id="c-kapat">Kapat</button>
    </div>`, true);

  const yenile = () => cariDetay(musteriId, { bas: $("cd-bas").value, bit: $("cd-bit").value, islem: $("cd-islem").value, detay: $("cd-detay").checked });
  ["cd-bas", "cd-bit", "cd-islem", "cd-detay"].forEach(id => $(id).addEventListener("change", yenile));
  $("cd-temizle").addEventListener("click", () => cariDetay(musteriId));
  $("modal-icerik").querySelectorAll("[data-afatura]").forEach(b => b.addEventListener("click", () => faturaGor(Number(b.dataset.afatura), () => cariDetay(musteriId, f))));
  $("modal-icerik").querySelectorAll("[data-fis]").forEach(b => b.addEventListener("click", () => fisDetay(Number(b.dataset.fis), () => cariDetay(musteriId, f))));
  $("cd-yazdir").addEventListener("click", () => cariEkstreYazdir(m, o, gorunen, f, false));
  $("cd-yazdir-detay").addEventListener("click", () => cariEkstreYazdir(m, o, gorunen, f, true));
  if ($("cd-tasarim")) $("cd-tasarim").addEventListener("click", () => ekstreTasarimiAc({ m, o, satirlar: gorunen, f, geri: () => cariDetay(musteriId, f) }));
  $("cd-tahsilat").addEventListener("click", () => tahsilatFormu(musteriId));
  $("cd-duzenle").addEventListener("click", () => musteriFormu(m));
  $("c-kapat").addEventListener("click", modalKapat);
}

// Müşteri cari hesap ekstresi (A4): listelenen hareketler ve satır sonu bakiyeleri
// Bir fişin içeriği: ürün, adet, birim fiyat, tutar, varsa indirim ve fiş toplamı
function fisKalemTablosu(satisId) {
  const s = DB.bul("satislar", x => x.id === satisId);
  const kalemler = DB.liste("satis_kalemleri", k => k.satis_id === satisId);
  if (!s || !kalemler.length) return '<span class="fis-kalem-yok">Fiş içeriği bulunamadı</span>';
  const ad = id => (DB.bul("urunler", u => u.id === id) || {}).ad || "Silinmiş ürün";
  return `<table class="fis-kalem">
    <tr><th>Ürün</th><th class="sag">Adet</th><th class="sag">Birim fiyat</th><th class="sag">Tutar</th></tr>
    ${kalemler.map(k => `<tr><td>${kac("", ad(k.urun_id))}</td><td class="sag">${sayi(k.miktar)}</td><td class="sag">${para(k.birim_fiyat)}</td><td class="sag">${para(k.tutar)}</td></tr>`).join("")}
    ${s.indirim > 0 ? `<tr><td colspan="3">İndirim</td><td class="sag">-${para(s.indirim)}</td></tr>` : ""}
    <tr><th colspan="3">Fiş toplamı${s.durum === "iptal" ? " (iptal edildi)" : ""}</th><th class="sag">${para(s.toplam)}</th></tr>
  </table>`;
}

// ---------- RAPORLAR ----------
// Gösterge paneli: dönem seçimi, 3 halka grafik (fiş sayısı, satış toplamı, tahsilat) ve günlük satış çizgisi
let raporDonem = "bugun", raporBas = "", raporSon = "", raporKasa = "";
const RAPOR_DONEMLERI = [["bugun", "Bugün"], ["hafta", "Bu Hafta"], ["ay", "Bu Ay"], ["3ay", "Son 3 Ay"], ["6ay", "Son 6 Ay"], ["yil", "1 Yıl"], ["tarih", "Tarih Seç"]];

function yerelGun(d) { return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
function raporAraligi() {
  const bugun = new Date(); bugun.setHours(0, 0, 0, 0);
  const geri = gun => { const d = new Date(bugun); d.setDate(d.getDate() - gun); return d; };
  let bas = bugun;
  if (raporDonem === "hafta") bas = geri((bugun.getDay() + 6) % 7);
  else if (raporDonem === "ay") bas = new Date(bugun.getFullYear(), bugun.getMonth(), 1);
  else if (raporDonem === "3ay") bas = geri(90);
  else if (raporDonem === "6ay") bas = geri(180);
  else if (raporDonem === "yil") bas = geri(365);
  if (raporDonem === "tarih") return { bas: raporBas || yerelGun(bugun), son: raporSon || yerelGun(bugun) };
  return { bas: yerelGun(bas), son: yerelGun(new Date()) };
}
// Kayıt tarihini yerel güne çevirir (kayıtlar ISO ya da "YYYY-MM-DD HH:MM:SS" olabilir)
function kayitGunu(t) {
  const s = String(t || "");
  const d = new Date(s.includes("T") || s.includes("Z") ? s : s.replace(" ", "T") + "Z");
  return isNaN(d) ? s.slice(0, 10) : yerelGun(d);
}

function halkaGrafik(baslik, merkez, dilimler) {
  const toplam = dilimler.reduce((t, d) => t + d.deger, 0);
  const R = 70, C = 2 * Math.PI * R;
  let ofset = 0;
  const halkalar = toplam > 0
    ? dilimler.filter(d => d.deger > 0).map(d => {
      const uzunluk = d.deger / toplam * C;
      const s = `<circle cx="100" cy="100" r="${R}" fill="none" stroke="${d.renk}" stroke-width="26" stroke-dasharray="${uzunluk} ${C - uzunluk}" stroke-dashoffset="${-ofset}" transform="rotate(-90 100 100)"><title>${kac("", d.ad)}: ${d.yazi}</title></circle>`;
      ofset += uzunluk;
      return s;
    }).join("")
    : `<circle cx="100" cy="100" r="${R}" fill="none" stroke="var(--line, #d8dee8)" stroke-width="26"/>`;
  return `<div class="halka">
    <svg viewBox="0 0 200 200" role="img" aria-label="${kac("", baslik)}">${halkalar}
      <text x="100" y="92" text-anchor="middle" class="halka-baslik">${kac("", baslik)}</text>
      <text x="100" y="116" text-anchor="middle" class="halka-deger">${kac("", merkez)}</text>
    </svg>
    <div class="halka-liste">${dilimler.map(d => `<span><i style="background:${d.renk}"></i>${kac("", d.ad)}: [${kac("", d.yazi)}]</span>`).join("")}</div>
  </div>`;
}

function satisCizgisi(gunler) {
  const G = 640, Y = 220, sol = 62, alt = 28, ust = 12, sag = 14;
  const en = Math.max(...gunler.map(g => g.toplam), 1);
  const adim = (() => { const ham = en / 4, us = Math.pow(10, Math.floor(Math.log10(ham))); const n = ham / us; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * us; })();
  const tavan = adim * Math.ceil(en / adim);
  const x = i => sol + (gunler.length === 1 ? (G - sol - sag) / 2 : i * (G - sol - sag) / (gunler.length - 1));
  const y = v => ust + (1 - v / tavan) * (Y - ust - alt);
  const izgara = [];
  for (let v = 0; v <= tavan + 0.001; v += adim) izgara.push(`<line x1="${sol}" x2="${G - sag}" y1="${y(v)}" y2="${y(v)}" class="cz-izgara"/><text x="${sol - 8}" y="${y(v) + 4}" text-anchor="end" class="cz-yazi">${Number(v).toLocaleString("tr-TR")} ₺</text>`);
  const noktalar = gunler.map((g, i) => x(i) + "," + y(g.toplam));
  const alan = gunler.length > 1 ? `<polygon points="${x(0)},${y(0)} ${noktalar.join(" ")} ${x(gunler.length - 1)},${y(0)}" class="cz-alan"/>` : "";
  const etiketAdim = Math.max(1, Math.ceil(gunler.length / 8));
  const etiketler = gunler.map((g, i) => i % etiketAdim === 0 || i === gunler.length - 1 ? `<text x="${x(i)}" y="${Y - 8}" text-anchor="middle" class="cz-yazi">${g.gun.slice(8)}.${g.gun.slice(5, 7)}</text>` : "").join("");
  return `<svg viewBox="0 0 ${G} ${Y}" class="cizgi-grafik" role="img" aria-label="Satışlar">${izgara.join("")}${alan}
    <polyline points="${noktalar.join(" ")}" class="cz-cizgi"/>
    ${gunler.map((g, i) => `<circle cx="${x(i)}" cy="${y(g.toplam)}" r="4" class="cz-nokta"><title>${g.gun}: ${para(g.toplam)}</title></circle>`).join("")}${etiketler}</svg>`;
}

function raporPanosu() {
  const { bas, son } = raporAraligi();
  const icinde = s => { const g = kayitGunu(s.tarih); return g >= bas && g <= son && (!raporKasa || String(s.kasa_no) === raporKasa); };
  const hepsi = DB.liste("satislar", s => icinde(s));
  const tamam = hepsi.filter(s => s.durum === "tamamlandi");
  const iptal = hepsi.filter(s => s.durum === "iptal");
  const toplam = l => l.reduce((t, s) => t + Number(s.toplam || 0), 0);
  const tamamIdleri = new Set(tamam.map(s => s.id));
  const odeme = y => DB.liste("odemeler", o => o.yontem === y && tamamIdleri.has(o.satis_id)).reduce((t, o) => t + Number(o.tutar || 0), 0);
  const nakit = odeme("nakit"), kart = odeme("kart"), veresiye = odeme("acik_hesap");

  // Günlük satış toplamları (aralıktaki her gün)
  const gunToplam = {};
  tamam.forEach(s => { const g = kayitGunu(s.tarih); gunToplam[g] = (gunToplam[g] || 0) + Number(s.toplam || 0); });
  const gunler = [];
  for (let d = new Date(bas + "T00:00:00"); yerelGun(d) <= son && gunler.length < 400; d.setDate(d.getDate() + 1)) gunler.push({ gun: yerelGun(d), toplam: gunToplam[yerelGun(d)] || 0 });

  const kasalar = [...new Set(DB.liste("satislar").map(s => String(s.kasa_no)))].sort();
  const toplamAcik = DB.liste("musteriler").reduce((t, m) => t + cariBakiye(m.id), 0);
  return `<div class="baslik-satir"><h2>Gösterge paneli</h2></div>
    <div class="donemler" id="rapor-donemler">
      ${RAPOR_DONEMLERI.map(([k, ad]) => `<button class="donem ${raporDonem === k ? "aktif" : ""}" data-donem="${k}">${ad}</button>`).join("")}
      ${raporDonem === "tarih" ? `<input type="date" id="rapor-bas" value="${bas}"> – <input type="date" id="rapor-son" value="${son}">` : ""}
      <select id="rapor-kasa" aria-label="Kasa seç"><option value="">Tüm kasalar</option>${kasalar.map(k => `<option value="${kac("", k)}" ${k === raporKasa ? "selected" : ""}>Kasa ${kac("", k)}</option>`).join("")}</select>
    </div>
    <div class="halkalar">
      ${halkaGrafik("Fiş Sayısı", tamam.length + iptal.length + " Adet", [
        { ad: "Satış fişi", deger: tamam.length, renk: "#d4a514", yazi: String(tamam.length) },
        { ad: "İptal fiş", deger: iptal.length, renk: "#a31d1d", yazi: String(iptal.length) }])}
      ${halkaGrafik("Satış Toplam", para(toplam(tamam)), [
        { ad: "Satış toplamı", deger: toplam(tamam), renk: "#d4a514", yazi: para(toplam(tamam)) },
        { ad: "İptal fiş toplamı", deger: toplam(iptal), renk: "#a31d1d", yazi: para(toplam(iptal)) }])}
      ${halkaGrafik("Tahsilat Toplam", para(nakit + kart), [
        { ad: "Nakit", deger: nakit, renk: "#2e9e5b", yazi: para(nakit) },
        { ad: "Kart", deger: kart, renk: "#3b7dd8", yazi: para(kart) },
        { ad: "Veresiye", deger: veresiye, renk: "#e07b39", yazi: para(veresiye) }])}
    </div>
    <div class="baslik-satir"><h2>Satışlar</h2><span class="rapor-not">Toplam açık hesap alacağı: <strong>${para(toplamAcik)}</strong></span></div>
    ${satisCizgisi(gunler)}`;
}

function raporCiz() {
  const bugun = new Date().toISOString().slice(0, 10);
  const satislar = DB.liste("satislar", s => s.durum === "tamamlandi");
  const bugunSatislar = satislar.filter(s => s.tarih.slice(0, 10) === bugun);
  const ciro = bugunSatislar.reduce((t, s) => t + s.toplam, 0);
  const nakit = DB.liste("odemeler").filter(o => o.yontem === "nakit" && bugunSatislar.some(s => s.id === o.satis_id)).reduce((t, o) => t + o.tutar, 0);
  const kart = DB.liste("odemeler").filter(o => o.yontem === "kart" && bugunSatislar.some(s => s.id === o.satis_id)).reduce((t, o) => t + o.tutar, 0);
  const acik = DB.liste("odemeler").filter(o => o.yontem === "acik_hesap" && bugunSatislar.some(s => s.id === o.satis_id)).reduce((t, o) => t + o.tutar, 0);
  const toplamAcik = DB.liste("musteriler").reduce((t, m) => t + cariBakiye(m.id), 0);

  // En çok satan
  const adet = {};
  const gecerliSatislar = new Set(satislar.map(s => s.id));
  DB.liste("satis_kalemleri", k => gecerliSatislar.has(k.satis_id)).forEach(k => { adet[k.urun_id] = (adet[k.urun_id] || 0) + k.miktar; });
  const enCok = Object.entries(adet).sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([id, m]) => ({ ad: (DB.bul("urunler", x => x.id === Number(id)) || {}).ad || "", m }));

  $("s-rapor").innerHTML = `
    ${raporPanosu()}
    ${raporDetayHtml()}
    ${gunSonuHtml()}
    ${kapanisGecmisiHtml()}
    <div class="baslik-satir"><h2>En çok satan ürünler</h2></div>
    <table class="tablo" style="margin-bottom:16px">
      <tr><th>Ürün</th><th class="sag">Satılan</th></tr>
      ${enCok.map(x => `<tr><td>${kac("", x.ad)}</td><td class="sag">${sayi(x.m)}</td></tr>`).join("") || '<tr><td colspan="2">Henüz satış yok</td></tr>'}
    </table>
    <div class="baslik-satir"><h2>Satış fişleri</h2></div>
    <table class="tablo">
      <tr><th>Fiş no</th><th>Tarih</th><th>Kasiyer</th><th class="sag">Toplam</th><th>Durum</th><th></th></tr>
      ${DB.liste("satislar").reverse().slice(0, 50).map(s => `<tr>
        <td>${s.fis_no}</td><td>${tarih(s.tarih)}</td>
        <td>${kac("", (DB.bul("kullanicilar", x => x.id === s.kullanici_id) || {}).ad_soyad)}</td>
        <td class="sag">${para(s.toplam)}</td>
        <td>${s.durum === "iptal" ? '<span class="rozet uyari">İptal</span>' : '<span class="rozet">Tamam</span>'}</td>
        <td>${s.durum === "tamamlandi" && aktifKullanici.rol === "yonetici" ? `<button class="btn kucuk tehlike" data-iptal="${s.id}">Fişi iptal et</button>` : ""}</td>
      </tr>`).join("") || '<tr><td colspan="6">Fiş yok</td></tr>'}
    </table>`;
  $("s-rapor").querySelectorAll("[data-iptal]").forEach(b => b.addEventListener("click", () => fisIptal(Number(b.dataset.iptal))));
  $("s-rapor").querySelectorAll("[data-donem]").forEach(b => b.addEventListener("click", () => { raporDonem = b.dataset.donem; raporCiz(); }));
  if ($("rapor-bas")) $("rapor-bas").addEventListener("change", e => { raporBas = e.target.value; raporCiz(); });
  if ($("rapor-son")) $("rapor-son").addEventListener("change", e => { raporSon = e.target.value; raporCiz(); });
  $("rapor-kasa").addEventListener("change", e => { raporKasa = e.target.value; raporCiz(); });
  raporDetayBagla();
  gunSonuBagla();
}

// Kesilmiş fişin iptali: neden sorulur, stok geri yüklenir, kayıt Fişler sayfasında kalır
function fisIptal(satisId) {
  const s = DB.bul("satislar", x => x.id === satisId);
  if (!s || s.durum === "iptal") return;
  modalAc(`
    <div class="modal-baslik">Fişi iptal et · ${s.fis_no}</div>
    <p>Toplam ${para(s.toplam)}. Stok geri yüklenir, açık hesap borcu varsa silinir. Fiş silinmez, iptal olarak kaydedilir.</p>
    <form id="ip-form" class="form">
      <label class="tam">İptal nedeni<input name="neden" placeholder="Örn. yanlış ürün, müşteri vazgeçti" required></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="ip-vazgec">Vazgeç</button><button class="btn tehlike" type="submit">Fişi iptal et</button></div>
    </form>`);
  $("ip-vazgec").addEventListener("click", modalKapat);
  $("ip-form").addEventListener("submit", e => {
    e.preventDefault();
    const neden = new FormData(e.target).get("neden").trim();
    if (!neden) return;
    DB.liste("satis_kalemleri", k => k.satis_id === satisId).forEach(k => {
      DB.stokHareketi(k.urun_id, "iade", k.miktar, "İptal: " + s.fis_no, aktifKullanici.id);
    });
    DB.guncelle("satislar", satisId, {
      durum: "iptal", iptal_turu: "fis", iptal_nedeni: neden,
      iptal_tarihi: new Date().toISOString(), iptal_eden_id: aktifKullanici.id
    });
    // Açık hesap borcu için ters kayıt
    DB.liste("cari_hareketler", h => h.satis_id === satisId && h.tur === "borc").forEach(h => {
      cariKaydet(h.musteri_id, "tahsilat", h.tutar, { satisId, islem: "fis_iptali", aciklama: `İptal: ${s.fis_no} (${neden})` });
    });
    modalKapat();
    sayfaGoster(aktifSayfa);
    bildir("Fiş iptal edildi, stok geri yüklendi");
  });
}

// Ödeme alınmadan vazgeçilen sepet de iptal fişi olarak kaydedilir (stok ve ödeme etkilenmez)
function sepetIptalKaydet(neden) {
  const araT = sepetToplami();
  const satis = DB.ekle("satislar", {
    fis_no: fisNo(), kasa_no: DB.ayarOku("kasaNo", "1"), kullanici_id: aktifKullanici.id,
    musteri_id: seciliMusteriId, ara_toplam: araT, indirim: araT - genelToplam(), toplam: genelToplam(),
    durum: "iptal", iptal_turu: "sepet", iptal_nedeni: neden || "Sepet iptali",
    iptal_tarihi: new Date().toISOString(), iptal_eden_id: aktifKullanici.id, tarih: new Date().toISOString()
  });
  sepet.forEach(s => DB.ekle("satis_kalemleri", { satis_id: satis.id, urun_id: s.id, miktar: s.adet, birim_fiyat: s.fiyat, tutar: s.fiyat * s.adet }));
  return satis;
}

// ---------- FİŞLER ----------
let fisTarih = null; // YYYY-MM-DD, boşsa bugün
let fisDurumFiltresi = "hepsi";

function yerelGun(iso) {
  const d = new Date(iso);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function fislerCiz() {
  const bugun = yerelGun(new Date().toISOString());
  if (!fisTarih) fisTarih = bugun;
  const gunSatislari = DB.liste("satislar", s => yerelGun(s.tarih) === fisTarih).reverse();
  const liste = gunSatislari.filter(s => fisDurumFiltresi === "hepsi" || (fisDurumFiltresi === "iptal" ? s.durum === "iptal" : s.durum === "tamamlandi"));
  const tamam = gunSatislari.filter(s => s.durum === "tamamlandi" && !s.iade);
  const iadeler = gunSatislari.filter(s => s.durum === "tamamlandi" && s.iade);
  const iptaller = gunSatislari.filter(s => s.durum === "iptal");
  const ciro = gunSatislari.filter(s => s.durum === "tamamlandi").reduce((t, s) => t + s.toplam, 0);
  const yontemAd = { nakit: "Nakit", kart: "Kart", acik_hesap: "Açık hesap" };
  const kasiyer = id => (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad || "";
  const yonetici = aktifKullanici.rol === "yonetici";

  $("s-fis").innerHTML = `
    <div class="baslik-satir">
      <h2>Fişler</h2>
      <div class="filtre">
        <input type="date" id="fis-tarih" value="${fisTarih}">
        <select id="fis-durum">
          <option value="hepsi" ${fisDurumFiltresi === "hepsi" ? "selected" : ""}>Tümü</option>
          <option value="tamam" ${fisDurumFiltresi === "tamam" ? "selected" : ""}>Satışlar</option>
          <option value="iptal" ${fisDurumFiltresi === "iptal" ? "selected" : ""}>İptaller</option>
        </select>
        <button class="btn" id="fis-bugun">Bugün</button>
      </div>
    </div>
    <div class="ozet-kutular">
      <div class="ozet"><small>Satış fişi</small><strong>${tamam.length}</strong></div>
      <div class="ozet"><small>Ciro</small><strong>${para(ciro)}</strong></div>
      <div class="ozet"><small>İptal edilen</small><strong>${iptaller.length}</strong></div>
      <div class="ozet"><small>İade</small><strong>${iadeler.length}${iadeler.length ? " · " + para(-iadeler.reduce((t, s) => t + s.toplam, 0)) : ""}</strong></div>
    </div>
    <table class="tablo">
      <tr><th>Fiş no</th><th>Saat</th><th>Kasiyer</th><th>Ödeme</th><th class="sag">Toplam</th><th>Durum</th><th></th></tr>
      ${liste.map(s => {
        const odeme = DB.bul("odemeler", o => o.satis_id === s.id);
        return `<tr>
          <td>${s.fis_no}</td>
          <td>${new Date(s.tarih).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}</td>
          <td>${kac("", kasiyer(s.kullanici_id))}</td>
          <td>${odeme ? odemeYazisi(s.id) : "-"}${s.musteri_id ? `<div style="font-size:12px;opacity:.75">👤 ${kac("", (DB.bul("musteriler", m => m.id === s.musteri_id) || {}).ad_soyad || "Müşteri #" + s.musteri_id)}</div>` : ""}</td>
          <td class="sag">${para(s.toplam)}</td>
          <td>${s.durum === "iptal" ? `<span class="rozet uyari">${s.iptal_turu === "sepet" ? "Sepet iptali" : "İptal"}</span>` : s.iade ? '<span class="rozet uyari">İade</span>' : '<span class="rozet">Tamam</span>'}</td>
          <td>
            <button class="btn kucuk" data-detay="${s.id}">Detay</button>
            ${s.durum === "tamamlandi" && !s.iade ? `<button class="btn kucuk" data-yazdir="${s.id}">Yazdır</button>` : ""}
            ${s.durum === "tamamlandi" && !s.iade && yonetici ? `<button class="btn kucuk" data-iade="${s.id}">İade al</button>` : ""}
            ${s.durum === "tamamlandi" && !s.iade && yonetici ? `<button class="btn kucuk tehlike" data-iptal="${s.id}">İptal et</button>` : ""}
          </td>
        </tr>`;
      }).join("") || '<tr><td colspan="7">Bu tarihte fiş yok</td></tr>'}
    </table>`;

  $("fis-tarih").addEventListener("change", e => { fisTarih = e.target.value || bugun; fislerCiz(); });
  $("fis-durum").addEventListener("change", e => { fisDurumFiltresi = e.target.value; fislerCiz(); });
  $("fis-bugun").addEventListener("click", () => { fisTarih = bugun; fislerCiz(); });
  $("s-fis").querySelectorAll("[data-detay]").forEach(b => b.addEventListener("click", () => fisDetay(Number(b.dataset.detay))));
  $("s-fis").querySelectorAll("[data-yazdir]").forEach(b => b.addEventListener("click", () => fisYazdir(Number(b.dataset.yazdir))));
  $("s-fis").querySelectorAll("[data-iade]").forEach(b => b.addEventListener("click", () => fisIade(Number(b.dataset.iade))));
  $("s-fis").querySelectorAll("[data-iptal]").forEach(b => b.addEventListener("click", () => fisIptal(Number(b.dataset.iptal))));
}

function fisDetay(satisId, geri) {
  const s = DB.bul("satislar", x => x.id === satisId);
  if (!s) return;
  const kalemler = DB.liste("satis_kalemleri", k => k.satis_id === satisId);
  const kim = id => (DB.bul("kullanicilar", x => x.id === id) || {}).ad_soyad || "";
  const musteri = s.musteri_id ? (DB.bul("musteriler", m => m.id === s.musteri_id) || {}).ad_soyad : "";
  modalAc(`
    <div class="modal-baslik">${s.fis_no} · ${tarih(s.tarih)}</div>
    <p>Kasiyer: ${kac("", kim(s.kullanici_id))}${musteri ? ` · Müşteri: ${kac("", musteri)}` : ""}</p>
    ${s.durum === "iptal" ? `<p class="hata">${s.iptal_turu === "sepet" ? "Sepet iptali" : "Fiş iptali"}: ${kac("", s.iptal_nedeni)} · ${tarih(s.iptal_tarihi)} · ${kac("", kim(s.iptal_eden_id))}</p>` : ""}
    <table class="tablo">
      <tr><th>Ürün</th><th class="sag">Adet</th><th class="sag">Fiyat</th><th class="sag">Tutar</th></tr>
      ${kalemler.map(k => `<tr><td>${kac("", (DB.bul("urunler", u => u.id === k.urun_id) || {}).ad)}</td><td class="sag">${sayi(k.miktar)}</td><td class="sag">${para(k.birim_fiyat)}</td><td class="sag">${para(k.tutar)}</td></tr>`).join("")}
      <tr><th colspan="3">Toplam</th><th class="sag">${para(s.toplam)}</th></tr>
    </table>
    <div class="modal-alt">${s.durum === "tamamlandi" && !s.iade && aktifKullanici.rol === "yonetici" ? '<button class="btn" id="fd-iade">İade al</button>' : ""}<button class="btn" id="fd-kapat">${geri ? "Geri dön" : "Kapat"}</button></div>`);
  if ($("fd-iade")) $("fd-iade").addEventListener("click", () => fisIade(satisId));
  $("fd-kapat").addEventListener("click", geri || modalKapat);
}

// ---------- KULLANICILAR (yönetici) ----------
function kullaniciCiz() {
  $("s-kullanici").innerHTML = `
    <div class="baslik-satir"><h2>Kullanıcılar</h2><button class="btn ana" id="k-yeni">Yeni kullanıcı</button></div>
    <p class="rapor-not" style="margin:0 0 10px">Kayıt olanlar: <strong>${DB.liste("kullanicilar", k => k.kendi_kaydi).length}</strong> kişi · son 7 günde: <strong>${DB.liste("kullanicilar", k => k.kendi_kaydi && Date.now() - new Date(k.kayit_tarihi) < 7 * 864e5).length}</strong></p>
    <table class="tablo">
      <tr><th>Ad soyad</th><th>Kullanıcı adı</th><th>Rol</th><th>Kayıt</th><th>Durum</th><th></th></tr>
      ${DB.liste("kullanicilar").map(k => `<tr>
        <td>${kac("", k.ad_soyad)}</td><td>${kac("", k.kullanici_adi)}</td>
        <td>${k.rol === "yonetici" ? "Yönetici" : "Satış"}</td>
        <td>${k.kendi_kaydi ? `<span class="rozet uyari">Kendi kaydı</span> <small>${kac("", tarih(k.kayit_tarihi))} · ${kac("", k.kayit_bilgisayar || "")}</small>` : "—"}</td>
        <td>${k.aktif ? '<span class="rozet">Aktif</span>' : '<span class="rozet uyari">Pasif</span>'}</td>
        <td><button class="btn kucuk" data-sifre="${k.id}">Şifre değiştir</button> <button class="btn kucuk" data-durum="${k.id}">${k.aktif ? "Pasifleştir" : "Aktifleştir"}</button> <button class="btn kucuk" data-rol="${k.id}">${k.rol === "yonetici" ? "Satışa çevir" : "Yönetici yap"}</button> <button class="btn kucuk tehlike" data-kul-sil="${k.id}">Sil</button></td>
      </tr>`).join("")}
    </table>`;
  $("k-yeni").addEventListener("click", kullaniciFormu);
  $("s-kullanici").querySelectorAll("[data-sifre]").forEach(b => b.addEventListener("click", () => sifreFormu(Number(b.dataset.sifre))));
  $("s-kullanici").querySelectorAll("[data-rol]").forEach(b => b.addEventListener("click", () => {
    const k = DB.bul("kullanicilar", x => x.id === Number(b.dataset.rol));
    if (!k) return;
    if (k.id === aktifKullanici.id) return bildir("Kendi rolünüzü değiştiremezsiniz");
    DB.guncelle("kullanicilar", k.id, { rol: k.rol === "yonetici" ? "kasiyer" : "yonetici" });
    kullaniciCiz();
  }));
  $("s-kullanici").querySelectorAll("[data-kul-sil]").forEach(b => b.addEventListener("click", async () => {
    const k = DB.bul("kullanicilar", x => x.id === Number(b.dataset.kulSil));
    if (!k) return;
    if (k.id === aktifKullanici.id) return bildir("Kendi hesabınızı silemezsiniz");
    if (DB.liste("kullanicilar", x => x.rol === "yonetici" && x.aktif && x.id !== k.id).length === 0 && k.rol === "yonetici") return bildir("Son yöneticiyi silemezsiniz");
    // Geçmiş kayıtlar (fiş, stok, cari, sayım) kullanıcıya bağlıysa silinemez, pasifleştirilir
    const kullanildi = ["satislar", "stok_hareketleri", "cari_hareketler", "sayimlar"].some(t => DB.liste(t).some(x => x.kullanici_id === k.id || x.iptal_eden_id === k.id || x.tamamlayan_id === k.id));
    if (kullanildi) return bildir("Bu kullanıcının geçmiş satış/stok kayıtları var, silinemez. Pasifleştirebilirsiniz.");
    if (!await kucukPencere({ baslik: "Kullanıcı silinsin mi?", mesaj: k.ad_soyad + " kullanıcısı silinecek.", evet: "Sil" })) return;
    DB.sil("kullanicilar", k.id);
    kullaniciCiz();
    bildir("Kullanıcı silindi");
  }));
  $("s-kullanici").querySelectorAll("[data-durum]").forEach(b => b.addEventListener("click", () => {
    const k = DB.bul("kullanicilar", x => x.id === Number(b.dataset.durum));
    if (k.id === aktifKullanici.id) return bildir("Kendi hesabınızı pasifleştiremezsiniz");
    DB.guncelle("kullanicilar", k.id, { aktif: k.aktif ? 0 : 1 });
    kullaniciCiz();
  }));
}

function kullaniciFormu() {
  modalAc(`
    <div class="modal-baslik">Yeni kullanıcı</div>
    <form id="k-form" class="form" style="margin-top:10px">
      <label>Ad soyad<input name="ad" required></label>
      <label>Kullanıcı adı<input name="kadi" required></label>
      <label>Şifre<input name="sifre" type="password" minlength="4" required></label>
      <label>Rol<select name="rol"><option value="kasiyer">Satış (satış yapar)</option><option value="yonetici">Yönetici (stok ve yönetim)</option></select></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="k-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  $("k-vazgec").addEventListener("click", modalKapat);
  $("k-form").addEventListener("submit", async e => {
    e.preventDefault();
    const f = new FormData(e.target);
    const yeniKadi = String(f.get("kadi")).trim();
    if (DB.bul("kullanicilar", x => String(x.kullanici_adi || "").trim().toLowerCase() === yeniKadi.toLowerCase())) return bildir("Bu kullanıcı adı bu bilgisayarda zaten kayıtlı, başka bir ad seçin");
    DB.ekle("kullanicilar", { ad_soyad: String(f.get("ad")).trim(), kullanici_adi: yeniKadi, sifre_hash: await sifreOzeti(f.get("sifre")), rol: f.get("rol"), aktif: 1 });
    modalKapat();
    kullaniciCiz();
    bildir("Kullanıcı eklendi");
  });
}

function sifreFormu(id) {
  const k = DB.bul("kullanicilar", x => x.id === id);
  modalAc(`
    <div class="modal-baslik">Şifre değiştir · ${kac("", k.kullanici_adi)}</div>
    <form id="s-form" class="form" style="margin-top:10px">
      <label class="tam">Yeni şifre<input name="sifre" type="password" minlength="4" required></label>
      <div class="modal-alt tam"><button type="button" class="btn" id="s-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  $("s-vazgec").addEventListener("click", modalKapat);
  $("s-form").addEventListener("submit", async e => {
    e.preventDefault();
    DB.guncelle("kullanicilar", id, { sifre_hash: await sifreOzeti(new FormData(e.target).get("sifre")) });
    modalKapat();
    bildir("Şifre güncellendi");
  });
}

// ---------- AYARLAR ----------
// Temalar: renk değişkenleri styles.css içindeki .tema-N sınıflarında; burada seçim kartlarındaki önizleme renkleri bulunur.
const TEMALAR = [
  { id: 1, ad: "Kurumsal mavi", ust: "#1F3A5F", vurgu: "#1F3A5F", sayfa: "#F5F7FA", yuzey: "#ffffff" },
  { id: 2, ad: "Doğal yeşil", ust: "#2D6A4F", vurgu: "#2D6A4F", sayfa: "#FEFAE0", yuzey: "#ffffff" },
  { id: 3, ad: "Canlı kampanya", ust: "#D62839", vurgu: "#D62839", sayfa: "#ffffff", yuzey: "#FFF8E1" },
  { id: 4, ad: "Gece altın", ust: "#0B0F1A", vurgu: "#D4AF37", sayfa: "#111827", yuzey: "#1F2937" },
  { id: 5, ad: "Okyanus mavisi", ust: "#0369A1", vurgu: "#0369A1", sayfa: "#F0F9FF", yuzey: "#ffffff" },
  { id: 6, ad: "Pastel sadakat", ust: "#7C3AED", vurgu: "#7C3AED", sayfa: "#FAF5FF", yuzey: "#ffffff" },
  { id: 7, ad: "Sıcak kahverengi", ust: "#78350F", vurgu: "#B45309", sayfa: "#FDF6EC", yuzey: "#ffffff" },
  { id: 8, ad: "Minimal gri", ust: "#F3F4F6", vurgu: "#111827", sayfa: "#ffffff", yuzey: "#ffffff" },
  { id: 9, ad: "Çok şubeli teal", ust: "#0F766E", vurgu: "#0F766E", sayfa: "#F0FDFA", yuzey: "#ffffff" },
  { id: 10, ad: "Sezon kırmızısı", ust: "#B91C1C", vurgu: "#B91C1C", sayfa: "#FFF7ED", yuzey: "#ffffff" },
  { id: 11, ad: "Gece mavisi", ust: "#070C16", vurgu: "#38BDF8", sayfa: "#0B1220", yuzey: "#131C2E" },
  { id: 12, ad: "Gece yeşili", ust: "#07100C", vurgu: "#22C55E", sayfa: "#0B1511", yuzey: "#12201A" }
];

function temaSec(no) {
  const gecerli = TEMALAR.some(t => t.id === Number(no)) ? Number(no) : 1;
  document.body.className = "tema-" + gecerli;
  DB.ayarYaz("tema", String(gecerli));
  temaListesiCiz();
}

// Üst çubuktaki Tema butonu: basınca tüm temalar sıralanır, birine tıklayınca anında uygulanır ve kaydedilir
function temaListesiCiz() {
  const aktif = Number(DB.ayarOku("tema", "1"));
  $("tema-liste").innerHTML = TEMALAR.map(t => `
    <button class="tema-oge ${t.id === aktif ? "secili" : ""}" role="menuitemradio" aria-checked="${t.id === aktif}" data-tema-sec="${t.id}">
      <span class="tema-onizleme" style="background:${t.sayfa}"><span class="tema-cubuk" style="background:${t.ust}"></span><span class="tema-govde"><span class="tema-kutu" style="background:${t.yuzey}"></span><span class="tema-dugme-mini" style="background:${t.vurgu}"></span></span></span>
      <span class="tema-ad-metin">${t.id}. ${t.ad}</span><span class="tik">✓</span>
    </button>`).join("");
}

function temaListesiAc(ac) {
  $("tema-liste").hidden = !ac;
  $("tema-dugme").setAttribute("aria-expanded", String(ac));
  document.querySelector(".ust").classList.toggle("menu-acik", ac);
}

// ---------- Güncelleme ----------
// Uygulama açılınca yeni sürüm olup olmadığına bakılır. Varsa güncellensin mi diye sorulur;
// güncelleme bitince sunucu yeniden başlar ve uygulama yeni sürümle açılır.
function guncellemePaneliGoster(html) {
  $("guncelleme-icerik").innerHTML = html;
  $("guncelleme-panel").style.display = "flex";
}

function guncellemePaneliKapat() {
  $("guncelleme-panel").style.display = "none";
}

function guncellemeMesaji(baslik, metin) {
  guncellemePaneliGoster(`<div class="panel-baslik">${kac("", baslik)}</div><p>${kac("", metin)}</p><button class="btn ana" id="gm-tamam">Tamam</button>`);
  $("gm-tamam").addEventListener("click", guncellemePaneliKapat);
}

// "Sonra" denen sürüm, uygulama kapanıp açılana kadar çalışırken tekrar sorulmaz
let ertelenenSurum = null;
let sonGuncellemeDenetimi = 0;

async function guncellemeKontrolu(sessiz, periyodik) {
  let s;
  sonGuncellemeDenetimi = Date.now();
  try {
    s = await (await fetch("/api/guncelleme/kontrol", { cache: "no-store" })).json();
  } catch (e) {
    if (!sessiz) guncellemeMesaji("Sunucuya ulaşılamadı", "Sunucunun çalıştığından emin olun.");
    return;
  }
  if (s.durum === "var") {
    if (periyodik && s.yeni === ertelenenSurum) return;
    return guncellemeSor(s);
  }
  if (sessiz) return;
  if (s.durum === "guncel") guncellemeMesaji("Uygulama güncel", `Kurulu sürüm ${s.mevcut}.`);
  else if (s.durum === "kaynak-yok") guncellemeMesaji("Güncelleme kaynağı ayarlanmamış", "Lütfen yöneticinizle görüşün.");
  else if (s.durum === "yetkisiz") guncellemeMesaji("Güncelleme yapılamıyor", "Güncelleme yalnızca sunucu bilgisayarındaki uygulamadan yapılır.");
  else guncellemeMesaji("Güncelleme denetlenemedi", s.hata || "Kaynağa ulaşılamadı.");
}

function guncellemeSor(s) {
  guncellemePaneliGoster(`
    <div class="panel-baslik">Güncelleme var</div>
    <p>Yeni sürüm <strong>${kac("", s.yeni)}</strong> hazır (şu an ${kac("", s.mevcut)}). Güncellemek ister misiniz?</p>
    ${s.notlar && s.notlar.length ? `<ul class="guncelleme-notlar">${s.notlar.map(n => `<li>${kac("", n)}</li>`).join("")}</ul>` : ""}
    <p class="guncelleme-alt">Güncelleme birkaç saniye sürer. Verileriniz korunur, bitince uygulama açılır.</p>
    <div class="modal-alt"><button class="btn" id="g-sonra">Sonra</button><button class="btn ana" id="g-simdi">Şimdi güncelle</button></div>`);
  $("g-sonra").addEventListener("click", () => { ertelenenSurum = s.yeni; guncellemePaneliKapat(); });
  $("g-simdi").addEventListener("click", () => guncellemeyiUygula(s.yeni));
}

async function guncellemeyiUygula(yeni) {
  guncellemePaneliGoster('<div class="panel-baslik">Güncelleniyor...</div><p>Lütfen pencereyi kapatmayın. Güncelleme bitince uygulama yeniden açılacak.</p><div class="ilerleme"><span></span></div>');
  try {
    const sonuc = await (await fetch("/api/guncelleme/uygula", { method: "POST" })).json();
    if (!sonuc.ok) throw new Error(sonuc.hata || "Güncelleme başarısız");
  } catch (e) {
    return guncellemeMesaji("Güncelleme yapılamadı", e.message + ". Uygulama eski sürümle çalışmaya devam ediyor.");
  }
  // Sunucu yeni sürümle yeniden açılana kadar bekle, sonra sayfayı yenile (uygulama yeni sürümle açılır)
  for (let i = 0; i < 90; i++) {
    await new Promise(r => setTimeout(r, 700));
    try {
      const s = await (await fetch("/api/surum", { cache: "no-store" })).json();
      if (s.surum === yeni) return location.reload();
    } catch (e) { /* sunucu yeniden başlıyor */ }
  }
  guncellemeMesaji("Uygulama yeniden başlamadı", "Masaüstündeki SOFTNEST-satış simgesine tekrar tıklayın.");
}

// ---------- Marka: logo ve işletme adı ----------
// Logo giriş ekranında, açılış animasyonunda, üst menüde, fişte ve cari ekstrede kullanılır.
const VARSAYILAN_ISLETME = "SOFTNEST-satış";
let marka = { logo: null, isletmeAdi: null };

function markaBilgisi() {
  return { logo: marka.logo || null, ad: (marka.isletmeAdi || "").trim() || VARSAYILAN_ISLETME };
}

function markayiUygula(yeni) {
  if (yeni) marka = { logo: yeni.logo || null, isletmeAdi: yeni.isletmeAdi || null };
  const { logo, ad } = markaBilgisi();
  document.title = ad;
  $("giris-logo").innerHTML = logo ? `<img src="${logo}" alt="">` : "";
  $("giris-baslik").textContent = ad;
  $("ust-marka").innerHTML = logo ? `<img src="${logo}" alt="">` : "";
  $("ust-marka").title = ad;
}

// Kayıtlı marka: önce tarayıcıdaki kopya, sonra sunucudaki (giriş yapmadan da görünsün diye)
async function markayiYukle() {
  markayiUygula({ logo: DB.ayarOku("logo", null), isletmeAdi: DB.ayarOku("isletmeAdi", null) });
  try {
    const m = await (await fetch("/api/marka", { cache: "no-store" })).json();
    if (m.logo || m.isletmeAdi) markayiUygula(m);
  } catch (e) { /* sunucu yoksa yerel kopya yeter */ }
}

function markaBolumu() {
  if (aktifKullanici.rol !== "yonetici") return "";
  const { logo, ad } = markaBilgisi();
  return `
    <div class="baslik-satir"><h2>Logo ve işletme adı</h2></div>
    <div class="marka-kutu">
      <div class="marka-onizleme">${logo ? `<img src="${logo}" alt="Logo">` : '<span>Logo yok</span>'}</div>
      <div class="marka-form">
        <label>İşletme adı<input id="marka-ad" value="${kac("", marka.isletmeAdi || "")}" placeholder="${VARSAYILAN_ISLETME}" maxlength="40"></label>
        <div class="filtre">
          <label class="btn" style="cursor:pointer">${logo ? "Logoyu değiştir" : "Logo ekle"}<input id="marka-dosya" type="file" accept="image/*" hidden></label>
          ${logo ? '<button class="btn tehlike" id="marka-sil">Logoyu sil</button>' : ""}
          <button class="btn ana" id="marka-kaydet">Adı kaydet</button>
        </div>
        <small style="opacity:0.75">Logo giriş ekranında, açılış animasyonunda, üst menüde, fişte ve cari ekstrede görünür. Resim otomatik küçültülür.</small>
      </div>
    </div>`;
}

// Fiş başlığı: logo (siyah-beyaz yazıcıda gri tonlu) ve işletme adı
function fisBasligi() {
  const { logo, ad } = markaBilgisi();
  return `${logo ? `<div class="ortala"><img src="${logo}" alt="" style="max-height:56px;max-width:200px;filter:grayscale(1)"></div>` : ""}<h1>${kac("", ad.toLocaleUpperCase("tr"))}</h1>${fisUstBilgi()}`;
}

function markaOlaylari() {
  if (!$("marka-kaydet")) return;
  $("marka-kaydet").addEventListener("click", () => {
    const ad = $("marka-ad").value.trim();
    DB.ayarYaz("isletmeAdi", ad);
    markayiUygula({ logo: marka.logo, isletmeAdi: ad });
    bildir("İşletme adı kaydedildi");
  });
  $("marka-dosya").addEventListener("change", async e => {
    const dosya = e.target.files[0];
    if (!dosya) return;
    if (!dosya.type.startsWith("image/")) return bildir("Lütfen bir resim dosyası seçin");
    if (dosya.size > 8 * 1024 * 1024) return bildir("Resim 8 MB'tan büyük olamaz");
    try {
      const logo = await resmiKucult(dosya, 256, "image/png"); // PNG: saydam arka plan korunur
      DB.ayarYaz("logo", logo);
      markayiUygula({ logo, isletmeAdi: marka.isletmeAdi });
      ayarCiz();
      bildir("Logo kaydedildi");
    } catch (err) {
      bildir("Resim okunamadı");
    }
  });
  if ($("marka-sil")) $("marka-sil").addEventListener("click", async () => {
    if (!await kucukPencere({ baslik: "Logo silinsin mi?", evet: "Sil" })) return;
    DB.ayarYaz("logo", null);
    markayiUygula({ logo: null, isletmeAdi: marka.isletmeAdi });
    ayarCiz();
    bildir("Logo silindi");
  });
}

// Uygulama açıkken de yeni sürüm olup olmadığına bakılır: 10 dakikada bir ve pencereye dönüldüğünde.
// Satış sırasında (sepet doluyken) ya da başka bir pencere açıkken rahatsız edilmez.
function guncellemeDenetimiBaslat() {
  const uygunMu = () => aktifKullanici && sepet.length === 0
    && $("modal").style.display !== "flex" && $("guncelleme-panel").style.display !== "flex";
  const dene = () => { if (uygunMu()) guncellemeKontrolu(true, true); };
  setInterval(dene, 10 * 60 * 1000);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && Date.now() - sonGuncellemeDenetimi > 2 * 60 * 1000) dene();
  });
}

async function surumuGoster(hedef) {
  try {
    const s = await (await fetch("/api/surum", { cache: "no-store" })).json();
    hedef.textContent = "Sürüm " + s.surum;
  } catch (e) { hedef.textContent = ""; }
}

// ---------- Kategori ayarları paneli (yönetici): kasadaki sağ taraftaki kategori butonlarının yanındaki dişli ----------
function kategoriPaneliAc() {
  if (!aktifKullanici || aktifKullanici.rol !== "yonetici") return;
  panelKonumu();
  $("cekmece").classList.remove("acik");
  $("kat-paneli").classList.add("acik");
  kategoriPaneliListele();
}

function kategoriPaneliKapat() {
  $("kat-paneli").classList.remove("acik");
}

// Kategoriler yöneticinin belirlediği sıraya (sira alanı) göre; sırası olmayanlar numarasına göre sona dizilir
function siraliKategoriler() { return DB.liste("kategoriler").slice().sort((x, y) => (x.sira ?? x.id) - (y.sira ?? y.id) || x.id - y.id); }
function kategoriSirala(liste) { liste.forEach((k, i) => { if (k.sira !== i + 1) DB.guncelle("kategoriler", k.id, { sira: i + 1 }); }); }
function kategoriTasi(id, yon) {
  const l = siraliKategoriler(), i = l.findIndex(k => k.id === id), j = i + yon;
  if (i < 0 || j < 0 || j >= l.length) return;
  [l[i], l[j]] = [l[j], l[i]];
  kategoriSirala(l);
  kategoriYenile();
}
function kategoriPaneliListele() {
  const urunSayisi = id => DB.liste("urunler", u => u.kategori_id === id).length;
  $("kat-liste").innerHTML = siraliKategoriler().map((k, i, tum) => `
    <div class="kat-satir">
      <div class="kat-sira"><button class="btn kucuk" data-kat-yukari="${k.id}" ${i === 0 ? "disabled" : ""} aria-label="Yukarı taşı">▲</button><button class="btn kucuk" data-kat-asagi="${k.id}" ${i === tum.length - 1 ? "disabled" : ""} aria-label="Aşağı taşı">▼</button></div>
      <div style="flex:1;min-width:0"><strong>${kac("", k.ad)}</strong><small>${urunSayisi(k.id)} ürün</small></div>
      <div class="kat-islem">
        <button class="btn kucuk" data-kat-gor="${k.id}">Ürünleri gör</button>
        <button class="btn kucuk ana" data-kat-urun="${k.id}">+ Ürün ekle</button>
        <button class="btn kucuk" data-kat-duzenle="${k.id}">Düzenle</button>
        <button class="btn kucuk tehlike" data-kat-sil="${k.id}">Sil</button>
      </div>
    </div>`).join("") || '<div class="bos">Kategori yok. "Yeni kategori" ile ekleyin.</div>';
}

// Kategori değişince kasadaki butonlar ve açık panel güncellenir
function kategoriYenile() {
  kasaUrunleriCiz();
  if ($("kat-paneli").classList.contains("acik")) kategoriPaneliListele();
}

function kategoriFormu(id) {
  const k = id ? DB.bul("kategoriler", x => x.id === id) : null;
  modalAc(`
    <div class="modal-baslik">${k ? "Kategoriyi düzenle" : "Yeni kategori"}</div>
    <form id="kf" class="form" style="margin-top:10px">
      <label class="tam">Kategori adı<input name="ad" value="${kac("", k ? k.ad : "")}" maxlength="30" required></label>
      <div class="hata tam" id="kf-hata"></div>
      <div class="modal-alt tam"><button type="button" class="btn" id="kf-vazgec">Vazgeç</button><button class="btn ana" type="submit">Kaydet</button></div>
    </form>`);
  const form = $("kf");
  form.elements.ad.focus();
  $("kf-vazgec").addEventListener("click", modalKapat);
  form.addEventListener("submit", e => {
    e.preventDefault();
    const ad = form.elements.ad.value.trim();
    if (!ad) return ($("kf-hata").textContent = "Kategori adı boş olamaz");
    const ayni = DB.bul("kategoriler", x => x.id !== id && x.ad.toLocaleLowerCase("tr") === ad.toLocaleLowerCase("tr"));
    if (ayni) return ($("kf-hata").textContent = "Bu isimde bir kategori zaten var");
    if (k) {
      if (seciliKategori === k.ad) seciliKategori = ad;
      DB.guncelle("kategoriler", id, { ad });
    } else {
      DB.ekle("kategoriler", { ad });
    }
    modalKapat();
    kategoriYenile();
    bildir(k ? "Kategori güncellendi" : "Kategori eklendi");
  });
}

// Seçilen kategoriye mevcut ürünleri ekler (arama + çoklu seçim); ürün başka kategorideyse taşınır
// Kategorideki ürünleri listeler: düzenleme paneli açılır ya da ürün kategoriden çıkarılır
function kategoriUrunleri(id) {
  const k = DB.bul("kategoriler", x => x.id === id);
  if (!k) return;
  let ara = "";
  const ciz = () => {
    const q = trKucuk(ara.trim());
    const l = DB.liste("urunler", u => u.kategori_id === id && (!q || trKucuk(u.ad).includes(q) || String(u.barkod || "").includes(q))).sort((x, y) => String(x.ad).localeCompare(String(y.ad), "tr"));
    const toplam = DB.liste("urunler", u => u.kategori_id === id).length;
    $("ku-baslik").textContent = k.ad + " · " + toplam + " ürün";
    $("ku-liste").innerHTML = l.map(u => `<tr><td>${kac("", u.ad)}<div style="font-size:12px;opacity:.6">${kac("", u.barkod)}</div></td><td class="sag">${para(u.satis_fiyati)}</td><td class="sag">${sayi(u.stok)}</td><td class="sag"><button class="btn kucuk ana" data-ku-duzenle="${u.id}">Düzenle</button> <button class="btn kucuk" data-ku-cikar="${u.id}">Kategoriden çıkar</button></td></tr>`).join("") || '<tr><td colspan="4" style="padding:20px;text-align:center;opacity:.7">Bu kategoride ürün yok. "+ Ürün ekle" ile stoktan ürün ekleyebilirsiniz.</td></tr>';
  };
  modalAc(`
    <div class="modal-baslik" id="ku-baslik"></div>
    <input id="ku-ara" class="arama" placeholder="Bu kategoride ürün ara" autocomplete="off" style="width:100%;margin:10px 0">
    <div style="max-height:52vh;overflow:auto"><table class="tablo"><tr><th>Ürün</th><th class="sag">Satış</th><th class="sag">Stok</th><th></th></tr><tbody id="ku-liste"></tbody></table></div>
    <div class="modal-alt"><button class="btn" id="ku-ekle">+ Stoktan ürün ekle</button><button class="btn" id="ku-kapat">Kapat</button></div>`, true);
  ciz();
  $("ku-ara").addEventListener("input", e => { ara = e.target.value; ciz(); });
  $("ku-kapat").addEventListener("click", modalKapat);
  $("ku-ekle").addEventListener("click", () => kategoriyeUrunEkle(id));
  $("ku-liste").addEventListener("click", e => {
    const du = e.target.closest("[data-ku-duzenle]");
    // Düzenleme küçük pencerede açılır; kaydedince ya da vazgeçince bu kategorinin listesine dönülür
    if (du) { const u = DB.bul("urunler", x => x.id === Number(du.dataset.kuDuzenle)); if (u) urunPenceresi(u, () => { kategoriUrunleri(id); kategoriYenile(); }); return; }
    const ci = e.target.closest("[data-ku-cikar]");
    if (ci) { DB.guncelle("urunler", Number(ci.dataset.kuCikar), { kategori_id: null }); ciz(); kategoriYenile(); bildir("Ürün kategoriden çıkarıldı"); }
  });
}

function kategoriyeUrunEkle(id) {
  const k = DB.bul("kategoriler", x => x.id === id);
  if (!k) return;
  const katAdi = kid => (DB.bul("kategoriler", x => x.id === kid) || {}).ad || "Kategori yok";
  const adaylar = DB.liste("urunler", u => u.aktif && u.kategori_id !== id);
  modalAc(`
    <div class="modal-baslik">${kac("", k.ad)} kategorisine ürün ekle</div>
    <div class="form" style="margin-top:10px">
      <input id="ke-ara" class="arama" placeholder="Ürün adı veya barkod ara" autocomplete="off">
      <div id="ke-liste" class="ke-liste">${
        adaylar.map(u => `<label class="ke-satir" data-ad="${kac("", (u.ad + " " + u.barkod).toLowerCase())}"><input type="checkbox" value="${u.id}"><b class="ke-sira" data-sira-of="${u.id}"></b><span class="ke-ad">${kac("", u.ad)}<small>${kac("", u.barkod)} · şu an: ${kac("", katAdi(u.kategori_id))}</small></span><span class="ke-fiyat">${para(u.satis_fiyati)}</span></label>`).join("")
        || '<div class="bos">Eklenecek başka ürün yok</div>'}</div>
      <div class="modal-alt tam">
        <button type="button" class="btn" id="ke-yeni">Yeni ürün oluştur</button>
        <button type="button" class="btn" id="ke-vazgec">Vazgeç</button>
        <button type="button" class="btn ana" id="ke-ekle">Seçilenleri ekle</button>
      </div>
    </div>`);
  $("ke-ara").focus();
  $("ke-ara").addEventListener("input", () => {
    const q = $("ke-ara").value.trim().toLowerCase();
    $("ke-liste").querySelectorAll(".ke-satir").forEach(s => { s.hidden = q !== "" && !s.dataset.ad.includes(q); });
  });
  $("ke-vazgec").addEventListener("click", modalKapat);
  // Tıklanma sırası tutulur: ürünler kasadaki hızlı satış bölümünde bu sırayla dizilir
  let secilen = [];
  $("ke-liste").addEventListener("change", e => {
    const uid = Number(e.target.value); if (!uid) return;
    secilen = secilen.filter(x => x !== uid); if (e.target.checked) secilen.push(uid);
    $("ke-liste").querySelectorAll("[data-sira-of]").forEach(b => { const i = secilen.indexOf(Number(b.dataset.siraOf)); b.textContent = i < 0 ? "" : i + 1; });
  });
  $("ke-ekle").addEventListener("click", () => {
    if (!secilen.length) return bildir("Önce ürün seçin");
    const son = Math.max(0, ...DB.liste("urunler", u => u.kategori_id === id).map(u => u.kat_sira || 0));
    secilen.forEach((uid, i) => DB.guncelle("urunler", uid, { kategori_id: id, kat_sira: son + i + 1 }));
    modalKapat();
    kategoriYenile();
    bildir(`${secilen.length} ürün "${k.ad}" kategorisine eklendi`);
  });
  // Yeni ürün: ürün ekleme sekmesi bu kategori seçili olarak açılır
  $("ke-yeni").addEventListener("click", () => {
    modalKapat();
    kategoriPaneliKapat();
    ekleKategorisi = id;
    urunAyarlariAc("ekle");
  });
}

function kategoriSil(id) {
  const k = DB.bul("kategoriler", x => x.id === id);
  if (!k) return;
  const urunler = DB.liste("urunler", u => u.kategori_id === id);
  const diger = DB.liste("kategoriler", x => x.id !== id);
  
  modalAc(`
    <div class="modal-baslik">Kategoriyi sil · ${kac("", k.ad)}</div>
    <form id="ks" class="form" style="margin-top:10px">
      ${urunler.length
        ? `<p class="tam">Bu kategoride <strong>${urunler.length} ürün</strong> var. Silmeden önce ürünlerin taşınacağı kategoriyi seçin.</p>
           <label class="tam">Ürünler şuraya taşınsın<select name="hedef"><option value="">Kategorisiz bırak</option>${diger.map(x => `<option value="${x.id}">${kac("", x.ad)}</option>`).join("")}</select></label>`
        : '<p class="tam">Bu kategoride ürün yok. Kategori silinecek.</p>'}
      <div class="modal-alt tam"><button type="button" class="btn" id="ks-vazgec">Vazgeç</button><button class="btn tehlike" type="submit">Kategoriyi sil</button></div>
    </form>`);
  $("ks-vazgec").addEventListener("click", modalKapat);
  $("ks").addEventListener("submit", e => {
    e.preventDefault();
    if (urunler.length) {
      const secim = new FormData(e.target).get("hedef");
      const hedef = secim ? Number(secim) : null;
      urunler.forEach(u => DB.guncelle("urunler", u.id, { kategori_id: hedef }));
    }
    DB.sil("kategoriler", id);
    if (seciliKategori === k.ad) seciliKategori = ""; // ilk kategoriye döner
    modalKapat();
    kategoriYenile();
    bildir(urunler.length ? `Kategori silindi, ${urunler.length} ürün taşındı` : "Kategori silindi");
  });
}

function ayarCiz() {
  const tema = DB.ayarOku("tema", "1");
  $("s-ayar").innerHTML = `
    <div class="baslik-satir"><h2>Ayarlar</h2></div>
    <div class="baslik-satir"><h2>Tema</h2><span style="font-size:12px;opacity:0.75">Seçiminiz kaydedilir ve her açılışta kullanılır</span></div>
    <div class="tema-izgara">
      ${TEMALAR.map(t => `
        <button class="tema-kart ${tema === String(t.id) ? "secili" : ""}" data-tema="${t.id}" aria-pressed="${tema === String(t.id)}">
          <span class="tema-onizleme" style="background:${t.sayfa}">
            <span class="tema-cubuk" style="background:${t.ust}"></span>
            <span class="tema-govde"><span class="tema-kutu" style="background:${t.yuzey}"></span><span class="tema-dugme" style="background:${t.vurgu}"></span></span>
          </span>
          <span class="tema-ad"><b>${t.id}</b> ${t.ad}</span>
        </button>`).join("")}
    </div>
    <table class="tablo" style="margin-bottom:16px">
      <tr><th>Ses</th><td><label style="cursor:pointer"><input type="checkbox" id="ses-ac" ${DB.ayarOku("sesAcik", true) === false ? "" : "checked"}> Barkod okutunca bip sesi çıksın</label></td></tr>
      <tr><th>Terazi etiketi</th><td><select id="terazi-deger"><option value="agirlik">Etikette ağırlık var (gram)</option><option value="tutar">Etikette tutar var (kuruş)</option></select> <small style="opacity:.7">Barkod: 2 + 6 hane ürün (PLU) kodu + 5 hane değer</small></td></tr>
      <tr><th>Kasa no</th><td><input id="kasa-no" value="${kac("", DB.ayarOku("kasaNo", "1"))}" style="width:80px;height:32px"> <button class="btn" id="kasa-kaydet">Kaydet</button></td></tr>
    </table>
    ${markaBolumu()}
    ${aktifKullanici.rol === "yonetici" ? `
      <div class="baslik-satir"><h2>Kategori</h2></div>
      <div class="ayar-kutular">
        <button class="ayar-kutu" id="ayar-kategori"><strong>Kategori ayarları</strong><small>Kasadaki kategori butonlarını ekle, düzenle, sil</small></button>
        <button class="ayar-kutu" id="ayar-toplu-urun"><strong>Excel ile toplu ürün yükle</strong><small>Excel (.xlsx) veya CSV dosyasından çok sayıda ürünü tek seferde ekle, güncelle</small></button>
        <button class="ayar-kutu" id="ayar-toplu-cari"><strong>Excel ile cari yükle</strong><small>Başka programdan alınan müşteri listesini bakiyeleriyle birlikte ekle</small></button>
        <button class="ayar-kutu" id="ayar-fis"><strong>Fiş ayarları</strong><small>Kağıt genişliği, adres, telefon, fiş altı notu, otomatik yazdırma</small></button>
        <button class="ayar-kutu" id="ayar-ekstre"><strong>Ekstre tasarımı</strong><small>Cari hesap ekstresinin ve detaylı ekstrenin görünümünü düzenle</small></button>
      </div>` : ""}
    ${aktifKullanici.rol === "yonetici" ? `
      <div class="baslik-satir"><h2>Telefon uygulaması bağlantısı</h2></div>
      <div id="bulut-bolum" style="margin-bottom:16px"></div>
      <div class="baslik-satir"><h2>Web sitesi bağlantısı</h2></div>
      <div id="web-bolum" style="margin-bottom:16px"></div>
      <div class="baslik-satir"><h2>Yedekleme</h2></div>
      <div id="yedek-bolum" style="margin-bottom:16px"></div>
      <div class="baslik-satir"><h2>Lisans</h2></div>
      <div class="filtre" style="margin-bottom:16px">
        <span id="lisans-ozet">Yükleniyor...</span>
        <button class="btn" id="lisans-degistir">Lisans anahtarını değiştir</button>
      </div>
      ` : ""}
    <div class="baslik-satir"><h2>Güncelleme</h2></div>
    <div class="filtre" style="margin-bottom:16px">
      <span id="ayar-surum">Sürüm</span>
      <button class="btn" id="guncelle-kontrol">Güncellemeleri denetle</button>
    </div>
    ${aktifKullanici.rol === "yonetici" ? `
    <div class="baslik-satir"><h2>Veri</h2></div>
    <div class="filtre">
      <button class="btn" id="yedek-al">Yedek al (JSON)</button>
      <label class="btn" style="cursor:pointer">Yedekten yükle<input id="yedek-yukle" type="file" accept="application/json" hidden></label>
      <button class="btn tehlike" id="sifirla">Deneme verilerini sıfırla</button>
    </div>` : ""}
    ${aktifKullanici.rol === "yonetici" ? `
    <div class="baslik-satir" style="margin-top:20px"><h2>SOFTNEST cari bağlantısı</h2></div>
    <div class="cari-kart" id="cari-baglanti">
      <div class="cari-ust">
        <span class="cari-nokta" id="cari-nokta"></span>
        <div><div class="cari-isletme" id="cari-isletme">Yükleniyor...</div><div class="cari-alt" id="cari-durum"></div></div>
        <button class="btn" id="cari-kod-uret" style="margin-left:auto">Bağlantı kodu üret</button>
      </div>
      <div id="cari-kod-sonuc"></div>
      <div class="cari-not">Bu kod, SOFTNEST cari programının faturaları bu işletmeye göndermesini sağlar. Lisans anahtarını içerir; yalnızca cari programının ayarına yapıştırın.</div>
    </div>` : ""}`;
  $("s-ayar").querySelectorAll("[data-tema]").forEach(b => b.addEventListener("click", () => { temaSec(b.dataset.tema); ayarCiz(); }));
  $("terazi-deger").value = DB.ayarOku("teraziDeger", "agirlik");
  $("terazi-deger").addEventListener("change", e => { DB.ayarYaz("teraziDeger", e.target.value); bildir("Terazi etiketi ayarı kaydedildi"); });
  $("kasa-kaydet").addEventListener("click", () => { DB.ayarYaz("kasaNo", $("kasa-no").value.trim() || "1"); bildir("Kasa no kaydedildi"); });
  if ($("ayar-kategori")) $("ayar-kategori").addEventListener("click", kategoriPaneliAc);
  if ($("ayar-toplu-urun")) $("ayar-toplu-urun").addEventListener("click", topluUrunAc);
  if ($("ayar-toplu-cari")) $("ayar-toplu-cari").addEventListener("click", topluCariAc);
  if ($("ayar-fis")) $("ayar-fis").addEventListener("click", fisAyarlariAc);
  if ($("ses-ac")) $("ses-ac").addEventListener("change", e => { DB.ayarYaz("sesAcik", e.target.checked); if (e.target.checked) bip(true); });
  yedekBolumuYukle(); webBolumuYukle(); bulutBolumuYukle();
  if ($("cari-isletme")) lisansBilgisi().then(l => {
    if (!$("cari-isletme")) return;
    const ad = (l && l.isletme) || DB.ayarOku("isletmeAdi", VARSAYILAN_ISLETME);
    const gelen = DB.veri().alis_faturalari.filter(f => f.kaynak === "cari" && f.durum !== "birlesti").sort((x, y) => y.id - x.id)[0];
    const bagli = !!(l && l.anahtarVar && l.gecerli);
    $("cari-isletme").textContent = ad;
    $("cari-nokta").style.background = bagli ? "#1e8e4e" : "#b8bfcc";
    $("cari-durum").textContent = !bagli ? "Bağlantı için önce geçerli bir lisans gerekir" : gelen ? "Bağlantıda · son cari faturası: " + tarih(gelen.olusturma || gelen.tarih) + " (" + gelen.fatura_no + ")" : "Bağlantıya hazır · cariden henüz fatura gelmedi";
  });
  if ($("cari-kod-uret")) $("cari-kod-uret").addEventListener("click", async () => {
    try {
      const s = await (await fetch("/api/entegrasyon-kodu", { headers: { Authorization: "Bearer " + (sessionStorage.getItem("perakende_token") || "") } })).json();
      if (!s.ok) return bildir(s.hata || "Kod üretilemedi");
      // Cariden fatura alınabilmesi için bulut eşitlemesi gerekir; kod üretilince otomatik açılır
      if (!DB.ayarOku("bulutEsitleme", false)) { DB.ayarYaz("bulutEsitleme", true); bildir("Bulut eşitlemesi açıldı: cariden gelen faturalar alınabilecek"); }
      $("cari-kod-sonuc").innerHTML = `<textarea id="cari-kod" readonly rows="3" style="width:100%;font-family:monospace;font-size:12px">${kac("", s.kod)}</textarea>
        <div style="margin-top:6px"><button class="btn ana" id="cari-kod-kopya">Kodu kopyala</button> <small style="opacity:.7">Yayınlanabilir anahtar: <code>${kac("", s.yayinlanabilirAnahtar)}</code></small></div>`;
      $("cari-kod-kopya").addEventListener("click", async () => { try { await navigator.clipboard.writeText(s.kod); } catch (e) { $("cari-kod").select(); document.execCommand("copy"); } bildir("Kod kopyalandı"); });
    } catch (e) { bildir("Sunucuya ulaşılamadı"); }
  });
  if ($("ayar-ekstre")) $("ayar-ekstre").addEventListener("click", () => ekstreTasarimiAc({}));
  markaOlaylari();
  if ($("lisans-ozet")) {
    lisansBilgisi().then(l => {
      if (!l || !$("lisans-ozet")) return;
      geliştiriciPaneliGoster(l);
      $("lisans-ozet").textContent = l.deneme ? "Deneme sürümü · " + l.kalanGun + " gün kaldı"
        : (l.isletme ? l.isletme + " · " : "") + "Lisans aktif" + (l.bitis ? " · bitiş: " + l.bitis + (l.kalanGun != null ? " (" + l.kalanGun + " gün)" : "") : "");
    });
    $("lisans-degistir").addEventListener("click", async () => {
      const anahtar = prompt("Yeni lisans anahtarını girin:");
      if (!anahtar) return;
      try {
        const s = await (await fetch("/api/lisans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ anahtar: anahtar.trim() }) })).json();
        bildir(s.ok ? "Lisans etkinleştirildi" : "Lisans: " + s.hata);
        if (s.ok) ayarCiz();
      } catch (e) { bildir("Sunucuya ulaşılamadı"); }
    });
  }
  if ($("guncelle-kontrol")) {
    surumuGoster($("ayar-surum"));
    $("guncelle-kontrol").addEventListener("click", () => guncellemeKontrolu(false));
  }
  if ($("yedek-al")) $("yedek-al").addEventListener("click", () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([DB.disaAktar()], { type: "application/json" }));
    a.download = "softnest-yedek.json";
    a.click();
  });
  if ($("yedek-yukle")) $("yedek-yukle").addEventListener("change", async e => {
    const dosya = e.target.files[0];
    if (!dosya || !confirm("Mevcut veri yedekle değiştirilecek. Devam edilsin mi?")) return;
    DB.iceAktar(await dosya.text());
    bildir("Yedek yüklendi, yeniden giriş yapın");
    cikis();
  });
  if ($("sifirla")) $("sifirla").addEventListener("click", async () => {
    if (DB.sunucuVarMi()) {
      if (aktifKullanici.rol !== "yonetici") return bildir("Yalnızca yönetici sıfırlayabilir");
      const onay = prompt("DENEME VERİLERİNİ SIFIRLA. Tüm ürünler, kategoriler, stoklar, satış fişleri, müşteriler ve cari kayıtlar silinir. Kullanıcılar ve ayarlar kalır. Önce otomatik yedek alınır. Onaylamak için SIFIRLA yazın:");
      if (onay !== "SIFIRLA") return onay === null ? null : bildir("Onay metni yanlış, sıfırlanmadı");
      const kullanicilarDa = confirm("Kullanıcılar da silinsin mi? TAMAM: tüm kullanıcılar ve ayarlar silinir, uygulama ilk kurulum ekranına döner (kendi yönetici hesabınızı oluşturursunuz). İPTAL: kullanıcılar ve ayarlar kalır.");
      try {
        const yanit = await (await fetch("/api/deneme-sifirla", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + (DB.token() || "") }, body: JSON.stringify({ onay, kullanicilar: kullanicilarDa }) })).json();
        if (!yanit.ok) return bildir("Sıfırlanamadı: " + yanit.hata);
      } catch (e) { return bildir("Sıfırlanamadı: sunucuya ulaşılamadı"); }
      DB.sifirla();
      try { localStorage.removeItem("kasaSatisSekmeleri"); if (kullanicilarDa) { localStorage.removeItem("girisHatirla"); sessionStorage.clear(); } } catch (e) { /* önemli değil */ }
      return location.reload();
    }
    if (!confirm("Bu tarayıcıdaki tüm veriler silinecek. Bu işlem geri alınamaz.")) return;
    DB.sifirla();
    location.reload();
  });
}

// ---------- BAŞLATMA ----------
async function baslat() {
  // Sunucu oturumu varsa veriyi sunucudan al, yoksa yerel örnek veriyi hazırla
  const sunucudanYuklendi = await DB.yukle();
  let sunucuYanitVeriyor = sunucudanYuklendi;
  if (!sunucudanYuklendi) {
    sunucuYanitVeriyor = await DB.sunucuErisilebilir();
    // Sunucu varsa ama oturum geçersizse yeniden giriş gerekir. Yerel kopya sunucu yerine kullanılmaz.
    if (sunucuYanitVeriyor) sessionStorage.removeItem("oturum");
    else await tohumla();
  }

  // Oturum süresi dolarsa kayıtlar tarayıcıda saklanır, giriş yapılınca sunucuya işlenir
  DB.onOturumDustu = () => {
    bildir("Oturum süresi doldu. Kayıtlar saklandı, tekrar giriş yapın");
    cikis();
  };

  // Birleştirmede yeni açılan müşteri/ürün başka numara aldıysa ekrandaki seçim ve sepetler de yeni numarayı gösterir
  DB.onNumaraDegisti = d => {
    const m = d.musteriler, u = d.urunler;
    if (m && m.has(seciliMusteriId)) seciliMusteriId = m.get(seciliMusteriId);
    satisSekmeleri.forEach(sk => {
      if (m && m.has(sk.musteriId)) sk.musteriId = m.get(sk.musteriId);
      if (u) (sk.sepet || []).forEach(s => { if (u.has(s.id)) s.id = u.get(s.id); });
    });
    if (u) sepet.forEach(s => { if (u.has(s.id)) s.id = u.get(s.id); });
    if (aktifSayfa === "kasa") { kasaMusteriDurumu(); sepetiCiz(); }
  };
  // Başka cihaz veriyi değiştirirse ekranı güncel veriyle yeniden çiz
  DB.onCakisma = () => {
    bildir("Veri başka bir cihazda değişti, güncellendi");
    if (aktifKullanici) {
      aktifKullanici = DB.bul("kullanicilar", x => x.id === aktifKullanici.id) || aktifKullanici;
      sayfaGoster(aktifSayfa);
    }
  };

  // Uygulama açılınca yeni sürüm varsa güncellensin mi diye sorulur (güncelleme sonrası açılış)
  markayiYukle();
  surumuGoster($("surum-yazi"));
  guncellemeKontrolu(true);
  guncellemeDenetimiBaslat();

  // Kayıtlı oturum varsa doğrudan kasa, yoksa giriş ekranı (animasyon girişten sonra oynar)
  const oturum = sessionStorage.getItem("oturum");
  const kayitliKullanici = oturum && DB.bul("kullanicilar", x => x.id === Number(oturum) && x.aktif);
  if (kayitliKullanici) { aktifKullanici = kayitliKullanici; oturumAc(false); }
  else { await girisEkraniHazirla(); $("giris").classList.remove("gizli"); }

  $("musteri-ara").addEventListener("click", musteriAra);
  // Üstteki müşteri kutusu: tıklayınca müşteri seçilir, × ile kaldırılır
  $("musteri-chip").addEventListener("click", e => {
    if (e.target.closest("#musteri-temizle")) {
      seciliMusteriId = null;
      kasaMusteriDurumu();
      return;
    }
    musteriAra();
  });
  // Satış sekmeleri: geçiş, yeni satış (+) ve kapatma
  $("satis-sekmeleri").addEventListener("click", e => {
    const kapat = e.target.closest("[data-kapat]");
    if (kapat) return sekmeKapat(Number(kapat.dataset.kapat));
    if (e.target.closest("#yeni-satis")) return yeniSatis();
    const sek = e.target.closest("[data-sek]");
    if (sek) sekmeyeGec(Number(sek.dataset.sek));
  });
  // Barkod / arama kutusuna tıklanınca ürün paneli yarım açılır
  // Barkod okutunca panel kendiliğinden açılmaz; ürünler paneli yandaki düğmeyle açılır
  $("urunler-ac").addEventListener("click", () => {
    if ($("cekmece").classList.contains("acik")) return urunPaneliKapat();
    cekmeceSekme = ""; urunPaneli("");
  });
  $("fiyat-gor").addEventListener("click", () => fiyatKutusuAc(!fiyatModu));
  $("fiyat-kutu-kapat").addEventListener("click", () => fiyatKutusuAc(false));
  $("cekmece-kapat").addEventListener("click", urunPaneliKapat);
  document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    // Ürünler paneli Esc ile kapanınca imleç barkod kutusuna döner (okutmaya devam edilebilsin)
    const panelAcikti = $("cekmece").classList.contains("acik");
    urunPaneliKapat(); kategoriPaneliKapat();
    if (panelAcikti && aktifSayfa === "kasa") $("arama").focus();
  });
  // Sağdan açılan paneller (ürünler/stok, kategoriler) dışarıda boş bir yere tıklanınca da kapanır.
  // Açık pencere (modal, küçük soru kutusu) üzerindeki tıklamalar paneli kapatmaz.
  document.addEventListener("pointerdown", e => {
    if (e.target.closest("#cekmece, #kat-paneli, .panel, .kp-kaplama, #bildirim")) return;
    const panelAcikti = $("cekmece").classList.contains("acik");
    if (panelAcikti) urunPaneliKapat();
    if ($("kat-paneli").classList.contains("acik")) kategoriPaneliKapat();
  });
  $("kat-kapat").addEventListener("click", kategoriPaneliKapat);
  $("kat-yeni").addEventListener("click", () => kategoriFormu());
  $("kat-az").addEventListener("click", () => { kategoriSirala(siraliKategoriler().sort((x, y) => String(x.ad).localeCompare(String(y.ad), "tr"))); kategoriYenile(); bildir("Kategoriler A–Z sıralandı"); });
  $("kat-liste").addEventListener("click", e => {
    const yk = e.target.closest("[data-kat-yukari]");
    if (yk) return kategoriTasi(Number(yk.dataset.katYukari), -1);
    const as = e.target.closest("[data-kat-asagi]");
    if (as) return kategoriTasi(Number(as.dataset.katAsagi), 1);
    const gor = e.target.closest("[data-kat-gor]");
    if (gor) return kategoriUrunleri(Number(gor.dataset.katGor));
    const u = e.target.closest("[data-kat-urun]");
    if (u) return kategoriyeUrunEkle(Number(u.dataset.katUrun));
    const d = e.target.closest("[data-kat-duzenle]");
    if (d) return kategoriFormu(Number(d.dataset.katDuzenle));
    const s = e.target.closest("[data-kat-sil]");
    if (s) kategoriSil(Number(s.dataset.katSil));
  });
  // Arama yalnızca listeyi süzer. Açık formu (ürün ekle, düzenle, stok, cari) silmez ve seçimi bozmaz.
  $("c-ara").addEventListener("input", cekmeceListele);
  // Enter: tek sonuç varsa (ör. barkod okutunca) o satıra tıklanmış gibi davranır
  $("c-ara").addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    e.preventDefault();
    const sonuclar = document.querySelectorAll("#c-liste [data-cid], #c-liste [data-mid]");
    if (sonuclar.length === 1) sonuclar[0].click();
  });
  $("c-liste").addEventListener("click", e => {
    // Cari güncelle sekmesinde listeden müşteri seçilir
    const m = e.target.closest("[data-mid]");
    if (m) {
      cekmeceMusteri = DB.bul("musteriler", x => x.id === Number(m.dataset.mid)) || null;
      cekmeceListele();
      cekmeceIcerigi();
      return;
    }
    const b = e.target.closest("[data-cid]");
    if (!b) return;
    const urun = DB.bul("urunler", x => x.id === Number(b.dataset.cid));
    // Düzenle, stok veya barkod sekmesi açıksa (ya da kasa dışındaki bir sayfadaysak) ürün seçilir, aksi halde sepete eklenir
    if (["duzenle", "stok", "barkod"].includes(cekmeceSekme) || aktifSayfa !== "kasa") {
      if (!cekmeceSekme) cekmeceSekme = "duzenle";
      cekmeceSecili = urun;
      cekmeceListele();
      cekmeceIcerigi();
      return;
    }
    if (urun && urun.aktif) {
      sepeteEkle(urun.id);
      bildir(urun.ad + " sepete eklendi");
    } else {
      bildir("Bu ürün pasif");
    }
  });
  // Sekmeye tekrar basınca seçim kalkar ve liste sepete ekleme moduna döner
  document.querySelectorAll(".sekme").forEach(b => b.addEventListener("click", () => {
    cekmeceSekme = cekmeceSekme === b.dataset.sekme ? "" : b.dataset.sekme;
    cekmeceListele(); // Cari güncelle sekmesinde liste müşteri olur
    cekmeceIcerigi();
  }));

  $("giris-form").addEventListener("submit", girisYap);
  girisDoldur();
  $("g-kayit-ac").addEventListener("click", () => kayitEkraniGoster(true));
  $("kt-geri").addEventListener("click", () => kayitEkraniGoster(false));
  $("kayit-form").addEventListener("submit", kayitOl);
  $("kurulum-form").addEventListener("submit", kurulumYap);
  $("lisans-form").addEventListener("submit", lisansEtkinlestir);
  $("li-geri").addEventListener("click", () => { lisansliGiris = false; girisFormuGoster("giris-form"); });
  $("g-lisansli-giris").addEventListener("click", () => { lisansliGiris = true; $("li-mesaj").textContent = "Sadece lisans anahtarını girin. Anahtar etkinleşince işletmenizin kullanıcıları ve ürünleri bu bilgisayara alınır; sonra kullanıcı adı ve şifrenizle giriş yaparsınız. Bu bilgisayardaki mevcut kayıtlar silinmez."; $("li-hata").textContent = ""; girisFormuGoster("lisans-form"); $("li-anahtar").focus(); });
  // Lisans giriş yapılmışken biterse oturum kapanır ve kilit ekranı açılır
  let sonKayitUyari = 0;
  DB.onKayitHatasi = m => { if (Date.now() - sonKayitUyari > 20000) { sonKayitUyari = Date.now(); bildir("Değişiklikler sunucuya kaydedilemedi: " + m + " — tekrar denenecek", 7000); } };
  DB.onLisans = async () => { const l = await lisansBilgisi(); cikis(); lisansEkraniGoster(l && l.neden); };
  setInterval(async () => {
    if (!aktifKullanici) return;
    const l = await lisansBilgisi();
    if (l && !l.gecerli) DB.onLisans();
  }, 10 * 60 * 1000);
  $("cikis").addEventListener("click", cikis);
  document.querySelectorAll("#menu button").forEach(b => b.addEventListener("click", () => sayfaGoster(b.dataset.sayfa)));
  document.querySelectorAll("#menu .alt-oge").forEach(o => o.addEventListener("click", () => {
    if (o.dataset.msekme) { musteriSekme = o.dataset.msekme; sayfaGoster("musteri"); }
    else { faturaSekme = o.dataset.fsekme; sayfaGoster("fatura"); }
    const g = o.closest(".menu-grup");
    g.classList.add("kapali"); // tıklayınca alt menü hemen kapanır; imleç çıkıp girince yeniden açılır
    g.addEventListener("mouseleave", () => g.classList.remove("kapali"), { once: true });
  }));

  // Tema
  document.body.className = "tema-" + DB.ayarOku("tema", "1");
  temaListesiCiz();
  $("tema-dugme").addEventListener("click", e => { e.stopPropagation(); temaListesiAc($("tema-liste").hidden); });
  $("tema-liste").addEventListener("click", e => {
    const oge = e.target.closest("[data-tema-sec]");
    if (!oge) return;
    temaSec(oge.dataset.temaSec);
    temaListesiAc(false);
    if (aktifSayfa === "ayar") ayarCiz(); // Ayarlar sayfasındaki seçili kart güncellensin
  });
  document.addEventListener("click", e => { if (!e.target.closest(".tema-menu")) temaListesiAc(false); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") temaListesiAc(false); });

  // Kasa olayları
  $("arama").addEventListener("input", kasaUrunleriCiz);
  // Barkod okuyucu Enter göndermese de okutulan barkod kendiliğinden işlenir:
  // rakamlar çok hızlı (okuyucu hızında) geldiyse ya da yazılan sayı stoktaki bir barkodsa kısa bir bekleyişten sonra işlenir
  let tarama = { ilk: 0, son: 0, zaman: null };
  $("arama").addEventListener("input", () => {
    const m = $("arama").value.trim(), simdi = performance.now();
    if (m.length <= 1 || simdi - tarama.son > 400) tarama.ilk = simdi;
    tarama.son = simdi;
    clearTimeout(tarama.zaman);
    if (!/^\d{6,14}$/.test(m)) return;
    tarama.zaman = setTimeout(() => {
      const guncel = $("arama").value.trim();
      if (guncel !== m) return;
      const hizli = tarama.son - tarama.ilk <= Math.max(300, m.length * 45);
      const kayitli = DB.bul("urunler", x => x.barkod === m && x.aktif);
      if (hizli || kayitli) barkodIsle(m);
    }, 200);
  });
  $("arama").addEventListener("keydown", e => {
    if (e.key !== "Enter") return;
    const m = e.target.value.trim(), a = trKucuk(m);
    if (!m) return;
    // Tam barkod değilse ve ada göre bulunan ürün tek ise sepete eklenir; birden çoksa liste açık kalır (ürün paneli açılmaz)
    if (m && !fiyatModu && !DB.bul("urunler", x => x.barkod === m && x.aktif) && !/^(d{1,3})s*[*xX]s*.+$/.test(m)) {
      const bulunan = DB.liste("urunler", u => u.aktif && trKucuk(u.ad).includes(a));
      if (bulunan.length === 1) { sepeteEkle(bulunan[0].id); $("arama").value = ""; kasaUrunleriCiz(); return; }
      if (bulunan.length > 1) return;
    }
    barkodIsle(m);
  });
  document.addEventListener("keydown", e => { if (e.key === "F4" && $("fiyat-gor")) { e.preventDefault(); fiyatKutusuAc(!fiyatModu); } });
  // Kısayollar: F2 ürünler panelini açar (Esc kapatır), F3 ödemeyi tamamla (tıklamaya gerek yok)
  window.addEventListener("keydown", e => {
    const modalAcik = $("modal").style.display === "flex" || $("odeme-panel").style.display === "flex";
    if (e.key === "F2") {
      e.preventDefault();
      if (aktifSayfa !== "kasa") sayfaGoster("kasa");
      if (!$("cekmece").classList.contains("acik")) { cekmeceSekme = ""; urunPaneli(""); }
      // Panel sağdan kayarak açılırken arama kutusu henüz ekran dışında; düz focus() bütün sayfayı yana kaydırıyordu
      $("c-ara").focus({ preventScroll: true }); $("c-ara").select(); yanKaymayiSifirla();
    } else if (e.key === "F3") {
      e.preventDefault();
      if (aktifSayfa !== "kasa") sayfaGoster("kasa");
      if (!modalAcik) $("odeme-ac").click();
    }
  }, true);
  $("urun-listesi").addEventListener("click", e => {
    const b = e.target.closest("[data-urun]");
    if (b) sepeteEkle(Number(b.dataset.urun));
  });
  $("kategoriler").addEventListener("click", e => {
    const b = e.target.closest("[data-kat]");
    if (!b) return;
    seciliKategori = b.dataset.kat;
    $("arama").value = ""; // arama yazılıyken kategoriler etkisiz kalıyordu
    kasaUrunleriCiz();
  });
  $("satirlar").addEventListener("click", e => {
    const ag = e.target.closest("[data-agirlik]");
    if (ag) { const sat = sepet.find(x => x.id === Number(ag.dataset.agirlik)); const u = sat && DB.bul("urunler", x => x.id === sat.id); if (u) agirlikSor(u, true).then(m => { if (m) { sat.adet = m; sepetiCiz(); } }); return; }
    const fy = e.target.closest("[data-fiyat-yaz]"); if (fy) return satirSayiSor(Number(fy.dataset.fiyatYaz), "fiyat");
    const ay = e.target.closest("[data-adet-yaz]"); if (ay) return satirSayiSor(Number(ay.dataset.adetYaz), "adet");
    const a = e.target.closest("[data-fark]");
    if (a) return adetDegistir(Number(a.dataset.id), Number(a.dataset.fark));
    const s = e.target.closest("[data-sil]");
    if (s) { sepet = sepet.filter(x => x.id !== Number(s.dataset.sil)); sepetiCiz(); }
  });
  $("odeme-ac").addEventListener("click", () => {
    if (sepet.length === 0) return bildir("Sepet boş");
    $("odeme-toplam").textContent = para(genelToplam());
    $("odeme-panel").style.display = "flex";
  });
  $("odeme-kapat").addEventListener("click", panelKapat);
  document.querySelectorAll("[data-yontem]").forEach(b => b.addEventListener("click", () => satisTamamla(b.dataset.yontem)));
  $("odeme-parcali").addEventListener("click", parcaliOdeme);
  $("musteri-kapat").addEventListener("click", () => { panelKapat(); $("odeme-panel").style.display = "flex"; });
  $("musteri-onay").addEventListener("click", () => {
    const id = Number($("musteri-sec").value);
    kaydetSatis("acik_hesap", id);
  });
  $("beklemeye-al").addEventListener("click", beklemeyeAl);
  $("bekleyenler-ac").addEventListener("click", bekleyenlerPenceresi);
  $("fis-iptal").addEventListener("click", async () => {
    if (sepet.length === 0) return bildir("İptal edilecek sepet yok");
    if (!await kucukPencere({ baslik: "Sepet iptal edilsin mi?", mesaj: "İptal fişi olarak kaydedilir.", evet: "İptal et", hayir: "Vazgeç" })) return;
    const kayit = sepetIptalKaydet("Sepet iptali");
    sepet = [];
    indirim = { tur: "yuzde", deger: 0 };
    seciliMusteriId = null;
    kasaCiz();
    bildir(kayit.fis_no + " iptal olarak kaydedildi");
  });
  $("indirim").addEventListener("click", indirimSor);

  // Modal dışına tıklayınca kapat
  $("modal").addEventListener("click", e => { if (e.target === $("modal")) modalKapat(); });
}

document.addEventListener("DOMContentLoaded", baslat);

// ---------- Yazıcılar paneli (sağ alt) ----------
async function yaziciPaneliAc() {
  const kutu = $("yazici-panel");
  if (kutu.classList.toggle("acik") === false) return;
  kutu.innerHTML = '<div class="yz-baslik">Yazıcılar</div><div class="yz-not">Yazıcılar okunuyor...</div>';
  let liste = [], hata = "";
  try { const c = await (await fetch("/api/yazicilar", { headers: tokenli() })).json(); if (c.ok) liste = c.liste; else hata = c.hata || ""; } catch (e) { hata = "Sunucuya ulaşılamadı"; }
  const ayar = yaziciAyari();
  const secenek = d => '<option value="">Windows varsayılanı</option>' + liste.map(p => `<option value="${kac("", p.ad)}" ${d === p.ad ? "selected" : ""}>${kac("", p.ad)}${p.varsayilan ? " (varsayılan)" : ""}</option>`).join("");
  kutu.innerHTML = `<div class="yz-baslik">Yazıcılar<button class="yz-kapat" id="yz-kapat" aria-label="Kapat">×</button></div>
    <div class="yz-sekmeler"><button class="aktif" data-yzs="ayar">Ayarlar</button><button data-yzs="sira">Yazdırma sırası <b id="yz-say"></b></button></div>
    <div id="yz-ayar">
    ${hata ? `<div class="yz-not" style="color:#c0392b">${kac("", hata)}</div>` : '<div class="yz-not">Her iş kendi yazıcısına gider. Bu seçim yalnızca bu bilgisayarda geçerlidir.</div>'}
    ${Object.entries(YAZICI_TURLERI).map(([t, e]) => `<label class="yz-satir"><span>${e}</span><select data-yz="${t}">${secenek(ayar[t])}</select><button class="btn kucuk" data-yz-test="${t}">Test</button></label>`).join("")}</div><div id="yz-sira" hidden></div>`;
  kutu.querySelectorAll("[data-yzs]").forEach(b => b.addEventListener("click", () => yaziciSekme(b.dataset.yzs)));
  $("yz-kapat").addEventListener("click", () => kutu.classList.remove("acik"));
  kutu.querySelectorAll("[data-yz]").forEach(s => s.addEventListener("change", () => { const a = yaziciAyari(); if (s.value) a[s.dataset.yz] = s.value; else delete a[s.dataset.yz]; yaziciAyariYaz(a); bildir("Kaydedildi"); }));
  kutu.querySelectorAll("[data-yz-test]").forEach(b => b.addEventListener("click", () => {
    const t = b.dataset.yzTest;
    sayfaIcindeYazdir(`<!doctype html><html><head><meta charset="utf-8"><title>Test</title><style>body{font-family:Arial,sans-serif;font-size:14px;width:240px;margin:8px;text-align:center}</style></head><body><b>SOFTNEST-satış</b><br>${YAZICI_TURLERI[t]}<br>Test çıktısı<br>${new Date().toLocaleString("tr-TR")}</body></html>`, t);
  }));
}
document.addEventListener("DOMContentLoaded", () => { if ($("yazici-ac")) $("yazici-ac").addEventListener("click", yaziciPaneliAc); });

// Yazdırma sırası: Windows yazıcı kuyruğundaki bekleyen / yazdırılan işler
let yaziciSiraZaman = null;
function yaziciSekme(ad) {
  $("yz-ayar").hidden = ad !== "sira" ? false : true;
  $("yz-sira").hidden = ad === "sira" ? false : true;
  document.querySelectorAll("[data-yzs]").forEach(b => b.classList.toggle("aktif", b.dataset.yzs === ad));
  clearInterval(yaziciSiraZaman);
  if (ad === "sira") { yaziciSiraYukle(); yaziciSiraZaman = setInterval(() => { if (!$("yazici-panel").classList.contains("acik")) return clearInterval(yaziciSiraZaman); yaziciSiraYukle(); }, 2500); }
}
const YZ_DURUM = [["printing", "Yazdırılıyor"], ["spooling", "Hazırlanıyor"], ["paused", "Duraklatıldı"], ["error", "Hata"], ["offline", "Yazıcı çevrimdışı"], ["paperout", "Kağıt bitti"], ["blocked", "Engellendi"], ["deleting", "Siliniyor"], ["retained", "Bekletiliyor"], ["userintervention", "Müdahale gerekiyor"]];
function yaziciDurumYazi(d) {
  const k = String(d || "").toLowerCase();
  const h = YZ_DURUM.filter(([a]) => k.includes(a)).map(x => x[1]);
  return h.length ? h.join(", ") : "Bekliyor";
}
async function yaziciSiraYukle() {
  const kutu = $("yz-sira"); if (!kutu) return;
  let c;
  try { c = await (await fetch("/api/yazdirma-isleri", { headers: tokenli() })).json(); } catch (e) { c = { ok: false, hata: "Sunucuya ulaşılamadı" }; }
  if (!$("yz-sira")) return;
  if (!c.ok) { kutu.innerHTML = '<div class="yz-not" style="color:#c0392b">' + kac("", c.hata || "") + "</div>"; return; }
  if ($("yz-say")) $("yz-say").textContent = c.liste.length ? "(" + c.liste.length + ")" : "";
  kutu.innerHTML = c.liste.length ? c.liste.map(j => `<div class="yz-is"><div><b>${kac("", j.belge || "Belge")}</b><small>${kac("", j.yazici)}</small></div><span class="yz-durum ${/error|offline|paperout|blocked|userintervention/i.test(j.durum) ? "hata" : /printing/i.test(j.durum) ? "yaz" : ""}">${yaziciDurumYazi(j.durum)}</span><button class="btn kucuk" data-yz-iptal="${j.id}" data-yz-y="${kac("", j.yazici)}">İptal</button></div>`).join("") : '<div class="yz-not">Bekleyen ya da yazdırılan iş yok.</div>';
  kutu.querySelectorAll("[data-yz-iptal]").forEach(b => b.addEventListener("click", async () => {
    await fetch("/api/yazdirma-iptal", { method: "POST", headers: tokenli(), body: JSON.stringify({ id: Number(b.dataset.yzIptal), yazici: b.dataset.yzY }) });
    yaziciSiraYukle();
  }));
}
// Yazdırma gönderilince düğme üzerindeki sayaç kısa süre izlenir
function yaziciRozetIzle() {
  clearInterval(yaziciRozetIzle.t); let n = 0;
  yaziciRozetIzle.t = setInterval(async () => {
    if (++n > 20) return clearInterval(yaziciRozetIzle.t);
    try { const c = await (await fetch("/api/yazdirma-isleri", { headers: tokenli() })).json(); const adet = c.ok ? c.liste.length : 0; const r = $("yazici-rozet"); if (r) { r.textContent = adet || ""; r.hidden = !adet; } if (!adet && n > 3) clearInterval(yaziciRozetIzle.t); } catch (e) {}
  }, 3000);
}
