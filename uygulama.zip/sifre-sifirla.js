// Kullanıcı şifresini komut satırından sıfırlar (şifreyi unuttuysanız).
// Kullanım:  node sifre-sifirla.js <kullanici_adi> <yeni_sifre>
// Örnek:     node sifre-sifirla.js admin 1234
// Sunucu çalışırken de kullanılabilir. Kullanıcı daha sonra Kullanıcılar sayfasından şifreyi değiştirebilir.
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const { sha256 } = require("./seed");

const [kadi, yeniSifre] = process.argv.slice(2);
if (!kadi || !yeniSifre) {
  console.log("Kullanım: node sifre-sifirla.js <kullanici_adi> <yeni_sifre>");
  process.exit(1);
}

const db = new DatabaseSync(path.join(__dirname, "data", "perakende.db"));
const kayit = db.prepare("SELECT veri FROM kayit WHERE anahtar = 'durum'").get();
if (!kayit) { console.log("Veritabanında kayıt yok. Önce sunucuyu bir kez çalıştırın."); process.exit(1); }

const durum = JSON.parse(kayit.veri);
const kullanici = (durum.kullanicilar || []).find(k => k.kullanici_adi === kadi);
if (!kullanici) {
  console.log(`"${kadi}" adında kullanıcı yok. Mevcut kullanıcılar: ` + durum.kullanicilar.map(k => k.kullanici_adi).join(", "));
  process.exit(1);
}

const ozet = sha256(yeniSifre);
kullanici.sifre_hash = ozet;
kullanici.aktif = 1;
db.prepare("UPDATE kayit SET veri = ? WHERE anahtar = 'durum'").run(JSON.stringify(durum));
db.prepare("UPDATE kullanicilar SET sifre_hash = ?, aktif = 1 WHERE kullanici_adi = ?").run(ozet, kadi);
const surum = db.prepare("SELECT veri FROM kayit WHERE anahtar = 'surum'").get();
if (surum) db.prepare("UPDATE kayit SET veri = ? WHERE anahtar = 'surum'").run(JSON.stringify({ no: JSON.parse(surum.veri).no + 1 }));
console.log(`"${kadi}" kullanıcısının şifresi güncellendi ve hesap aktif edildi.`);
