@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ikon-olustur.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kisayol-olustur.ps1"
pause
